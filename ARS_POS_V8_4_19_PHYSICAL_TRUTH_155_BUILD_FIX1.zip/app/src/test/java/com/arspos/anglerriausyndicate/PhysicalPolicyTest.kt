package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test
import javax.imageio.ImageIO

class PhysicalPolicyTest {
    private fun box(l:Int,t:Int,r:Int,b:Int) = NormalPixelOwnership.Box(l,t,r,b)
    private fun scene(boxes: List<NormalPixelOwnership.Box>, pixel: (Int,Int)->Int) =
        NormalPixelOwnership.resolve(240,240,boxes,pixel)

    @Test fun packAndShadowDuplicateSharesOnePhysicalOwner() {
        val image = ImageIO.read(javaClass.getResourceAsStream("/physical_truth/smart-scan-1789448694800-f532d4.jpg"))
        val result = NormalPixelOwnership.resolve(image.width,image.height,
            listOf(box(319,147,566,527),box(318,371,483,655)),image::getRGB)
        assertEquals(1,result.groups.size)
        assertTrue(result.ambiguous.isEmpty())
    }
    @Test fun twoSeparatedIdenticalProductsRemainTwo() {
        val result=scene(listOf(box(25,40,100,200),box(140,40,215,200))) { x,y ->
            if(y in 50..190 && (x in 35..90 || x in 150..205)) 0xff111111.toInt() else 0xffffffff.toInt()
        }
        assertEquals(2,result.groups.size);assertTrue(result.ambiguous.isEmpty())
    }
    @Test fun overlappingUnknownForegroundCannotCreateTwoAutomaticQuantities() {
        val result=scene(listOf(box(25,40,150,200),box(60,70,190,230))) { _,_ -> 0xffffffff.toInt() }
        assertEquals(setOf(0,1),result.ambiguous)
    }
    @Test fun broadContainerCannotBridgeTwoProducts() {
        val result=scene(listOf(box(25,40,100,200),box(140,40,215,200),box(25,40,215,200))) { x,y ->
            if(y in 50..190 && (x in 35..90 || x in 150..205)) 0xff111111.toInt() else 0xffffffff.toInt()
        }
        assertTrue(result.groups.size>=2);assertTrue(2 in result.ambiguous)
    }
    @Test fun partialRodIgnoresTipScoreWhenChoosingHandle() {
        assertTrue(RodAnchorRolePolicy.handleOnLeft(90,70,100,0,false,false))
        assertFalse(RodAnchorRolePolicy.handleOnLeft(70,90,0,100,false,true))
    }
    @Test fun roleAssignmentRemainsConsistentWithinEachProduct() {
        assertTrue(RodAnchorRolePolicy.handleOnLeft(90,30,10,85,true,false))
        assertFalse(RodAnchorRolePolicy.handleOnLeft(35,95,80,10,true,true))
    }
    @Test fun uniformBeamDoesNotBecomeRodEvenWithPerfectContinuity() {
        val result=RodMaterialProfile.measure(400,400,200f,40f,200f,360f) { x,_ ->
            if(x in 185..215) 0xff111111.toInt() else 0xffffffff.toInt()
        }
        assertFalse(result.supported)
    }
    @Test fun acceptedSkuStillRequiresPhysicalOwnerForQuantity() {
        assertFalse(ScanQuantityPolicy.eligible(true,true,true,false,"","NORMAL-1",ScanProposal.TYPE_NORMAL))
        assertFalse(ScanQuantityPolicy.eligible(true,true,true,false,"TRACK-1","TRACK-2",ScanProposal.TYPE_LONG))
        assertTrue(ScanQuantityPolicy.eligible(true,true,true,false,"NORMAL-1","NORMAL-1",ScanProposal.TYPE_NORMAL))
    }
    @Test fun rescueAndUncertainAndRejectedIdentityNeverCommitQuantity() {
        assertFalse(ScanQuantityPolicy.eligible(true,true,true,false,"TRACK-1","TRACK-1",ScanProposal.TYPE_RESCUE))
        assertFalse(ScanQuantityPolicy.eligible(true,true,false,false,"TRACK-1","TRACK-1",ScanProposal.TYPE_LONG))
        assertFalse(ScanQuantityPolicy.eligible(false,true,true,false,"TRACK-1","TRACK-1",ScanProposal.TYPE_LONG))
    }
}
