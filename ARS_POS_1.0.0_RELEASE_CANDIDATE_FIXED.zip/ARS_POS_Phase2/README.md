# ARS POS — Phase 3 Core POS Engine
ANGLER RIAU SYNDICATE

Implemented:
- Room/SQLite offline database
- Master produk dengan SKU dan barcode
- Harga modal, jual, grosir
- Stok dan minimum stok
- Pencarian produk
- Keranjang dan quantity
- Checkout cash
- Validasi stok
- Pengurangan stok otomatis
- Invoice otomatis
- Sale items
- Stock movement
- Omzet dan jumlah transaksi hari ini

Belum diaktifkan:
Bluetooth ESC/POS, scanner kamera, QRIS, retur, hutang/piutang,
cash ledger, multi-user, audit log, backup/restore, export laporan.

Buka project di Android Studio, Gradle Sync, lalu Run.
