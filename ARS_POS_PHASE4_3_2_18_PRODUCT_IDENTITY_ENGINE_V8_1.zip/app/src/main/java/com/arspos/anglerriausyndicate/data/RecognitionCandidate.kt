package com.arspos.anglerriausyndicate.data

import com.arspos.anglerriausyndicate.data.db.ProductEntity

/** Candidate evidence for ARS Product Identity Engine V8. */
data class RecognitionCandidate(
    val product: ProductEntity,
    val visualScore: Int,
    val textScore: Int,
    val profileScore: Int = 0,
    val finalScore: Int,
    val evidence: String,
    val hasMaster: Boolean,
    val masterVerified: Boolean = false,
    val isLongObject: Boolean = false
)
