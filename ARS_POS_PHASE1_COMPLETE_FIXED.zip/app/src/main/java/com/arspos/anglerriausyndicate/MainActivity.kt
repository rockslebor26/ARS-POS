package com.arspos.anglerriausyndicate

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.arspos.anglerriausyndicate.data.LoginResult
import com.arspos.anglerriausyndicate.data.PinHasher
import com.arspos.anglerriausyndicate.data.CartLine
import com.arspos.anglerriausyndicate.data.CheckoutResult
import com.arspos.anglerriausyndicate.data.db.ProductEntity
import com.arspos.anglerriausyndicate.printer.BluetoothPrinter
import com.arspos.anglerriausyndicate.printer.EscPosReceipt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Black=Color(0xFF080808)
private val Panel=Color(0xFF151515)
private val Gold=Color(0xFFC99A3A)
private val GoldSoft=Color(0xFFE1BC68)
private val Muted=Color(0xFF9A9A9A)

class MainActivity:ComponentActivity(){
    private val vm by viewModels<PosViewModel>()
    private val printer=BluetoothPrinter()
    private val prefs by lazy{getSharedPreferences("ars_pos",MODE_PRIVATE)}
    override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App(vm,this)}}
    fun requestBluetooth(){if(Build.VERSION.SDK_INT>=31)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN),9)}
    fun savePrinter(d:BluetoothDevice){prefs.edit().putString("printer_address",d.address).putString("printer_name",d.name?:"Printer").apply()}
    @SuppressLint("MissingPermission") fun selectedPrinter():BluetoothDevice?{
        val address=prefs.getString("printer_address",null)?:return null
        return printer.pairedDevices().firstOrNull{it.address==address}
    }
    suspend fun print(result:CheckoutResult):String=withContext(Dispatchers.IO){
        val d=selectedPrinter()?:return@withContext "Transaksi tersimpan. Printer belum dipilih."
        printer.print(d,EscPosReceipt.build(result.cart,result.total,result.paid,result.change,result.invoice,result.paymentMethod))
        "Transaksi ${result.invoice} berhasil dicetak."
    }
    suspend fun reprint(invoice:String,items:List<CartLine>,total:Long,paid:Long,change:Long,method:String):String=withContext(Dispatchers.IO){
        val d=selectedPrinter()?:return@withContext "Printer belum dipilih."
        printer.print(d,EscPosReceipt.build(items,total,paid,change,invoice,method));"Cetak ulang $invoice OK"
    }
}

@Composable fun ArsBackground(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(com.arspos.anglerriausyndicate.R.drawable.ars_background),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.58f)))
        content()
    }
}

@Composable
fun App(vm: PosViewModel, a: MainActivity) {
    var session by remember { mutableStateOf<LoginResult?>(null) }
    var page by remember { mutableStateOf("home") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Black,
            surface = Panel,
            primary = Gold,
            onPrimary = Color.Black
        )
    ) {
        val currentSession = session

        if (currentSession == null) {
            Login(vm) { result ->
                session = result
                page = "home"
            }
        } else {
            val navItems = listOf(
                Triple("home", Icons.Default.Home, "Home"),
                Triple("kasir", Icons.Default.ShoppingCart, "Kasir"),
                Triple("produk", Icons.Default.Inventory2, "Produk"),
                Triple("laporan", Icons.Default.Assessment, "Laporan"),
                Triple("printer", Icons.Default.Print, "Printer")
            )

            ArsBackground {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color.Transparent,
                    bottomBar = {
                        NavigationBar(
                            containerColor = Panel.copy(alpha = 0.94f)
                        ) {
                            navItems.forEach { item ->
                                NavigationBarItem(
                                    selected = page == item.first,
                                    onClick = { page = item.first },
                                    icon = { Icon(item.second, contentDescription = item.third) },
                                    label = { Text(item.third, fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (page) {
                            "home" -> Home(vm, currentSession)
                            "kasir" -> Cashier(vm, a)
                            "produk" -> Products(vm)
                            "laporan" -> Reports(vm, a)
                            "printer" -> Printer(a)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Login(vm: PosViewModel, go: (LoginResult) -> Unit) {
    var u by remember { mutableStateOf("admin") }
    var pin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    ArsBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(com.arspos.anglerriausyndicate.R.drawable.ars_logo_master),
                contentDescription = "ARS",
                modifier = Modifier.size(180.dp),
                contentScale = ContentScale.Fit
            )
            Text("ARS POS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 24.sp)
            Text("ANGLER RIAU SYNDICATE", color = GoldSoft, fontWeight = FontWeight.Bold)
            Text("FISHING STORE • OFFLINE POS", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(24.dp))

            OutlinedTextField(
                value = u,
                onValueChange = { u = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Username") },
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = pin,
                onValueChange = { pin = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("PIN") },
                singleLine = true
            )
            Spacer(Modifier.height(12.dp))

            Button(
                onClick = {
                    scope.launch {
                        vm.login(u, pin).fold(
                            onSuccess = { go(it) },
                            onFailure = { msg = it.message ?: "Login gagal" }
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(Gold)
            ) {
                Text("LOGIN")
            }
            Text(msg, color = GoldSoft, modifier = Modifier.padding(8.dp))
        }
    }
}

@Composable
fun Header(s: String, subtitle: String = "ANGLER RIAU SYNDICATE") {
    Column(Modifier.padding(18.dp)) {
        Text(s, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = GoldSoft, fontSize = 10.sp)
    }
}

@Composable
fun Home(vm: PosViewModel, s: LoginResult) {
    val r by vm.revenue.collectAsState()
    val n by vm.transactions.collectAsState()
    val c by vm.cashBalance.collectAsState()

    Column {
        Header("DASHBOARD", "${s.displayName} • ${s.role}")
        Card(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(Panel)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("OMZET HARI INI", color = Muted)
                Text("Rp $r", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = GoldSoft)
                Text("Transaksi $n • Kas Rp $c", color = Muted)
            }
        }
    }
}

@Composable
fun Cashier(vm: PosViewModel, a: MainActivity) {
    val ps by vm.products.collectAsState()
    val cart by vm.cart.collectAsState()
    val total by vm.subtotal.collectAsState()
    val query by vm.query.collectAsState()
    var paid by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("CASH") }
    var dialog by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Header("KASIR")
        OutlinedTextField(
            value = query,
            onValueChange = vm::search,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            placeholder = { Text("Cari nama / SKU / barcode") },
            singleLine = true
        )

        LazyColumn(
            Modifier
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(ps, key = { it.id }) { p ->
                Card(
                    Modifier
                        .fillMaxWidth()
                        .clickable { vm.add(p) },
                    colors = CardDefaults.cardColors(Panel)
                ) {
                    Row(Modifier.padding(12.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name)
                            Text("${p.sku} • stok ${p.stock}", color = Muted, fontSize = 11.sp)
                        }
                        Text("Rp ${p.sellPrice}", color = GoldSoft)
                    }
                }
            }
            item {
                cart.forEach { line ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(line.product.name, Modifier.weight(1f))
                        Text("${line.quantity} x Rp ${line.subtotal}")
                    }
                }
            }
        }

        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(Panel)
        ) {
            Column(Modifier.padding(14.dp)) {
                Text("TOTAL Rp $total", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = GoldSoft)
                Button(
                    onClick = {
                        paid = total.toString()
                        dialog = true
                    },
                    enabled = cart.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(Gold)
                ) {
                    Text("BAYAR & CETAK")
                }
                Text(msg, color = GoldSoft)
            }
        }
    }

    if (dialog) {
        AlertDialog(
            onDismissRequest = { dialog = false },
            title = { Text("PEMBAYARAN") },
            text = {
                Column {
                    Text("Total Rp $total")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("CASH", "QRIS", "TRANSFER", "DEBIT").forEach { x ->
                            FilterChip(
                                selected = method == x,
                                onClick = { method = x },
                                label = { Text(x, fontSize = 8.sp) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = paid,
                        onValueChange = { paid = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Nominal dibayar") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            vm.checkout(paid.toLongOrNull() ?: 0, method).fold(
                                onSuccess = { result ->
                                    msg = a.print(result)
                                    dialog = false
                                },
                                onFailure = { e -> msg = e.message ?: "Gagal" }
                            )
                        }
                    }
                ) { Text("BAYAR") }
            },
            dismissButton = {
                TextButton(onClick = { dialog = false }) { Text("BATAL") }
            }
        )
    }
}

@Composable
fun Products(vm: PosViewModel) {
    val ps by vm.products.collectAsState()
    var add by remember { mutableStateOf(false) }
    var stockProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var msg by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("PRODUK", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Master produk & stok", color = GoldSoft, fontSize = 10.sp)
            }
            Button({ add = true }, colors = ButtonDefaults.buttonColors(Gold)) { Text("+ PRODUK") }
        }
        Text(msg, color = GoldSoft, modifier = Modifier.padding(horizontal = 18.dp))
        LazyColumn(Modifier.padding(16.dp)) {
            items(ps, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(Panel)) {
                    Row(Modifier.padding(12.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name)
                            Text("${p.sku} • ${p.category} • stok ${p.stock}", color = Muted, fontSize = 11.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Rp ${p.sellPrice}", color = GoldSoft)
                            TextButton({ stockProduct = p }) { Text("STOK +") }
                        }
                    }
                }
            }
        }
    }
    stockProduct?.let { p ->
        var qty by remember(p.id) { mutableStateOf("") }
        var cost by remember(p.id) { mutableStateOf(p.costPrice.toString()) }
        var supplier by remember(p.id) { mutableStateOf("") }
        var invoice by remember(p.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { stockProduct = null },
            title = { Text("STOK MASUK • ${p.name}") },
            text = { Column {
                OutlinedTextField(qty, { qty = it }, Modifier.fillMaxWidth(), label = { Text("Jumlah") })
                OutlinedTextField(cost, { cost = it }, Modifier.fillMaxWidth(), label = { Text("Harga modal/unit") })
                OutlinedTextField(supplier, { supplier = it }, Modifier.fillMaxWidth(), label = { Text("Supplier") })
                OutlinedTextField(invoice, { invoice = it }, Modifier.fillMaxWidth(), label = { Text("No. invoice") })
            } },
            confirmButton = { TextButton({
                scope.launch {
                    vm.stockIn(p.id, qty.toIntOrNull() ?: 0, cost.toLongOrNull() ?: 0, supplier.ifBlank { null }, invoice.ifBlank { null })
                        .fold({ msg = "Stok +${qty.ifBlank { "0" }} berhasil" }, { msg = it.message ?: "Gagal" })
                    stockProduct = null
                }
            }) { Text("SIMPAN") } },
            dismissButton = { TextButton({ stockProduct = null }) { Text("BATAL") } }
        )
    }

    if (add) {
        var name by remember { mutableStateOf("") }
        var sku by remember { mutableStateOf("") }
        var barcode by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("LAINNYA") }
        var cost by remember { mutableStateOf("") }
        var price by remember { mutableStateOf("") }
        var stock by remember { mutableStateOf("0") }
        AlertDialog(
            onDismissRequest = { add = false },
            title = { Text("TAMBAH PRODUK") },
            text = {
                LazyColumn {
                    item { OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Nama") }) }
                    item { OutlinedTextField(sku, { sku = it }, Modifier.fillMaxWidth(), label = { Text("SKU") }) }
                    item { OutlinedTextField(barcode, { barcode = it }, Modifier.fillMaxWidth(), label = { Text("Barcode") }) }
                    item { OutlinedTextField(category, { category = it }, Modifier.fillMaxWidth(), label = { Text("Kategori") }) }
                    item { OutlinedTextField(cost, { cost = it }, Modifier.fillMaxWidth(), label = { Text("Modal") }) }
                    item { OutlinedTextField(price, { price = it }, Modifier.fillMaxWidth(), label = { Text("Harga jual") }) }
                    item { OutlinedTextField(stock, { stock = it }, Modifier.fillMaxWidth(), label = { Text("Stok awal") }) }
                }
            },
            confirmButton = {
                TextButton({
                    scope.launch {
                        vm.addProduct(name, sku, barcode.ifBlank { null }, category,
                            cost.toLongOrNull() ?: 0, price.toLongOrNull() ?: 0, stock.toIntOrNull() ?: 0)
                            .fold({ msg = "Produk ditambahkan" }, { msg = it.message ?: "Gagal" })
                        add = false
                    }
                }) { Text("SIMPAN") }
            },
            dismissButton = { TextButton({ add = false }) { Text("BATAL") } }
        )
    }
}

@Composable
fun Reports(vm: PosViewModel, a: MainActivity) {
    val r by vm.revenue.collectAsState()
    val n by vm.transactions.collectAsState()
    val c by vm.cashBalance.collectAsState()
    val sales by vm.sales.collectAsState()
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var profit by remember { mutableStateOf<com.arspos.anglerriausyndicate.data.ProfitSummary?>(null) }
    var returnSale by remember { mutableStateOf<Long?>(null) }
    var reason by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { profit = vm.profitSummary() }
    Column {
        Header("LAPORAN")
        Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Panel)) {
            Column(Modifier.padding(18.dp)) {
                Text("Omzet bersih Rp $r")
                Text("Transaksi $n")
                Text("Saldo kas Rp $c")
                profit?.let { Text("Laba kotor Rp ${it.grossProfit}", color = GoldSoft); Text("Modal Rp ${it.cost}", color = Muted) }
                Text(msg, color = GoldSoft)
            }
        }
        Text("TRANSAKSI TERBARU", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp))
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            items(sales.take(30), key = { it.id }) { sale ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(Panel)) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(sale.invoiceNumber)
                            Text("Rp ${sale.grandTotal} • ${sale.paymentMethod}", color = Muted, fontSize = 11.sp)
                        }
                        TextButton({
                            scope.launch {
                                val saleItems = vm.saleItems(sale.id)
                                val items = saleItems.map { item ->
                                    CartLine(ProductEntity(id = item.productId, name = item.productName, sku = "", costPrice = item.costPrice, sellPrice = item.sellPrice), item.quantity)
                                }
                                msg = a.reprint(sale.invoiceNumber, items, sale.grandTotal, sale.paidAmount, sale.changeAmount, sale.paymentMethod)
                            }
                        }) { Text("CETAK") }
                        TextButton({ returnSale = sale.id; reason = "" }) { Text("RETUR") }
                    }
                }
            }
        }
    }
    returnSale?.let { id ->
        AlertDialog(
            onDismissRequest = { returnSale = null },
            title = { Text("RETUR TRANSAKSI") },
            text = { OutlinedTextField(reason, { reason = it }, Modifier.fillMaxWidth(), label = { Text("Alasan retur") }) },
            confirmButton = {
                TextButton({
                    scope.launch {
                        vm.processReturn(id, reason.ifBlank { "Retur barang" }).fold(
                            { v -> msg = "Retur Rp $v berhasil" },
                            { e -> msg = e.message ?: "Retur gagal" }
                        )
                        returnSale = null
                        profit = vm.profitSummary()
                    }
                }) { Text("PROSES") }
            },
            dismissButton = { TextButton({ returnSale = null }) { Text("BATAL") } }
        )
    }
}

@SuppressLint("MissingPermission")
@Composable
fun Printer(a: MainActivity) {
    var ds by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
    var sel by remember { mutableStateOf<BluetoothDevice?>(null) }
    var msg by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Header("PRINTER BLUETOOTH")
        Button({
            if (Build.VERSION.SDK_INT >= 31 && ContextCompat.checkSelfPermission(a, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                a.requestBluetooth()
            } else {
                ds = BluetoothPrinter().pairedDevices()
                msg = "${ds.size} perangkat terpasang"
            }
        }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Gold)) { Text("CARI PRINTER PAIRED") }
        Text(msg, color = GoldSoft)
        LazyColumn(Modifier.weight(1f)) {
            items(ds, key = { it.address }) { d ->
                Card(Modifier.fillMaxWidth().padding(4.dp).clickable { sel = d; a.savePrinter(d) }, colors = CardDefaults.cardColors(Panel)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(d.name ?: "Printer")
                        Text(d.address, color = Muted, fontSize = 11.sp)
                        if (sel?.address == d.address) Text("✓ DIPILIH", color = GoldSoft, fontSize = 11.sp)
                    }
                }
            }
        }
        Button(onClick={
            sel?.let { d ->
                scope.launch {
                    msg = try {
                        withContext(Dispatchers.IO) { BluetoothPrinter().print(d, EscPosReceipt.build(emptyList(), 0, 0, 0, "ARS-TEST")) }
                        "TEST PRINT OK"
                    } catch (e: Exception) { "Gagal: ${e.message}" }
                }
            } ?: run { msg = "Pilih printer" }
        }, enabled = sel != null, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Gold)) { Text("TEST PRINT") }
    }
}
