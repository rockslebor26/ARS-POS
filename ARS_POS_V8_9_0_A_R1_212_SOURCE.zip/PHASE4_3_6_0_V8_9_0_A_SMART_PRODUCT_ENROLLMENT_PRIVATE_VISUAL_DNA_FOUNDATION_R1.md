# Phase 4.3.6.0 / V8.9.0-A
## SMART_PRODUCT_ENROLLMENT_PRIVATE_VISUAL_DNA_FOUNDATION_R1

V8.9.0-A is the database and contract foundation for the new Smart Capture / Private Visual DNA architecture.

### Activated in this build
- Room DB v6 with additive `MIGRATION_5_6`; no destructive migration.
- Smart Product Enrollment persistent session state.
- Visual reference view records with quality/coverage/segmentation metadata.
- Product Visual DNA schema: global embedding payload, shape/geometry/texture signatures, model/catalog versions and open-set calibration statistics.
- Dense local feature schema and discriminative-region schema.
- Catalog collision graph with LOW/MEDIUM/HIGH/CRITICAL severity.
- Enrollment hard quality gate and multi-view coverage gate.
- Deterministic enrollment state machine with bounded MORE_EVIDENCE flow.
- Atomic catalog snapshot commit with only one ACTIVE snapshot.
- High/critical unresolved collision veto before catalog activation.
- Legacy `product_photos` paths copied into the v6 audit layer as provisional references; they are not falsely marked as V8.9-quality-approved.

### Deliberately NOT activated yet
- New Visual DNA feature extraction model.
- Instance-segmentation model routing for the new pipeline.
- Smart Scan routing through the new Visual DNA catalog.

Those are staged for later V8.9.0 builds after model/index regression is available. The production Smart Scan continues using the V8.8.9 path in this foundation build.

### Safety retained
- All 14 recognition thresholds remain unchanged.
- Physical-object truth remains the sole source of quantity.
- Identity/quantity decoupling, Safety Kernel, Ground Truth, Replay, Rod Authenticity, Package Edge Firewall, anti-bridge/cross-lane protection and canonical continuity remain intact.
- Package: `com.arspos.anglerriausyndicate`.
- Official signer must remain unchanged.
- Update must be in-place from code 211 to code 212.
