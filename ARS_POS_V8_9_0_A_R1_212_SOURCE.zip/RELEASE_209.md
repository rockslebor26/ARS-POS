# ARS POS 1.10.9 (209) — V8.8.7 Release Candidate

- Phase: `4.3.5.7`
- Engine: `V8.8.7`
- Revision: `CANONICAL_IDENTITY_CONTINUITY_TEMPORAL_EVIDENCE_CONVERGENCE_R1`
- Previous official candidate: `1.10.8 (208)`
- Current candidate: `1.10.9 (209)`
- Package: `com.arspos.anglerriausyndicate`
- Room DB: `5`
- Required update path: in-place only

## Main changes

- Project Target / Phase Gate is visible in ARS Dev Center.
- canonical identity (`CID-*`) survives bounded transient `LIVE-*` rebind;
- Top-K identity evidence accumulates across independent frames with duplicate-frame weighting;
- live identity cooldown follows canonical identity rather than transient track IDs;
- canonical fused candidates seed final candidate recall but cannot accept identity by themselves;
- high-resolution ambiguity recovery now supports physically trusted LONG objects;
- LONG matching adds bounded role-discriminative FULL/HANDLE/SIDE/TIP evidence;
- NORMAL completeness uses expanded object-local ownership before quantity eligibility;
- Ground Truth V2 records operator confirmation and learned-reference integrity fields structurally;
- canonical rebind/evidence/reset telemetry is included in live/final diagnostics.

## Safety retained

All 14 recognition thresholds remain unchanged. Identity and quantity remain decoupled. AI/cloud paths cannot create quantity, modify stock/payment, alter the signer, or bypass release gates. Final quantity remains owned by physical truth and Safety Kernel.

## Acceptance status

This source package is an implementation candidate. Static/source regression validation may pass locally, but Android compilation/signing and real-device Smart Scan evidence are required before `TARGET PASSED` or `CLOSED` is allowed.
