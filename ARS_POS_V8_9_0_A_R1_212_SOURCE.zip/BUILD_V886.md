# V8.8.6 Build Notes

Build the supplied V8.8.6 source ZIP with its matching `build-apk.yml` workflow. The workflow verifies the exact source SHA-256, source-file integrity, static safety invariants, Android debug/release compilation, JVM/Android unit tests, official release signing, package/version metadata, alignment and official signer fingerprint.

Required update transition: `1.10.7 (207) -> 1.10.8 (208)` **in place**. Do not uninstall the current ARS POS installation before acceptance testing.

Android 14 diagnostic screen recording requires operator MediaProjection consent for each new recording session. This is intentional platform behavior and must not be bypassed.
