# V8.8.8 Build Notes

Build this V8.8.8 source ZIP only with its matching V8.8.8 workflow. The workflow must verify exact source ZIP SHA-256, source-file integrity, unchanged recognition thresholds, Android/JVM tests, official release signing, APK metadata, zip alignment and signer fingerprint.

Required transition:

`ARS POS 1.10.9 (209) -> 1.11.0 (210)` **in place**.

Do not uninstall the official installation for acceptance testing. Package remains `com.arspos.anglerriausyndicate`, Room DB remains v5, and the official signer must remain identical.

After installation run the V8.8.8 single/multi-object regression matrix with ground truth, then export **CHATGPT + EVIDENCE ZIP**.
