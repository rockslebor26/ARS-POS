# ARS POS 1.10.8 (208) — V8.8.6 Release Candidate

- Phase: `4.3.5.6`
- Engine: `V8.8.6`
- Revision: `PHYSICAL_IDENTITY_DECOUPLING_EVIDENCE_RECORDER_R1`
- Previous official candidate: `1.10.7 (207)`
- Current candidate: `1.10.8 (208)`
- Package: `com.arspos.anglerriausyndicate`
- Room DB: `5`
- Update path: in-place only

## V8.8.6 changes

- recognized identity is decoupled from quantity authorization;
- sticky identity owner has bounded same-lane fallback after short tracker splits;
- best identity evidence can carry forward through the bounded persistent evidence cache;
- independent NORMAL completeness can veto unsafe shared-foreground merging;
- elongated ambiguous geometry is explicitly telemetry-routed without creating quantity;
- operator ground truth is recorded before adaptive-reference promotion;
- ARS Visual Diagnostic Recorder V1 added with Android MediaProjection foreground service;
- `CHATGPT + EVIDENCE ZIP` now builds one package containing report/logs, capture/keyframes, optional screen video, scanner/performance telemetry, decision/ground-truth/replay evidence, bookmarks and SHA-256 integrity data;
- diagnostic export redacts secrets and tolerates partial evidence/video failure.

## Safety retained

All 14 recognition thresholds are unchanged. Cloud Identity remains `SHADOW`; Self Learning remains `ACTIVE_CONFIRMED_ONLY`; ARS AI Engineer remains `DEV_CENTER_DIAGNOSTIC_ONLY` and outside the critical scan path. Safety Kernel and physical quantity rules remain authoritative.

## Validation status

Static source invariants, Python regression tests and ARS AI Gateway Node tests are executed locally before packaging. Full Android debug/release compilation, Android/JVM tests, official signing, APK metadata verification and in-place installation are delegated to the matching GitHub Actions workflow. Real-device Smart Scan and diagnostic-video acceptance remain mandatory before V8.8.6 is declared finished.
