# Phase 4.3.5.8 / V8.8.8 — Authoritative Canonical Evidence Handoff + Multi-Instance NORMAL Truth R1

## Mission

V8.8.8 is a convergence and physical-truth phase. It addresses two verified V8.8.7 faults without lowering any recognition threshold:

1. live identity evidence can already be correct and strong, then finalization can rescore a weaker/fresher frame and lose the correct candidate;
2. two independent NORMAL products can share one coarse foreground component and be collapsed into one canonical NORMAL object.

Primary invariant:

`PHYSICAL LOCK -> CANONICAL IDENTITY -> BEST EVIDENCE ESCROW -> FINAL IDENTITY`

while transaction quantity uses a separate physical invariant:

`FRESH PHYSICAL FRAME -> INDEPENDENT PHYSICAL INSTANCE -> SAFE QUANTITY`

## Authoritative canonical evidence escrow

`CanonicalEvidenceSuperiorityPolicy` preserves the strongest already-observed canonical candidate as an advisory recall seed. A weaker fresh frame cannot replace stable accepted evidence merely because it arrived later. A different SKU can replace the incumbent only when independent evidence is materially stronger.

This mechanism does **not** accept identity. Final acceptance remains owned by `SmartRecognitionEngine` with all 14 thresholds unchanged.

Telemetry includes:
- `canonicalAuthoritativeProductId` / score / margin;
- `canonicalEvidenceDowngradePrevented`;
- candidate swap attempted / accepted / rejected.

## Dual-frame finalization

V8.8.8 splits finalization evidence into two camera snapshots:

- **fresh physical frame**: object existence, segmentation, physical truth and quantity;
- **best identity frame**: high-resolution visual/OCR identity evidence retained within the bounded canonical lifetime.

The ViewModel copies both frames before the Compose camera surface is dismissed. `FINALIZATION_BARRIER_CREATED` records an immutable `finalizationSnapshotId`, track/CID snapshot and frame ages before final scanning starts.

## Physical-lock identity persistence

A short missing tracker observation no longer clears a locked canonical owner immediately. The canonical owner has a bounded lock hold and is restored to a visible re-bound track sharing the same CID. Telemetry records `ownerVacancyWhilePhysicalLocked` and canonical owner restoration.

## Multi-Instance NORMAL Truth V2

`NormalMergeRiskPolicy` prevents shared-foreground ownership from becoming unconditional merge authority. Merge risk considers overlap, centre separation, union expansion, independent ML Kit proposals and local completeness. High-risk pairs are vetoed and remain independent physical instances.

`SCAN_NORMAL_MERGE_RISK_VETO` records the risk score and reasons.

## Temporal NORMAL Completeness V3

A single, clean NORMAL proposal that is `PARTIAL` in one final crop may receive physical completeness support from its bound live track only when all of the following hold:

- purity is safe;
- it is not a merged fragment;
- final/local completeness is already at least 65;
- final-to-live physical binding is strong;
- the same NORMAL track is currently `LOCKED`, visible and has >=5 observations / >=4 hit streak;
- there is no ownership conflict.

This policy can strengthen physical completeness only. It cannot manufacture identity; Safety Kernel still requires recognition acceptance before quantity.

## Final recall / high-resolution handoff

The authoritative product is preferred as the final recall seed. NORMAL final scoring may use the retained high-resolution identity frame when canonical authoritative evidence exists, even if the fresh physical frame itself no longer requests high-resolution ambiguity recovery.

## Protected architecture

The following remain non-negotiable:
- package `com.arspos.anglerriausyndicate`;
- Room DB v5;
- official signer unchanged;
- versionCode increases 209 -> 210;
- in-place update only for acceptance testing;
- all 14 recognition thresholds unchanged;
- identity/quantity decoupling;
- Rod Authenticity, Package Edge Firewall, anti-bridge, cross-lane gates;
- Safety Kernel, Decision Evidence Ledger, Ground Truth, Replay V4;
- Self Learning `ACTIVE_CONFIRMED_ONLY`;
- Cloud Identity `SHADOW`;
- AI Engineer `DEV_CENTER_DIAGNOSTIC_ONLY`.

## V8.8.7 evidence baseline

From the supplied real-device V8.8.7 diagnostic bundle:
- 12/12 sessions completed; crash/ANR/native crash/evidence recorder error = 0;
- average completed scan 1826 ms; average object end-to-end 1147 ms; average crop OCR 816 ms;
- latest first candidate 4789 ms, with another observed first candidate 8019 ms; live MATCHED was not reached;
- live/final comparable 9 with 5 consistent and 4 mismatches in the report summary;
- a two-NORMAL scene was collapsed from 2 canonical proposals to 1 shared-foreground merged fragment;
- ground-truth annotations = 0;
- native heap high-water 179 MB and PSS high-water 323 MB; no OS low-memory kill.

## Phase gate targets

Real-device targets; source validation does not claim these are achieved:
- crash / ANR / evidence error = 0;
- stable accepted identity live -> final mismatch = 0;
- false shared-foreground NORMAL merge = 0 in regression set;
- duplicate/false automatic quantity = 0;
- first plausible candidate <=1.5 s target;
- stable known identity <=2.5 s target under adequate evidence;
- final after lock <=1.5 s target;
- ground truth present for the regression run;
- native memory bounded after warm-up.
