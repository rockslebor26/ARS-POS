# V8.8.7 Build Notes

Build the supplied V8.8.7 source ZIP only with its matching V8.8.7 workflow. The workflow verifies the exact source SHA-256, source-file integrity, recognition-threshold invariants, Android/JVM tests, official release signing, APK package/version metadata, zip alignment and signer fingerprint.

Required transition:

`ARS POS 1.10.8 (208) -> 1.10.9 (209)` **in place**.

Do not uninstall the official ARS POS installation for acceptance testing. Package must remain `com.arspos.anglerriausyndicate`, Room DB remains v5, and the official signer must remain identical.

After installation, use ARS Dev Center -> PROJECT TARGET / PHASE GATE to confirm the current mission, then run the V8.8.7 acceptance matrix and export **CHATGPT + EVIDENCE ZIP**.
