# BUILD V8.9.0-A / 1.12.0 (212)

Expected source archive: `ARS_POS_V8_9_0_A_R1_212_SOURCE.zip`.

The matching GitHub workflow must:
1. verify the exact source ZIP SHA-256;
2. run source invariants and Python tests;
3. verify DB v6 + MIGRATION_5_6 + Visual DNA foundation contracts;
4. compile debug/release Kotlin and run Android/JVM unit tests;
5. build signed release APK;
6. verify package `com.arspos.anglerriausyndicate`, version 1.12.0 (212), official signer and zip alignment;
7. publish APK + validation reports.

V8.9.0-A intentionally keeps Visual DNA extraction/scanner routing OFF until later stage regression.
