# ARS POS 1.12.0 (212)

- Phase: 4.3.6.0
- Engine: V8.9.0-A
- Revision: SMART_PRODUCT_ENROLLMENT_PRIVATE_VISUAL_DNA_FOUNDATION_R1
- Database: v6 (non-destructive migration from v5)
- Package: com.arspos.anglerriausyndicate
- Previous build: 1.11.1 (211) / V8.8.9

## Release intent
This release establishes Smart Product Enrollment and ARS Private Visual DNA persistence/contracts while retaining the V8.8.9 production scanner path. It must not be interpreted as activation of the final V8.9.0 Visual DNA recognition engine.

## Update rule
Install in-place over the existing official ARS POS. Do not uninstall the production app before update. The GitHub workflow verifies the official certificate fingerprint before publishing the APK artifact.
