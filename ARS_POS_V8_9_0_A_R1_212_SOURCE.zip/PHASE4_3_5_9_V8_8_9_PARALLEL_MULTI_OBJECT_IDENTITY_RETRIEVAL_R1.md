# Phase 4.3.5.9 / V8.8.9 — PARALLEL_MULTI_OBJECT_IDENTITY_RETRIEVAL_R1

## Mission
Smart Scan must identify single and multi-object scenes without serializing identity behind one sticky owner. Physical tracking and quantity safety remain authoritative.

## Runtime changes
- Up to 4 visible LOCKED canonical tracks may receive visual identity retrieval in one live pass.
- Manual/selected track is priority only; it never suppresses other scheduled tracks.
- At most 1 high-resolution escalation and 1 new OCR request are allowed per live pass.
- OCR cache hits do not consume the new-OCR budget.
- Starved locked tracks are prioritized after 1.5 s without an identity attempt.
- Visual master fingerprints are prewarmed after repository seed, outside the live scan critical path.
- Final selected-track handling preserves the complete multi-object proposal set and only reorders the selected proposal first.
- Weak final NORMAL live-to-final bindings below 0.48 are vetoed before canonical identity handoff; LONG minimum is 0.40.
- Existing recognition thresholds are unchanged.

## Safety retained
- Identity/quantity decoupling.
- Physical quantity truth and duplicate prevention.
- NORMAL purity/completeness and merge-risk veto.
- Rod authenticity, package-edge firewall, anti-bridge and cross-lane protection.
- Canonical evidence escrow, evidence superiority, dual-frame finalization and immutable finalization barrier.
- Ground Truth, Replay V4, Decision Evidence Ledger and one-tap diagnostic evidence.
- Cloud Identity SHADOW; Self Learning ACTIVE_CONFIRMED_ONLY; AI Engineer Dev Center diagnostic only.

## Regression targets
- Single-object first candidate P95 <= 1.5 s.
- 2–4 stable objects: every object receives an identity candidate <= 2.0 s P95 when catalog evidence is sufficient.
- Locked tracks with no identity attempt < 10%.
- PHYSICAL_STATE_BEFORE_IDENTITY after physical lock < 5%.
- No canonical locked track > 2.0 s without an identity attempt.
- Live/final identity consistency >= 95% for comparable accepted objects.
- Selected-track collapse in MULTI mode = 0.
- False/duplicate automatic quantity = 0.
- Recognition threshold relaxation = 0.
- Ground Truth must be populated during regression runs.
