# Build V8.8.9

Build target: ARS POS 1.11.1 (211), Phase 4.3.5.9 / V8.8.9.

Use JDK 17, Android SDK 35 / build-tools 35.0.0, Gradle 8.9. Build the release APK with the existing official ARS signing secrets. Verify package, versionName/versionCode, signer SHA-256 and zip alignment before publishing the artifact.

Install 1.11.1 (211) directly over official 1.11.0 (210). Do not uninstall the production app.
