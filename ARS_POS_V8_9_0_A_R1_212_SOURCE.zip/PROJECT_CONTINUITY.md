# ARS POS Project Continuity

Current source candidate: **1.10.8 (208) / Phase 4.3.5.6 / V8.8.6 — Physical Identity Decoupling + Evidence Recorder R1**.

Direct predecessor: **1.10.7 (207) / Phase 4.3.5.5 / V8.8.5 — Canonical Physical Target + Fast Identity Convergence R1**. Package `com.arspos.anglerriausyndicate`, Room v5, official signer and all 14 recognition thresholds remain unchanged.

## Current architecture direction

Canonical physical truth remains prior to identity. V8.8.6 separates *recognized identity* from *quantity authorization*: an identity that passes recognition can remain visible even if physical quantity safety correctly withholds checkout quantity. This prevents a safety rejection from looking like an identity failure.

LIVE identity is still owned by one sticky locked physical object at a time. A bounded persistent evidence cache now carries the best known product hint across short tracker splits, and a same-lane geometry fallback may rebind the identity owner for at most the configured short gap. This fallback is advisory only and cannot create quantity or bypass final recognition.

NORMAL physical resolution distinguishes shared segmentation from true shared physical identity. Independently complete spatially separated objects can veto a shared-foreground merge. Elongated NORMAL/LONG ambiguity is explicitly marked for evidence escalation rather than being treated as type authority.

Operator-confirmed adaptive learning now records ground truth before promoting the learned reference.

ARS Dev Center adds **ARS Visual Diagnostic Recorder V1**. With operator screen-capture permission active, **CHATGPT + EVIDENCE ZIP** finalizes the video and packages it with logs, captures/keyframes, scanner/performance telemetry, decision ledger, ground truth, Replay V4 evidence, automatic failure bookmarks and SHA-256 integrity metadata. Export is secret-redacted and partial-failure tolerant.

ARS AI Engineer remains `DEV_CENTER_DIAGNOSTIC_ONLY`; Cloud Identity remains `SHADOW`; Self Learning remains `ACTIVE_CONFIRMED_ONLY`.

## Finish criteria

V8.8.6 is not finished by source validation or successful APK compilation alone. Signed real-device evidence must show: stable single/multi-object physical lock, materially faster and persistent identity convergence, no false/duplicate quantity, no cross-lane identity-owner fallback, independent-object preservation under shared foreground, correct LONG authenticity/anchor behavior, video/log timestamp correlation, acceptable recorder memory/latency overhead, crash/ANR/native-crash zero during the acceptance window, and safe in-place `207 -> 208` update behavior.
