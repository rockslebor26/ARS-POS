package com.arspos.anglerriausyndicate.visualdna

import kotlin.math.roundToInt

data class EnrollmentCoverageInput(
    val acceptedViewTypes: Set<String>,
    val visibleSurfaceCoverage: Float,
    val featureCoverage: Float,
    val discriminativeCoverage: Float,
    val viewDiversity: Float,
    val longObject: Boolean
)

data class EnrollmentCoverageDecision(
    val sufficient: Boolean,
    val score: Int,
    val missingEvidence: Set<String>
)

object EnrollmentCoveragePolicy {
    fun evaluate(input: EnrollmentCoverageInput): EnrollmentCoverageDecision {
        val views = input.acceptedViewTypes.map(String::uppercase).toSet()
        val missing = linkedSetOf<String>()

        if (input.longObject) {
            if ("LONG_FULL_A" !in views && "LONG_FULL_B" !in views) missing += "LONG_FULL"
            if ("LONG_HANDLE" !in views) missing += "LONG_HANDLE"
            if ("LONG_TIP" !in views) missing += "LONG_TIP"
            if ("LONG_SIDE" !in views) missing += "LONG_SIDE"
        } else {
            if ("FRONT" !in views) missing += "FRONT"
            if ("BACK" !in views) missing += "BACK"
            if (views.none { it == "LEFT" || it == "RIGHT" || it == "ANGLE_45" }) missing += "SIDE_OR_ANGLE"
        }

        if (input.visibleSurfaceCoverage < 0.62f) missing += "MORE_SURFACE"
        if (input.featureCoverage < 0.55f) missing += "MORE_FEATURES"
        if (input.viewDiversity < 0.50f) missing += "NEW_ANGLE"
        if (input.discriminativeCoverage < 0.45f) missing += "DISTINCTIVE_DETAIL"

        val structural = if (missing.none { it in setOf("FRONT", "BACK", "SIDE_OR_ANGLE", "LONG_FULL", "LONG_HANDLE", "LONG_TIP", "LONG_SIDE") }) 1f else 0.45f
        val score = (
            structural * 25f +
                input.visibleSurfaceCoverage.coerceIn(0f, 1f) * 25f +
                input.featureCoverage.coerceIn(0f, 1f) * 20f +
                input.viewDiversity.coerceIn(0f, 1f) * 15f +
                input.discriminativeCoverage.coerceIn(0f, 1f) * 15f
            ).roundToInt().coerceIn(0, 100)

        return EnrollmentCoverageDecision(missing.isEmpty() && score >= 70, score, missing)
    }
}
