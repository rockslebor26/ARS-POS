package com.arspos.anglerriausyndicate

/**
 * V8.8.8 conservative temporal NORMAL completeness bridge.
 *
 * This can strengthen physical completeness only for one already-independent,
 * locked NORMAL instance. It cannot accept identity and cannot rescue merged or
 * purity-review proposals.
 */
object TemporalNormalCompletenessPolicy {
    data class Result(val safeForQuantity: Boolean, val score: Int, val reason: String)

    fun evaluate(proposal: ScanProposal, binding: PersistentPhysicalIdBinder.ProposalBinding?): Result {
        if (proposal.proposalType != ScanProposal.TYPE_NORMAL) return Result(false, 0, "NOT_NORMAL")
        if (proposal.normalPurityState == "REVIEW_REQUIRED" || proposal.normalPurityScore < 75) {
            return Result(false, proposal.normalCompletenessScore, "NORMAL_PURITY_NOT_SAFE")
        }
        if (proposal.hypothesesMerged > 1 || proposal.normalFragmentState == "MERGED_FRAGMENT") {
            return Result(false, proposal.normalCompletenessScore, "MERGED_FRAGMENT_NOT_TEMPORAL_COMPLETE")
        }
        val track = binding?.liveTrack ?: return Result(false, proposal.normalCompletenessScore, "NO_TEMPORAL_BINDING")
        if (binding.totalScore < 0.62f) return Result(false, proposal.normalCompletenessScore, "WEAK_TEMPORAL_BINDING")
        if (track.proposalType != ScanProposal.TYPE_NORMAL || track.missingFrames != 0 ||
            track.physicalState != PhysicalObjectStateMachine.STATE_LOCKED) {
            return Result(false, proposal.normalCompletenessScore, "NORMAL_NOT_CURRENTLY_LOCKED")
        }
        val stablePhysical = track.observationCount >= 5 && track.hitStreak >= 4
        val localEnough = proposal.normalCompletenessScore >= 65
        val safe = stablePhysical && localEnough && !proposal.normalOwnershipConflict
        val temporalBonus = when {
            track.observationCount >= 8 && track.hitStreak >= 6 -> 18
            stablePhysical -> 12
            else -> 0
        }
        return Result(
            safeForQuantity = safe,
            score = (proposal.normalCompletenessScore + temporalBonus).coerceAtMost(100),
            reason = if (safe) "TEMPORAL_NORMAL_INSTANCE_COMPLETE" else "TEMPORAL_NORMAL_EVIDENCE_INSUFFICIENT"
        )
    }
}
