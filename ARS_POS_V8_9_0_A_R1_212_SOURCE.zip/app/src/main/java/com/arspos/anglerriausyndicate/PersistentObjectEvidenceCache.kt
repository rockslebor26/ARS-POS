package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * V8.8.6 bounded cache for the best live identity evidence of a physical track.
 *
 * It is advisory only: no cache entry can create quantity or bypass final
 * recognition. Its purpose is to survive a short LIVE-* track split so sticky
 * identity ownership and the best known product hint are not reset to zero.
 */
class PersistentObjectEvidenceCache(
    private val ttlMs: Long = ArsV850Config.PERSISTENT_EVIDENCE_TTL_MS
) {
    data class Evidence(
        val trackId: String,
        val bounds: Rect,
        val proposalType: String,
        val productId: Long,
        val bestVisualScore: Int,
        val bestMargin: Int,
        val observedAtMs: Long
    )

    private val byTrack = LinkedHashMap<String, Evidence>()

    fun clear() = byTrack.clear()

    fun observe(tracks: List<LiveSceneTrack>, nowMs: Long) {
        tracks.forEach { track ->
            val existing = byTrack[track.trackId]
            val candidate = Evidence(
                trackId = track.trackId,
                bounds = Rect(track.bounds),
                proposalType = track.proposalType,
                productId = track.product?.id ?: track.bestEvidenceProductId,
                bestVisualScore = max(track.bestVisualScore, track.visualScore),
                bestMargin = max(track.bestMargin, track.margin),
                observedAtMs = nowMs
            )
            if (existing == null) {
                byTrack[track.trackId] = candidate
            } else if (candidate.productId > 0L &&
                (existing.productId <= 0L || candidate.bestVisualScore >= existing.bestVisualScore || candidate.productId == existing.productId)
            ) {
                byTrack[track.trackId] = candidate.copy(
                    bestVisualScore = max(existing.bestVisualScore, candidate.bestVisualScore),
                    bestMargin = max(existing.bestMargin, candidate.bestMargin)
                )
            } else {
                byTrack[track.trackId] = existing.copy(
                    bounds = Rect(track.bounds),
                    bestVisualScore = max(existing.bestVisualScore, candidate.bestVisualScore),
                    bestMargin = max(existing.bestMargin, candidate.bestMargin),
                    observedAtMs = nowMs
                )
            }
        }
        prune(nowMs)
    }

    fun evidence(trackId: String?, nowMs: Long): Evidence? {
        if (trackId.isNullOrBlank()) return null
        prune(nowMs)
        return byTrack[trackId]
    }

    /**
     * Find a replacement LIVE track for a recently-lost owner. Geometry is
     * primary; matching best-evidence product is a bonus, never a requirement.
     */
    fun fallbackFor(previousTrackId: String?, tracks: List<LiveSceneTrack>, nowMs: Long): LiveSceneTrack? {
        val previous = evidence(previousTrackId, nowMs) ?: return null
        if (nowMs - previous.observedAtMs > ArsV850Config.IDENTITY_OWNER_FALLBACK_MAX_GAP_MS) return null
        return tracks.asSequence()
            .filter { it.trackId != previousTrackId }
            .filter { it.missingFrames == 0 }
            .filter { it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED }
            .filter { laneFamily(it.proposalType) == laneFamily(previous.proposalType) }
            .map { track -> track to continuityScore(previous, track) }
            .filter { it.second >= 0.46f }
            .maxByOrNull { it.second }
            ?.first
    }

    fun inherit(fromTrackId: String?, toTrack: LiveSceneTrack, nowMs: Long) {
        val previous = evidence(fromTrackId, nowMs) ?: return
        val current = byTrack[toTrack.trackId]
        if (previous.productId <= 0L && previous.bestVisualScore <= 0) return
        if (current == null || current.productId <= 0L || previous.bestVisualScore > current.bestVisualScore) {
            byTrack[toTrack.trackId] = previous.copy(
                trackId = toTrack.trackId,
                bounds = Rect(toTrack.bounds),
                proposalType = toTrack.proposalType,
                observedAtMs = nowMs
            )
        }
    }

    fun inheritedPreferredProductId(trackId: String?, nowMs: Long): Long =
        evidence(trackId, nowMs)?.productId ?: 0L

    private fun continuityScore(previous: Evidence, current: LiveSceneTrack): Float {
        val overlap = iou(previous.bounds, current.bounds)
        val scale = min(diagonal(previous.bounds), diagonal(current.bounds)).coerceAtLeast(1f)
        val distance = centerDistance(previous.bounds, current.bounds) / scale
        val geometry = max(overlap, (1f - distance).coerceIn(0f, 1f))
        val currentProduct = current.product?.id ?: current.bestEvidenceProductId
        val productBonus = if (previous.productId > 0L && currentProduct == previous.productId) 0.20f else 0f
        return (geometry * 0.80f + productBonus).coerceIn(0f, 1f)
    }

    private fun prune(nowMs: Long) {
        val iterator = byTrack.entries.iterator()
        while (iterator.hasNext()) {
            val e = iterator.next()
            if (nowMs - e.value.observedAtMs > ttlMs) iterator.remove()
        }
    }

    private fun laneFamily(type: String): String = when (type) {
        ScanProposal.TYPE_LONG -> "LONG"
        ScanProposal.TYPE_NORMAL -> "NORMAL"
        else -> type
    }

    private fun area(r: Rect): Long = r.width().coerceAtLeast(0).toLong() * r.height().coerceAtLeast(0).toLong()

    private fun iou(a: Rect, b: Rect): Float {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val intersection = (right - left).toLong() * (bottom - top).toLong()
        val union = area(a) + area(b) - intersection
        return if (union > 0L) intersection.toFloat() / union.toFloat() else 0f
    }

    private fun centerDistance(a: Rect, b: Rect): Float = hypot(
        ((a.left + a.right) - (b.left + b.right)) / 2f,
        ((a.top + a.bottom) - (b.top + b.bottom)) / 2f
    )

    private fun diagonal(r: Rect): Float = hypot(r.width().toFloat(), r.height().toFloat())
}
