package com.arspos.anglerriausyndicate

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * V8.8.8 multi-instance NORMAL truth policy.
 *
 * A shared coarse foreground component is not physical-object authority. This
 * policy scores the risk that merging two detector proposals would collapse two
 * independent sellable objects into one canonical NORMAL object.
 */
object NormalMergeRiskPolicy {
    data class Box(val left: Int, val top: Int, val right: Int, val bottom: Int) {
        val width: Int get() = (right - left).coerceAtLeast(0)
        val height: Int get() = (bottom - top).coerceAtLeast(0)
    }

    data class Result(val score: Int, val veto: Boolean, val reasons: List<String>)

    const val VETO_SCORE = 60

    fun evaluate(
        a: Box,
        b: Box,
        sourceA: String,
        sourceB: String,
        completenessA: Int,
        completenessB: Int
    ): Result {
        val overlap = overlapOfSmaller(a, b)
        val minDiag = min(diagonal(a), diagonal(b)).coerceAtLeast(1f)
        val centerRatio = centerDistance(a, b) / minDiag
        val expansion = area(union(a, b)).toFloat() / max(area(a), area(b)).coerceAtLeast(1L).toFloat()
        val independentDetectorPair = sourceA == "MLKIT" && sourceB == "MLKIT"

        var score = 0
        val reasons = ArrayList<String>()
        if (overlap < 0.08f) { score += 25; reasons += "LOW_OVERLAP" }
        else if (overlap < 0.18f) { score += 15; reasons += "WEAK_OVERLAP" }
        if (centerRatio > 0.70f) { score += 25; reasons += "SEPARATE_CENTERS" }
        else if (centerRatio > 0.45f) { score += 15; reasons += "CENTER_SEPARATION" }
        if (expansion > 1.85f) { score += 25; reasons += "LARGE_UNION_EXPANSION" }
        else if (expansion > 1.45f) { score += 15; reasons += "UNION_EXPANSION" }
        if (independentDetectorPair && overlap < 0.20f) { score += 20; reasons += "INDEPENDENT_MLKIT_PROPOSALS" }
        if (completenessA >= 75 && completenessB >= 75) { score += 15; reasons += "BOTH_LOCALLY_COMPLETE" }

        // Strong containment is fragment evidence and reduces split risk.
        if (overlap >= 0.70f) { score -= 35; reasons += "STRONG_CONTAINMENT" }
        if (centerRatio <= 0.20f) { score -= 15; reasons += "CENTERS_COINCIDE" }

        val bounded = score.coerceIn(0, 100)
        return Result(bounded, bounded >= VETO_SCORE, reasons)
    }

    private fun area(box: Box): Long = box.width.toLong() * box.height.toLong()
    private fun union(a: Box, b: Box) = Box(min(a.left,b.left), min(a.top,b.top), max(a.right,b.right), max(a.bottom,b.bottom))
    private fun diagonal(a: Box): Float = hypot(a.width.toFloat(), a.height.toFloat())
    private fun centerDistance(a: Box, b: Box): Float = hypot(
        ((a.left + a.right) - (b.left + b.right)) / 2f,
        ((a.top + a.bottom) - (b.top + b.bottom)) / 2f
    )
    private fun overlapOfSmaller(a: Box, b: Box): Float {
        val left=max(a.left,b.left); val top=max(a.top,b.top); val right=min(a.right,b.right); val bottom=min(a.bottom,b.bottom)
        if (right<=left || bottom<=top) return 0f
        val inter=(right-left).toLong()*(bottom-top).toLong()
        return inter.toFloat()/min(area(a),area(b)).coerceAtLeast(1L).toFloat()
    }
}
