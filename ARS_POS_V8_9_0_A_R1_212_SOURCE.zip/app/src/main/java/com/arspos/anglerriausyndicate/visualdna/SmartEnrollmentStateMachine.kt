package com.arspos.anglerriausyndicate.visualdna

enum class EnrollmentState {
    DRAFT,
    CAPTURING,
    QUALITY_CHECK,
    SEGMENTATION_READY,
    DNA_EXTRACTING,
    COVERAGE_CHECK,
    COLLISION_CHECK,
    MORE_EVIDENCE,
    READY_TO_COMMIT,
    COMMITTED,
    RECOGNITION_READY,
    FAILED
}

enum class EnrollmentEvent {
    START,
    CAPTURED,
    QUALITY_PASSED,
    SEGMENTATION_PASSED,
    DNA_READY,
    COVERAGE_SUFFICIENT,
    COVERAGE_INSUFFICIENT,
    COLLISION_CLEAR,
    COLLISION_NEEDS_EVIDENCE,
    RETRY_CAPTURE,
    COMMIT_SUCCEEDED,
    ACTIVATE,
    FAIL
}

data class EnrollmentTransition(
    val from: EnrollmentState,
    val event: EnrollmentEvent,
    val to: EnrollmentState,
    val accepted: Boolean
)

object SmartEnrollmentStateMachine {
    fun transition(state: EnrollmentState, event: EnrollmentEvent): EnrollmentTransition {
        if (event == EnrollmentEvent.FAIL) return EnrollmentTransition(state, event, EnrollmentState.FAILED, true)
        val next = when (state to event) {
            EnrollmentState.DRAFT to EnrollmentEvent.START -> EnrollmentState.CAPTURING
            EnrollmentState.CAPTURING to EnrollmentEvent.CAPTURED -> EnrollmentState.QUALITY_CHECK
            EnrollmentState.QUALITY_CHECK to EnrollmentEvent.QUALITY_PASSED -> EnrollmentState.SEGMENTATION_READY
            EnrollmentState.SEGMENTATION_READY to EnrollmentEvent.SEGMENTATION_PASSED -> EnrollmentState.DNA_EXTRACTING
            EnrollmentState.DNA_EXTRACTING to EnrollmentEvent.DNA_READY -> EnrollmentState.COVERAGE_CHECK
            EnrollmentState.COVERAGE_CHECK to EnrollmentEvent.COVERAGE_SUFFICIENT -> EnrollmentState.COLLISION_CHECK
            EnrollmentState.COVERAGE_CHECK to EnrollmentEvent.COVERAGE_INSUFFICIENT -> EnrollmentState.MORE_EVIDENCE
            EnrollmentState.COLLISION_CHECK to EnrollmentEvent.COLLISION_CLEAR -> EnrollmentState.READY_TO_COMMIT
            EnrollmentState.COLLISION_CHECK to EnrollmentEvent.COLLISION_NEEDS_EVIDENCE -> EnrollmentState.MORE_EVIDENCE
            EnrollmentState.MORE_EVIDENCE to EnrollmentEvent.RETRY_CAPTURE -> EnrollmentState.CAPTURING
            EnrollmentState.READY_TO_COMMIT to EnrollmentEvent.COMMIT_SUCCEEDED -> EnrollmentState.COMMITTED
            EnrollmentState.COMMITTED to EnrollmentEvent.ACTIVATE -> EnrollmentState.RECOGNITION_READY
            else -> state
        }
        return EnrollmentTransition(state, event, next, next != state)
    }
}
