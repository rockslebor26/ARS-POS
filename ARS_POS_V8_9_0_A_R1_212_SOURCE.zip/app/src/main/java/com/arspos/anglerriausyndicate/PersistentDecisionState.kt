package com.arspos.anglerriausyndicate

/** Snapshot shared from live advisory identity into final authoritative recall. */
data class PersistentDecisionState(
    val persistentPhysicalId: String,
    val candidateProductId: Long,
    val visualScore: Int,
    val margin: Int,
    val decision: String,
    val evidenceStage: String,
    val identityEvaluations: Int,
    val candidateDemotions: Int,
    val acceptedPreview: Boolean
)

fun LiveSceneTrack.toPersistentDecisionState() = PersistentDecisionState(
    persistentPhysicalId = trackId,
    candidateProductId = authoritativeProductId.takeIf { it > 0L } ?: product?.id ?: bestEvidenceProductId,
    visualScore = authoritativeScore.takeIf { it > 0 } ?: visualScore,
    margin = authoritativeMargin.takeIf { it > 0 } ?: margin,
    decision = identityDecision,
    evidenceStage = evidenceStage,
    identityEvaluations = identityEvaluationCount,
    candidateDemotions = candidateDemotions,
    acceptedPreview = state == LiveSceneTrack.STATE_MATCHED
)
