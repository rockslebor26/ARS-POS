package com.arspos.anglerriausyndicate.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ArsDao {
    @Query("SELECT * FROM products WHERE active=1 ORDER BY name")
    fun products():Flow<List<ProductEntity>>

    @Query("""SELECT * FROM products WHERE active=1 AND
        (name LIKE '%'||:q||'%' OR sku LIKE '%'||:q||'%' OR IFNULL(barcode,'') LIKE '%'||:q||'%')
        ORDER BY name""")
    fun search(q:String):Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id=:id LIMIT 1")
    suspend fun product(id:Long):ProductEntity?

    @Query("SELECT * FROM products WHERE barcode=:barcode LIMIT 1")
    suspend fun byBarcode(barcode:String):ProductEntity?

    @Insert(onConflict=OnConflictStrategy.ABORT)
    suspend fun insertProduct(p:ProductEntity):Long
    @Update suspend fun updateProduct(p:ProductEntity)

    @Query("UPDATE products SET stock=stock+:delta, updatedAt=:now WHERE id=:id")
    suspend fun changeStock(id:Long,delta:Int,now:Long=System.currentTimeMillis())

    @Query("SELECT * FROM product_photos WHERE productId=:productId ORDER BY isPrimary DESC, createdAt ASC")
    fun productPhotos(productId:Long):Flow<List<ProductPhotoEntity>>
    @Query("SELECT * FROM product_photos ORDER BY productId, isPrimary DESC, createdAt ASC")
    suspend fun allProductPhotos():List<ProductPhotoEntity>

    @Insert(onConflict=OnConflictStrategy.REPLACE)
    suspend fun insertProductPhoto(photo:ProductPhotoEntity):Long

    @Query("UPDATE product_photos SET isPrimary=0 WHERE productId=:productId")
    suspend fun clearPrimaryPhoto(productId:Long)

    @Query("UPDATE product_photos SET isPrimary=1 WHERE id=:photoId")
    suspend fun setPrimaryPhoto(photoId:Long)

    @Delete
    suspend fun deleteProductPhoto(photo:ProductPhotoEntity)

    @Query("DELETE FROM product_photos WHERE productId=:productId AND captureAngle=:angle")
    suspend fun deleteProductPhotosForAngle(productId:Long, angle:String)

    @Query("SELECT COUNT(*) FROM products WHERE active=1")
    suspend fun countProducts():Int

    @Insert suspend fun insertSale(s:SaleEntity):Long
    @Insert suspend fun insertItems(items:List<SaleItemEntity>)
    @Insert suspend fun insertMovement(m:StockMovementEntity)

    @Query("SELECT COALESCE((SELECT SUM(grandTotal) FROM sales WHERE status='PAID' AND createdAt>=:start),0) - COALESCE((SELECT SUM(total) FROM returns WHERE createdAt>=:start),0)")
    fun revenue(start:Long):Flow<Long>
    @Query("SELECT COUNT(*) FROM sales WHERE status='PAID' AND createdAt>=:start")
    fun transactionCount(start:Long):Flow<Int>

    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    fun sales():Flow<List<SaleEntity>>
    @Query("SELECT * FROM sales WHERE id=:id LIMIT 1")
    suspend fun sale(id:Long):SaleEntity?
    @Query("SELECT * FROM sale_items WHERE saleId=:saleId")
    suspend fun saleItems(saleId:Long):List<SaleItemEntity>

    @Insert suspend fun insertCash(c:CashTransactionEntity):Long
    @Query("SELECT COALESCE(SUM(CASE WHEN type='IN' THEN amount ELSE -amount END),0) FROM cash_transactions")
    fun cashBalance():Flow<Long>

    @Insert suspend fun insertCustomer(c:CustomerEntity):Long
    @Query("SELECT * FROM customers ORDER BY name")
    fun customers():Flow<List<CustomerEntity>>

    @Insert suspend fun insertReturn(r:ReturnEntity):Long
    @Insert suspend fun insertReturnItems(items:List<ReturnItemEntity>)
    @Query("SELECT * FROM returns WHERE saleId=:saleId ORDER BY createdAt DESC")
    suspend fun returnsForSale(saleId:Long):List<ReturnEntity>

    @Insert suspend fun audit(a:AuditLogEntity)

    @Insert(onConflict=OnConflictStrategy.IGNORE)
    suspend fun insertUser(u:UserEntity):Long
    @Update
    suspend fun updateUser(u:UserEntity)
    @Query("SELECT * FROM users WHERE username=:username AND active=1 LIMIT 1")
    suspend fun user(username:String):UserEntity?

    @Insert suspend fun insertReceipt(r:StockReceiptEntity):Long
    @Insert suspend fun insertReceiptItems(items:List<StockReceiptItemEntity>)

    @Query("SELECT value FROM settings WHERE `key`=:key LIMIT 1")
    suspend fun setting(key:String):String?
    @Query("SELECT * FROM settings WHERE `key` LIKE 'identity_profile_%'")
    suspend fun identityProfileSettings():List<SettingEntity>
    @Query("SELECT * FROM settings WHERE `key` LIKE 'master_verified_%'")
    suspend fun masterVerificationSettings():List<SettingEntity>
    @Insert(onConflict=OnConflictStrategy.REPLACE)
    suspend fun setSetting(s:SettingEntity)


    // Phase 4.3.6.0 / V8.9.0-A — Smart Enrollment + Private Visual DNA foundation.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEnrollmentSession(session: ProductEnrollmentEntity)

    @Query("SELECT * FROM product_enrollment_sessions WHERE sessionId=:sessionId LIMIT 1")
    suspend fun enrollmentSession(sessionId: String): ProductEnrollmentEntity?

    @Query("SELECT * FROM product_enrollment_sessions WHERE productId=:productId ORDER BY updatedAt DESC LIMIT 1")
    suspend fun latestEnrollmentSession(productId: Long): ProductEnrollmentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVisualReferenceView(view: VisualReferenceViewEntity)

    @Query("SELECT * FROM visual_reference_views WHERE productId=:productId ORDER BY createdAt ASC")
    suspend fun visualReferenceViews(productId: Long): List<VisualReferenceViewEntity>

    @Query("SELECT * FROM visual_reference_views WHERE enrollmentSessionId=:sessionId ORDER BY createdAt ASC")
    suspend fun enrollmentReferenceViews(sessionId: String): List<VisualReferenceViewEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProductVisualDna(dna: ProductVisualDnaEntity)

    @Query("SELECT * FROM product_visual_dna WHERE productId=:productId AND status='RECOGNITION_READY' ORDER BY updatedAt DESC LIMIT 1")
    suspend fun activeProductVisualDna(productId: Long): ProductVisualDnaEntity?

    @Query("SELECT * FROM product_visual_dna WHERE status='RECOGNITION_READY' ORDER BY productId, updatedAt DESC")
    suspend fun recognitionReadyVisualDna(): List<ProductVisualDnaEntity>

    @Query("UPDATE product_visual_dna SET status='SUPERSEDED', updatedAt=:now WHERE productId=:productId AND status='RECOGNITION_READY'")
    suspend fun supersedeProductVisualDna(productId: Long, now: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVisualLocalFeatures(features: List<VisualLocalFeatureEntity>)

    @Query("DELETE FROM visual_local_features WHERE dnaId=:dnaId")
    suspend fun deleteVisualLocalFeatures(dnaId: String)

    @Query("SELECT * FROM visual_local_features WHERE dnaId=:dnaId ORDER BY discriminativeScore DESC")
    suspend fun visualLocalFeatures(dnaId: String): List<VisualLocalFeatureEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDiscriminativeRegions(regions: List<DiscriminativeRegionEntity>)

    @Query("DELETE FROM discriminative_regions WHERE productId=:productId")
    suspend fun deleteDiscriminativeRegions(productId: Long)

    @Query("SELECT * FROM discriminative_regions WHERE productId=:productId ORDER BY discriminativeScore DESC")
    suspend fun discriminativeRegions(productId: Long): List<DiscriminativeRegionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCatalogCollisions(collisions: List<CatalogCollisionEntity>)

    @Query("DELETE FROM catalog_collisions WHERE sourceProductId=:productId OR targetProductId=:productId")
    suspend fun deleteCatalogCollisionsForProduct(productId: Long)

    @Query("SELECT * FROM catalog_collisions WHERE sourceProductId=:productId OR targetProductId=:productId ORDER BY collisionSeverity DESC")
    suspend fun catalogCollisions(productId: Long): List<CatalogCollisionEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertCatalogSnapshot(snapshot: CatalogSnapshotEntity)

    @Query("SELECT * FROM catalog_snapshots WHERE state='ACTIVE' ORDER BY catalogVersion DESC LIMIT 1")
    suspend fun activeCatalogSnapshot(): CatalogSnapshotEntity?

    @Query("SELECT COALESCE(MAX(catalogVersion), 0) FROM catalog_snapshots")
    suspend fun maxCatalogVersion(): Long

    @Query("UPDATE catalog_snapshots SET state='SUPERSEDED' WHERE state='ACTIVE'")
    suspend fun supersedeActiveCatalog()

    @Query("SELECT COUNT(*) FROM product_visual_dna WHERE status='RECOGNITION_READY'")
    suspend fun countRecognitionReadyDna(): Int

}
