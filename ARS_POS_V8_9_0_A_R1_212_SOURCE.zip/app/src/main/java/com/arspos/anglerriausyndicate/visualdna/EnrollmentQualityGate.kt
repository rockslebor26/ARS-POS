package com.arspos.anglerriausyndicate.visualdna

import kotlin.math.roundToInt

data class EnrollmentCaptureMetrics(
    val sharpness: Float,
    val exposure: Float,
    val objectCoverage: Float,
    val segmentationConfidence: Float,
    val occlusionRatio: Float,
    val motionBlur: Float,
    val featureDensity: Float,
    val objectCount: Int
)

data class EnrollmentQualityDecision(
    val accepted: Boolean,
    val score: Int,
    val reason: String
)

/**
 * Enrollment-only quality gate. These constants are not Smart Scan recognition
 * thresholds and must never be used to relax identity acceptance.
 */
object EnrollmentQualityGate {
    const val ACCEPT = "ACCEPT"
    const val REJECT_MULTI_OBJECT = "REJECT_MULTI_OBJECT"
    const val REJECT_BLUR = "REJECT_BLUR"
    const val REJECT_EXPOSURE = "REJECT_EXPOSURE"
    const val REJECT_OBJECT_TOO_SMALL = "REJECT_OBJECT_TOO_SMALL"
    const val REJECT_BAD_SEGMENTATION = "REJECT_BAD_SEGMENTATION"
    const val REJECT_OCCLUSION = "REJECT_OCCLUSION"
    const val REJECT_LOW_FEATURE_COVERAGE = "REJECT_LOW_FEATURE_COVERAGE"

    fun evaluate(m: EnrollmentCaptureMetrics): EnrollmentQualityDecision {
        val reason = when {
            m.objectCount != 1 -> REJECT_MULTI_OBJECT
            m.sharpness < 0.55f || m.motionBlur > 0.40f -> REJECT_BLUR
            m.exposure < 0.20f || m.exposure > 0.92f -> REJECT_EXPOSURE
            m.objectCoverage < 0.18f -> REJECT_OBJECT_TOO_SMALL
            m.segmentationConfidence < 0.60f -> REJECT_BAD_SEGMENTATION
            m.occlusionRatio > 0.45f -> REJECT_OCCLUSION
            m.featureDensity < 0.15f -> REJECT_LOW_FEATURE_COVERAGE
            else -> ACCEPT
        }

        val exposureQuality = (1f - kotlin.math.abs(m.exposure - 0.58f) / 0.58f).coerceIn(0f, 1f)
        val score = (
            m.sharpness.coerceIn(0f, 1f) * 24f +
                exposureQuality * 12f +
                m.objectCoverage.coerceIn(0f, 1f) * 18f +
                m.segmentationConfidence.coerceIn(0f, 1f) * 18f +
                (1f - m.occlusionRatio.coerceIn(0f, 1f)) * 10f +
                (1f - m.motionBlur.coerceIn(0f, 1f)) * 8f +
                m.featureDensity.coerceIn(0f, 1f) * 10f
            ).roundToInt().coerceIn(0, 100)

        return EnrollmentQualityDecision(reason == ACCEPT, score, reason)
    }
}
