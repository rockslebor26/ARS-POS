package com.arspos.anglerriausyndicate

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * V8.8.6 diagnostic-only screen recorder.
 *
 * Android MediaProjection consent remains operator-controlled. The recorder does
 * not alter Smart Scan recognition, physical-object state, quantity, database,
 * network identity, or transaction behavior. It only creates a bounded MP4 that
 * is finalized by the one-tap CHATGPT + EVIDENCE ZIP export.
 */
data class DiagnosticVideoArtifact(
    val status: String,
    val file: File? = null,
    val startedAtMs: Long = 0L,
    val finishedAtMs: Long = 0L,
    val reason: String = ""
) {
    val durationMs: Long
        get() = if (startedAtMs > 0L && finishedAtMs >= startedAtMs) finishedAtMs - startedAtMs else 0L
}

object ArsDiagnosticScreenRecorder {
    private const val PREF = "ars_visual_diagnostic_recorder"
    private const val KEY_ACTIVE_PATH = "active_path"
    private const val KEY_LAST_PATH = "last_path"
    private const val KEY_LAST_EXPORTED_PATH = "last_exported_path"
    private const val KEY_STARTED_AT = "started_at"
    private const val KEY_FINISHED_AT = "finished_at"
    private const val VIDEO_DIR = "ars_diagnostic_video"

    const val STATUS_RECORDED = "RECORDED"
    const val STATUS_NOT_STARTED = "NOT_STARTED"
    const val STATUS_FAILED = "FAILED"
    const val STATUS_FINALIZE_TIMEOUT = "FINALIZE_TIMEOUT"

    @Volatile private var recording = false

    fun isRecording(context: Context): Boolean = recording || activePath(context).isNotBlank()

    fun start(context: Context, resultCode: Int, projectionData: Intent) {
        val intent = Intent(context, ArsDiagnosticScreenRecorderService::class.java).apply {
            action = ArsDiagnosticScreenRecorderService.ACTION_START
            putExtra(ArsDiagnosticScreenRecorderService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ArsDiagnosticScreenRecorderService.EXTRA_PROJECTION_DATA, projectionData)
        }
        ContextCompat.startForegroundService(context, intent)
    }

    fun requestStop(context: Context) {
        if (!isRecording(context)) return
        val intent = Intent(context, ArsDiagnosticScreenRecorderService::class.java).apply {
            action = ArsDiagnosticScreenRecorderService.ACTION_STOP
        }
        runCatching { context.startService(intent) }
    }

    /**
     * Finalizes the active recording if present. If a just-finished recording has
     * not yet been exported, it is returned. Old already-exported video is never
     * silently attached to a later diagnostic package.
     */
    fun stopAndFinalizeForExport(context: Context, timeoutMs: Long = 4_500L): DiagnosticVideoArtifact {
        val startedAt = prefs(context).getLong(KEY_STARTED_AT, 0L)
        if (isRecording(context)) {
            requestStop(context)
            val deadline = System.currentTimeMillis() + timeoutMs.coerceAtLeast(250L)
            while (isRecording(context) && System.currentTimeMillis() < deadline) {
                try {
                    Thread.sleep(50L)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    break
                }
            }
            if (isRecording(context)) {
                return DiagnosticVideoArtifact(
                    status = STATUS_FINALIZE_TIMEOUT,
                    startedAtMs = startedAt,
                    finishedAtMs = System.currentTimeMillis(),
                    reason = "MEDIA_PROJECTION_FINALIZE_TIMEOUT"
                )
            }
        }

        val p = prefs(context)
        val path = p.getString(KEY_LAST_PATH, "").orEmpty()
        val exported = p.getString(KEY_LAST_EXPORTED_PATH, "").orEmpty()
        val finishedAt = p.getLong(KEY_FINISHED_AT, 0L)
        val file = path.takeIf { it.isNotBlank() }?.let(::File)
        if (file != null && file.exists() && file.length() > 0L && path != exported) {
            return DiagnosticVideoArtifact(
                status = STATUS_RECORDED,
                file = file,
                startedAtMs = startedAt,
                finishedAtMs = finishedAt.takeIf { it > 0L } ?: file.lastModified()
            )
        }
        return DiagnosticVideoArtifact(
            status = STATUS_NOT_STARTED,
            startedAtMs = startedAt,
            finishedAtMs = finishedAt,
            reason = if (path == exported && path.isNotBlank()) "LATEST_VIDEO_ALREADY_EXPORTED" else "NO_DIAGNOSTIC_VIDEO"
        )
    }

    fun markExported(context: Context, artifact: DiagnosticVideoArtifact) {
        val path = artifact.file?.absolutePath ?: return
        prefs(context).edit().putString(KEY_LAST_EXPORTED_PATH, path).apply()
    }

    internal fun allocateTarget(context: Context): File {
        val dir = File(context.filesDir, VIDEO_DIR).apply { mkdirs() }
        dir.listFiles()?.filter { it.isFile && it.extension.equals("mp4", true) }
            ?.sortedByDescending { it.lastModified() }
            ?.drop(3)
            ?.forEach { runCatching { it.delete() } }
        return File(dir, "diagnostic_screen_${System.currentTimeMillis()}.mp4")
    }

    internal fun onStarted(context: Context, file: File, startedAt: Long) {
        recording = true
        prefs(context).edit()
            .putString(KEY_ACTIVE_PATH, file.absolutePath)
            .putLong(KEY_STARTED_AT, startedAt)
            .putLong(KEY_FINISHED_AT, 0L)
            .apply()
        ArsFlightRecorder.event(
            "DIAGNOSTIC_VIDEO_START",
            "ARS Visual Diagnostic Recorder started",
            mapOf("file" to file.name, "startedAt" to startedAt)
        )
    }

    internal fun onFinished(context: Context, file: File?, success: Boolean, reason: String) {
        recording = false
        val finishedAt = System.currentTimeMillis()
        val validFile = file?.takeIf { it.exists() && it.length() > 0L }
        val edit = prefs(context).edit()
            .remove(KEY_ACTIVE_PATH)
            .putLong(KEY_FINISHED_AT, finishedAt)
        if (validFile != null) edit.putString(KEY_LAST_PATH, validFile.absolutePath)
        edit.apply()
        ArsFlightRecorder.event(
            if (success && validFile != null) "DIAGNOSTIC_VIDEO_FINALIZED" else "DIAGNOSTIC_VIDEO_ERROR",
            if (success && validFile != null) "Diagnostic screen recording finalized" else "Diagnostic screen recording unavailable",
            mapOf(
                "file" to (validFile?.name ?: ""),
                "bytes" to (validFile?.length() ?: 0L),
                "finishedAt" to finishedAt,
                "reason" to reason
            )
        )
    }

    internal fun clearActiveState(context: Context) {
        recording = false
        prefs(context).edit().remove(KEY_ACTIVE_PATH).apply()
    }

    fun metadataJson(artifact: DiagnosticVideoArtifact): String = JSONObject().apply {
        put("status", artifact.status)
        put("file", artifact.file?.name ?: "")
        put("bytes", artifact.file?.length() ?: 0L)
        put("startedAt", artifact.startedAtMs)
        put("finishedAt", artifact.finishedAtMs)
        put("durationMs", artifact.durationMs)
        put("reason", artifact.reason)
        put("diagnosticOnly", true)
        put("containsAudio", false)
    }.toString(2)

    private fun activePath(context: Context): String = prefs(context).getString(KEY_ACTIVE_PATH, "").orEmpty()
    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}

class ArsDiagnosticScreenRecorderService : Service() {
    companion object {
        const val ACTION_START = "com.arspos.anglerriausyndicate.action.DIAGNOSTIC_SCREEN_START"
        const val ACTION_STOP = "com.arspos.anglerriausyndicate.action.DIAGNOSTIC_SCREEN_STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_PROJECTION_DATA = "projection_data"
        private const val CHANNEL_ID = "ars_visual_diagnostic"
        private const val NOTIFICATION_ID = 886
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var targetFile: File? = null
    private var finished = false

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            finalizeRecording("MEDIA_PROJECTION_STOPPED")
            stopSelf()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                finalizeRecording("EXPORT_REQUESTED")
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                if (projection != null || recorder != null) return START_NOT_STICKY
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    NotificationCompat.Builder(this, CHANNEL_ID)
                        .setSmallIcon(android.R.drawable.presence_video_online)
                        .setContentTitle("ARS Visual Diagnostic Recorder")
                        .setContentText("Merekam layar untuk paket diagnostik ARS POS")
                        .setOngoing(true)
                        .setOnlyAlertOnce(true)
                        .build(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = projectionIntent(intent)
                if (resultCode == 0 || data == null) {
                    ArsDiagnosticScreenRecorder.onFinished(this, null, false, "MEDIA_PROJECTION_PERMISSION_DATA_MISSING")
                    stopSelf()
                    return START_NOT_STICKY
                }
                runCatching { beginProjection(resultCode, data) }
                    .onFailure {
                        ArsDiagnosticScreenRecorder.onFinished(this, targetFile, false, it.message ?: it::class.java.simpleName)
                        releaseResources()
                        stopSelf()
                    }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (!finished && (projection != null || recorder != null)) finalizeRecording("SERVICE_DESTROYED")
        releaseResources()
        ArsDiagnosticScreenRecorder.clearActiveState(this)
        super.onDestroy()
    }

    private fun beginProjection(resultCode: Int, data: Intent) {
        val metrics = resources.displayMetrics
        val rawWidth = metrics.widthPixels.coerceAtLeast(2)
        val rawHeight = metrics.heightPixels.coerceAtLeast(2)
        val longest = max(rawWidth, rawHeight)
        val scale = if (longest > 1280) 1280f / longest.toFloat() else 1f
        val width = even((rawWidth * scale).roundToInt().coerceAtLeast(2))
        val height = even((rawHeight * scale).roundToInt().coerceAtLeast(2))
        val density = metrics.densityDpi.coerceAtLeast(1)
        val file = ArsDiagnosticScreenRecorder.allocateTarget(this)
        targetFile = file

        val mr = createMediaRecorder().apply {
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(file.absolutePath)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setVideoEncodingBitRate(4_000_000)
            setVideoFrameRate(24)
            setVideoSize(width, height)
            prepare()
        }
        recorder = mr

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = manager.getMediaProjection(resultCode, data)
            ?: throw IllegalStateException("MediaProjection unavailable")
        projection = mp
        mp.registerCallback(projectionCallback, Handler(Looper.getMainLooper()))
        virtualDisplay = mp.createVirtualDisplay(
            "ARS-Visual-Diagnostic",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            mr.surface,
            null,
            null
        )
        mr.start()
        ArsDiagnosticScreenRecorder.onStarted(this, file, System.currentTimeMillis())
    }

    private fun finalizeRecording(reason: String) {
        if (finished) return
        finished = true
        var success = false
        runCatching {
            recorder?.stop()
            success = targetFile?.let { it.exists() && it.length() > 0L } == true
        }
        runCatching { recorder?.reset() }
        runCatching { recorder?.release() }
        recorder = null
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { projection?.unregisterCallback(projectionCallback) }
        val mp = projection
        projection = null
        runCatching { mp?.stop() }
        if (!success) runCatching { targetFile?.delete() }
        ArsDiagnosticScreenRecorder.onFinished(this, targetFile, success, reason)
    }

    private fun releaseResources() {
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { recorder?.release() }
        recorder = null
        val mp = projection
        runCatching { mp?.unregisterCallback(projectionCallback) }
        projection = null
        runCatching { mp?.stop() }
    }

    @Suppress("DEPRECATION")
    private fun createMediaRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(this) else MediaRecorder()

    @Suppress("DEPRECATION")
    private fun projectionIntent(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
        }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "ARS Visual Diagnostic",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Screen recording khusus sesi diagnostik ARS POS"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun even(value: Int): Int = if (value % 2 == 0) value else value - 1
}
