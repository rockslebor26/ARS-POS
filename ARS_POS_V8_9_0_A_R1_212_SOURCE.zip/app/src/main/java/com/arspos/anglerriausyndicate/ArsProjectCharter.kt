package com.arspos.anglerriausyndicate

/**
 * Persistent development target lock shown in ARS Dev Center.
 * This is documentation/diagnostics only and is never used as recognition logic.
 */
object ArsProjectCharter {
    val ultimateGoal = """
        CAMERA → PHYSICAL OBJECT → STABLE OBJECT LOCK → IDENTITY → PRODUCT → SAFE QUANTITY

        Satu benda fisik harus dipertahankan sebagai satu objek yang sama sampai identitasnya diputuskan atau evidence dinyatakan belum cukup. Smart Scan harus cepat dan konsisten pada single-object maupun multi-object tanpa membuat quantity palsu.
    """.trimIndent()

    val nonNegotiableRules = """
        • Recognition threshold/margin tidak boleh diturunkan agar terlihat berhasil.
        • Identity accepted tidak otomatis berarti quantity accepted.
        • Cloud/AI tidak boleh membuat quantity, mengubah stok/pembayaran, signer, atau memasang APK.
        • Canonical physical truth, Safety Kernel, Decision Ledger, Ground Truth, Replay, Rod Authenticity, Package Edge Firewall, dan update in-place tetap dilindungi.
        • Package resmi tetap com.arspos.anglerriausyndicate; versionCode wajib meningkat; signer resmi wajib sama.
    """.trimIndent()

    val currentMission = """
        V8.9.0-A CURRENT MISSION

        Bangun fondasi Smart Product Enrollment + ARS Private Visual DNA tanpa mengganggu scanner produksi V8.8.9. Setiap produk harus memiliki lifecycle enrollment eksplisit, quality/coverage gate, metadata model/catalog, discriminative-region contract, collision graph, dan open-set statistics foundation. DB v5 harus bermigrasi non-destruktif ke DB v6; produk, stok, transaksi, dan foto master lama wajib tetap utuh. Visual DNA scanner routing belum diaktifkan pada stage A. Threshold recognition tidak berubah dan quantity tetap berasal dari physical-object truth.
    """.trimIndent()

    val baseline = """
        BASELINE V8.8.7 — real-device diagnostic 2026-09-28
        • Scan sessions: 12/12 complete; crash/ANR/native crash/evidence error: 0.
        • Average completed scan: 1826 ms; object end-to-end: 1147 ms; crop OCR: 816 ms.
        • Latest first candidate: 4789 ms; another observed first candidate: 8019 ms; live MATCHED: 0.
        • Live/final comparable: 9; consistent: 5; mismatch: 4.
        • Verified failure: 2 NORMAL proposals sharing coarse foreground were merged into 1 canonical MERGED_FRAGMENT.
        • Ground-truth annotations: 0. PSS high-water: 323 MB; native high-water: 179 MB.
    """.trimIndent()

    val regressionGuard = """
        PHASE GATE
        IMPLEMENTED → TESTING → EVIDENCE VERIFIED → TARGET PASSED → CLOSED

        Target V8.9.0-A: migration 5→6 non-destruktif; destructive migration = 0; legacy product_photos tetap tersedia; quality gate menolak blur/multi-object/bad segmentation; duplicate/low-diversity views tidak dianggap coverage cukup; HIGH/CRITICAL catalog collision harus meminta evidence pembeda; hanya satu catalog snapshot ACTIVE; commit katalog atomik; Visual DNA extraction/scanner routing tetap OFF sampai stage berikutnya; seluruh 14 recognition threshold V8.8.9 tetap identik; false/duplicate automatic quantity = 0.
    """.trimIndent()

}
