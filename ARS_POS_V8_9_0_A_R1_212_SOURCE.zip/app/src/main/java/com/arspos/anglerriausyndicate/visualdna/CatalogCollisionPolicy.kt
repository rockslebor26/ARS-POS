package com.arspos.anglerriausyndicate.visualdna

data class CatalogSimilarityEvidence(
    val globalSimilarity: Float,
    val localSimilarity: Float,
    val geometrySimilarity: Float,
    val textureSimilarity: Float
)

data class CatalogCollisionDecision(
    val severity: String,
    val requiresAdditionalEvidence: Boolean,
    val reason: String
)

object CatalogCollisionPolicy {
    fun evaluate(e: CatalogSimilarityEvidence): CatalogCollisionDecision {
        val strongest = maxOf(e.globalSimilarity, e.localSimilarity, e.geometrySimilarity, e.textureSimilarity)
        val combined = (
            e.globalSimilarity.coerceIn(0f, 1f) * 0.38f +
                e.localSimilarity.coerceIn(0f, 1f) * 0.32f +
                e.geometrySimilarity.coerceIn(0f, 1f) * 0.18f +
                e.textureSimilarity.coerceIn(0f, 1f) * 0.12f
            )

        val severity = when {
            combined >= 0.92f || (strongest >= 0.96f && combined >= 0.88f) -> VisualDnaContract.COLLISION_CRITICAL
            combined >= 0.86f -> VisualDnaContract.COLLISION_HIGH
            combined >= 0.78f -> VisualDnaContract.COLLISION_MEDIUM
            combined >= 0.68f -> VisualDnaContract.COLLISION_LOW
            else -> VisualDnaContract.COLLISION_NONE
        }
        val requires = severity == VisualDnaContract.COLLISION_HIGH || severity == VisualDnaContract.COLLISION_CRITICAL
        return CatalogCollisionDecision(
            severity = severity,
            requiresAdditionalEvidence = requires,
            reason = if (requires) "DISCRIMINATIVE_EVIDENCE_REQUIRED" else "COLLISION_WITHIN_FOUNDATION_LIMIT"
        )
    }
}
