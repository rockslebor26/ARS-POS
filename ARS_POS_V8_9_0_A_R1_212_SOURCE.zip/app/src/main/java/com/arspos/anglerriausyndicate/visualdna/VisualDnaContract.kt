package com.arspos.anglerriausyndicate.visualdna

/** Stable contract shared by enrollment, catalog storage and future scanner stages. */
object VisualDnaContract {
    const val DNA_VERSION = "DNA_V1_FOUNDATION"
    const val EMBEDDING_MODEL_VERSION = "PENDING_V8_9_0_B"
    const val SEGMENTATION_MODEL_VERSION = "PENDING_V8_9_0_D"

    const val DNA_STATUS_STAGING = "STAGING"
    const val DNA_STATUS_RECOGNITION_READY = "RECOGNITION_READY"
    const val DNA_STATUS_SUPERSEDED = "SUPERSEDED"

    const val CATALOG_STATE_BUILDING = "BUILDING"
    const val CATALOG_STATE_ACTIVE = "ACTIVE"
    const val CATALOG_STATE_SUPERSEDED = "SUPERSEDED"
    const val CATALOG_STATE_FAILED = "FAILED"

    const val COLLISION_NONE = "NONE"
    const val COLLISION_LOW = "LOW"
    const val COLLISION_MEDIUM = "MEDIUM"
    const val COLLISION_HIGH = "HIGH"
    const val COLLISION_CRITICAL = "CRITICAL"
}
