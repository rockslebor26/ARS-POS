package com.arspos.anglerriausyndicate.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities=[
        ProductEntity::class, SaleEntity::class, SaleItemEntity::class,
        StockMovementEntity::class, UserEntity::class, CustomerEntity::class,
        CashTransactionEntity::class, ReturnEntity::class, ReturnItemEntity::class,
        AuditLogEntity::class, StockReceiptEntity::class, StockReceiptItemEntity::class,
        SettingEntity::class, ProductPhotoEntity::class,
        ProductEnrollmentEntity::class, VisualReferenceViewEntity::class,
        ProductVisualDnaEntity::class, VisualLocalFeatureEntity::class,
        DiscriminativeRegionEntity::class, CatalogCollisionEntity::class,
        CatalogSnapshotEntity::class
    ],
    version=6, exportSchema=false
)
abstract class ArsDatabase:RoomDatabase(){
    abstract fun dao():ArsDao
    companion object{
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS product_photos (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, productId INTEGER NOT NULL, localPath TEXT NOT NULL, isPrimary INTEGER NOT NULL DEFAULT 0, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_product_photos_productId ON product_photos(productId)")
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE product_photos ADD COLUMN captureAngle TEXT NOT NULL DEFAULT 'UNKNOWN'")
            }
        }

        /**
         * V8.9.0-A: additive/non-destructive Visual DNA foundation.
         * Existing POS, stock, transaction and product_photos rows are preserved.
         */
        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS product_enrollment_sessions (sessionId TEXT NOT NULL, productId INTEGER NOT NULL, state TEXT NOT NULL, requestedEvidence TEXT NOT NULL, qualityScore INTEGER NOT NULL, coverageScore INTEGER NOT NULL, collisionSeverity TEXT NOT NULL, startedAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(sessionId))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_product_enrollment_sessions_productId ON product_enrollment_sessions(productId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_product_enrollment_sessions_state ON product_enrollment_sessions(state)")

                db.execSQL("CREATE TABLE IF NOT EXISTS visual_reference_views (viewId TEXT NOT NULL, productId INTEGER NOT NULL, enrollmentSessionId TEXT NOT NULL, viewType TEXT NOT NULL, rawImagePath TEXT NOT NULL, enhancedImagePath TEXT, maskPath TEXT, qualityScore INTEGER NOT NULL, coverageScore INTEGER NOT NULL, segmentationScore INTEGER NOT NULL, featureDensity INTEGER NOT NULL, accepted INTEGER NOT NULL, rejectionReason TEXT NOT NULL, createdAt INTEGER NOT NULL, PRIMARY KEY(viewId))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_visual_reference_views_productId ON visual_reference_views(productId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_visual_reference_views_enrollmentSessionId ON visual_reference_views(enrollmentSessionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_visual_reference_views_productId_viewType ON visual_reference_views(productId, viewType)")

                db.execSQL("CREATE TABLE IF NOT EXISTS product_visual_dna (dnaId TEXT NOT NULL, productId INTEGER NOT NULL, dnaVersion TEXT NOT NULL, embeddingModelVersion TEXT NOT NULL, segmentationModelVersion TEXT NOT NULL, catalogVersion INTEGER NOT NULL, globalEmbedding BLOB NOT NULL, shapeSignature TEXT NOT NULL, geometrySignature TEXT NOT NULL, textureSignature TEXT NOT NULL, enrollmentQualityScore INTEGER NOT NULL, coverageScore INTEGER NOT NULL, intraProductVariation REAL NOT NULL, nearestNeighborDistance REAL NOT NULL, acceptedFeatureRange REAL NOT NULL, collisionGroupId TEXT, calibrationProfileId TEXT NOT NULL, status TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(dnaId))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_product_visual_dna_productId ON product_visual_dna(productId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_product_visual_dna_catalogVersion ON product_visual_dna(catalogVersion)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_product_visual_dna_status ON product_visual_dna(status)")

                db.execSQL("CREATE TABLE IF NOT EXISTS visual_local_features (featureId TEXT NOT NULL, dnaId TEXT NOT NULL, viewId TEXT NOT NULL, regionId TEXT, descriptor BLOB NOT NULL, normalizedX REAL NOT NULL, normalizedY REAL NOT NULL, normalizedWidth REAL NOT NULL, normalizedHeight REAL NOT NULL, stabilityScore REAL NOT NULL, discriminativeScore REAL NOT NULL, PRIMARY KEY(featureId))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_visual_local_features_dnaId ON visual_local_features(dnaId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_visual_local_features_viewId ON visual_local_features(viewId)")

                db.execSQL("CREATE TABLE IF NOT EXISTS discriminative_regions (regionId TEXT NOT NULL, productId INTEGER NOT NULL, semanticRole TEXT NOT NULL, normalizedX REAL NOT NULL, normalizedY REAL NOT NULL, normalizedWidth REAL NOT NULL, normalizedHeight REAL NOT NULL, discriminativeScore REAL NOT NULL, stabilityScore REAL NOT NULL, conflictingProductIds TEXT NOT NULL, preferredEvidenceType TEXT NOT NULL, createdAt INTEGER NOT NULL, PRIMARY KEY(regionId))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_discriminative_regions_productId ON discriminative_regions(productId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_discriminative_regions_semanticRole ON discriminative_regions(semanticRole)")

                db.execSQL("CREATE TABLE IF NOT EXISTS catalog_collisions (sourceProductId INTEGER NOT NULL, targetProductId INTEGER NOT NULL, globalSimilarity REAL NOT NULL, localSimilarity REAL NOT NULL, geometrySimilarity REAL NOT NULL, textureSimilarity REAL NOT NULL, collisionSeverity TEXT NOT NULL, resolvedByRegionId TEXT, status TEXT NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(sourceProductId, targetProductId))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_collisions_collisionSeverity ON catalog_collisions(collisionSeverity)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_collisions_status ON catalog_collisions(status)")

                db.execSQL("CREATE TABLE IF NOT EXISTS catalog_snapshots (catalogVersion INTEGER NOT NULL, embeddingModelVersion TEXT NOT NULL, segmentationModelVersion TEXT NOT NULL, visualDnaVersion TEXT NOT NULL, productCount INTEGER NOT NULL, dnaCount INTEGER NOT NULL, checksum TEXT NOT NULL, state TEXT NOT NULL, createdAt INTEGER NOT NULL, activatedAt INTEGER, PRIMARY KEY(catalogVersion))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_snapshots_state ON catalog_snapshots(state)")

                // Preserve legacy reference paths for audit, but do not mark them as V8.9-quality-approved.
                db.execSQL("INSERT OR IGNORE INTO visual_reference_views (viewId, productId, enrollmentSessionId, viewType, rawImagePath, enhancedImagePath, maskPath, qualityScore, coverageScore, segmentationScore, featureDensity, accepted, rejectionReason, createdAt) SELECT 'legacy-v5-' || id, productId, 'LEGACY_V5_IMPORT', captureAngle, localPath, NULL, NULL, 0, 0, 0, 0, 0, 'LEGACY_REQUIRES_V890A_REENROLLMENT', createdAt FROM product_photos")
            }
        }
        @Volatile private var instance:ArsDatabase?=null
        fun get(context:Context):ArsDatabase =
            instance ?: synchronized(this){
                instance ?: Room.databaseBuilder(
                    context.applicationContext,ArsDatabase::class.java,"ars_pos.db"
                ).addMigrations(MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6).build().also{instance=it}
            }
    }
}
