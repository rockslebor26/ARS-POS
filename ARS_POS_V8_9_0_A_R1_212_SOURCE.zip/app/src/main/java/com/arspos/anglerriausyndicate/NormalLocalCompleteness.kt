package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.max

/**
 * V8.8.7 local NORMAL completeness measurement.
 *
 * V8.8.6 could classify a visually complete compact product as PARTIAL when a
 * coarse, scene-wide foreground component included floor/table pixels. This
 * policy re-measures ownership in an expanded object-local ROI. It is a
 * physical-quantity safety signal only: it never changes identity thresholds.
 */
object NormalLocalCompleteness {
    data class Result(
        val policy: NormalCompletenessPolicy.Result,
        val ownerAreaRatio: Float,
        val ownerCoverage: Float,
        val ownerComponent: Int,
        val roi: Rect,
        val ownerTouchesRoiEdge: Boolean,
        val source: String
    )

    fun evaluate(
        bitmap: Bitmap,
        objectBounds: Rect,
        mergedProposals: Int
    ): Result? {
        if (bitmap.width <= 1 || bitmap.height <= 1 || objectBounds.width() < 4 || objectBounds.height() < 4) {
            return null
        }

        val safeObject = Rect(
            objectBounds.left.coerceIn(0, bitmap.width - 1),
            objectBounds.top.coerceIn(0, bitmap.height - 1),
            objectBounds.right.coerceIn(1, bitmap.width),
            objectBounds.bottom.coerceIn(1, bitmap.height)
        )
        if (safeObject.width() < 4 || safeObject.height() < 4) return null

        // Large enough to observe whether the foreground body genuinely extends
        // beyond the detector crop, but bounded to avoid reintroducing scene-wide
        // floor/background ownership.
        val expansion = max(12, (max(safeObject.width(), safeObject.height()) * 0.28f).toInt())
        val roi = Rect(
            (safeObject.left - expansion).coerceAtLeast(0),
            (safeObject.top - expansion).coerceAtLeast(0),
            (safeObject.right + expansion).coerceAtMost(bitmap.width),
            (safeObject.bottom + expansion).coerceAtMost(bitmap.height)
        )
        if (roi.width() < 8 || roi.height() < 8) return null

        val localBox = NormalPixelOwnership.Box(
            safeObject.left - roi.left,
            safeObject.top - roi.top,
            safeObject.right - roi.left,
            safeObject.bottom - roi.top
        )
        val ownership = NormalPixelOwnership.resolve(
            width = roi.width(),
            height = roi.height(),
            boxes = listOf(localBox)
        ) { x, y ->
            bitmap.getPixel(roi.left + x, roi.top + y)
        }
        val owner = ownership.owners.firstOrNull() ?: return null
        val ownerBounds = owner.componentBounds
        if (owner.component <= 0 || ownerBounds == null) return null

        val objectArea = safeObject.width().toLong().coerceAtLeast(1L) * safeObject.height().toLong().coerceAtLeast(1L)
        val ownerArea = (ownerBounds.right - ownerBounds.left).toLong().coerceAtLeast(0L) *
            (ownerBounds.bottom - ownerBounds.top).toLong().coerceAtLeast(0L)
        val ownerAreaRatio = ownerArea.toFloat() / objectArea.toFloat()
        val edgeTolerance = 3
        val touchesEdge = ownerBounds.left <= edgeTolerance || ownerBounds.top <= edgeTolerance ||
            ownerBounds.right >= roi.width() - edgeTolerance || ownerBounds.bottom >= roi.height() - edgeTolerance

        val raw = NormalCompletenessPolicy.evaluate(
            foregroundComponent = owner.component,
            ownerAreaRatio = ownerAreaRatio,
            mergedProposals = mergedProposals
        )
        val guarded = if (touchesEdge && raw.safeForQuantity) {
            NormalCompletenessPolicy.Result(
                score = raw.score.coerceAtMost(69),
                state = NormalCompletenessPolicy.STATE_PARTIAL,
                reason = "NORMAL_LOCAL_OWNER_TOUCHES_ROI_EDGE",
                safeForQuantity = false
            )
        } else if (raw.safeForQuantity) {
            raw.copy(reason = "NORMAL_LOCAL_COMPLETENESS_VERIFIED")
        } else {
            raw.copy(reason = "NORMAL_LOCAL_OWNER_EXTENDS_BEYOND_CROP")
        }

        return Result(
            policy = guarded,
            ownerAreaRatio = ownerAreaRatio,
            ownerCoverage = owner.coverage,
            ownerComponent = owner.component,
            roi = roi,
            ownerTouchesRoiEdge = touchesEdge,
            source = "LOCAL_EXPANDED_ROI"
        )
    }
}
