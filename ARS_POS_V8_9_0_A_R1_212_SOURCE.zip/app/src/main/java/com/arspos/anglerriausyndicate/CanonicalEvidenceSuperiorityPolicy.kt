package com.arspos.anglerriausyndicate

/**
 * Phase 4.3.5.8 / V8.8.8 authoritative canonical-evidence policy.
 *
 * This policy NEVER accepts a product and NEVER changes SmartRecognitionEngine
 * thresholds. It only decides which already-observed live candidate is safe to
 * preserve as the authoritative recall seed across frame degradation/rebinds.
 */
object CanonicalEvidenceSuperiorityPolicy {
    data class Evidence(
        val productId: Long,
        val score: Int,
        val margin: Int,
        val independentEvidence: Int,
        val acceptedEvidence: Int,
        val ocrSupported: Boolean,
        val highResolutionSupported: Boolean,
        val observedAtMs: Long
    ) {
        val stable: Boolean get() = independentEvidence >= ArsV850Config.CANONICAL_STABLE_EVIDENCE_COUNT
    }

    data class Decision(
        val selected: Evidence,
        val action: String,
        val challengerQuality: Int,
        val currentQuality: Int,
        val downgradePrevented: Boolean = false,
        val swapAttempted: Boolean = false,
        val swapAccepted: Boolean = false,
        val swapRejected: Boolean = false
    )

    const val ACTION_INITIALIZE = "INITIALIZE"
    const val ACTION_REINFORCE = "REINFORCE"
    const val ACTION_KEEP_STRONGER = "KEEP_STRONGER"
    const val ACTION_SWITCH_SUPERIOR = "SWITCH_SUPERIOR"
    const val ACTION_REJECT_WEAKER_SWAP = "REJECT_WEAKER_SWAP"

    fun select(current: Evidence?, challenger: Evidence): Decision {
        val challengerQuality = quality(challenger)
        if (current == null || current.productId <= 0L) {
            return Decision(challenger, ACTION_INITIALIZE, challengerQuality, 0)
        }

        val currentQuality = quality(current)
        if (current.productId == challenger.productId) {
            val selected = if (challengerQuality >= currentQuality) challenger else current
            return Decision(
                selected = selected,
                action = if (selected === challenger) ACTION_REINFORCE else ACTION_KEEP_STRONGER,
                challengerQuality = challengerQuality,
                currentQuality = currentQuality,
                downgradePrevented = selected === current && challengerQuality < currentQuality
            )
        }

        // A product swap requires materially stronger evidence. A stable/accepted
        // incumbent receives extra hysteresis because one weak fresh frame must
        // not erase a canonical identity already supported by independent views.
        val requiredAdvantage = when {
            current.acceptedEvidence > 0 && current.stable -> 14
            current.stable -> 10
            current.acceptedEvidence > 0 -> 9
            else -> 6
        }
        val challengerHasIndependentAuthority = challenger.independentEvidence >= 2 ||
            (challenger.ocrSupported && challenger.margin >= 8) ||
            (challenger.acceptedEvidence > 0 && challenger.margin >= 6)
        val maySwitch = challengerHasIndependentAuthority &&
            challengerQuality >= currentQuality + requiredAdvantage &&
            challenger.score >= current.score.coerceAtMost(92) - 2

        return if (maySwitch) {
            Decision(
                selected = challenger,
                action = ACTION_SWITCH_SUPERIOR,
                challengerQuality = challengerQuality,
                currentQuality = currentQuality,
                swapAttempted = true,
                swapAccepted = true
            )
        } else {
            Decision(
                selected = current,
                action = ACTION_REJECT_WEAKER_SWAP,
                challengerQuality = challengerQuality,
                currentQuality = currentQuality,
                downgradePrevented = challengerQuality < currentQuality,
                swapAttempted = true,
                swapRejected = true
            )
        }
    }

    /** Bounded quality score. Recognition acceptance remains elsewhere. */
    fun quality(e: Evidence): Int {
        var value = e.score.coerceIn(0, 100)
        value += e.margin.coerceIn(0, 20) / 2
        value += (e.independentEvidence.coerceIn(0, 6) - 1).coerceAtLeast(0) * 2
        value += e.acceptedEvidence.coerceIn(0, 2) * 2
        if (e.ocrSupported) value += 3
        if (e.highResolutionSupported) value += 2
        return value.coerceIn(0, 120)
    }
}
