package com.arspos.anglerriausyndicate.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Phase 4.3.6.0 / V8.9.0-A persistent foundation.
 *
 * These tables intentionally store only deterministic enrollment/catalog evidence.
 * They do not change recognition thresholds and they do not own quantity.
 */
@Entity(
    tableName = "product_enrollment_sessions",
    indices = [Index(value = ["productId"]), Index(value = ["state"])]
)
data class ProductEnrollmentEntity(
    @PrimaryKey val sessionId: String,
    val productId: Long,
    val state: String,
    val requestedEvidence: String = "",
    val qualityScore: Int = 0,
    val coverageScore: Int = 0,
    val collisionSeverity: String = "NONE",
    val startedAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "visual_reference_views",
    indices = [
        Index(value = ["productId"]),
        Index(value = ["enrollmentSessionId"]),
        Index(value = ["productId", "viewType"])
    ]
)
data class VisualReferenceViewEntity(
    @PrimaryKey val viewId: String,
    val productId: Long,
    val enrollmentSessionId: String,
    val viewType: String,
    val rawImagePath: String,
    val enhancedImagePath: String? = null,
    val maskPath: String? = null,
    val qualityScore: Int,
    val coverageScore: Int,
    val segmentationScore: Int,
    val featureDensity: Int,
    val accepted: Boolean,
    val rejectionReason: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "product_visual_dna",
    indices = [
        Index(value = ["productId"]),
        Index(value = ["catalogVersion"]),
        Index(value = ["status"])
    ]
)
data class ProductVisualDnaEntity(
    @PrimaryKey val dnaId: String,
    val productId: Long,
    val dnaVersion: String,
    val embeddingModelVersion: String,
    val segmentationModelVersion: String,
    val catalogVersion: Long,
    val globalEmbedding: ByteArray,
    val shapeSignature: String,
    val geometrySignature: String,
    val textureSignature: String,
    val enrollmentQualityScore: Int,
    val coverageScore: Int,
    val intraProductVariation: Float,
    val nearestNeighborDistance: Float,
    val acceptedFeatureRange: Float,
    val collisionGroupId: String? = null,
    val calibrationProfileId: String,
    val status: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "visual_local_features",
    indices = [Index(value = ["dnaId"]), Index(value = ["viewId"])]
)
data class VisualLocalFeatureEntity(
    @PrimaryKey val featureId: String,
    val dnaId: String,
    val viewId: String,
    val regionId: String? = null,
    val descriptor: ByteArray,
    val normalizedX: Float,
    val normalizedY: Float,
    val normalizedWidth: Float,
    val normalizedHeight: Float,
    val stabilityScore: Float,
    val discriminativeScore: Float
)

@Entity(
    tableName = "discriminative_regions",
    indices = [Index(value = ["productId"]), Index(value = ["semanticRole"])]
)
data class DiscriminativeRegionEntity(
    @PrimaryKey val regionId: String,
    val productId: Long,
    val semanticRole: String,
    val normalizedX: Float,
    val normalizedY: Float,
    val normalizedWidth: Float,
    val normalizedHeight: Float,
    val discriminativeScore: Float,
    val stabilityScore: Float,
    val conflictingProductIds: String,
    val preferredEvidenceType: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "catalog_collisions",
    primaryKeys = ["sourceProductId", "targetProductId"],
    indices = [Index(value = ["collisionSeverity"]), Index(value = ["status"])]
)
data class CatalogCollisionEntity(
    val sourceProductId: Long,
    val targetProductId: Long,
    val globalSimilarity: Float,
    val localSimilarity: Float,
    val geometrySimilarity: Float,
    val textureSimilarity: Float,
    val collisionSeverity: String,
    val resolvedByRegionId: String? = null,
    val status: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "catalog_snapshots",
    indices = [Index(value = ["state"])]
)
data class CatalogSnapshotEntity(
    @PrimaryKey val catalogVersion: Long,
    val embeddingModelVersion: String,
    val segmentationModelVersion: String,
    val visualDnaVersion: String,
    val productCount: Int,
    val dnaCount: Int,
    val checksum: String,
    val state: String,
    val createdAt: Long = System.currentTimeMillis(),
    val activatedAt: Long? = null
)
