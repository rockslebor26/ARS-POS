package com.arspos.anglerriausyndicate

/**
 * V8.8.9 parallel multi-object identity scheduler.
 *
 * Physical tracking remains authoritative for object existence/quantity, but identity
 * is no longer serialized behind one sticky owner. Every visible LOCKED canonical
 * track may receive a cheap visual retrieval slot in the same pass. Only one object
 * may escalate to high-resolution work per pass so ambiguity recovery cannot starve
 * the remaining scene.
 *
 * Recognition thresholds are not changed here.
 */
object LiveIdentityScheduler {
    const val IDENTITY_COOLDOWN_MS = 320L
    const val AMBIGUOUS_COOLDOWN_MS = 650L
    const val HIGH_RES_COOLDOWN_MS = 1_500L
    const val MATCHED_REVERIFY_MS = 8_000L
    const val REQUIRED_VIEW_CHANGE = 0.055f
    const val STATIC_AMBIGUITY_RETRY_MS = 2_000L
    const val MAX_AMBIGUOUS_IDENTITY_EVALUATIONS = 6
    const val MAX_PARALLEL_IDENTITIES = 4
    const val MAX_HIGH_RES_PER_PASS = 1
    const val STARVATION_PRIORITY_MS = 1_500L

    data class Selection(val trackId: String, val highResolution: Boolean)
    data class BatchPlan(
        val selections: List<Selection>,
        val nextCursor: Int,
        val visibleLockedCount: Int,
        val starvationCount: Int
    )

    private fun identityKey(track: LiveSceneTrack, identityKeyByTrack: Map<String, String>): String =
        identityKeyByTrack[track.trackId] ?: track.trackId

    /**
     * Select up to [maxBatch] tracks for one live pass. A preferred/manual track is
     * processed first when eligible, but it never excludes other locked objects.
     */
    fun chooseBatch(
        tracks: List<LiveSceneTrack>,
        lastIdentityAt: Map<String, Long>,
        lastHighResAt: Map<String, Long>,
        nowMs: Long,
        preferredTrackId: String?,
        cursor: Int,
        sceneChange: Float = 1f,
        identityKeyByTrack: Map<String, String> = emptyMap(),
        maxBatch: Int = MAX_PARALLEL_IDENTITIES
    ): BatchPlan {
        val visibleLocked = tracks.filter {
            it.missingFrames == 0 && it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED
        }
        if (visibleLocked.isEmpty()) return BatchPlan(emptyList(), cursor, 0, 0)

        fun identityAge(track: LiveSceneTrack): Long =
            nowMs - (lastIdentityAt[identityKey(track, identityKeyByTrack)] ?: 0L)

        fun fastEligible(track: LiveSceneTrack): Boolean {
            val age = identityAge(track)
            if (track.state == LiveSceneTrack.STATE_MATCHED) return age >= MATCHED_REVERIFY_MS
            val minimum = when (track.evidenceStage) {
                LiveEvidenceEscalationPolicy.HIGH_RES_REQUIRED,
                LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED -> AMBIGUOUS_COOLDOWN_MS
                else -> IDENTITY_COOLDOWN_MS
            }
            return age >= minimum
        }

        fun highResEligible(track: LiveSceneTrack): Boolean {
            if (track.evidenceStage != LiveEvidenceEscalationPolicy.HIGH_RES_REQUIRED &&
                track.evidenceStage != LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED
            ) return false
            val key = identityKey(track, identityKeyByTrack)
            val highResAge = nowMs - (lastHighResAt[key] ?: 0L)
            if (highResAge < HIGH_RES_COOLDOWN_MS) return false
            if (track.evidenceStage == LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED &&
                sceneChange < REQUIRED_VIEW_CHANGE
            ) {
                val age = identityAge(track)
                return track.identityEvaluationCount < MAX_AMBIGUOUS_IDENTITY_EVALUATIONS &&
                    age >= STATIC_AMBIGUITY_RETRY_MS
            }
            return true
        }

        val eligible = visibleLocked.filter(::fastEligible)
        if (eligible.isEmpty()) return BatchPlan(emptyList(), cursor, visibleLocked.size, 0)

        val preferred = preferredTrackId?.let { id -> eligible.firstOrNull { it.trackId == id } }
        val unresolved = eligible.filter { it.state != LiveSceneTrack.STATE_MATCHED }
        val reverify = eligible.filter { it.state == LiveSceneTrack.STATE_MATCHED }
        val basePool = if (unresolved.isNotEmpty()) unresolved else reverify

        // Starved tracks jump ahead of ordinary round-robin work. This bounds the
        // time a locked canonical object may exist without an identity attempt.
        val starved = basePool.filter { identityAge(it) >= STARVATION_PRIORITY_MS }
            .sortedByDescending(::identityAge)
        val normal = basePool.filterNot { it in starved }
        val rotated = if (normal.isEmpty()) emptyList() else {
            val start = Math.floorMod(cursor, normal.size)
            normal.drop(start) + normal.take(start)
        }

        val ordered = (listOfNotNull(preferred) + starved + rotated)
            .distinctBy { it.trackId }
            .take(maxBatch.coerceIn(1, MAX_PARALLEL_IDENTITIES))

        var highResBudget = MAX_HIGH_RES_PER_PASS
        val selections = ordered.map { track ->
            val highRes = highResBudget > 0 && highResEligible(track)
            if (highRes) highResBudget--
            Selection(track.trackId, highRes)
        }
        val advance = if (normal.isEmpty()) 0 else selections.count { s -> normal.any { it.trackId == s.trackId } }
        return BatchPlan(
            selections = selections,
            nextCursor = cursor + advance,
            visibleLockedCount = visibleLocked.size,
            starvationCount = starved.size
        )
    }

    /** Compatibility helper for policy tests and single-target callers. */
    fun choose(
        tracks: List<LiveSceneTrack>,
        lastIdentityAt: Map<String, Long>,
        lastHighResAt: Map<String, Long>,
        nowMs: Long,
        preferredTrackId: String?,
        cursor: Int,
        sceneChange: Float = 1f,
        identityKeyByTrack: Map<String, String> = emptyMap()
    ): Pair<Selection?, Int> {
        val plan = chooseBatch(
            tracks, lastIdentityAt, lastHighResAt, nowMs, preferredTrackId, cursor,
            sceneChange, identityKeyByTrack, maxBatch = 1
        )
        return plan.selections.firstOrNull() to plan.nextCursor
    }
}
