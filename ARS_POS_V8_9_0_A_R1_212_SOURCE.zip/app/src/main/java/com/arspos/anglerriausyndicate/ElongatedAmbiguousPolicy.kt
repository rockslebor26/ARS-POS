package com.arspos.anglerriausyndicate

import kotlin.math.max
import kotlin.math.min

/**
 * V8.8.6 diagnostic routing for elongated shapes whose geometry alone cannot
 * decide NORMAL vs LONG. The route is evidence-only metadata; the proposal
 * remains in its existing typed lane and all recognition/quantity thresholds
 * remain authoritative.
 */
object ElongatedAmbiguousPolicy {
    fun mark(proposal: ScanProposal): ScanProposal {
        if (proposal.bridgeSuppressed) return proposal
        val w = proposal.normalizedBounds.width().coerceAtLeast(1)
        val h = proposal.normalizedBounds.height().coerceAtLeast(1)
        val aspect = max(w, h).toFloat() / min(w, h).toFloat()
        if (aspect < 2.6f) return proposal

        val ambiguous = when (proposal.proposalType) {
            ScanProposal.TYPE_LONG -> !proposal.trustedRod ||
                proposal.rodAuthenticityState == ScanProposal.AUTH_UNCERTAIN ||
                !proposal.foregroundSupported
            ScanProposal.TYPE_NORMAL -> proposal.rodClaim ||
                proposal.normalPurityState == "REVIEW_REQUIRED" ||
                proposal.normalCompletenessState == NormalCompletenessPolicy.STATE_PARTIAL
            else -> false
        }
        if (!ambiguous) return proposal

        val reason = when (proposal.proposalType) {
            ScanProposal.TYPE_LONG -> "ELONGATED_LONG_IDENTITY_REQUIRES_DISCRIMINATIVE_EVIDENCE"
            ScanProposal.TYPE_NORMAL -> "ELONGATED_NORMAL_GEOMETRY_NOT_TYPE_AUTHORITY"
            else -> "ELONGATED_AMBIGUOUS"
        }
        return proposal.copy(elongatedAmbiguous = true, elongatedAmbiguousReason = reason)
    }
}
