package com.arspos.anglerriausyndicate

import android.graphics.Rect
import com.arspos.anglerriausyndicate.data.RecognitionCandidate

/** Hasil deteksi + pengenalan satu objek pada Phase 4.3.5.6 V8.8.6. */
data class VisualScanObject(
    val index: Int,
    val bounds: Rect,
    /** Match yang boleh membuat quantity. Tetap null bila Safety Kernel menahan quantity. */
    val match: VisualProductMatch?,
    /** Identitas hasil recognition. Dapat tetap ada walau quantity ditahan. */
    val identityMatch: VisualProductMatch? = match,
    val bestScore: Int = identityMatch?.score ?: match?.score ?: 0,
    val visualScore: Int = bestScore,
    val textScore: Int = 0,
    val finalScore: Int = bestScore,
    val ocrText: String = "",
    val identityOcrText: String = "",
    val barcode: String = "",
    val reason: String = "",
    val candidates: List<RecognitionCandidate> = emptyList(),
    val proposalId: String = "",
    val proposalSource: String = "UNKNOWN",
    val proposalType: String = ScanProposal.TYPE_NORMAL,
    val proposalRotation: Int = 0,
    val lineageId: String = "",
    val physicalInstanceHint: String = "",
    val physicalObjectId: String = "",
    // Stable diagnostic identity bridged from live temporal tracking when available.
    val persistentPhysicalId: String = "",
    val recognitionAccepted: Boolean = identityMatch != null,
    val quantityEligible: Boolean = true,
    val bridgeSuppressed: Boolean = false,
    val originalBounds: Rect = Rect(bounds),
    val normalizedBounds: Rect = Rect(bounds),
    val frameWidth: Int = 0,
    val frameHeight: Int = 0,
    val decisionRuleId: String = "NO_DECISION"
) {
    val canCommitQuantity: Boolean
        get() = ScanQuantityPolicy.eligible(recognitionAccepted, match != null, quantityEligible,
            bridgeSuppressed, physicalObjectId, physicalInstanceHint, proposalType)
}
