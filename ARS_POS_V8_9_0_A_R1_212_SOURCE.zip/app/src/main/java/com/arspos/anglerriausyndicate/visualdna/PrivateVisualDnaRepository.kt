package com.arspos.anglerriausyndicate.visualdna

import androidx.room.withTransaction
import com.arspos.anglerriausyndicate.data.db.ArsDatabase
import com.arspos.anglerriausyndicate.data.db.CatalogCollisionEntity
import com.arspos.anglerriausyndicate.data.db.CatalogSnapshotEntity
import com.arspos.anglerriausyndicate.data.db.DiscriminativeRegionEntity
import com.arspos.anglerriausyndicate.data.db.ProductEnrollmentEntity
import com.arspos.anglerriausyndicate.data.db.ProductVisualDnaEntity
import com.arspos.anglerriausyndicate.data.db.VisualLocalFeatureEntity
import com.arspos.anglerriausyndicate.data.db.VisualReferenceViewEntity

data class VisualDnaCommitPackage(
    val enrollment: ProductEnrollmentEntity,
    val dna: ProductVisualDnaEntity,
    val localFeatures: List<VisualLocalFeatureEntity>,
    val discriminativeRegions: List<DiscriminativeRegionEntity>,
    val collisions: List<CatalogCollisionEntity>,
    val catalogChecksum: String
)

data class CatalogCommitResult(
    val catalogVersion: Long,
    val productId: Long,
    val dnaId: String,
    val state: String
)

/**
 * Atomic DB boundary for V8.9.0-A. It is intentionally not wired into Smart Scan yet.
 * Scanner routing remains V8.8.9 until later V8.9.0 stages pass regression gates.
 */
class PrivateVisualDnaRepository(private val db: ArsDatabase) {
    private val dao = db.dao()

    suspend fun beginEnrollment(session: ProductEnrollmentEntity) {
        require(session.productId > 0L) { "productId must be persisted before enrollment" }
        dao.upsertEnrollmentSession(session.copy(state = EnrollmentState.CAPTURING.name, updatedAt = System.currentTimeMillis()))
    }

    suspend fun recordReferenceView(view: VisualReferenceViewEntity) {
        require(view.productId > 0L)
        require(view.rawImagePath.isNotBlank())
        dao.upsertVisualReferenceView(view)
    }

    suspend fun latestEnrollment(productId: Long): ProductEnrollmentEntity? = dao.latestEnrollmentSession(productId)

    suspend fun activeCatalog(): CatalogSnapshotEntity? = dao.activeCatalogSnapshot()

    suspend fun activeDna(productId: Long): ProductVisualDnaEntity? = dao.activeProductVisualDna(productId)

    suspend fun commit(packageData: VisualDnaCommitPackage): CatalogCommitResult = db.withTransaction {
        val now = System.currentTimeMillis()
        val session = packageData.enrollment
        val dna = packageData.dna

        require(session.productId == dna.productId) { "Enrollment/DNA product mismatch" }
        require(session.state == EnrollmentState.READY_TO_COMMIT.name) { "Enrollment is not READY_TO_COMMIT" }
        require(session.qualityScore >= 0 && session.coverageScore >= 70) { "Enrollment coverage gate not satisfied" }
        require(packageData.collisions.none { collision ->
            (collision.collisionSeverity == VisualDnaContract.COLLISION_HIGH ||
                collision.collisionSeverity == VisualDnaContract.COLLISION_CRITICAL) &&
                collision.status != "RESOLVED"
        }) { "Unresolved HIGH/CRITICAL catalog collision" }
        require(packageData.catalogChecksum.isNotBlank()) { "Catalog checksum is required" }
        require(dna.dnaVersion == VisualDnaContract.DNA_VERSION) { "DNA version mismatch" }
        require(dna.embeddingModelVersion.isNotBlank())
        require(dna.segmentationModelVersion.isNotBlank())

        val nextCatalogVersion = dao.maxCatalogVersion() + 1L
        dao.supersedeActiveCatalog()
        dao.supersedeProductVisualDna(dna.productId, now)

        dao.upsertProductVisualDna(
            dna.copy(
                catalogVersion = nextCatalogVersion,
                status = VisualDnaContract.DNA_STATUS_RECOGNITION_READY,
                updatedAt = now
            )
        )

        dao.deleteVisualLocalFeatures(dna.dnaId)
        if (packageData.localFeatures.isNotEmpty()) dao.upsertVisualLocalFeatures(packageData.localFeatures)

        dao.deleteDiscriminativeRegions(dna.productId)
        if (packageData.discriminativeRegions.isNotEmpty()) dao.upsertDiscriminativeRegions(packageData.discriminativeRegions)

        dao.deleteCatalogCollisionsForProduct(dna.productId)
        if (packageData.collisions.isNotEmpty()) dao.upsertCatalogCollisions(packageData.collisions)

        val recognitionReadyCount = dao.countRecognitionReadyDna()
        val productCount = dao.countProducts()
        dao.insertCatalogSnapshot(
            CatalogSnapshotEntity(
                catalogVersion = nextCatalogVersion,
                embeddingModelVersion = dna.embeddingModelVersion,
                segmentationModelVersion = dna.segmentationModelVersion,
                visualDnaVersion = dna.dnaVersion,
                productCount = productCount,
                dnaCount = recognitionReadyCount,
                checksum = packageData.catalogChecksum,
                state = VisualDnaContract.CATALOG_STATE_ACTIVE,
                createdAt = now,
                activatedAt = now
            )
        )

        dao.upsertEnrollmentSession(
            session.copy(
                state = EnrollmentState.RECOGNITION_READY.name,
                updatedAt = now
            )
        )

        CatalogCommitResult(nextCatalogVersion, dna.productId, dna.dnaId, VisualDnaContract.CATALOG_STATE_ACTIVE)
    }
}
