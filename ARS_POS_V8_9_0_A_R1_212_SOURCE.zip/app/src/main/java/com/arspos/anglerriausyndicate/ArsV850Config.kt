package com.arspos.anglerriausyndicate

/**
 * Phase 4.3.6.0 / V8.9.0-A — Smart Product Enrollment + Private Visual DNA Foundation R1.
 *
 * V8.9.0-A keeps the V8.8.9 scanner and all physical/quantity safety gates intact
 * while adding the non-destructive DB v6 foundation for guided enrollment, private
 * Visual DNA, catalog collision analysis, open-set calibration metadata, and atomic
 * catalog commits. The new extraction/retrieval engine is deliberately NOT activated
 * in this foundation build; recognition thresholds remain unchanged.
 */
object ArsV850Config {
    const val PHASE = "4.3.6.0"
    const val ENGINE = "V8.9.0-A"
    const val RELEASE_REVISION = "SMART_PRODUCT_ENROLLMENT_PRIVATE_VISUAL_DNA_FOUNDATION_R1"
    const val VERSION_NAME = "1.12.0"
    const val VERSION_CODE = 212

    const val FEATURE_PERSISTENT_FRAGMENT_FUSION = true
    const val FEATURE_ML_GUIDED_LOCAL_RECOVERY = true
    const val FEATURE_BEST_EVIDENCE_MEMORY = true
    const val FEATURE_DECISION_EVIDENCE_LEDGER = true
    const val FEATURE_GROUND_TRUTH_LEARNING = true
    const val FEATURE_AI_ENGINEER_UI = true
    const val FEATURE_AI_ENGINEER_VISUAL_EVIDENCE = true
    const val FEATURE_AI_GATEWAY_SIGNED_REQUESTS = true
    const val FEATURE_AI_GATEWAY_STRUCTURED_DIAGNOSTICS = true
    const val FEATURE_AI_GATEWAY_HEALTH_CHECK = true
    const val AI_ENGINEER_MAX_IMAGES = 3
    const val AI_ENGINEER_MAX_REPORT_CHARS = 48_000

    const val CLOUD_IDENTITY_MODE = "SHADOW"
    const val SELF_LEARNING_MODE = "ACTIVE_CONFIRMED_ONLY"
    const val AI_ENGINEER_MODE = "DEV_CENTER_DIAGNOSTIC_ONLY"

    const val FEATURE_CONFIRMED_VISUAL_TEACHING = true
    const val FEATURE_NORMAL_VISUAL_ONLY_MASTER = true
    const val FEATURE_UPDATE_PROPOSAL_GATE = true

    const val FEATURE_NON_ROD_TO_NORMAL_RESCUE = true
    const val FEATURE_LIVE_ML_TALL_NORMAL_FALLBACK = true
    const val FEATURE_CATALOG_SNAPSHOT_EVIDENCE = true
    const val FEATURE_AMBIGUOUS_VISUAL_OCR = true
    const val FEATURE_REGULATORY_TEXT_FILTER = true
    const val FEATURE_WEAK_OCR_VISUAL_FALLBACK = true
    const val FEATURE_DIRECT_TEACH_CTA = true
    const val FEATURE_CONFIRMED_HYBRID_VISUAL = true

    // V8.8.2 safety foundations retained.
    const val FEATURE_FINAL_SCAN_VIEWMODEL_SCOPE = true
    const val FEATURE_LOCKED_SCENE_CONTINUITY = true
    const val FEATURE_LIVE_OCR_CACHE = true
    const val FEATURE_ADAPTIVE_ROD_AXIS_WIDTH = true
    const val FEATURE_PHYSICAL_OBJECT_STATE_MACHINE = true
    const val FEATURE_TWO_STAGE_CANDIDATE_RETRIEVAL = true
    const val FEATURE_UNIFIED_RECOVERY_COORDINATOR = true
    const val FEATURE_GUIDED_EVIDENCE_ACQUISITION = true
    const val FEATURE_AI_IN_CRITICAL_SCAN_PATH = false

    // V8.8.3 orchestration retained. These schedule evidence; they never relax recognition thresholds.
    const val FEATURE_EVENT_DRIVEN_IDENTITY = true
    const val FEATURE_OBJECT_SCOPED_RETRIEVAL = true
    const val FEATURE_CANDIDATE_MEMORY = true
    const val FEATURE_CANDIDATE_HYSTERESIS = true
    const val FEATURE_SINGLE_FLIGHT_OCR = true
    const val FEATURE_NEGATIVE_OCR_CACHE = true
    const val FEATURE_DISCRIMINATIVE_EVIDENCE = true
    const val FEATURE_HIGH_RES_NORMAL_AMBIGUITY = true
    const val FEATURE_ADAPTIVE_IDENTITY_ROI = true
    const val FEATURE_BEST_FRAME_SELECTION = true
    const val FEATURE_MULTI_OBJECT_TARGET_SELECTION = true
    const val FEATURE_IDENTITY_FREEZE_AFTER_CONFIRMATION = true
    const val FEATURE_LIVE_FINAL_DECISION_CONVERGENCE = true
    const val FEATURE_LIVE_CANDIDATE_FINAL_RECALL_SEED = true

    // V8.8.4 convergence fixes retained.
    const val FEATURE_STICKY_PHYSICAL_LOCK_UI = true
    const val FEATURE_ATOMIC_LOCK_GATE_STATE = true
    const val FEATURE_USEFUL_HIGH_RES_GAIN = true
    const val FEATURE_DISCRIMINATIVE_MICRO_OCR = true
    const val FEATURE_STATIC_AMBIGUITY_RETRY = true
    const val FEATURE_BEST_EVIDENCE_FINALIZATION = true

    // V8.8.5 canonical physical-target + fast identity convergence retained.
    const val FEATURE_POST_RECOVERY_CANONICAL_NORMAL = true
    const val FEATURE_NORMAL_COMPLETENESS_GATE = true
    const val FEATURE_STICKY_IDENTITY_OWNER = true
    const val FEATURE_SINGLE_OBJECT_FAST_IDENTITY = true
    const val FEATURE_MULTI_OBJECT_IDENTITY_SCHEDULER = true
    const val FEATURE_OCR_UTILITY_ROUTER = true
    const val FEATURE_FRESH_LOCK_FRAME_GATE = true
    const val FEATURE_SELECTED_TRACK_FINALIZATION = true

    // V8.8.6 identity/physical truth and diagnostic evidence hardening.
    const val FEATURE_IDENTITY_QUANTITY_DECOUPLING = true
    const val FEATURE_LOCKED_OBJECT_BEST_EVIDENCE_CARRY_FORWARD = true
    const val FEATURE_IDENTITY_OWNER_FALLBACK = true
    const val FEATURE_INDEPENDENT_NORMAL_COMPLETENESS = true
    const val FEATURE_SHARED_FOREGROUND_MERGE_VETO = true
    const val FEATURE_ELONGATED_AMBIGUOUS_LANE = true
    const val FEATURE_PERSISTENT_OBJECT_EVIDENCE_CACHE = true
    const val FEATURE_GROUND_TRUTH_ENFORCEMENT = true
    const val FEATURE_VISUAL_DIAGNOSTIC_RECORDER = true
    const val FEATURE_ONE_TAP_CHATGPT_EVIDENCE = true
    const val FEATURE_DIAGNOSTIC_AUTOMATIC_BOOKMARKS = true
    const val FEATURE_DIAGNOSTIC_SECRET_REDACTION = true
    const val FEATURE_DIAGNOSTIC_PARTIAL_FAILURE_TOLERANCE = true

    // V8.8.7 canonical identity continuity + temporal evidence convergence.
    const val FEATURE_PROJECT_TARGET_LOCK = true
    const val FEATURE_CANONICAL_IDENTITY_CONTINUITY = true
    const val FEATURE_TEMPORAL_TOP_K_EVIDENCE_FUSION = true
    const val FEATURE_CANONICAL_IDENTITY_REBIND_TRANSFER = true
    const val FEATURE_CANONICAL_IDENTITY_TELEMETRY = true
    const val FEATURE_IDENTITY_AFTER_PHYSICAL_LOCK = true
    const val FEATURE_NORMAL_LOCAL_COMPLETENESS_V2 = true
    const val FEATURE_ROLE_DISCRIMINATIVE_LONG_IDENTITY = true
    const val FEATURE_REGRESSION_GUARD = true

    // V8.8.8 authoritative evidence handoff + multi-instance NORMAL truth.
    const val FEATURE_CANONICAL_EVIDENCE_ESCROW = true
    const val FEATURE_EVIDENCE_SUPERIORITY_REBIND = true
    const val FEATURE_DUAL_FRAME_FINALIZATION = true
    const val FEATURE_IMMUTABLE_FINALIZATION_BARRIER = true
    const val FEATURE_PHYSICAL_LOCK_IDENTITY_PERSISTENCE = true
    const val FEATURE_MULTI_INSTANCE_NORMAL_TRUTH_V2 = true
    const val FEATURE_NORMAL_MERGE_RISK_VETO = true
    const val FEATURE_TEMPORAL_NORMAL_COMPLETENESS_V3 = true
    const val FEATURE_GROUND_TRUTH_REGRESSION_GATE = true

    // V8.8.9 low-latency multi-object identity architecture.
    const val FEATURE_PARALLEL_MULTI_OBJECT_IDENTITY = true
    const val FEATURE_PER_TRACK_IDENTITY_STATE = true
    const val FEATURE_BATCH_IDENTITY_RETRIEVAL = true
    const val FEATURE_PREWARMED_VISUAL_MASTER = true
    const val FEATURE_SELECTIVE_OCR_ESCALATION = true
    const val FEATURE_SELECTIVE_HIGH_RES_ESCALATION = true
    const val FEATURE_SELECTED_TRACK_PRIORITY_ONLY = true
    const val FEATURE_MULTI_OBJECT_FINALIZATION_PRESERVE = true
    const val FEATURE_STRICT_FINAL_BINDING_VETO = true
    const val FEATURE_LATEST_FRAME_BACKPRESSURE = true


    // V8.9.0-A enrollment/private Visual DNA foundation.
    const val FEATURE_SMART_PRODUCT_ENROLLMENT_FOUNDATION = true
    const val FEATURE_PRIVATE_VISUAL_DNA_SCHEMA = true
    const val FEATURE_ENROLLMENT_QUALITY_GATE = true
    const val FEATURE_ENROLLMENT_COVERAGE_GATE = true
    const val FEATURE_DISCRIMINATIVE_REGION_MODEL = true
    const val FEATURE_CATALOG_COLLISION_GRAPH = true
    const val FEATURE_OPEN_SET_STATISTICS_FOUNDATION = true
    const val FEATURE_ATOMIC_CATALOG_COMMIT = true
    const val FEATURE_CATALOG_MODEL_COMPATIBILITY = true
    const val FEATURE_DB_V6_NON_DESTRUCTIVE_MIGRATION = true

    // Activation is intentionally deferred to later V8.9.0 stages.
    const val FEATURE_VISUAL_DNA_EXTRACTION_ENGINE = false
    const val FEATURE_VISUAL_DNA_SCANNER_ROUTING = false
    const val PRIVATE_VISUAL_DNA_VERSION = "DNA_V1_FOUNDATION"
    const val EMBEDDING_MODEL_VERSION = "PENDING_V8_9_0_B"
    const val SEGMENTATION_MODEL_VERSION = "PENDING_V8_9_0_D"

    const val MAX_PARALLEL_IDENTITY_TRACKS = 4
    const val MAX_LIVE_OCR_REQUESTS_PER_PASS = 1
    const val MAX_LIVE_HIGH_RES_REQUESTS_PER_PASS = 1
    const val IDENTITY_STARVATION_LIMIT_MS = 2_000L

    const val LIVE_LOOP_DELAY_MS = 160L
    const val LIVE_STABLE_REFRESH_MS = 400L
    const val MAX_FINAL_BEST_FRAME_AGE_MS = 1_500L
    const val MAX_FINAL_IDENTITY_FRAME_AGE_MS = 12_000L
    const val PHYSICAL_LOCK_IDENTITY_HOLD_MS = 3_000L
    const val IDENTITY_OWNER_FALLBACK_MAX_GAP_MS = 1_250L
    const val PERSISTENT_EVIDENCE_TTL_MS = 12_000L

    const val CANONICAL_IDENTITY_TTL_MS = 12_000L
    const val CANONICAL_IDENTITY_REBIND_MAX_GAP_MS = 1_800L
    const val CANONICAL_IDENTITY_MIN_REBIND_SCORE = 0.44f
    const val CANONICAL_TOP_K = 5
    const val CANONICAL_MAX_CANDIDATES = 8
    const val CANONICAL_STABLE_EVIDENCE_COUNT = 3
    const val CANONICAL_INDEPENDENT_EVIDENCE_GAP_MS = 900L
    const val DUPLICATE_FRAME_EVIDENCE_WEIGHT = 0.25f
}
