package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test

class NormalMergeRiskPolicyTest {
    @Test fun twoSeparatedMlkitObjectsVetoSharedForegroundMerge() {
        val a = NormalMergeRiskPolicy.Box(10, 20, 130, 180)
        val b = NormalMergeRiskPolicy.Box(180, 30, 300, 190)
        val result = NormalMergeRiskPolicy.evaluate(a,b,"MLKIT","MLKIT",82,80)
        assertTrue(result.veto)
        assertTrue(result.score >= NormalMergeRiskPolicy.VETO_SCORE)
        assertTrue(result.reasons.contains("INDEPENDENT_MLKIT_PROPOSALS"))
    }

    @Test fun strongContainmentDoesNotLookLikeTwoIndependentObjects() {
        val a = NormalMergeRiskPolicy.Box(10, 20, 300, 400)
        val b = NormalMergeRiskPolicy.Box(30, 40, 280, 380)
        val result = NormalMergeRiskPolicy.evaluate(a,b,"MLKIT","MLKIT",50,50)
        assertFalse(result.veto)
    }
}
