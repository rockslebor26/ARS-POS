package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test

class CanonicalEvidenceSuperiorityPolicyTest {
    private fun e(id:Long, score:Int, margin:Int, independent:Int=3, accepted:Int=1, ocr:Boolean=false, high:Boolean=false, at:Long=1L) =
        CanonicalEvidenceSuperiorityPolicy.Evidence(id, score, margin, independent, accepted, ocr, high, at)

    @Test fun weakFreshFrameCannotReplaceStableCanonicalEvidence() {
        val current = e(32, 97, 10, independent=4, accepted=1, ocr=true, high=true)
        val weak = e(21, 85, 0, independent=1, accepted=0, at=2)
        val decision = CanonicalEvidenceSuperiorityPolicy.select(current, weak)
        assertEquals(32L, decision.selected.productId)
        assertTrue(decision.swapRejected)
        assertTrue(decision.downgradePrevented)
    }

    @Test fun materiallySuperiorIndependentEvidenceMayCorrectIdentity() {
        val current = e(32, 82, 1, independent=1, accepted=0)
        val better = e(21, 99, 16, independent=3, accepted=1, ocr=true, high=true, at=2)
        val decision = CanonicalEvidenceSuperiorityPolicy.select(current, better)
        assertEquals(21L, decision.selected.productId)
        assertTrue(decision.swapAccepted)
    }

    @Test fun sameProductLowerQualityDoesNotDowngradeEscrow() {
        val current = e(32, 96, 9, independent=4, accepted=1, high=true)
        val weaker = e(32, 86, 1, independent=4, accepted=1, at=2)
        val decision = CanonicalEvidenceSuperiorityPolicy.select(current, weaker)
        assertEquals(current, decision.selected)
        assertTrue(decision.downgradePrevented)
    }
}
