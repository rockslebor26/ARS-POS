package com.arspos.anglerriausyndicate

import android.graphics.Rect
import org.junit.Assert.*
import org.junit.Test

class LiveIdentitySchedulerTest {
    private fun track(id: String, stage: String, state: String = LiveSceneTrack.STATE_UNKNOWN) = LiveSceneTrack(
        trackId = id,
        bounds = Rect(0, 0, 100, 100),
        proposalType = ScanProposal.TYPE_NORMAL,
        product = null,
        visualScore = 80,
        margin = 2,
        hitStreak = 3,
        missingFrames = 0,
        state = state,
        quantityPreviewEligible = false,
        reason = "TEST",
        physicalState = PhysicalObjectStateMachine.STATE_LOCKED,
        evidenceStage = stage
    )

    @Test fun fourLockedObjectsCanReceiveIdentityInSamePass() {
        val tracks = (1..4).map { track("LIVE-$it", LiveEvidenceEscalationPolicy.VISUAL_RETRIEVAL) }
        val plan = LiveIdentityScheduler.chooseBatch(tracks, emptyMap(), emptyMap(), 10_000, null, 0)
        assertEquals(4, plan.selections.size)
        assertEquals(setOf("LIVE-1","LIVE-2","LIVE-3","LIVE-4"), plan.selections.map { it.trackId }.toSet())
    }

    @Test fun selectedObjectGetsPriorityWithoutSuppressingOthers() {
        val tracks = listOf(
            track("LIVE-1", LiveEvidenceEscalationPolicy.VISUAL_RETRIEVAL),
            track("LIVE-2", LiveEvidenceEscalationPolicy.OCR),
            track("LIVE-3", LiveEvidenceEscalationPolicy.VISUAL_RETRIEVAL)
        )
        val plan = LiveIdentityScheduler.chooseBatch(tracks, emptyMap(), emptyMap(), 10_000, "LIVE-2", 0)
        assertEquals("LIVE-2", plan.selections.first().trackId)
        assertEquals(3, plan.selections.size)
    }

    @Test fun highResolutionEscalationIsSingleFlightPerPass() {
        val tracks = listOf(
            track("LIVE-1", LiveEvidenceEscalationPolicy.HIGH_RES_REQUIRED),
            track("LIVE-2", LiveEvidenceEscalationPolicy.HIGH_RES_REQUIRED),
            track("LIVE-3", LiveEvidenceEscalationPolicy.VISUAL_RETRIEVAL)
        )
        val plan = LiveIdentityScheduler.chooseBatch(tracks, emptyMap(), emptyMap(), 10_000, null, 0)
        assertEquals(3, plan.selections.size)
        assertEquals(1, plan.selections.count { it.highResolution })
    }

    @Test fun highResolutionCooldownDoesNotStarveOtherVisualObjects() {
        val tracks = listOf(
            track("LIVE-1", LiveEvidenceEscalationPolicy.HIGH_RES_REQUIRED),
            track("LIVE-2", LiveEvidenceEscalationPolicy.VISUAL_RETRIEVAL)
        )
        val plan = LiveIdentityScheduler.chooseBatch(
            tracks, emptyMap(), mapOf("LIVE-1" to 9_000L), 10_000L, null, 0
        )
        assertEquals(2, plan.selections.size)
        assertFalse(plan.selections.first { it.trackId == "LIVE-1" }.highResolution)
        assertTrue(plan.selections.any { it.trackId == "LIVE-2" })
    }

    @Test fun canonicalCooldownSurvivesTransientTrackRebind() {
        val rebound = listOf(track("LIVE-9", LiveEvidenceEscalationPolicy.VISUAL_RETRIEVAL))
        val plan = LiveIdentityScheduler.chooseBatch(
            rebound,
            lastIdentityAt = mapOf("CID-1" to 9_800L),
            lastHighResAt = emptyMap(),
            nowMs = 10_000L,
            preferredTrackId = "LIVE-9",
            cursor = 0,
            identityKeyByTrack = mapOf("LIVE-9" to "CID-1")
        )
        assertTrue(plan.selections.isEmpty())
    }

    @Test fun starvedLockedTrackIsPrioritized() {
        val tracks = listOf(
            track("LIVE-1", LiveEvidenceEscalationPolicy.VISUAL_RETRIEVAL),
            track("LIVE-2", LiveEvidenceEscalationPolicy.VISUAL_RETRIEVAL)
        )
        val plan = LiveIdentityScheduler.chooseBatch(
            tracks,
            lastIdentityAt = mapOf("LIVE-1" to 9_500L, "LIVE-2" to 1_000L),
            lastHighResAt = emptyMap(),
            nowMs = 10_000L,
            preferredTrackId = null,
            cursor = 0,
            maxBatch = 1
        )
        assertEquals("LIVE-2", plan.selections.firstOrNull()?.trackId)
        assertEquals(1, plan.starvationCount)
    }
}
