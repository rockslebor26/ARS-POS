package com.arspos.anglerriausyndicate.visualdna

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EnrollmentQualityGateTest {
    @Test fun acceptsSingleSharpWellExposedObject() {
        val d = EnrollmentQualityGate.evaluate(
            EnrollmentCaptureMetrics(0.88f, 0.58f, 0.62f, 0.91f, 0.08f, 0.08f, 0.72f, 1)
        )
        assertTrue(d.accepted)
        assertEquals(EnrollmentQualityGate.ACCEPT, d.reason)
    }

    @Test fun rejectsMultiObjectEnrollment() {
        val d = EnrollmentQualityGate.evaluate(
            EnrollmentCaptureMetrics(0.9f, 0.58f, 0.7f, 0.9f, 0.05f, 0.05f, 0.8f, 2)
        )
        assertFalse(d.accepted)
        assertEquals(EnrollmentQualityGate.REJECT_MULTI_OBJECT, d.reason)
    }
}
