package com.arspos.anglerriausyndicate.visualdna

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CatalogCollisionPolicyTest {
    @Test fun criticalNearDuplicateRequiresAdditionalEvidence() {
        val d = CatalogCollisionPolicy.evaluate(CatalogSimilarityEvidence(0.95f, 0.94f, 0.90f, 0.88f))
        assertEquals(VisualDnaContract.COLLISION_CRITICAL, d.severity)
        assertTrue(d.requiresAdditionalEvidence)
    }

    @Test fun distantProductDoesNotBlockEnrollment() {
        val d = CatalogCollisionPolicy.evaluate(CatalogSimilarityEvidence(0.44f, 0.40f, 0.51f, 0.38f))
        assertEquals(VisualDnaContract.COLLISION_NONE, d.severity)
        assertFalse(d.requiresAdditionalEvidence)
    }
}
