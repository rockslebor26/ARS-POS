package com.arspos.anglerriausyndicate.visualdna

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EnrollmentCoveragePolicyTest {
    @Test fun normalProductNeedsFrontBackAndSideEvidence() {
        val d = EnrollmentCoveragePolicy.evaluate(
            EnrollmentCoverageInput(setOf("FRONT", "BACK", "RIGHT"), 0.82f, 0.80f, 0.72f, 0.78f, false)
        )
        assertTrue(d.sufficient)
    }

    @Test fun repeatedFrontViewsDoNotPassCoverage() {
        val d = EnrollmentCoveragePolicy.evaluate(
            EnrollmentCoverageInput(setOf("FRONT"), 0.80f, 0.76f, 0.70f, 0.20f, false)
        )
        assertFalse(d.sufficient)
        assertTrue("BACK" in d.missingEvidence)
        assertTrue("SIDE_OR_ANGLE" in d.missingEvidence)
    }
}
