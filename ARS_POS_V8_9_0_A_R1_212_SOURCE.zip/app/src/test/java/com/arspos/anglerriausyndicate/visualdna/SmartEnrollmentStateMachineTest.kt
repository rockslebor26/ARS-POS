package com.arspos.anglerriausyndicate.visualdna

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartEnrollmentStateMachineTest {
    @Test fun happyPathEndsRecognitionReady() {
        var state = EnrollmentState.DRAFT
        val events = listOf(
            EnrollmentEvent.START,
            EnrollmentEvent.CAPTURED,
            EnrollmentEvent.QUALITY_PASSED,
            EnrollmentEvent.SEGMENTATION_PASSED,
            EnrollmentEvent.DNA_READY,
            EnrollmentEvent.COVERAGE_SUFFICIENT,
            EnrollmentEvent.COLLISION_CLEAR,
            EnrollmentEvent.COMMIT_SUCCEEDED,
            EnrollmentEvent.ACTIVATE
        )
        events.forEach { event ->
            val t = SmartEnrollmentStateMachine.transition(state, event)
            assertTrue(t.accepted)
            state = t.to
        }
        assertEquals(EnrollmentState.RECOGNITION_READY, state)
    }

    @Test fun unresolvedCollisionReturnsForMoreEvidence() {
        val t = SmartEnrollmentStateMachine.transition(EnrollmentState.COLLISION_CHECK, EnrollmentEvent.COLLISION_NEEDS_EVIDENCE)
        assertTrue(t.accepted)
        assertEquals(EnrollmentState.MORE_EVIDENCE, t.to)
        val invalid = SmartEnrollmentStateMachine.transition(EnrollmentState.MORE_EVIDENCE, EnrollmentEvent.COMMIT_SUCCEEDED)
        assertFalse(invalid.accepted)
    }
}
