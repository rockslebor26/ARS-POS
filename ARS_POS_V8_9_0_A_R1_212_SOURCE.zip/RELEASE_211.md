# ARS POS 1.11.1 (211) — V8.8.9 Release Candidate

- Phase: 4.3.5.9
- Engine: V8.8.9
- Revision: PARALLEL_MULTI_OBJECT_IDENTITY_RETRIEVAL_R1
- Package: com.arspos.anglerriausyndicate
- Database: v5
- Previous official version: 1.11.0 (210)
- Current candidate: 1.11.1 (211)
- Update mode: IN_PLACE_UPDATE ONLY
- Official signer SHA-256: AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB

Recognition thresholds are unchanged. AI Engineer remains outside the critical scan path. Cloud Identity remains SHADOW.
