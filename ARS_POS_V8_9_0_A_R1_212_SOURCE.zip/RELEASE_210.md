# ARS POS 1.11.0 (210) — V8.8.8 Release Candidate

- Phase: `4.3.5.8`
- Engine: `V8.8.8`
- Revision: `AUTHORITATIVE_CANONICAL_EVIDENCE_HANDOFF_MULTI_INSTANCE_NORMAL_TRUTH_R1`
- Previous official candidate: `1.10.9 (209)`
- Current candidate: `1.11.0 (210)`
- Package: `com.arspos.anglerriausyndicate`
- Room DB: `5`
- Required update path: in-place only

## Main changes

- authoritative canonical evidence escrow and evidence-superiority swap rule;
- physical-lock canonical identity persistence/restoration;
- dual-frame finalization: fresh physical frame + best bounded identity frame;
- immutable finalization snapshot telemetry;
- authoritative candidate is preferred for final recall/high-resolution handoff;
- NORMAL shared-foreground merge-risk veto;
- conservative temporal NORMAL completeness for stable independent locked instances;
- expanded live/final continuity and merge-risk telemetry.

## Safety retained

All 14 recognition thresholds remain unchanged. Identity and quantity remain decoupled. Temporal completeness cannot accept product identity. Cloud/AI cannot create quantity, modify stock/payment, alter signer or bypass release gates.

## Acceptance status

Implementation candidate only. Local source/static/host-policy validation does not replace Android Gradle compilation, official signer verification, in-place installation, or the required real-device regression diagnostic bundle.
