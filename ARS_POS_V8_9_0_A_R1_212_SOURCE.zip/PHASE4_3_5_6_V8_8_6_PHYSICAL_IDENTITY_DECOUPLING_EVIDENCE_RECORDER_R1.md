# Phase 4.3.5.6 / V8.8.6 — Physical Identity Decoupling + Evidence Recorder R1

## Objective

V8.8.6 keeps the V8.8.5 canonical physical-object architecture and addresses two remaining classes of failure:

1. **identity continuity** — a product identity must not disappear merely because cashier quantity is held, a LIVE track splits briefly, or a high-quality earlier frame is replaced by a weaker frame; and
2. **diagnostic observability** — one ARS Dev Center action must produce a time-correlated evidence bundle containing logs, visual captures, screen video (when operator-authorized), scanner telemetry, decision evidence, ground truth, replay data and integrity hashes.

No recognition threshold is lowered.

## Scanner changes

### Identity / quantity decoupling

`VisualScanObject.identityMatch` owns recognized identity. `VisualScanObject.match` remains the quantity-authorized match. A product can therefore remain visibly recognized while Safety Kernel/physical truth holds quantity. `canCommitQuantity` still requires a non-null quantity match and all physical quantity gates.

### Locked best-evidence carry-forward

`PersistentObjectEvidenceCache` retains bounded best identity evidence for a LIVE object. A short LIVE track split may inherit the previous product hint for identity retrieval only. The cache cannot create quantity or bypass the final recognition engine.

### Sticky identity-owner fallback

When the current LIVE identity owner disappears because of a brief tracker split, V8.8.6 attempts a bounded same-lane geometry continuity rebind. The fallback window is `IDENTITY_OWNER_FALLBACK_MAX_GAP_MS=1250`. A fallback is telemetry-visible as `LIVE_IDENTITY_OWNER_FALLBACK`. Completed identities are released normally so multi-object scheduling can progress.

### Independent NORMAL completeness + shared-foreground merge veto

A coarse foreground component is no longer sufficient to collapse two spatially separated, independently complete NORMAL objects. The canonical resolver applies an explicit shared-foreground merge veto and reports `sharedForegroundMergeVetoes`.

### Elongated-ambiguous evidence lane

Elongated geometry that is not sufficient to establish NORMAL-vs-LONG type truth is marked with `elongatedAmbiguous` metadata. This is an evidence-routing state, not a transaction lane: it does not grant quantity and does not change recognition thresholds.

### Ground Truth enforcement

Operator confirmation is written as `TEACH_CONFIRMED_BEFORE_PROMOTION` before an adaptive learned reference can be promoted. Promotion is then separately recorded. Self-learning remains `ACTIVE_CONFIRMED_ONLY`.

## ARS Visual Diagnostic Recorder V1

ARS Dev Center can start an operator-consented Android MediaProjection recording. Android 14 requires a new screen-capture consent for each recording session. The service runs as a `mediaProjection` foreground service and records video only; diagnostic audio is not captured.

When **CHATGPT + EVIDENCE ZIP** is pressed, ARS POS performs one export transaction:

1. request screen-recorder stop and finalize MP4;
2. drain pending visual-evidence writes within a bounded timeout;
3. snapshot/redact flight logs;
4. extract scanner and performance event streams;
5. generate automatic failure bookmarks with `videoTimestampMs`;
6. copy evidence sessions, decision ledger, ground truth, replay artifacts and visual crops;
7. select recent diagnostic keyframes;
8. write screen-video metadata including timestamp-correlated session IDs;
9. write package metadata and SHA-256 integrity manifest; and
10. compress everything into one ZIP and hand it to the Android share flow, preferring ChatGPT when installed.

If video or a pending evidence write fails, export remains partial-failure tolerant. The manifest states which component was unavailable instead of silently discarding the whole report.

## Diagnostic bundle contract

Expected top-level structure:

```text
ARS_DIAGNOSTIC_V8_8_6_<timestamp>.zip
├── report/
├── logs/
├── scanner/
├── performance/
├── bookmarks/
├── screenshots/
├── screen_recording/
├── evidence/<sessionId>/
├── package_manifest.json
├── package_info.json
└── integrity/sha256_manifest.json
```

Correlation fields remain authoritative where available: `sessionId`, `proposalId`, `frame/timestamp`, `trackId`, `physicalObjectId`, `persistentPhysicalId`, `candidateProductId`, `decisionRuleId`, and `videoTimestampMs`.

Secrets such as bearer credentials, API keys, gateway tokens and passwords are redacted from exported textual diagnostics.

## Retained safety invariants

- package `com.arspos.anglerriausyndicate`;
- Room DB v5;
- official ARS signing channel;
- in-place update only;
- all 14 recognition thresholds unchanged;
- Cloud Identity `SHADOW`;
- Self Learning `ACTIVE_CONFIRMED_ONLY`;
- AI Engineer `DEV_CENTER_DIAGNOSTIC_ONLY` and outside the critical scan path;
- Object Lock Before Identity;
- canonical/persistent physical-object truth;
- two-stage candidate retrieval + exact re-rank;
- Safety Kernel, Decision Evidence Ledger, Ground Truth and Replay V4;
- no AI/cloud path may directly create quantity, alter stock/payment or relax recognition thresholds.

## Acceptance criteria

Source/build success is not Smart Scan acceptance. Real-device testing must verify:

- identity remains visible when quantity is correctly held;
- no duplicate quantity is introduced by identity/quantity decoupling;
- brief LIVE track splits can rebind without identity-owner thrashing;
- fallback never crosses NORMAL/LONG lane boundaries;
- independently complete objects sharing one coarse foreground component remain independent;
- elongated ambiguity does not manufacture type or quantity;
- one-tap diagnostic ZIP contains the expected evidence and valid hashes;
- video bookmarks align with visible lock/track/candidate events;
- diagnostic video capture does not materially destabilize scanner latency or memory;
- crash/ANR/native crash remains zero in the acceptance window;
- update `207 -> 208` succeeds in place with official signer and DB v5 preserved.
