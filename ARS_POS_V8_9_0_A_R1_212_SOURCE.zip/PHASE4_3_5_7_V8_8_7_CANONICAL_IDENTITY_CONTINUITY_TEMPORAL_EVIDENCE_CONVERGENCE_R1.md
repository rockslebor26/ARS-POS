# Phase 4.3.5.7 / V8.8.7 — Canonical Identity Continuity + Temporal Evidence Convergence R1

## Mission

V8.8.7 is a convergence phase, not a feature-expansion phase. It keeps the V8.8.6 physical-truth, quantity-safety and diagnostic architecture and addresses the verified bottleneck: one physical object may remain locked while transient `LIVE-*` identity ownership changes and identity evidence is fragmented.

Primary invariant:

`ONE PHYSICAL OBJECT -> ONE CANONICAL IDENTITY -> ACCUMULATED EVIDENCE -> PRODUCT IDENTITY -> SAFE QUANTITY`

Recognition thresholds are unchanged.

## Project Target Lock

ARS Dev Center now exposes **PROJECT TARGET / PHASE GATE**. It contains the permanent goal, non-negotiable rules, V8.8.6 real-device baseline, V8.8.7 current mission, engineering targets and regression guard. A phase is not considered complete merely because the APK compiles.

Phase states:

`IMPLEMENTED -> TESTING -> EVIDENCE VERIFIED -> TARGET PASSED -> CLOSED`

## Canonical identity continuity

`CanonicalIdentityContinuity` owns identity memory above transient tracker IDs. Bounded same-lane geometry continuity can map `LIVE-4 -> LIVE-5 -> LIVE-7` to one `CID-*` without resetting identity evidence. Old transient aliases remain bounded by the canonical TTL so selected-track/owner recovery can resolve a rebind.

The canonical layer is advisory only. It cannot accept a product, create cart quantity, relax thresholds, or bypass `SmartRecognitionEngine` / Safety Kernel.

Telemetry includes canonical generation, transient rebind count, null-owner transitions, evidence-transfer count, reset count, fused candidate, fused margin and independent-evidence count.

## Temporal Top-K evidence fusion

Each canonical identity retains a bounded Top-K candidate history. Evidence is weighted by independence: repeated nearly-identical frames receive reduced weight, while sufficiently separated views/time receive full weight. OCR/high-resolution evidence can add bounded quality weight.

The fused candidate is a retrieval/final-recall seed only. Final product acceptance still uses the unchanged recognition rules.

## Identity scheduling after physical lock

Live identity cooldown now follows the canonical identity key rather than transient `LIVE-*` IDs. A tracker rebind therefore does not restart the identity budget from zero. Identity scheduling remains object-scoped and quantity-independent.

Cooldowns are tightened for convergence while remaining bounded:
- normal identity retry: 450 ms;
- ambiguous retry: 700 ms;
- high-resolution retry: 1500 ms;
- static ambiguity bounded retry: 2200 ms;
- max ambiguous evaluations before view-change hold: 6.

## High-resolution LONG identity

V8.8.6 returned no result for LONG in the high-resolution ambiguity path. V8.8.7 removes that dead-end. A physically trusted LONG track may use the high-resolution frame with anchor-aware references and role-discriminative scoring. Live MATCHED remains preview-only and requires physical temporal trust; final quantity is still final-scan/Safety-Kernel owned.

## Role-discriminative LONG evidence

LONG scoring continues to use FULL/HANDLE/SIDE/TIP references. V8.8.7 derives a product-local role composite when physical anchor confidence is adequate and at least two role families are available. A relative delta is bounded to `-4..+4` points, preserving score scale and leaving all acceptance thresholds unchanged. Telemetry exposes role composites/deltas and explicitly records that thresholds were not changed.

## NORMAL local completeness V2

Scene-wide foreground ownership can include floor/table/background and incorrectly mark a complete compact package as partial. V8.8.7 re-measures completeness in an expanded local ROI around the canonical NORMAL object. If the local owner reaches the ROI edge it remains PARTIAL; otherwise local owner/crop geometry may verify completeness. Purity, ownership-conflict and identity gates remain independent.

## Ground Truth V2

Ground-truth entries now contain structured fields for predicted product, operator-confirmed product, learned-reference ID/SHA-256 and `predictionCorrect`. Operator confirmation is still required before learned-reference promotion.

## Protected architecture / regression guard

The following must not regress:
- package `com.arspos.anglerriausyndicate`;
- Room DB v5;
- official ARS release signing and in-place updates;
- all 14 recognition thresholds unchanged;
- Object Lock Before Identity;
- canonical/persistent physical truth;
- Rod Authenticity, Anchor Role Truth, Package Edge Firewall;
- Physical Quantity Safety / Safety Kernel;
- two-stage Top-K retrieval + exact re-rank;
- Decision Evidence Ledger, Ground Truth, Replay V4;
- ViewModel finalization;
- Visual Diagnostic Recorder / one-tap CHATGPT evidence bundle;
- Cloud Identity `SHADOW`, Self Learning `ACTIVE_CONFIRMED_ONLY`, AI Engineer `DEV_CENTER_DIAGNOSTIC_ONLY`.

## V8.8.6 baseline and V8.8.7 targets

Validated V8.8.6 evidence baseline:
- 10/10 scans completed;
- crash/ANR/native crash/evidence error = 0;
- first candidate observed as high as 12.434 s;
- live MATCHED in analyzed updates = 0;
- physical rod truth was substantially stable;
- identity owner churn remained the principal convergence fault.

V8.8.7 engineering targets for known objects with adequate evidence:
- physical lock <= 800 ms;
- first meaningful candidate <= 1.5 s;
- stable identity <= 3.0 s;
- same-physical-object canonical reset = 0;
- false automatic quantity = 0;
- duplicate physical quantity = 0;
- threshold relaxation = 0;
- crash/ANR/evidence corruption = 0.

These are real-device acceptance targets, not claims made by source-level validation.
