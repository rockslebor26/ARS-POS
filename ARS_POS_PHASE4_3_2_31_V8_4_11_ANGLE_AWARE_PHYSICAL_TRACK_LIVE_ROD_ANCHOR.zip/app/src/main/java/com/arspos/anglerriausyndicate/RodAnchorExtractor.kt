package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max

/**
 * V8.4.11 live rod-anchor extractor.
 *
 * The oriented LONG crop is canonicalized left-to-right. The endpoint with the
 * larger sustained mass/texture is treated as HANDLE; the opposite endpoint is
 * TIP. This lets live HANDLE/SIDE/TIP evidence be compared only with the same
 * master anchor type instead of comparing one full crop against every anchor.
 */
object RodAnchorExtractor {
    data class Anchors(
        val handle: Bitmap,
        val side: Bitmap,
        val tip: Bitmap,
        val handleOnLeft: Boolean
    ) {
        fun recycle() {
            listOf(handle, side, tip).distinct().forEach { if (!it.isRecycled) it.recycle() }
        }
    }

    fun extract(orientedRod: Bitmap): Anchors? {
        if (orientedRod.width < 72 || orientedRod.height < 24) return null
        val endpointFraction = 0.34f
        val handleOnLeft = endpointEnergy(orientedRod, true) >= endpointEnergy(orientedRod, false)

        val endpointW = max(36, (orientedRod.width * endpointFraction).toInt()).coerceAtMost(orientedRod.width)
        val tipW = max(30, (orientedRod.width * 0.28f).toInt()).coerceAtMost(orientedRod.width)
        val sideW = max(48, (orientedRod.width * 0.52f).toInt()).coerceAtMost(orientedRod.width)
        val sideLeft = ((orientedRod.width - sideW) / 2).coerceAtLeast(0)

        return runCatching {
            val handleLeft = if (handleOnLeft) 0 else orientedRod.width - endpointW
            val tipLeft = if (handleOnLeft) orientedRod.width - tipW else 0
            Anchors(
                handle = Bitmap.createBitmap(orientedRod, handleLeft, 0, endpointW, orientedRod.height),
                side = Bitmap.createBitmap(orientedRod, sideLeft, 0, sideW, orientedRod.height),
                tip = Bitmap.createBitmap(orientedRod, tipLeft, 0, tipW, orientedRod.height),
                handleOnLeft = handleOnLeft
            )
        }.getOrNull()
    }

    private fun endpointEnergy(bitmap: Bitmap, left: Boolean): Float {
        val w = max(24, (bitmap.width * 0.30f).toInt()).coerceAtMost(bitmap.width)
        val startX = if (left) 0 else bitmap.width - w
        val stepX = max(1, w / 36)
        val stepY = max(1, bitmap.height / 24)
        var texture = 0f
        var darkMass = 0f
        var samples = 0

        var y = 0
        while (y < bitmap.height) {
            var x = startX
            while (x < startX + w) {
                val current = luminance(bitmap.getPixel(x, y))
                val x2 = (x + stepX).coerceAtMost(startX + w - 1)
                val y2 = (y + stepY).coerceAtMost(bitmap.height - 1)
                texture += abs(current - luminance(bitmap.getPixel(x2, y)))
                texture += abs(current - luminance(bitmap.getPixel(x, y2)))
                darkMass += (1f - current).coerceIn(0f, 1f)
                samples++
                x += stepX
            }
            y += stepY
        }
        if (samples == 0) return 0f
        return texture / samples.toFloat() * 0.62f + darkMass / samples.toFloat() * 0.38f
    }

    private fun luminance(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
}
