package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.31 V8.4.11 — deterministic global LONG physical-track resolver.
 *
 * Physical identity is resolved globally after all LONG proposals are present.
 * Two crossing axes stay separate even if their bounding rectangles overlap.
 * ML-only boxes can support exactly one resolved track; if they span multiple
 * tracks they become CROSS_LANE evidence-only and never affect quantity.
 */
object RodPhysicalTrackResolver {
    private const val MIN_AXIS_CONFIDENCE = 32
    private const val MIN_TRACK_STRUCTURE = 32
    private const val SAME_TRACK_ANGLE = 13f
    private const val CROSSING_ANGLE = 18f

    data class Result(
        val proposals: List<ScanProposal>,
        val trackCount: Int,
        val crossingPairsPreserved: Int,
        val crossLaneSuppressed: Int
    )

    fun resolve(input: List<ScanProposal>): Result {
        if (input.isEmpty()) return Result(emptyList(), 0, 0, 0)

        val suppressed = input.filter { it.bridgeSuppressed || it.proposalType == ScanProposal.TYPE_AMBIGUOUS_CONTAINER }.toMutableList()
        val usable = input.filterNot { it.bridgeSuppressed || it.proposalType == ScanProposal.TYPE_AMBIGUOUS_CONTAINER }
        val axisCandidates = usable.filter {
            it.hasResolvedAxis && it.axisConfidence >= MIN_AXIS_CONFIDENCE && it.rodStructureScore >= MIN_TRACK_STRUCTURE
        }
        val fallback = usable.filterNot { axisCandidates.contains(it) }

        val groups = mutableListOf<MutableList<ScanProposal>>()
        axisCandidates.sortedWith(
            compareByDescending<ScanProposal> { it.rodStructureScore }
                .thenByDescending { it.axisConfidence }
                .thenByDescending { it.strength }
        ).forEach { candidate ->
            val group = groups.firstOrNull { current -> current.all { sameTrack(it, candidate) } }
            if (group == null) groups += mutableListOf(candidate) else group += candidate
        }

        // If the angle-aware analyzer could not establish any track, retain one
        // conservative ML fallback per clearly separated long box. This avoids a
        // regression on difficult rods while still refusing local duplicate IDs.
        if (groups.isEmpty()) {
            val fallbackGroups = mutableListOf<MutableList<ScanProposal>>()
            fallback.sortedByDescending { it.strength }.forEach { candidate ->
                val group = fallbackGroups.firstOrNull { current ->
                    current.all { rectFallbackSameTrack(it.normalizedBounds, candidate.normalizedBounds) }
                }
                if (group == null) fallbackGroups += mutableListOf(candidate) else group += candidate
            }
            val tracks = fallbackGroups.take(3).mapIndexed { index, group ->
                mergeTrack(group, "TRACK-${index + 1}")
            }
            return Result(tracks + suppressed, tracks.size, 0, suppressed.count { it.source == ScanProposal.SOURCE_CROSS_LANE })
        }

        var tracks = groups.mapIndexed { index, group -> mergeTrack(group, "TRACK-${index + 1}") }.toMutableList()
        val mlSupport = IntArray(tracks.size)

        // ML proposals are independent support for an angle-aware track. They do
        // not create quantity by themselves once real axes exist. A proposal that
        // touches two tracks is explicitly CROSS_LANE evidence-only.
        fallback.forEach { candidate ->
            val hits = tracks.withIndex().filter { (_, track) -> supportsTrack(candidate, track) }
            when (hits.size) {
                1 -> {
                    val i = hits.first().index
                    if (candidate.source == ScanProposal.SOURCE_MLKIT) mlSupport[i]++
                    tracks[i] = mergeTrack(listOf(tracks[i], candidate), tracks[i].physicalInstanceHint)
                }
                0 -> {
                    suppressed += candidate.copy(
                        proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                        source = ScanProposal.SOURCE_BACKGROUND,
                        physicalInstanceHint = "UNRESOLVED-${candidate.proposalId}",
                        quantityEligible = false,
                        bridgeSuppressed = true
                    )
                }
                else -> {
                    suppressed += candidate.copy(
                        proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                        source = ScanProposal.SOURCE_CROSS_LANE,
                        physicalInstanceHint = "CROSS-LANE-${candidate.proposalId}",
                        quantityEligible = false,
                        bridgeSuppressed = true
                    )
                }
            }
        }

        // When ML Kit has successfully supported at least one physical axis in a
        // multi-object scene, unsupported analyzer-only tracks are treated as
        // background evidence. This specifically blocks tile/grout axes from
        // becoming third/fourth phantom rods. If ML supports nothing, analyzer
        // tracks remain available as the conservative fallback path.
        if (mlSupport.any { it > 0 }) {
            val retained = ArrayList<ScanProposal>()
            tracks.forEachIndexed { index, track ->
                if (mlSupport[index] > 0) {
                    retained += track
                } else {
                    suppressed += track.copy(
                        proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                        source = ScanProposal.SOURCE_BACKGROUND,
                        physicalInstanceHint = "UNSUPPORTED-${track.physicalInstanceHint}",
                        quantityEligible = false,
                        bridgeSuppressed = true
                    )
                }
            }
            tracks = retained.mapIndexed { index, track ->
                track.copy(
                    physicalInstanceHint = "TRACK-${index + 1}",
                    lineageId = "TRACK-LINEAGE-TRACK-${index + 1}"
                )
            }.toMutableList()
        }

        var crossingPairs = 0
        for (i in tracks.indices) for (j in i + 1 until tracks.size) {
            val a = tracks[i]
            val b = tracks[j]
            if (a.hasResolvedAxis && b.hasResolvedAxis &&
                angleDifference(a.axisAngleDeg, b.axisAngleDeg) >= CROSSING_ANGLE &&
                segmentsNearOrCross(a, b)
            ) crossingPairs++
        }

        return Result(
            proposals = tracks + suppressed,
            trackCount = tracks.size,
            crossingPairsPreserved = crossingPairs,
            crossLaneSuppressed = suppressed.count { it.source == ScanProposal.SOURCE_CROSS_LANE }
        )
    }

    fun crossingPairs(proposals: List<ScanProposal>): Int {
        val tracks = proposals.filter { it.proposalType == ScanProposal.TYPE_LONG && it.physicalInstanceHint.startsWith("TRACK-") }
        var count = 0
        for (i in tracks.indices) for (j in i + 1 until tracks.size) {
            if (angleDifference(tracks[i].axisAngleDeg, tracks[j].axisAngleDeg) >= CROSSING_ANGLE && segmentsNearOrCross(tracks[i], tracks[j])) count++
        }
        return count
    }

    private fun sameTrack(a: ScanProposal, b: ScanProposal): Boolean {
        if (!a.hasResolvedAxis || !b.hasResolvedAxis) return false
        if (angleDifference(a.axisAngleDeg, b.axisAngleDeg) > SAME_TRACK_ANGLE) return false
        val distance = symmetricLineDistance(a, b)
        val width = max(a.axisWidthPx, b.axisWidthPx).coerceAtLeast(24)
        if (distance > width * 0.72f + 12f) return false
        return axisProjectionOverlap(a, b) >= 0.28f
    }

    private fun supportsTrack(candidate: ScanProposal, track: ScanProposal): Boolean {
        if (!track.hasResolvedAxis) return false
        val cx = (candidate.normalizedBounds.left + candidate.normalizedBounds.right) * 0.5f
        val cy = (candidate.normalizedBounds.top + candidate.normalizedBounds.bottom) * 0.5f
        val distance = pointToSegmentDistance(
            cx, cy,
            track.axisStartX.toFloat(), track.axisStartY.toFloat(),
            track.axisEndX.toFloat(), track.axisEndY.toFloat()
        )
        val shortAxis = min(candidate.normalizedBounds.width(), candidate.normalizedBounds.height()).coerceAtLeast(1)
        val limit = max(track.axisWidthPx * 1.25f, shortAxis * 0.85f) + 10f
        if (distance > limit) return false
        val overlap = intersectionOverSmaller(candidate.normalizedBounds, track.normalizedBounds)
        return overlap >= 0.12f || centerProjectionInside(candidate, track)
    }

    private fun centerProjectionInside(candidate: ScanProposal, track: ScanProposal): Boolean {
        val px = (candidate.normalizedBounds.left + candidate.normalizedBounds.right) * 0.5f
        val py = (candidate.normalizedBounds.top + candidate.normalizedBounds.bottom) * 0.5f
        val ax = track.axisStartX.toFloat()
        val ay = track.axisStartY.toFloat()
        val bx = track.axisEndX.toFloat()
        val by = track.axisEndY.toFloat()
        val vx = bx - ax
        val vy = by - ay
        val len2 = vx * vx + vy * vy
        if (len2 <= 1f) return false
        val t = ((px - ax) * vx + (py - ay) * vy) / len2
        return t in -0.10f..1.10f
    }

    private fun mergeTrack(group: List<ScanProposal>, trackId: String): ScanProposal {
        val axisSource = group.filter { it.hasResolvedAxis }.maxWithOrNull(
            compareBy<ScanProposal> { it.rodStructureScore }
                .thenBy { it.axisConfidence }
                .thenBy { it.strength }
        )
        val representative = axisSource ?: group.maxByOrNull { it.strength } ?: group.first()
        val ids = group.flatMap { it.proposalId.split('+') }.filter { it.isNotBlank() }.distinct().joinToString("+")
        val sources = group.map { it.source }.distinct()
        val mergedBounds = if (axisSource != null) Rect(axisSource.normalizedBounds) else union(group.map { it.normalizedBounds })
        val originalBounds = if (axisSource != null) Rect(axisSource.originalBounds) else union(group.map { it.originalBounds })

        return representative.copy(
            proposalId = ids.ifBlank { representative.proposalId },
            source = if (sources.size == 1) sources.first() else ScanProposal.SOURCE_MERGED,
            proposalType = ScanProposal.TYPE_LONG,
            originalBounds = originalBounds,
            normalizedBounds = mergedBounds,
            lineageId = "TRACK-LINEAGE-$trackId",
            physicalInstanceHint = trackId,
            quantityEligible = true,
            bridgeSuppressed = false,
            rodStructureScore = group.maxOfOrNull { it.rodStructureScore } ?: representative.rodStructureScore,
            strength = group.maxOfOrNull { it.strength } ?: representative.strength,
            axisAngleDeg = axisSource?.axisAngleDeg ?: representative.axisAngleDeg,
            axisStartX = axisSource?.axisStartX ?: representative.axisStartX,
            axisStartY = axisSource?.axisStartY ?: representative.axisStartY,
            axisEndX = axisSource?.axisEndX ?: representative.axisEndX,
            axisEndY = axisSource?.axisEndY ?: representative.axisEndY,
            axisWidthPx = axisSource?.axisWidthPx ?: representative.axisWidthPx,
            axisConfidence = axisSource?.axisConfidence ?: representative.axisConfidence,
            orientation = axisSource?.orientation ?: representative.orientation
        )
    }

    private fun segmentsNearOrCross(a: ScanProposal, b: ScanProposal): Boolean {
        val d1 = segmentDistance(
            a.axisStartX.toFloat(), a.axisStartY.toFloat(), a.axisEndX.toFloat(), a.axisEndY.toFloat(),
            b.axisStartX.toFloat(), b.axisStartY.toFloat(), b.axisEndX.toFloat(), b.axisEndY.toFloat()
        )
        return d1 <= max(a.axisWidthPx, b.axisWidthPx).coerceAtLeast(30) * 1.4f
    }

    private fun symmetricLineDistance(a: ScanProposal, b: ScanProposal): Float {
        val aMidX = (a.axisStartX + a.axisEndX) * 0.5f
        val aMidY = (a.axisStartY + a.axisEndY) * 0.5f
        val bMidX = (b.axisStartX + b.axisEndX) * 0.5f
        val bMidY = (b.axisStartY + b.axisEndY) * 0.5f
        val d1 = pointToSegmentDistance(aMidX, aMidY, b.axisStartX.toFloat(), b.axisStartY.toFloat(), b.axisEndX.toFloat(), b.axisEndY.toFloat())
        val d2 = pointToSegmentDistance(bMidX, bMidY, a.axisStartX.toFloat(), a.axisStartY.toFloat(), a.axisEndX.toFloat(), a.axisEndY.toFloat())
        return (d1 + d2) * 0.5f
    }

    private fun axisProjectionOverlap(a: ScanProposal, b: ScanProposal): Float {
        val ax = a.axisStartX.toFloat()
        val ay = a.axisStartY.toFloat()
        val bx = a.axisEndX.toFloat()
        val by = a.axisEndY.toFloat()
        val vx = bx - ax
        val vy = by - ay
        val length = hypot(vx, vy).coerceAtLeast(1f)
        val ux = vx / length
        val uy = vy / length
        fun projection(x: Float, y: Float): Float = (x - ax) * ux + (y - ay) * uy
        val a0 = 0f
        val a1 = length
        val b0 = projection(b.axisStartX.toFloat(), b.axisStartY.toFloat())
        val b1 = projection(b.axisEndX.toFloat(), b.axisEndY.toFloat())
        val bMin = min(b0, b1)
        val bMax = max(b0, b1)
        val overlap = (min(a1, bMax) - max(a0, bMin)).coerceAtLeast(0f)
        val bLength = abs(bMax - bMin).coerceAtLeast(1f)
        return overlap / min(length, bLength).coerceAtLeast(1f)
    }

    private fun rectFallbackSameTrack(a: Rect, b: Rect): Boolean {
        val inter = intersectionOverSmaller(a, b)
        if (inter >= 0.68f) return true
        val caX = (a.left + a.right) * 0.5f
        val caY = (a.top + a.bottom) * 0.5f
        val cbX = (b.left + b.right) * 0.5f
        val cbY = (b.top + b.bottom) * 0.5f
        val dist = hypot(caX - cbX, caY - cbY)
        val scale = min(hypot(a.width().toFloat(), a.height().toFloat()), hypot(b.width().toFloat(), b.height().toFloat())).coerceAtLeast(1f)
        return dist <= scale * 0.16f
    }

    private fun segmentDistance(
        ax: Float, ay: Float, bx: Float, by: Float,
        cx: Float, cy: Float, dx: Float, dy: Float
    ): Float {
        if (segmentsIntersect(ax, ay, bx, by, cx, cy, dx, dy)) return 0f
        return minOf(
            pointToSegmentDistance(ax, ay, cx, cy, dx, dy),
            pointToSegmentDistance(bx, by, cx, cy, dx, dy),
            pointToSegmentDistance(cx, cy, ax, ay, bx, by),
            pointToSegmentDistance(dx, dy, ax, ay, bx, by)
        )
    }

    private fun segmentsIntersect(ax: Float, ay: Float, bx: Float, by: Float, cx: Float, cy: Float, dx: Float, dy: Float): Boolean {
        fun cross(px: Float, py: Float, qx: Float, qy: Float, rx: Float, ry: Float): Float =
            (qx - px) * (ry - py) - (qy - py) * (rx - px)
        val c1 = cross(ax, ay, bx, by, cx, cy)
        val c2 = cross(ax, ay, bx, by, dx, dy)
        val c3 = cross(cx, cy, dx, dy, ax, ay)
        val c4 = cross(cx, cy, dx, dy, bx, by)
        return (c1 == 0f || c2 == 0f || c1 * c2 <= 0f) && (c3 == 0f || c4 == 0f || c3 * c4 <= 0f)
    }

    private fun pointToSegmentDistance(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val vx = bx - ax
        val vy = by - ay
        val len2 = vx * vx + vy * vy
        if (len2 <= 1e-5f) return hypot(px - ax, py - ay)
        val t = (((px - ax) * vx + (py - ay) * vy) / len2).coerceIn(0f, 1f)
        val qx = ax + vx * t
        val qy = ay + vy * t
        return hypot(px - qx, py - qy)
    }

    private fun intersectionOverSmaller(a: Rect, b: Rect): Float {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val inter = (right - left).toLong() * (bottom - top).toLong()
        val smaller = min(a.width().toLong() * a.height().toLong(), b.width().toLong() * b.height().toLong()).coerceAtLeast(1L)
        return inter.toFloat() / smaller.toFloat()
    }

    private fun union(rects: List<Rect>): Rect {
        if (rects.isEmpty()) return Rect()
        return Rect(
            rects.minOf { it.left }, rects.minOf { it.top },
            rects.maxOf { it.right }, rects.maxOf { it.bottom }
        )
    }

    private fun normalizedAngle(angle: Float): Float {
        var a = angle
        while (a > 90f) a -= 180f
        while (a <= -90f) a += 180f
        return a
    }

    private fun angleDifference(a: Float, b: Float): Float {
        var d = abs(normalizedAngle(a) - normalizedAngle(b))
        if (d > 90f) d = 180f - d
        return d
    }
}
