package com.arspos.anglerriausyndicate

import android.graphics.Rect

/**
 * Phase 4.3.2.31 V8.4.11 — canonical scanner proposal metadata.
 *
 * All proposal engines publish coordinates in the canonical customer-photo
 * coordinate system. LONG proposals can additionally carry a real geometric
 * axis. `physicalInstanceHint` becomes a resolved TRACK-* identity only after
 * the global physical-track resolver has compared every LONG proposal in the
 * scene. This prevents a local detector from deciding cashier quantity too
 * early.
 */
data class ScanProposal(
    val proposalId: String,
    val source: String,
    val proposalType: String,
    val originalBounds: Rect,
    val normalizedBounds: Rect,
    val rotationDegrees: Int = 0,
    val lineageId: String,
    val physicalInstanceHint: String = "",
    val quantityEligible: Boolean = true,
    val bridgeSuppressed: Boolean = false,
    val normalOwnershipConflict: Boolean = false,
    val rodStructureScore: Int = 0,
    val orientation: String = "UNKNOWN",
    val strength: Int = 0,
    val axisAngleDeg: Float = 0f,
    val axisStartX: Int = 0,
    val axisStartY: Int = 0,
    val axisEndX: Int = 0,
    val axisEndY: Int = 0,
    val axisWidthPx: Int = 0,
    val axisConfidence: Int = 0
) {
    val hasResolvedAxis: Boolean
        get() = axisConfidence > 0 &&
            (axisStartX != axisEndX || axisStartY != axisEndY)

    companion object {
        const val TYPE_NORMAL = "NORMAL_OBJECT"
        const val TYPE_LONG = "LONG_OBJECT"
        const val TYPE_RESCUE = "FULL_FRAME_RESCUE"
        const val TYPE_AMBIGUOUS_CONTAINER = "AMBIGUOUS_CONTAINER"

        const val SOURCE_MLKIT = "MLKIT"
        const val SOURCE_LONG = "LONG_ANALYZER"
        const val SOURCE_MERGED = "MERGED"
        const val SOURCE_RESCUE = "FULL_FRAME_RESCUE"
        const val SOURCE_SCENE_BARCODE = "SCENE_BARCODE"
        const val SOURCE_BRIDGE = "BRIDGE_SUPPRESSED"
        const val SOURCE_CROSS_LANE = "CROSS_LANE_SUPPRESSED"
        const val SOURCE_BACKGROUND = "BACKGROUND_REJECTED"
        const val SOURCE_TRACK = "PHYSICAL_TRACK"
    }
}
