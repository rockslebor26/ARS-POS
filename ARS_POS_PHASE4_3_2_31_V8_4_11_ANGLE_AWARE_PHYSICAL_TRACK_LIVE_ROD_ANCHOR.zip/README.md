# ARS POS — ANGLER RIAU SYNDICATE

Current development release candidate:

- Phase **4.3.2.31**
- Engine **V8.4.11 — Angle-Aware Physical Track + Live Rod Anchor Identity**
- Version **1.4.6**
- versionCode **146**
- Database **5 (unchanged)**
- Package **com.arspos.anglerriausyndicate**
- Signing channel **ARS POS OFFICIAL RELEASE**

## V8.4.11 focus
V8.4.10 field diagnostics showed the remaining rod-recognition problem is primarily LONG geometry/physical-instance identity, not a need for lower recognition thresholds. V8.4.11 therefore adds:

- arbitrary-angle rod axis metadata and canonical coordinate normalization;
- deterministic global `TRACK-*` physical-instance resolution;
- LONG-vs-LONG crossing-axis preservation before merge;
- anti-bridge and background evidence-only suppression;
- axis-aware rod-structure background rejection V2;
- narrow oriented LONG crop instead of broad scene bands;
- live HANDLE/SIDE/TIP anchor extraction and same-type master matching;
- physical-track quantity safety;
- decision/axis/crossing/memory telemetry;
- unchanged conservative recognition thresholds and evidence-only full-frame rescue.

Install V8.4.11 directly over V8.4.10 Official. Do **not** uninstall the official app. The official signer must remain identical.

See `PHASE4_3_2_31_V8_4_11_ANGLE_AWARE_PHYSICAL_TRACK_LIVE_ROD_ANCHOR.md`.
