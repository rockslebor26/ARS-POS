# ARS POS PROJECT CONTINUITY

Baseline pengembangan resmi berikutnya: **Phase 4.3.2.31 / V8.4.11 / 1.4.6 (146)**.

Update chain resmi:
- V8.4.6 Official: 1.4.1 (141)
- V8.4.7: 1.4.2 (142) — IN_PLACE_UPDATE terbukti berhasil
- V8.4.8: 1.4.3 (143) — multi-object physical-instance separation + scanner hardening
- V8.4.9: 1.4.4 (144) — rod anchor identity + cross-lane scene gate + cached long matcher
- V8.4.10: 1.4.5 (145) — anchor-preserving rod shortlist + deterministic identity evidence; field diagnostic baseline
- V8.4.11: 1.4.6 (146) — angle-aware physical tracks + LONG-vs-LONG cross-axis separation + live HANDLE/SIDE/TIP anchors

Aturan permanen:
- applicationId tetap `com.arspos.anglerriausyndicate`
- ARS POS OFFICIAL RELEASE signer harus tetap identik
- versionCode selalu meningkat
- jangan uninstall official app ketika menguji update berikutnya
- UNKNOWN lebih aman daripada salah SKU
- jangan menurunkan recognition threshold hanya agar produk terlihat dikenali
- AMBIGUOUS_CONTAINER/bridge/CROSS_LANE/FULL_FRAME_RESCUE tidak boleh membuat quantity baru
- quantity LONG berasal dari resolved `TRACK-*`, bukan jumlah proposal
- same SKU + physical track berbeda boleh menjadi quantity > 1
- database tetap version 5 kecuali ada migration yang benar-benar diperlukan

Fokus validasi V8.4.11:
1. 1 rod -> exactly 1 LONG `TRACK-*`
2. 2 rod sejajar -> exactly 2 LONG tracks
3. 2 rod silang -> exactly 2 LONG tracks dan crossing pair preserved
4. 2 rod + produk NORMAL -> 2 LONG tracks + 1 NORMAL object
5. nat keramik/background linear -> tidak boleh menjadi sellable LONG quantity
6. repeated scan 1 rod -> physical count stabil 1
7. rod identity memakai oriented crop + live HANDLE/SIDE/TIP ke master anchor sejenis
8. rod mirip dengan margin tidak cukup -> UNKNOWN, threshold tidak diturunkan
9. full-frame rescue tetap quantityEligible=false
10. decision rule, visual margin, anchor score/margin, axis angle/confidence tercatat
11. native heap/PSS/temp crop telemetry tetap sehat
12. update 1.4.5 (145) -> 1.4.6 (146) harus IN_PLACE_UPDATE dengan package/signer sama

Lihat `PHASE4_3_2_31_V8_4_11_ANGLE_AWARE_PHYSICAL_TRACK_LIVE_ROD_ANCHOR.md`.
