package com.arspos.anglerriausyndicate

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arspos.anglerriausyndicate.data.*
import com.arspos.anglerriausyndicate.data.db.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

class PosViewModel(app:Application):AndroidViewModel(app){
    private val repo=ProductionRepository(ArsDatabase.get(app))
    val query=MutableStateFlow("")
    val products=query.flatMapLatest(repo::search).stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    private val _cart=MutableStateFlow<List<CartLine>>(emptyList())
    val cart=_cart.asStateFlow()
    private val scanCommitLock = Any()
    private val committedScanSessions = LinkedHashSet<String>()
    private var reviewSessionId = ""
    private var reviewProducts = emptyMap<Long, ProductEntity>()
    val subtotal=_cart.map{it.sumOf(CartLine::subtotal)}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0L)
    private val start=Calendar.getInstance().apply{
        set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)
    }.timeInMillis
    val revenue=repo.revenue(start).stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0L)
    val transactions=repo.transactionCount(start).stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0)
    val cashBalance=repo.cashBalance().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0L)
    val sales=repo.sales().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val customers=repo.customers().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    init{viewModelScope.launch{repo.seed()}}
    fun search(s:String){query.value=s}
    fun add(p:ProductEntity): Unit = synchronized(scanCommitLock){
        if(p.stock<=0) return@synchronized
        val x=_cart.value.find{it.product.id==p.id}
        if(x==null){
            _cart.value=_cart.value+CartLine(p,1)
        }else if(x.quantity < p.stock){
            _cart.value=_cart.value.map{if(it.product.id==p.id)it.copy(quantity=it.quantity+1)else it}
        }
    }
    /**
     * V8.4.20 atomic quantity confirmation + duplicate-session guard.
     * One scan session can mutate the cart only once, even if the operator
     * double-taps CONFIRM. A new scan session may legitimately add more units.
     */
    fun commitScanQuantities(sessionId:String, drafts:List<ScanQuantityDraft>):ScanCartCommitResult = synchronized(scanCommitLock){
        val session = sessionId.trim()
        val requested = drafts.filter { it.quantity > 0 }
        val rejection = ScanCommitPolicy.rejection(
            session, reviewSessionId, committedScanSessions.contains(session),
            drafts.map { it.product.id to it.quantity }, reviewProducts.mapValues { it.value.stock },
            _cart.value.associate { it.product.id to it.quantity }
        )
        if(rejection != null){
            ArsFlightRecorder.event("SCAN_CART_COMMIT_BLOCKED", rejection, mapOf("session" to session, "reason" to rejection))
            val message = when(rejection){
                "DUPLICATE_SESSION" -> "Hasil scan ini sudah ditambahkan. Penambahan ulang diblokir."
                "STOCK_LIMIT_REVIEW_REQUIRED" -> "Jumlah melebihi sisa stok setelah isi keranjang. Kurangi jumlah; belum ada item yang ditambahkan."
                "EMPTY_REVIEW" -> "Tidak ada jumlah yang dipilih."
                else -> "Hasil scan atau pilihan tidak lagi valid. Silakan scan ulang."
            }
            return@synchronized ScanCartCommitResult(false,rejection == "DUPLICATE_SESSION",0,0,message)
        }

        val cartBefore = _cart.value
        var nextCart = cartBefore
        var added = 0
        var affected = 0
        requested.forEach { draft ->
            // Identity and price come from the accepted scan snapshot, not
            // editable draft fields. Checkout still revalidates the Room DB.
            val product = reviewProducts.getValue(draft.product.id)
            if(product.stock <= 0) return@forEach
            val currentQty = nextCart.firstOrNull { it.product.id == product.id }?.quantity ?: 0
            val room = (product.stock - currentQty).coerceAtLeast(0)
            val addQty = draft.quantity.coerceAtMost(room)
            if(addQty <= 0) return@forEach
            nextCart = if(currentQty == 0){
                nextCart + CartLine(product, addQty)
            } else {
                nextCart.map { line -> if(line.product.id == product.id) line.copy(quantity = line.quantity + addQty) else line }
            }
            added += addQty
            affected++
        }

        if(added <= 0){
            return@synchronized ScanCartCommitResult(false,false,0,0,"Quantity tidak dapat ditambahkan karena batas stok.")
        }

        _cart.value = nextCart
        committedScanSessions += session
        while(committedScanSessions.size > 100){
            val first = committedScanSessions.firstOrNull() ?: break
            committedScanSessions.remove(first)
        }
        ArsFlightRecorder.event(
            "SCAN_CART_COMMIT",
            "Confirmed scan quantities committed once",
            mapOf("session" to session,"addedQuantity" to added,"affectedProducts" to affected,"requestedProducts" to requested.size,
                "productIds" to requested.map { it.product.id }.joinToString(","),
                "cartBefore" to cartBefore.joinToString(",") { "${it.product.id}:${it.quantity}" },
                "cartAfter" to nextCart.joinToString(",") { "${it.product.id}:${it.quantity}" })
        )
        ScanCartCommitResult(true,false,added,affected,"$added item dari hasil scan ditambahkan ke keranjang.")
    }

    fun qty(id:Long,d:Int): Unit = synchronized(scanCommitLock){
        _cart.value=_cart.value.mapNotNull{line ->
            if(line.product.id!=id) line
            else {
                val next=(line.quantity+d).coerceIn(0,line.product.stock)
                line.copy(quantity=next).takeIf{it.quantity>0}
            }
        }
    }
    fun remove(id:Long): Unit = synchronized(scanCommitLock){
        _cart.value=_cart.value.filterNot{it.product.id==id}
    }
    fun clear(){synchronized(scanCommitLock){
        _cart.value=emptyList()
        reviewSessionId = ""
        reviewProducts = emptyMap()
    }}
    suspend fun login(u:String,p:String)=repo.login(u,p)
    suspend fun checkout(paid:Long,method:String)=runCatching{repo.checkout(_cart.value,paid,method).also{clear()}}
    suspend fun addProduct(n:String,s:String,b:String?,c:String,cost:Long,price:Long,stock:Int,brand:String?=null,variant:String?=null)=runCatching{repo.addProduct(n,s,b,c,cost,price,stock,brand,variant)}
    fun productPhotos(productId:Long)=repo.productPhotos(productId)
    suspend fun findVisualMatches(bitmap:android.graphics.Bitmap)=repo.visualProductMatches(bitmap)
    suspend fun liveScenePreview(bitmap:android.graphics.Bitmap)=repo.liveScenePreview(bitmap)
    suspend fun smartVisualScan(bitmap:android.graphics.Bitmap, diagnosticSession:String=""):List<VisualScanObject>{
        synchronized(scanCommitLock){reviewSessionId=diagnosticSession.trim();reviewProducts=emptyMap()}
        val results=repo.smartVisualScan(bitmap, diagnosticSession)
        synchronized(scanCommitLock){
            if(reviewSessionId == diagnosticSession.trim()){
                reviewProducts=results.filter { it.canCommitQuantity }.distinctBy { it.physicalObjectId }
                    .mapNotNull { it.match?.product }.associateBy { it.id }
            }
        }
        return results
    }
    suspend fun verifyProductMaster(productId:Long,bitmap:android.graphics.Bitmap)=repo.verifyProductMaster(productId,bitmap)
    suspend fun isMasterVerified(productId:Long)=repo.isMasterVerified(productId)
    suspend fun productIdentityProfile(productId:Long)=repo.productIdentityProfile(productId)
    suspend fun setProductRecognitionMode(productId:Long,mode:String,isLongObject:Boolean)=runCatching{repo.setProductRecognitionMode(productId,mode,isLongObject)}
    suspend fun invalidateMasterVerification(productId:Long)=repo.invalidateMasterVerification(productId)
    suspend fun mergeProductIdentityProfile(productId:Long,rawText:String="",brand:String="",name:String="",variant:String="",modelCode:String="",barcode:String="",recognitionMode:String="HYBRID",isLongObject:Boolean=false)=runCatching{repo.mergeProductIdentityProfile(productId,rawText,brand,name,variant,modelCode,barcode,recognitionMode,isLongObject)}
    suspend fun addProductPhoto(productId:Long,path:String,primary:Boolean=false,captureAngle:String="UNKNOWN")=runCatching{repo.addProductPhoto(productId,path,primary,captureAngle)}
    suspend fun clearProductPhotoAngle(productId:Long,angle:String)=runCatching{repo.clearProductPhotoAngle(productId,angle)}
    suspend fun setPrimaryProductPhoto(productId:Long,photoId:Long)=runCatching{repo.setPrimaryProductPhoto(productId,photoId)}
    suspend fun deleteProductPhoto(photo:ProductPhotoEntity)=runCatching{repo.deleteProductPhoto(photo)}
    suspend fun stockIn(productId:Long,qty:Int,cost:Long,supplier:String?,invoice:String?)=runCatching{repo.stockIn(productId,qty,cost,supplier,invoice)}
    suspend fun saleItems(id:Long)=repo.saleItems(id)
    suspend fun processReturn(saleId:Long,reason:String)=runCatching{repo.processReturn(saleId,reason)}
    suspend fun profitSummary():ProfitSummary {
        val start=Calendar.getInstance().apply{
            set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)
        }.timeInMillis
        return repo.profitSummary(start)
    }
}
