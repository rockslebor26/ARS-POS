package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Rect
import com.arspos.anglerriausyndicate.data.db.ProductEntity
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.40 / V8.4.20 — Scene-aware Smart Scan preview contracts.
 *
 * These models are preview-only. They never mutate cart quantity and they never
 * bypass the final SmartVisualScanner / SmartRecognitionEngine decision gates.
 */
data class LiveSceneDetection(
    val bounds: Rect,
    val proposalType: String,
    val product: ProductEntity? = null,
    val visualScore: Int = 0,
    val secondVisualScore: Int = 0,
    val margin: Int = 0,
    val identityAccepted: Boolean = false,
    val reason: String = "OBJECT_DETECTED"
)

data class LiveSceneTrack(
    val trackId: String,
    val bounds: Rect,
    val proposalType: String,
    val product: ProductEntity?,
    val visualScore: Int,
    val margin: Int,
    val hitStreak: Int,
    val missingFrames: Int,
    val state: String,
    val quantityPreviewEligible: Boolean,
    val reason: String
) {
    companion object {
        const val STATE_TRACKING = "TRACKING"
        const val STATE_ANALYZING = "ANALYZING"
        const val STATE_MATCHED = "MATCHED"
        const val STATE_CANDIDATE = "CANDIDATE"
        const val STATE_UNKNOWN = "UNKNOWN"
        const val STATE_OCCLUDED = "OCCLUDED"
    }
}

/**
 * Small temporal ledger used only by the live camera preview.
 *
 * The critical invariant is one preview quantity per temporal physical track,
 * not one quantity per detector rectangle. Final cashier quantity remains owned
 * by Physical Object Truth after the user locks the scene.
 */
class LiveSceneLedger(
    private val stableHits: Int = 3,
    private val maxMissingFrames: Int = 3,
    private val minimumIou: Float = 0.26f
) {
    private data class State(
        val id: Int,
        var bounds: Rect,
        var proposalType: String,
        var product: ProductEntity?,
        var visualScore: Int,
        var margin: Int,
        var identityAccepted: Boolean,
        var hitStreak: Int,
        var missingFrames: Int,
        var reason: String,
        var candidateProductId: Long?,
        var candidateAgreement: Int
    )

    private var nextId = 1
    private val tracks = LinkedHashMap<Int, State>()

    fun clear() {
        tracks.clear()
        nextId = 1
    }

    fun update(detections: List<LiveSceneDetection>): List<LiveSceneTrack> {
        val available = tracks.values.toMutableSet()
        val touched = HashSet<Int>()

        detections.sortedByDescending { area(it.bounds) }.forEach { detection ->
            val candidate = available
                .map { state -> state to matchScore(state, detection) }
                .filter { it.second >= minimumIou }
                .maxByOrNull { it.second }
                ?.first

            if (candidate == null) {
                val productId = detection.product?.id
                val state = State(
                    id = nextId++,
                    bounds = Rect(detection.bounds),
                    proposalType = detection.proposalType,
                    product = detection.product,
                    visualScore = detection.visualScore,
                    margin = detection.margin,
                    identityAccepted = detection.identityAccepted,
                    hitStreak = 1,
                    missingFrames = 0,
                    reason = detection.reason,
                    candidateProductId = productId,
                    candidateAgreement = if (productId != null) 1 else 0
                )
                tracks[state.id] = state
                touched += state.id
            } else {
                available.remove(candidate)
                touched += candidate.id
                candidate.bounds = smooth(candidate.bounds, detection.bounds)
                candidate.proposalType = detection.proposalType
                candidate.visualScore = detection.visualScore
                candidate.margin = detection.margin
                candidate.identityAccepted = detection.identityAccepted
                candidate.hitStreak += 1
                candidate.missingFrames = 0
                candidate.reason = detection.reason

                val nextProduct = detection.product
                val nextProductId = nextProduct?.id
                if (nextProductId != null && nextProductId == candidate.candidateProductId) {
                    candidate.candidateAgreement += 1
                    candidate.product = nextProduct
                } else if (nextProductId != null) {
                    candidate.candidateProductId = nextProductId
                    candidate.candidateAgreement = 1
                    candidate.product = nextProduct
                } else {
                    candidate.candidateAgreement = 0
                    candidate.candidateProductId = null
                    candidate.product = null
                }
            }
        }

        tracks.values.forEach { state ->
            if (state.id !in touched) {
                state.missingFrames += 1
                state.hitStreak = max(0, state.hitStreak - 1)
            }
        }
        tracks.entries.removeAll { it.value.missingFrames > maxMissingFrames }

        return snapshot()
    }

    fun snapshot(): List<LiveSceneTrack> = tracks.values
        .sortedWith(compareBy<State> { it.bounds.top }.thenBy { it.bounds.left })
        .map { state ->
            val stable = state.hitStreak >= stableHits
            val sameCandidateStable = state.candidateAgreement >= 2
            val previewIdentity = stable && sameCandidateStable && state.identityAccepted && state.product != null
            val stateName = when {
                state.missingFrames > 0 -> LiveSceneTrack.STATE_OCCLUDED
                !stable -> LiveSceneTrack.STATE_TRACKING
                previewIdentity -> LiveSceneTrack.STATE_MATCHED
                state.product != null -> LiveSceneTrack.STATE_CANDIDATE
                stable -> LiveSceneTrack.STATE_UNKNOWN
                else -> LiveSceneTrack.STATE_ANALYZING
            }
            LiveSceneTrack(
                trackId = "LIVE-${state.id}",
                bounds = Rect(state.bounds),
                proposalType = state.proposalType,
                product = state.product,
                visualScore = state.visualScore,
                margin = state.margin,
                hitStreak = state.hitStreak,
                missingFrames = state.missingFrames,
                state = stateName,
                quantityPreviewEligible = previewIdentity,
                reason = state.reason
            )
        }

    private fun matchScore(state: State, detection: LiveSceneDetection): Float {
        val overlap = iou(state.bounds, detection.bounds)
        if (overlap <= 0f) return 0f
        val stateLong = state.proposalType == ScanProposal.TYPE_LONG
        val detectionLong = detection.proposalType == ScanProposal.TYPE_LONG
        val laneFactor = if (stateLong == detectionLong) 1f else 0.72f
        val productFactor = when {
            state.candidateProductId == null || detection.product == null -> 1f
            state.candidateProductId == detection.product.id -> 1.12f
            else -> 0.80f
        }
        return (overlap * laneFactor * productFactor).coerceAtMost(1f)
    }

    private fun smooth(old: Rect, next: Rect): Rect = Rect(
        ((old.left * 2 + next.left) / 3f).toInt(),
        ((old.top * 2 + next.top) / 3f).toInt(),
        ((old.right * 2 + next.right) / 3f).toInt(),
        ((old.bottom * 2 + next.bottom) / 3f).toInt()
    )

    private fun iou(a: Rect, b: Rect): Float {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val intersection = (right - left).toLong() * (bottom - top).toLong()
        val union = area(a) + area(b) - intersection
        return if (union <= 0L) 0f else intersection.toFloat() / union.toFloat()
    }

    private fun area(rect: Rect): Long = rect.width().coerceAtLeast(0).toLong() * rect.height().coerceAtLeast(0).toLong()
}

/**
 * Cheap event trigger for live preview. Difference from background/previous
 * scene starts analysis; it is never treated as product identity by itself.
 */
object LiveFrameDifference {
    private const val GRID = 20

    fun signature(bitmap: Bitmap): IntArray {
        if (bitmap.width <= 0 || bitmap.height <= 0) return IntArray(0)
        val out = IntArray(GRID * GRID)
        var index = 0
        for (gy in 0 until GRID) {
            val y = ((gy + 0.5f) * bitmap.height / GRID).toInt().coerceIn(0, bitmap.height - 1)
            for (gx in 0 until GRID) {
                val x = ((gx + 0.5f) * bitmap.width / GRID).toInt().coerceIn(0, bitmap.width - 1)
                val p = bitmap.getPixel(x, y)
                val r = (p shr 16) and 0xff
                val g = (p shr 8) and 0xff
                val b = p and 0xff
                out[index++] = (r * 30 + g * 59 + b * 11) / 100
            }
        }
        return out
    }

    fun score(previous: IntArray?, current: IntArray): Float {
        if (previous == null || previous.size != current.size || current.isEmpty()) return 1f
        var total = 0L
        current.indices.forEach { total += abs(current[it] - previous[it]).toLong() }
        return (total.toFloat() / current.size.toFloat() / 255f).coerceIn(0f, 1f)
    }
}
