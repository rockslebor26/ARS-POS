package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test

class CanonicalIdentityContinuityTest {
    private fun obs(
        track: String,
        left: Int,
        top: Int,
        right: Int,
        bottom: Int,
        eval: Int,
        candidates: List<CanonicalIdentityContinuity.Candidate> = emptyList(),
        accepted: Boolean = false,
        at: Long
    ) = CanonicalIdentityContinuity.Observation(
        trackId = track,
        proposalType = "NORMAL_OBJECT",
        bounds = CanonicalIdentityContinuity.Box(left, top, right, bottom),
        visible = true,
        locked = true,
        identityEvaluationCount = eval,
        highResolutionEvidenceCount = 0,
        identityAcceptedLatest = accepted,
        identityOcrPresentLatest = false,
        candidateScores = candidates,
        observedAtMs = at
    )

    @Test fun transientTrackSplitKeepsCanonicalIdentity() {
        val continuity = CanonicalIdentityContinuity(ttlMs = 10_000, rebindMaxGapMs = 2_000)
        continuity.reconcile(listOf(obs("LIVE-4", 100,100,220,300,1, at=1_000)), 1_000)
        val first = continuity.canonicalIdForTrack("LIVE-4")
        continuity.reconcile(listOf(obs("LIVE-5", 106,104,226,304,1, at=1_500)), 1_500)
        val rebound = continuity.canonicalIdForTrack("LIVE-5")
        assertEquals(first, rebound)
        assertEquals(first, continuity.canonicalIdForTrack("LIVE-4"))
        val snapshot = continuity.snapshotForTrack("LIVE-5", 1_500)!!
        assertEquals(1, snapshot.transientOwnerSwitchCount)
        assertEquals(1, snapshot.evidenceTransferCount)
        assertEquals(0, snapshot.identityResetCount)
    }

    @Test fun independentObjectsCannotShareOneCanonicalIdentityInSamePass() {
        val continuity = CanonicalIdentityContinuity(ttlMs = 10_000, rebindMaxGapMs = 2_000)
        continuity.reconcile(listOf(obs("LIVE-1", 0,0,100,100,1,at=1_000)), 1_000)
        continuity.reconcile(listOf(
            obs("LIVE-2", 2,2,102,102,1,at=1_400),
            obs("LIVE-3", 300,300,400,400,1,at=1_400)
        ), 1_400)
        assertNotEquals(continuity.canonicalIdForTrack("LIVE-2"), continuity.canonicalIdForTrack("LIVE-3"))
    }

    @Test fun repeatedTopKEvidenceAccumulatesWithoutAcceptingIdentity() {
        val continuity = CanonicalIdentityContinuity(ttlMs = 10_000, rebindMaxGapMs = 2_000)
        val p6 = CanonicalIdentityContinuity.Candidate(6, 86)
        val p21 = CanonicalIdentityContinuity.Candidate(21, 82)
        continuity.reconcile(listOf(obs("LIVE-1", 100,100,220,300,1,listOf(p6,p21),at=1_000)),1_000)
        continuity.reconcile(listOf(obs("LIVE-1", 112,100,232,300,2,listOf(CanonicalIdentityContinuity.Candidate(6,90),CanonicalIdentityContinuity.Candidate(21,80)),at=2_200)),2_200)
        continuity.reconcile(listOf(obs("LIVE-1", 100,112,220,312,3,listOf(CanonicalIdentityContinuity.Candidate(6,92),CanonicalIdentityContinuity.Candidate(21,78)),at=3_400)),3_400)
        val snapshot = continuity.snapshotForTrack("LIVE-1",3_400)!!
        assertEquals(6L, snapshot.fusedCandidateProductId)
        assertTrue(snapshot.independentEvidenceCount >= 3)
        assertTrue(snapshot.stableCandidate)
        assertEquals(0, snapshot.acceptedEvidenceCount)
    }

    @Test fun identicalRapidFramesReceiveBoundedDuplicateWeight() {
        val continuity = CanonicalIdentityContinuity(ttlMs = 10_000, rebindMaxGapMs = 2_000)
        val p6 = listOf(CanonicalIdentityContinuity.Candidate(6, 80))
        continuity.reconcile(listOf(obs("LIVE-1", 100,100,220,300,1,p6,at=1_000)),1_000)
        continuity.reconcile(listOf(obs("LIVE-1", 100,100,220,300,2,p6,at=1_100)),1_100)
        continuity.reconcile(listOf(obs("LIVE-1", 100,100,220,300,3,p6,at=1_200)),1_200)
        val snapshot = continuity.snapshotForTrack("LIVE-1",1_200)!!
        assertEquals(1, snapshot.independentEvidenceCount)
        assertFalse(snapshot.stableCandidate)
    }
}
