package com.arspos.anglerriausyndicate

/**
 * Persistent development target lock shown in ARS Dev Center.
 * This is documentation/diagnostics only and is never used as recognition logic.
 */
object ArsProjectCharter {
    val ultimateGoal = """
        CAMERA → PHYSICAL OBJECT → STABLE OBJECT LOCK → IDENTITY → PRODUCT → SAFE QUANTITY

        Satu benda fisik harus dipertahankan sebagai satu objek yang sama sampai identitasnya diputuskan atau evidence dinyatakan belum cukup. Smart Scan harus cepat dan konsisten pada single-object maupun multi-object tanpa membuat quantity palsu.
    """.trimIndent()

    val nonNegotiableRules = """
        • Recognition threshold/margin tidak boleh diturunkan agar terlihat berhasil.
        • Identity accepted tidak otomatis berarti quantity accepted.
        • Cloud/AI tidak boleh membuat quantity, mengubah stok/pembayaran, signer, atau memasang APK.
        • Canonical physical truth, Safety Kernel, Decision Ledger, Ground Truth, Replay, Rod Authenticity, Package Edge Firewall, dan update in-place tetap dilindungi.
        • Package resmi tetap com.arspos.anglerriausyndicate; versionCode wajib meningkat; signer resmi wajib sama.
    """.trimIndent()

    val currentMission = """
        V8.8.7 CURRENT MISSION

        Pertahankan satu canonical identity untuk setiap physical object. Evidence Top-K visual/OCR/high-resolution harus terakumulasi lintas-frame walaupun transient LIVE-* berubah. Identity dimulai segera setelah physical lock tanpa menunggu quantity verification. Tingkatkan convergence dan pembeda kandidat tanpa menurunkan recognition threshold. False quantity wajib tetap nol.
    """.trimIndent()

    val baseline = """
        BASELINE V8.8.6 — real-device diagnostic 2026-09-28
        • Scan sessions: 10/10 complete; crash/ANR/native crash/evidence error: 0.
        • Average completed scan: 1311 ms; object end-to-end: 655 ms; crop OCR: 375 ms.
        • Latest first candidate: 12,434 ms; live MATCHED observed in analyzed bundle: 0.
        • Physical rod truth berhasil: trusted rod 85–94 pada contoh valid; background/non-rod disuppress.
        • Main bottleneck: canonical physical object bertahan tetapi identity owner berpindah antar LIVE-* dan evidence terfragmentasi.
    """.trimIndent()

    val regressionGuard = """
        PHASE GATE
        IMPLEMENTED → TESTING → EVIDENCE VERIFIED → TARGET PASSED → CLOSED

        Target engineering V8.8.7: physical lock ≤800 ms, first meaningful candidate ≤1.5 s, stable identity ≤3 s bila evidence memadai, same-object canonical identity reset = 0, false automatic quantity = 0, duplicate physical quantity = 0, threshold relaxation = 0, crash/ANR/evidence corruption = 0.
    """.trimIndent()
}
