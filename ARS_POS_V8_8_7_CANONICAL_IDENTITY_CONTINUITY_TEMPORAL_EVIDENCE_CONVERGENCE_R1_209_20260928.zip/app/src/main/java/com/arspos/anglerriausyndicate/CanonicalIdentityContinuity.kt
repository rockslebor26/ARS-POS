package com.arspos.anglerriausyndicate

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.5.7 / V8.8.7.
 *
 * Canonical identity continuity lives above transient LIVE-* tracker IDs. It is
 * advisory-only: it may preserve/fuse identity evidence and seed retrieval, but
 * it cannot accept a product, create quantity, relax a recognition threshold,
 * or bypass final SmartRecognitionEngine/Safety Kernel decisions.
 */
class CanonicalIdentityContinuity(
    private val ttlMs: Long = ArsV850Config.CANONICAL_IDENTITY_TTL_MS,
    private val rebindMaxGapMs: Long = ArsV850Config.CANONICAL_IDENTITY_REBIND_MAX_GAP_MS
) {
    data class Box(val left: Int, val top: Int, val right: Int, val bottom: Int) {
        val width: Int get() = (right - left).coerceAtLeast(0)
        val height: Int get() = (bottom - top).coerceAtLeast(0)
    }

    data class Candidate(val productId: Long, val score: Int)

    data class Observation(
        val trackId: String,
        val proposalType: String,
        val bounds: Box,
        val visible: Boolean,
        val locked: Boolean,
        val identityEvaluationCount: Int,
        val highResolutionEvidenceCount: Int,
        val identityAcceptedLatest: Boolean,
        val identityOcrPresentLatest: Boolean,
        val candidateScores: List<Candidate>,
        val observedAtMs: Long
    )

    data class Snapshot(
        val canonicalIdentityId: String,
        val currentTrackId: String,
        val proposalType: String,
        val generation: Int,
        val transientOwnerSwitchCount: Int,
        val nullOwnerTransitionCount: Int,
        val evidenceTransferCount: Int,
        val identityResetCount: Int,
        val fusedCandidateProductId: Long,
        val fusedScore: Int,
        val fusedSecondScore: Int,
        val fusedMargin: Int,
        val independentEvidenceCount: Int,
        val acceptedEvidenceCount: Int,
        val stableCandidate: Boolean,
        val lastSeenAtMs: Long
    )

    private data class Accumulator(
        var weightedScore: Double = 0.0,
        var totalWeight: Double = 0.0,
        var independentSamples: Int = 0,
        var acceptedSamples: Int = 0,
        var lastSeenAtMs: Long = 0L,
        var lastIndependentAtMs: Long = 0L,
        var lastIndependentBounds: Box? = null
    )

    private data class State(
        val id: Int,
        var proposalType: String,
        var bounds: Box,
        var currentTrackId: String?,
        var lastSeenAtMs: Long,
        var generation: Int = 1,
        var transientSwitches: Int = 0,
        var nullTransitions: Int = 0,
        var evidenceTransfers: Int = 0,
        var identityResets: Int = 0,
        val lastIdentityEvaluationByTrack: MutableMap<String, Int> = LinkedHashMap(),
        val lastHighResCountByTrack: MutableMap<String, Int> = LinkedHashMap(),
        val candidates: MutableMap<Long, Accumulator> = LinkedHashMap()
    )

    private var nextCanonicalId = 1
    private val states = LinkedHashMap<Int, State>()
    private val trackToState = LinkedHashMap<String, Int>()

    fun clear() {
        states.clear()
        trackToState.clear()
        nextCanonicalId = 1
    }

    /**
     * Reconcile all currently visible tracker observations to canonical identity
     * objects. One canonical object can own at most one visible track per pass.
     */
    fun reconcile(observations: List<Observation>, nowMs: Long): Map<String, Snapshot> {
        prune(nowMs)
        val visible = observations.filter { it.visible }
        val assignedStates = HashSet<Int>()
        val assignedTracks = HashSet<String>()

        visible.sortedWith(compareByDescending<Observation> { it.locked }.thenByDescending { area(it.bounds) })
            .forEach { observation ->
                var state = trackToState[observation.trackId]
                    ?.let(states::get)
                    ?.takeIf { laneFamily(it.proposalType) == laneFamily(observation.proposalType) }

                if (state == null || state.id in assignedStates) {
                    state = findRebindCandidate(observation, assignedStates, nowMs)
                }

                if (state == null) {
                    state = State(
                        id = nextCanonicalId++,
                        proposalType = observation.proposalType,
                        bounds = observation.bounds,
                        currentTrackId = observation.trackId,
                        lastSeenAtMs = nowMs
                    )
                    states[state.id] = state
                } else if (state.currentTrackId != observation.trackId) {
                    val previousTrack = state.currentTrackId
                    if (!previousTrack.isNullOrBlank()) {
                        state.transientSwitches += 1
                        state.evidenceTransfers += 1
                    } else if (state.candidates.isNotEmpty()) {
                        state.evidenceTransfers += 1
                    }
                    state.currentTrackId = observation.trackId
                    state.generation += 1
                }

                // Keep bounded transient aliases until the canonical state expires.
                // This lets selection/UI owners survive LIVE-* rebind without losing identity evidence.
                trackToState[observation.trackId] = state.id
                state.proposalType = observation.proposalType
                state.bounds = observation.bounds
                state.lastSeenAtMs = nowMs
                ingestFreshEvidence(state, observation)
                assignedStates += state.id
                assignedTracks += observation.trackId
            }

        states.values.forEach { state ->
            val owner = state.currentTrackId
            if (!owner.isNullOrBlank() && owner !in assignedTracks && nowMs - state.lastSeenAtMs <= rebindMaxGapMs) {
                state.currentTrackId = null
                state.nullTransitions += 1
                state.generation += 1
            }
        }

        prune(nowMs)
        return snapshots(nowMs)
    }

    fun canonicalIdForTrack(trackId: String?): String? {
        if (trackId.isNullOrBlank()) return null
        val state = trackToState[trackId]?.let(states::get) ?: return null
        return canonicalId(state.id)
    }

    fun currentTrackForCanonical(canonicalIdentityId: String?): String? {
        val id = parseCanonicalId(canonicalIdentityId) ?: return null
        return states[id]?.currentTrackId
    }

    fun snapshotForTrack(trackId: String?, nowMs: Long): Snapshot? {
        if (trackId.isNullOrBlank()) return null
        prune(nowMs)
        val state = trackToState[trackId]?.let(states::get) ?: return null
        return snapshot(state, nowMs)
    }

    fun snapshotForCanonical(canonicalIdentityId: String?, nowMs: Long): Snapshot? {
        val id = parseCanonicalId(canonicalIdentityId) ?: return null
        prune(nowMs)
        return states[id]?.let { snapshot(it, nowMs) }
    }

    fun snapshots(nowMs: Long): Map<String, Snapshot> = states.values.associate { state ->
        canonicalId(state.id) to snapshot(state, nowMs)
    }

    /** Retrieval seed only. This cannot accept identity or quantity. */
    fun preferredProductIdForTrack(trackId: String?, nowMs: Long): Long =
        snapshotForTrack(trackId, nowMs)?.fusedCandidateProductId ?: 0L

    private fun findRebindCandidate(
        observation: Observation,
        assignedStates: Set<Int>,
        nowMs: Long
    ): State? = states.values.asSequence()
        .filter { it.id !in assignedStates }
        .filter { laneFamily(it.proposalType) == laneFamily(observation.proposalType) }
        .filter { nowMs - it.lastSeenAtMs <= rebindMaxGapMs }
        .map { it to continuityScore(it, observation) }
        .filter { it.second >= ArsV850Config.CANONICAL_IDENTITY_MIN_REBIND_SCORE }
        .maxByOrNull { it.second }
        ?.first

    private fun ingestFreshEvidence(state: State, observation: Observation) {
        val previousEval = state.lastIdentityEvaluationByTrack[observation.trackId] ?: 0
        if (observation.identityEvaluationCount <= previousEval) return

        val previousHighRes = state.lastHighResCountByTrack[observation.trackId] ?: 0
        val highResFresh = observation.highResolutionEvidenceCount > previousHighRes
        state.lastIdentityEvaluationByTrack[observation.trackId] = observation.identityEvaluationCount
        state.lastHighResCountByTrack[observation.trackId] = observation.highResolutionEvidenceCount

        observation.candidateScores
            .filter { it.productId > 0L && it.score > 0 }
            .distinctBy { it.productId }
            .take(ArsV850Config.CANONICAL_TOP_K)
            .forEach { candidate ->
                val accumulator = state.candidates.getOrPut(candidate.productId) { Accumulator() }
                val independence = evidenceIndependence(
                    previousBounds = accumulator.lastIndependentBounds,
                    previousAtMs = accumulator.lastIndependentAtMs,
                    currentBounds = observation.bounds,
                    currentAtMs = observation.observedAtMs
                )
                var weight = if (independence) 1.0 else ArsV850Config.DUPLICATE_FRAME_EVIDENCE_WEIGHT.toDouble()
                if (highResFresh) weight += 0.20
                if (observation.identityOcrPresentLatest) weight += 0.20
                weight = weight.coerceAtMost(1.35)

                accumulator.weightedScore += candidate.score.coerceIn(0, 100) * weight
                accumulator.totalWeight += weight
                accumulator.lastSeenAtMs = observation.observedAtMs
                if (independence) {
                    accumulator.independentSamples += 1
                    accumulator.lastIndependentAtMs = observation.observedAtMs
                    accumulator.lastIndependentBounds = observation.bounds
                }
                if (observation.identityAcceptedLatest && observation.candidateScores.firstOrNull()?.productId == candidate.productId) {
                    accumulator.acceptedSamples += 1
                }
            }

        while (state.candidates.size > ArsV850Config.CANONICAL_MAX_CANDIDATES) {
            val oldest = state.candidates.minByOrNull { it.value.lastSeenAtMs }?.key ?: break
            state.candidates.remove(oldest)
        }
    }

    private fun snapshot(state: State, nowMs: Long): Snapshot {
        val ranked = state.candidates.map { (productId, acc) ->
            val average = if (acc.totalWeight > 0.0) acc.weightedScore / acc.totalWeight else 0.0
            val age = (nowMs - acc.lastSeenAtMs).coerceAtLeast(0L)
            val freshness = (1.0 - (age.toDouble() / ttlMs.coerceAtLeast(1L).toDouble()) * 0.12).coerceIn(0.88, 1.0)
            val consensusBonus = ((acc.independentSamples - 1).coerceAtLeast(0) * 1.5).coerceAtMost(4.5)
            val rankingScore = (average * freshness + consensusBonus).toInt().coerceIn(0, 100)
            Triple(productId, rankingScore, acc)
        }.sortedByDescending { it.second }

        val top = ranked.firstOrNull()
        val second = ranked.getOrNull(1)
        val topScore = top?.second ?: 0
        val secondScore = second?.second ?: 0
        val topAccumulator = top?.third
        val independent = topAccumulator?.independentSamples ?: 0
        val accepted = topAccumulator?.acceptedSamples ?: 0
        return Snapshot(
            canonicalIdentityId = canonicalId(state.id),
            currentTrackId = state.currentTrackId.orEmpty(),
            proposalType = state.proposalType,
            generation = state.generation,
            transientOwnerSwitchCount = state.transientSwitches,
            nullOwnerTransitionCount = state.nullTransitions,
            evidenceTransferCount = state.evidenceTransfers,
            identityResetCount = state.identityResets,
            fusedCandidateProductId = top?.first ?: 0L,
            fusedScore = topScore,
            fusedSecondScore = secondScore,
            fusedMargin = (topScore - secondScore).coerceAtLeast(0),
            independentEvidenceCount = independent,
            acceptedEvidenceCount = accepted,
            stableCandidate = independent >= ArsV850Config.CANONICAL_STABLE_EVIDENCE_COUNT,
            lastSeenAtMs = state.lastSeenAtMs
        )
    }

    private fun evidenceIndependence(
        previousBounds: Box?,
        previousAtMs: Long,
        currentBounds: Box,
        currentAtMs: Long
    ): Boolean {
        if (previousBounds == null || previousAtMs <= 0L) return true
        if (currentAtMs - previousAtMs >= ArsV850Config.CANONICAL_INDEPENDENT_EVIDENCE_GAP_MS) return true
        val overlap = iou(previousBounds, currentBounds)
        val scale = min(diagonal(previousBounds), diagonal(currentBounds)).coerceAtLeast(1f)
        val motion = centerDistance(previousBounds, currentBounds) / scale
        return overlap <= 0.82f || motion >= 0.12f
    }

    private fun continuityScore(state: State, observation: Observation): Float {
        val overlap = iou(state.bounds, observation.bounds)
        val scale = min(diagonal(state.bounds), diagonal(observation.bounds)).coerceAtLeast(1f)
        val motionSimilarity = (1f - centerDistance(state.bounds, observation.bounds) / (scale * 1.35f)).coerceIn(0f, 1f)
        val sizeSimilarity = areaSimilarity(state.bounds, observation.bounds)
        val fusedProductId = snapshot(state, observation.observedAtMs).fusedCandidateProductId
        val observationTop = observation.candidateScores.firstOrNull()?.productId ?: 0L
        val identityBonus = if (fusedProductId > 0L && fusedProductId == observationTop) 0.10f else 0f
        return (overlap * 0.52f + motionSimilarity * 0.30f + sizeSimilarity * 0.18f + identityBonus).coerceIn(0f, 1f)
    }

    private fun prune(nowMs: Long) {
        val expired = states.values.filter { nowMs - it.lastSeenAtMs > ttlMs }.map { it.id }.toSet()
        if (expired.isEmpty()) return
        states.keys.removeAll(expired)
        trackToState.entries.removeAll { it.value in expired }
    }

    private fun laneFamily(type: String): String = when (type) {
        "LONG_OBJECT" -> "LONG"
        "NORMAL_OBJECT" -> "NORMAL"
        else -> type
    }

    private fun canonicalId(id: Int) = "CID-$id"
    private fun parseCanonicalId(value: String?): Int? = value?.removePrefix("CID-")?.toIntOrNull()
    private fun area(box: Box): Long = box.width.toLong() * box.height.toLong()

    private fun iou(a: Box, b: Box): Float {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val intersection = (right - left).toLong() * (bottom - top).toLong()
        val union = area(a) + area(b) - intersection
        return if (union > 0L) intersection.toFloat() / union.toFloat() else 0f
    }

    private fun centerDistance(a: Box, b: Box): Float = hypot(
        ((a.left + a.right) - (b.left + b.right)) / 2f,
        ((a.top + a.bottom) - (b.top + b.bottom)) / 2f
    )

    private fun diagonal(box: Box): Float = hypot(box.width.toFloat(), box.height.toFloat())

    private fun areaSimilarity(a: Box, b: Box): Float {
        val aa = area(a).coerceAtLeast(1L).toFloat()
        val bb = area(b).coerceAtLeast(1L).toFloat()
        return min(aa, bb) / max(aa, bb)
    }
}
