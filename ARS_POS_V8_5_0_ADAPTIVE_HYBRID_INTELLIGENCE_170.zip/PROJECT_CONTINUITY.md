# ARS POS Project Continuity

Current source candidate: **1.6.1 (161) / Phase 4.3.2.44 / V8.4.24 — Live Identity Fast Path + Type-Aware Persistent Binding + Temporal Consensus**.

Direct predecessor: **1.6.0 (160) / Phase 4.3.2.43 / V8.4.23**. Database remains v5; package and official signer must remain unchanged. All recognition thresholds remain unchanged.

V8.4.20 implementation sequence: A Package Edge Firewall + Bidirectional Anchor Role; B Instance-Masked Track + Crossing Preservation; C Physical Quantity Truth V2 + Reciprocal NORMAL Ownership; D LONG Shortlist Safety + Rescue Gate V3.

## 2026-09-16 — Phase 4.3.2.40 / V8.4.20 Scene-Aware Smart Scan (1.5.7/157)

Smart Scan now begins with live object discovery and a temporal Scene Object Ledger. Live candidates are advisory only. `KUNCI & TINJAU HASIL` locks one snapshot and routes it through the existing production scanner; final identity, physical quantity and cart mutation remain protected by the same conservative gates. Recognition thresholds are unchanged. Version 157 is used to avoid collision with the earlier V8.4.20-A candidate build 156.

## 2026-09-20 — Phase 4.3.2.43 / V8.4.23 (1.6.0/160)

V8.4.23 makes temporal physical evidence part of final scanning before SKU identity scoring. It adds pre-gate LIVE-to-final persistent binding, safe temporal ML-seeded LONG geometry recovery that still requires final pixel authenticity, high-resolution locked-frame ROI for LONG identity, Compose cancellation hygiene, and replay/session evidence-integrity V2. Package Edge, NORMAL Purity, Rod Authenticity, cross-lane safety, anchor role truth, rescue safety and atomic quantity review remain active. Recognition thresholds are unchanged.


## 2026-09-21 — Phase 4.3.2.44 / V8.4.24 (1.6.1/161)

V8.4.24 targets the measured live-recognition latency from V8.4.23. Advisory product candidates are exposed earlier in the live stream, live LONG scoring uses a coarse fingerprint fast path, LONG persistent binding now uses axis-angle/aspect/center evidence in addition to rectangle overlap, LONG final OCR uses its oriented 0/180 fast path, live NORMAL OCR uses a single-orientation advisory path, and generated OCR rotation bitmaps are explicitly recycled. New telemetry records time-to-first-candidate/match and end-to-end identity cost. Evidence export now creates `ground_truth.jsonl` even when empty. Final recognition thresholds, package-edge/purity/rod/cross-lane/anchor gates and physical quantity safety remain unchanged.
