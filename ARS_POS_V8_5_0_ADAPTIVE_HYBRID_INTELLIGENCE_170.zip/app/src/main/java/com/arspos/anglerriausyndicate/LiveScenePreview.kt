package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Rect
import com.arspos.anglerriausyndicate.data.db.ProductEntity
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.3.0 / V8.5.0 — Live Identity Fast Path + Type-Aware Temporal Memory.
 *
 * Live boxes and candidates are advisory only. They never mutate cart quantity
 * and never bypass the final SmartVisualScanner / SmartRecognitionEngine gates.
 */
data class LiveSceneDetection(
    val bounds: Rect,
    val proposalType: String,
    val product: ProductEntity? = null,
    val visualScore: Int = 0,
    val secondVisualScore: Int = 0,
    val margin: Int = 0,
    val identityAccepted: Boolean = false,
    val rodStructureScore: Int = 0,
    val rodAuthenticityScore: Int = 0,
    val rodAuthenticityState: String = ScanProposal.AUTH_UNKNOWN,
    val foregroundSupported: Boolean = false,
    val axisAngleDeg: Float = 0f,
    val axisConfidence: Int = 0,
    val axisWidthPx: Int = 0,
    val reason: String = "OBJECT_DETECTED"
)

data class LiveSceneLockSnapshot(
    val frameWidth: Int,
    val frameHeight: Int,
    val lockedAtMs: Long = System.currentTimeMillis(),
    val sceneEpoch: Long = 0L,
    val tracks: List<LiveSceneTrack>
)

data class LiveSceneTrack(
    val trackId: String,
    val bounds: Rect,
    val proposalType: String,
    val product: ProductEntity?,
    val visualScore: Int,
    val margin: Int,
    val hitStreak: Int,
    val missingFrames: Int,
    val state: String,
    val quantityPreviewEligible: Boolean,
    val reason: String,
    val observationCount: Int = 0,
    val physicalSampleCount: Int = 0,
    val trustedPhysicalHits: Int = 0,
    val uncertainPhysicalHits: Int = 0,
    val foregroundSupportHits: Int = 0,
    val maxRodAuthenticityScore: Int = 0,
    val averageRodAuthenticityScore: Int = 0,
    val maxRodStructureScore: Int = 0,
    val temporalPhysicalState: String = "NOT_APPLICABLE",
    val axisAngleDeg: Float = 0f,
    val axisConfidence: Int = 0,
    val axisWidthPx: Int = 0,
    val firstSeenAtMs: Long = 0L,
    val firstCandidateAtMs: Long = 0L,
    val firstMatchedAtMs: Long = 0L,
    val bestVisualScore: Int = 0,
    val bestMargin: Int = 0,
    val bestEvidenceProductId: Long = 0L,
    val bestEvidenceAtMs: Long = 0L
) {
    companion object {
        const val STATE_TRACKING = "TRACKING"
        const val STATE_ANALYZING = "ANALYZING"
        const val STATE_MATCHED = "MATCHED"
        const val STATE_CANDIDATE = "CANDIDATE"
        const val STATE_UNKNOWN = "UNKNOWN"
        const val STATE_OCCLUDED = "OCCLUDED"
    }
}

/**
 * V8.5.0 temporal object-memory ledger with early candidate surfacing and LONG axis-aware continuity.
 *
 * Key safety changes from V8.4.21:
 * 1. NORMAL/LONG lanes are never rebound across lanes.
 * 2. Track continuity uses IoU + centre motion + area similarity, so small
 *    camera/object motion does not allocate a new LIVE id merely because IoU
 *    briefly falls.
 * 3. Candidate identity uses hysteresis. One noisy frame cannot replace a
 *    stable database candidate.
 * 4. MATCHED requires repeated accepted identity for the same temporal track.
 * 5. This is still preview-only; cashier quantity remains final-scan owned.
 */
class LiveSceneLedger(
    private val stableHits: Int = 2,
    private val maxMissingFrames: Int = 3,
    private val minimumMatchScore: Float = 0.34f
) {
    private data class State(
        val id: Int,
        var bounds: Rect,
        var proposalType: String,
        var product: ProductEntity?,
        var visualScore: Int,
        var margin: Int,
        var identityAccepted: Boolean,
        var hitStreak: Int,
        var missingFrames: Int,
        var reason: String,
        var candidateProductId: Long?,
        var candidateAgreement: Int,
        var acceptedAgreement: Int,
        var pendingProduct: ProductEntity?,
        var pendingProductId: Long?,
        var pendingAgreement: Int,
        var observationCount: Int,
        var physicalSampleCount: Int,
        var trustedPhysicalHits: Int,
        var uncertainPhysicalHits: Int,
        var foregroundSupportHits: Int,
        var rodAuthenticityTotal: Int,
        var maxRodAuthenticityScore: Int,
        var maxRodStructureScore: Int,
        var axisAngleDeg: Float,
        var axisConfidence: Int,
        var axisWidthPx: Int,
        val firstSeenAtMs: Long,
        var firstCandidateAtMs: Long,
        var firstMatchedAtMs: Long,
        var bestVisualScore: Int,
        var bestMargin: Int,
        var bestEvidenceProductId: Long,
        var bestEvidenceAtMs: Long
    )

    private var nextId = 1
    private val tracks = LinkedHashMap<Int, State>()

    fun clear() {
        tracks.clear()
        nextId = 1
    }

    fun update(detections: List<LiveSceneDetection>): List<LiveSceneTrack> {
        val available = tracks.values.toMutableList()
        val touched = HashSet<Int>()

        detections.sortedByDescending { area(it.bounds) }.forEach { detection ->
            val candidate = available
                .map { state -> state to matchScore(state, detection) }
                .filter { it.second >= minimumMatchScore }
                .maxByOrNull { it.second }
                ?.first

            if (candidate == null) {
                val productId = detection.product?.id
                val state = State(
                    id = nextId++,
                    bounds = Rect(detection.bounds),
                    proposalType = detection.proposalType,
                    product = detection.product,
                    visualScore = detection.visualScore,
                    margin = detection.margin,
                    identityAccepted = detection.identityAccepted,
                    hitStreak = 1,
                    missingFrames = 0,
                    reason = detection.reason,
                    candidateProductId = productId,
                    candidateAgreement = if (productId != null) 1 else 0,
                    acceptedAgreement = if (productId != null && detection.identityAccepted) 1 else 0,
                    pendingProduct = null,
                    pendingProductId = null,
                    pendingAgreement = 0,
                    observationCount = 1,
                    physicalSampleCount = if (detection.proposalType == ScanProposal.TYPE_LONG) 1 else 0,
                    trustedPhysicalHits = if (detection.rodAuthenticityState == ScanProposal.AUTH_TRUSTED) 1 else 0,
                    uncertainPhysicalHits = if (detection.rodAuthenticityState == ScanProposal.AUTH_UNCERTAIN) 1 else 0,
                    foregroundSupportHits = if (detection.foregroundSupported) 1 else 0,
                    rodAuthenticityTotal = if (detection.proposalType == ScanProposal.TYPE_LONG) detection.rodAuthenticityScore else 0,
                    maxRodAuthenticityScore = detection.rodAuthenticityScore,
                    maxRodStructureScore = detection.rodStructureScore,
                    axisAngleDeg = detection.axisAngleDeg,
                    axisConfidence = detection.axisConfidence,
                    axisWidthPx = detection.axisWidthPx,
                    firstSeenAtMs = System.currentTimeMillis(),
                    firstCandidateAtMs = if (productId != null) System.currentTimeMillis() else 0L,
                    firstMatchedAtMs = 0L,
                    bestVisualScore = detection.visualScore,
                    bestMargin = detection.margin,
                    bestEvidenceProductId = productId ?: 0L,
                    bestEvidenceAtMs = if (productId != null) System.currentTimeMillis() else 0L
                )
                tracks[state.id] = state
                touched += state.id
            } else {
                available.remove(candidate)
                touched += candidate.id
                candidate.bounds = smooth(candidate.bounds, detection.bounds)
                candidate.visualScore = detection.visualScore
                candidate.margin = detection.margin
                candidate.identityAccepted = detection.identityAccepted
                candidate.hitStreak += 1
                candidate.missingFrames = 0
                candidate.reason = detection.reason
                candidate.observationCount += 1
                val evidenceQuality = detection.visualScore * 2 + detection.margin.coerceAtLeast(0)
                val previousQuality = candidate.bestVisualScore * 2 + candidate.bestMargin.coerceAtLeast(0)
                if (detection.product != null && evidenceQuality > previousQuality) {
                    candidate.bestVisualScore = detection.visualScore
                    candidate.bestMargin = detection.margin
                    candidate.bestEvidenceProductId = detection.product.id
                    candidate.bestEvidenceAtMs = System.currentTimeMillis()
                }
                if (detection.proposalType == ScanProposal.TYPE_LONG) {
                    if (detection.axisConfidence >= candidate.axisConfidence || candidate.axisConfidence <= 0) {
                        candidate.axisAngleDeg = detection.axisAngleDeg
                        candidate.axisConfidence = detection.axisConfidence
                        candidate.axisWidthPx = detection.axisWidthPx
                    }

                    candidate.physicalSampleCount += 1
                    candidate.rodAuthenticityTotal += detection.rodAuthenticityScore
                    candidate.maxRodAuthenticityScore = max(candidate.maxRodAuthenticityScore, detection.rodAuthenticityScore)
                    candidate.maxRodStructureScore = max(candidate.maxRodStructureScore, detection.rodStructureScore)
                    if (detection.rodAuthenticityState == ScanProposal.AUTH_TRUSTED) candidate.trustedPhysicalHits += 1
                    if (detection.rodAuthenticityState == ScanProposal.AUTH_UNCERTAIN) candidate.uncertainPhysicalHits += 1
                    if (detection.foregroundSupported) candidate.foregroundSupportHits += 1
                }

                val nextProduct = detection.product
                val nextProductId = nextProduct?.id
                when {
                    nextProductId == null -> {
                        // Keep a proven candidate through one weak/noisy frame,
                        // but decay confidence so stale identities disappear.
                        candidate.candidateAgreement = max(0, candidate.candidateAgreement - 1)
                        candidate.acceptedAgreement = max(0, candidate.acceptedAgreement - 1)
                        candidate.pendingProduct = null
                        candidate.pendingProductId = null
                        candidate.pendingAgreement = 0
                        if (candidate.candidateAgreement == 0) {
                            candidate.product = null
                            candidate.candidateProductId = null
                        }
                    }
                    nextProductId == candidate.candidateProductId -> {
                        candidate.product = nextProduct
                        if (candidate.firstCandidateAtMs == 0L) candidate.firstCandidateAtMs = System.currentTimeMillis()
                        candidate.candidateAgreement += 1
                        candidate.acceptedAgreement = if (detection.identityAccepted) {
                            candidate.acceptedAgreement + 1
                        } else {
                            max(0, candidate.acceptedAgreement - 1)
                        }
                        candidate.pendingProduct = null
                        candidate.pendingProductId = null
                        candidate.pendingAgreement = 0
                    }
                    else -> {
                        // Do not switch a stable LIVE id to another SKU because
                        // of a single visual/OCR wobble. Require two frames.
                        if (candidate.pendingProductId == nextProductId) {
                            candidate.pendingAgreement += 1
                            candidate.pendingProduct = nextProduct
                        } else {
                            candidate.pendingProductId = nextProductId
                            candidate.pendingProduct = nextProduct
                            candidate.pendingAgreement = 1
                        }
                        if (candidate.pendingAgreement >= 2) {
                            candidate.candidateProductId = nextProductId
                            candidate.product = nextProduct
                            if (candidate.firstCandidateAtMs == 0L) candidate.firstCandidateAtMs = System.currentTimeMillis()
                            candidate.candidateAgreement = candidate.pendingAgreement
                            candidate.acceptedAgreement = if (detection.identityAccepted) 1 else 0
                            candidate.pendingProduct = null
                            candidate.pendingProductId = null
                            candidate.pendingAgreement = 0
                        } else {
                            candidate.candidateAgreement = max(0, candidate.candidateAgreement - 1)
                            candidate.acceptedAgreement = max(0, candidate.acceptedAgreement - 1)
                        }
                    }
                }
            }
        }

        tracks.values.forEach { state ->
            if (state.id !in touched) {
                state.missingFrames += 1
                state.hitStreak = max(0, state.hitStreak - 1)
                state.acceptedAgreement = max(0, state.acceptedAgreement - 1)
            }
        }
        tracks.entries.removeAll { it.value.missingFrames > maxMissingFrames }
        return snapshot()
    }

    fun snapshot(): List<LiveSceneTrack> = tracks.values
        .sortedWith(compareBy<State> { it.bounds.top }.thenBy { it.bounds.left })
        .map { state ->
            val stable = state.hitStreak >= stableHits
            val sameCandidateStable = state.candidateAgreement >= 2
            val acceptedStable = state.acceptedAgreement >= 2
            val previewIdentity = stable && sameCandidateStable && acceptedStable && state.product != null
            if (previewIdentity && state.firstMatchedAtMs == 0L) state.firstMatchedAtMs = System.currentTimeMillis()
            val stateName = when {
                state.missingFrames > 0 -> LiveSceneTrack.STATE_OCCLUDED
                previewIdentity -> LiveSceneTrack.STATE_MATCHED
                state.product != null -> LiveSceneTrack.STATE_CANDIDATE
                !stable -> LiveSceneTrack.STATE_TRACKING
                stable -> LiveSceneTrack.STATE_UNKNOWN
                else -> LiveSceneTrack.STATE_ANALYZING
            }
            val avgAuth = if (state.physicalSampleCount > 0) state.rodAuthenticityTotal / state.physicalSampleCount else 0
            val temporalPhysicalState = when {
                state.proposalType != ScanProposal.TYPE_LONG -> "NOT_APPLICABLE"
                state.trustedPhysicalHits >= 2 && state.foregroundSupportHits >= 2 && state.maxRodAuthenticityScore >= 80 -> "TEMPORAL_TRUSTED_ROD"
                state.trustedPhysicalHits + state.uncertainPhysicalHits >= 2 -> "TEMPORAL_ROD_CANDIDATE"
                else -> "TEMPORAL_UNPROVEN"
            }
            LiveSceneTrack(
                trackId = "LIVE-${state.id}",
                bounds = Rect(state.bounds),
                proposalType = state.proposalType,
                product = state.product,
                visualScore = state.visualScore,
                margin = state.margin,
                hitStreak = state.hitStreak,
                missingFrames = state.missingFrames,
                state = stateName,
                quantityPreviewEligible = previewIdentity,
                reason = state.reason,
                observationCount = state.observationCount,
                physicalSampleCount = state.physicalSampleCount,
                trustedPhysicalHits = state.trustedPhysicalHits,
                uncertainPhysicalHits = state.uncertainPhysicalHits,
                foregroundSupportHits = state.foregroundSupportHits,
                maxRodAuthenticityScore = state.maxRodAuthenticityScore,
                averageRodAuthenticityScore = avgAuth,
                maxRodStructureScore = state.maxRodStructureScore,
                temporalPhysicalState = temporalPhysicalState,
                axisAngleDeg = state.axisAngleDeg,
                axisConfidence = state.axisConfidence,
                axisWidthPx = state.axisWidthPx,
                firstSeenAtMs = state.firstSeenAtMs,
                firstCandidateAtMs = state.firstCandidateAtMs,
                firstMatchedAtMs = state.firstMatchedAtMs,
                bestVisualScore = state.bestVisualScore,
                bestMargin = state.bestMargin,
                bestEvidenceProductId = state.bestEvidenceProductId,
                bestEvidenceAtMs = state.bestEvidenceAtMs
            )
        }

    private fun matchScore(state: State, detection: LiveSceneDetection): Float {
        val stateLong = state.proposalType == ScanProposal.TYPE_LONG
        val detectionLong = detection.proposalType == ScanProposal.TYPE_LONG
        if (stateLong != detectionLong) return 0f // typed-lane invariant

        val overlap = iou(state.bounds, detection.bounds)
        val centre = centreSimilarity(state.bounds, detection.bounds)
        val size = areaSimilarity(state.bounds, detection.bounds)
        val angle = if (stateLong && state.axisConfidence > 0 && detection.axisConfidence > 0) {
            axisAngleSimilarity(state.axisAngleDeg, detection.axisAngleDeg)
        } else 1f

        // LONG objects are poor rectangle-IoU citizens: rotation or partial
        // visibility can change their bounding box while the physical axis is
        // still the same. NORMAL keeps the stricter rectangle continuity gate.
        if (stateLong) {
            if (overlap < 0.04f && (centre < 0.52f || size < 0.32f || angle < 0.52f)) return 0f
        } else {
            if (overlap < 0.08f && (centre < 0.58f || size < 0.40f)) return 0f
        }

        val productFactor = when {
            state.candidateProductId == null || detection.product == null -> 1f
            state.candidateProductId == detection.product.id -> 1.06f
            else -> 0.90f
        }
        val geometric = if (stateLong) {
            overlap * 0.34f + centre * 0.28f + size * 0.13f + angle * 0.25f
        } else {
            overlap * 0.55f + centre * 0.30f + size * 0.15f
        }
        return (geometric * productFactor).coerceIn(0f, 1f)
    }

    private fun axisAngleSimilarity(a: Float, b: Float): Float {
        var delta = abs(a - b) % 180f
        if (delta > 90f) delta = 180f - delta
        return (1f - delta / 60f).coerceIn(0f, 1f)
    }

    private fun smooth(old: Rect, next: Rect): Rect = Rect(
        ((old.left * 2 + next.left) / 3f).toInt(),
        ((old.top * 2 + next.top) / 3f).toInt(),
        ((old.right * 2 + next.right) / 3f).toInt(),
        ((old.bottom * 2 + next.bottom) / 3f).toInt()
    )

    private fun centreSimilarity(a: Rect, b: Rect): Float {
        val ax = (a.left + a.right) / 2f; val ay = (a.top + a.bottom) / 2f
        val bx = (b.left + b.right) / 2f; val by = (b.top + b.bottom) / 2f
        val scale = max(max(a.width(), a.height()), max(b.width(), b.height())).coerceAtLeast(1).toFloat()
        return (1f - hypot(ax - bx, ay - by) / (scale * 1.75f)).coerceIn(0f, 1f)
    }

    private fun areaSimilarity(a: Rect, b: Rect): Float {
        val aa = area(a).coerceAtLeast(1L).toFloat()
        val bb = area(b).coerceAtLeast(1L).toFloat()
        return min(aa, bb) / max(aa, bb)
    }

    private fun iou(a: Rect, b: Rect): Float {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val intersection = (right - left).toLong() * (bottom - top).toLong()
        val union = area(a) + area(b) - intersection
        return if (union <= 0L) 0f else intersection.toFloat() / union.toFloat()
    }

    private fun area(rect: Rect): Long = rect.width().coerceAtLeast(0).toLong() * rect.height().coerceAtLeast(0).toLong()
}

/** Cheap scene-change trigger. Motion is never identity evidence by itself. */
object LiveFrameDifference {
    private const val GRID = 20

    fun signature(bitmap: Bitmap): IntArray {
        if (bitmap.width <= 0 || bitmap.height <= 0) return IntArray(0)
        val out = IntArray(GRID * GRID)
        var index = 0
        for (gy in 0 until GRID) {
            val y = ((gy + 0.5f) * bitmap.height / GRID).toInt().coerceIn(0, bitmap.height - 1)
            for (gx in 0 until GRID) {
                val x = ((gx + 0.5f) * bitmap.width / GRID).toInt().coerceIn(0, bitmap.width - 1)
                val p = bitmap.getPixel(x, y)
                val r = (p shr 16) and 0xff
                val g = (p shr 8) and 0xff
                val b = p and 0xff
                out[index++] = (r * 30 + g * 59 + b * 11) / 100
            }
        }
        return out
    }

    fun score(previous: IntArray?, current: IntArray): Float {
        if (previous == null || previous.size != current.size || current.isEmpty()) return 1f
        var total = 0L
        current.indices.forEach { total += abs(current[it] - previous[it]).toLong() }
        return (total.toFloat() / current.size.toFloat() / 255f).coerceIn(0f, 1f)
    }
}
