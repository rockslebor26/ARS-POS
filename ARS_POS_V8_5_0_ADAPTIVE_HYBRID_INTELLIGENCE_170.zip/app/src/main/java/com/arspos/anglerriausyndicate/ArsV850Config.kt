package com.arspos.anglerriausyndicate

/**
 * Phase 4.3.3.0 / V8.5.0 — Adaptive Hybrid Intelligence.
 *
 * The feature flags are intentionally conservative. Physical truth and cashier
 * safety are production-active; cloud identity and self-learning remain shadow
 * capabilities until field evidence proves them safe.
 */
object ArsV850Config {
    const val PHASE = "4.3.3.0"
    const val ENGINE = "V8.5.0"
    const val VERSION_NAME = "1.7.0"
    const val VERSION_CODE = 170

    const val FEATURE_PERSISTENT_FRAGMENT_FUSION = true
    const val FEATURE_ML_GUIDED_LOCAL_RECOVERY = true
    const val FEATURE_BEST_EVIDENCE_MEMORY = true
    const val FEATURE_DECISION_EVIDENCE_LEDGER = true
    const val FEATURE_GROUND_TRUTH_LEARNING = true

    // Network/learning features are deliberately non-authoritative in the first
    // V8.5 build. They may observe/evaluate but cannot create identity/quantity.
    const val CLOUD_IDENTITY_MODE = "SHADOW"
    const val SELF_LEARNING_MODE = "SHADOW"
    const val AI_ENGINEER_MODE = "DIAGNOSTIC_ONLY"
}
