package com.arspos.anglerriausyndicate.data

import com.arspos.anglerriausyndicate.data.db.ProductEntity
import org.junit.Assert.*
import org.junit.Test

class RecognitionSafetyTest {
    private fun candidate(visual: Int = 99, text: Int = 0, long: Boolean = false, anchor: Int = 99) =
        RecognitionCandidate(ProductEntity(sku = "TEST", name = "LIGHTS AMERICAN BLEND", costPrice = 0, sellPrice = 15000),
            visualScore = visual, textScore = text, finalScore = maxOf(visual, text),
            evidence = "test", hasMaster = true, masterVerified = true, isLongObject = long, anchorScore = anchor)

    @Test fun normalVisualAloneNeverAcceptsEvenWithoutRodClaim() {
        for (visual in 0..100) {
            val result = SmartRecognitionEngine.decide(candidate(visual), null, visual, 0, "", "", false, true)
            assertFalse("visual=$visual", result.accepted)
        }
    }
    @Test fun exactBarcodeRemainsAccepted() {
        val result = SmartRecognitionEngine.decide(candidate(text = 100).copy(exactBarcodeMatch = true), null, 100, 0, "8886419710455", "", true, false)
        assertTrue(result.accepted)
        assertEquals("BARCODE_EXACT", result.ruleId)
    }
    @Test fun strongCropTextRemainsAcceptedWithVisualFirewall() {
        val result = SmartRecognitionEngine.decide(candidate(83, 100), null, 100, 0, "", "", true, false)
        assertTrue(result.accepted)
        assertEquals("OCR_VERY_STRONG", result.ruleId)
    }
    @Test fun weakTextCannotBeRescuedByHighVisualScore() {
        val result = SmartRecognitionEngine.decide(candidate(99, 46), null, 99, 0, "", "", true, true)
        assertFalse(result.accepted)
        assertEquals("REJECT_TEXT_TOO_WEAK", result.ruleId)
    }
    @Test fun rodWithStrongAnchorsCanStillPassExistingGate() {
        val result = SmartRecognitionEngine.decide(candidate(long = true), null, 99, 99, "", "", false, true)
        assertTrue(result.accepted)
        assertEquals("ROD_ANCHOR_VISUAL_VERIFIED", result.ruleId)
    }
    @Test fun closeRodCandidatesRemainUnknown() {
        val result = SmartRecognitionEngine.decide(candidate(long = true), candidate(98, long = true), 1, 1, "", "", false, true)
        assertFalse(result.accepted)
        assertEquals("REJECT_VISUAL_MARGIN", result.ruleId)
    }
    @Test fun highTextCannotPretendToBeExactBarcode() {
        val result = SmartRecognitionEngine.decide(candidate(text = 100), null, 100, 0, "WRONGCODE", "", true, true)
        assertFalse(result.accepted)
        assertEquals("REJECT_BARCODE_MISMATCH", result.ruleId)
    }
    @Test fun duplicateCatalogBarcodeCannotSelectOneSku() {
        val result = SmartRecognitionEngine.decide(candidate(text = 100).copy(exactBarcodeMatch = true), null, 100, 0, "8886419710455", "", true, true, 2)
        assertFalse(result.accepted)
        assertEquals("REJECT_BARCODE_AMBIGUOUS", result.ruleId)
    }
    @Test fun tiedIdentityStillRequiresOperatorReview() {
        val result = SmartRecognitionEngine.decide(candidate(text = 100), candidate(text = 100), 0, 0, "", "", true, true)
        assertEquals("REJECT_IDENTITY_MARGIN", result.ruleId)
    }
}
