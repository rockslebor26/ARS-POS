package com.arspos.anglerriausyndicate.data

import android.graphics.Bitmap
import com.arspos.anglerriausyndicate.SmartProductInput
import com.arspos.anglerriausyndicate.VisualProductMatch
import com.arspos.anglerriausyndicate.data.db.ProductEntity
import kotlin.math.roundToInt

/**
 * Phase 4.3.2.8: ARS Recognition Engine V3.
 *
 * Decision model:
 * 1) Barcode exact match is the strongest identity proof.
 * 2) OCR is normalized and evaluated using distinctive identity tokens.
 * 3) Visual evidence is aggregated across many master frames, not one frame.
 * 4) A large score is never enough by itself: the winner must also beat the
 *    second candidate by a meaningful margin.
 * 5) The final score is an identity-confidence score, not a raw OCR score.
 */
object SmartRecognitionEngine {
    data class Result(
        val match: VisualProductMatch?,
        val visualScore: Int,
        val textScore: Int,
        val finalScore: Int,
        val ocrText: String,
        val barcode: String = "",
        val reason: String,
        val candidates: List<RecognitionCandidate> = emptyList()
    )

    // Phase 4.3.2.9: Identity Engine V2
    // Identity evidence is intentionally separated from raw OCR length.
    private const val ACCEPT_EXACT_BARCODE = 90
    private const val ACCEPT_STRONG_IDENTITY = 78
    private const val ACCEPT_IDENTITY_WITH_VISUAL = 68
    private const val ACCEPT_VISUAL_ONLY = 88
    private const val MIN_VISUAL_SUPPORT = 38
    private const val MIN_MARGIN = 8

    suspend fun recognize(
        crop: Bitmap,
        products: List<ProductEntity>,
        references: List<VisualProductMatch>,
        ocr: SmartProductInput.Draft
    ): Result {
        if (products.isEmpty()) return Result(null, 0, 0, 0, ocr.rawText, ocr.barcode, "Katalog kosong")

        val normalizedOcr = normalize(ocr.rawText)
        val detectedBarcode = normalizeCode(ocr.barcode)
        val detectedModel = normalizeCode(ocr.modelCode)
        val refsByProduct = references.groupBy { it.product.id }

        val candidates = products.map { product ->
            val refs = refsByProduct[product.id].orEmpty()
            val visual = aggregateVisual(refs)
            val text = identityScore(product, normalizedOcr, detectedBarcode, detectedModel)
            val final = fuse(visual, text, detectedBarcode, detectedModel, product, refs)
            RecognitionCandidate(
                product = product,
                visualScore = visual,
                textScore = text,
                finalScore = final,
                evidence = evidence(product, visual, text, detectedBarcode, detectedModel, refs),
                hasMaster = refs.isNotEmpty()
            )
        }.sortedWith(
            compareByDescending<RecognitionCandidate> { it.finalScore }
                .thenByDescending { it.textScore }
                .thenByDescending { it.visualScore }
        ).take(5)

        val best = candidates.firstOrNull()
        val second = candidates.getOrNull(1)
        val margin = if (best != null && second != null) best.finalScore - second.finalScore else 100
        val accepted = best != null && accept(best, margin, detectedBarcode, detectedModel)
        val bestReference = best?.let { refsByProduct[it.product.id].orEmpty().maxByOrNull { ref -> ref.score } }

        val reason = when {
            best == null -> "Tidak ada kandidat katalog"
            accepted -> acceptedReason(best, margin, detectedBarcode, detectedModel)
            else -> rejectionReason(best, second, margin, detectedBarcode, detectedModel)
        }

        return Result(
            match = if (accepted) bestReference else null,
            visualScore = best?.visualScore ?: 0,
            textScore = best?.textScore ?: 0,
            finalScore = best?.finalScore ?: 0,
            ocrText = ocr.rawText,
            barcode = ocr.barcode,
            reason = reason,
            candidates = candidates
        )
    }

    /** Public for master verification and diagnostics. */
    fun textScore(product: ProductEntity, ocrText: String, barcode: String = "", model: String = ""): Int =
        identityScore(product, normalize(ocrText), normalizeCode(barcode), normalizeCode(model))

    private fun identityScore(product: ProductEntity, ocr: String, barcode: String, model: String): Int {
        val productBarcode = normalizeCode(product.barcode.orEmpty())
        if (barcode.isNotBlank() && productBarcode.isNotBlank() && barcode == productBarcode) return 100
        if (ocr.isBlank()) return 0

        val ocrTokens = tokenize(ocr)
        val brandTokens = identityTokens(product.brand.orEmpty())
        val nameTokens = identityTokens(product.name)
        val variantTokens = identityTokens(product.variant.orEmpty())
        val skuTokens = identityTokens(product.sku)

        var score = 0
        var strongHits = 0

        // Brand is useful, but never enough on its own.
        val brandHits = fuzzyHits(brandTokens, ocrTokens)
        if (brandTokens.isNotEmpty() && brandHits > 0) {
            score += minOf(18, 12 + brandHits * 3)
            if (brandHits >= 1) strongHits++
        }

        val name = fieldScore(ocrTokens, nameTokens, 42)
        score += name.first
        strongHits += name.second

        val variant = fieldScore(ocrTokens, variantTokens, 25)
        score += variant.first
        strongHits += variant.second

        // SKU/model is a high-value identity clue when OCR sees it.
        val modelTokens = buildList {
            addAll(extractModelTokens(product.name))
            addAll(extractModelTokens(product.variant.orEmpty()))
            addAll(extractModelTokens(product.sku))
        }.distinct()

        if (model.isNotBlank() && modelTokens.any { fuzzyCode(it, model) }) {
            score += 25
            strongHits += 2
        } else if (modelTokens.isNotEmpty()) {
            val modelHit = fuzzyHits(modelTokens, ocrTokens, codeMode = true)
            if (modelHit > 0) {
                score += minOf(25, 18 + modelHit * 4)
                strongHits += 2
            }
        }

        if (skuTokens.isNotEmpty()) {
            val skuHit = fuzzyHits(skuTokens, ocrTokens, codeMode = true)
            if (skuHit > 0) {
                score += minOf(15, 10 + skuHit * 3)
                strongHits++
            }
        }

        if (productBarcode.isNotBlank() && containsCode(ocr, productBarcode)) {
            score += 20
            strongHits += 2
        }

        // Two independent identity signals are much stronger than one long OCR phrase.
        if (strongHits >= 2) score += 8
        if (strongHits >= 4) score += 7

        return score.coerceIn(0, 100)
    }

    private fun aggregateVisual(refs: List<VisualProductMatch>): Int {
        if (refs.isEmpty()) return 0

        // Prefer one strong reference per capture angle. This prevents a single
        // repeated angle from dominating the whole master.
        val angleBest = refs
            .filter { it.photo.captureAngle != "UNKNOWN" }
            .groupBy { it.photo.captureAngle }
            .values
            .mapNotNull { group -> group.maxByOrNull { it.score }?.score }

        val scores = if (angleBest.isNotEmpty()) angleBest else refs.map { it.score }
        val sorted = scores.sortedDescending()
        val best = sorted.first()
        val top = sorted.take(6)
        val support = top.count { it >= 50 }
        val strong = top.count { it >= 65 }
        val average = top.average()
        val median = sorted[sorted.size / 2]

        var value = best * 0.50 + average * 0.25 + median * 0.10
        value += support.coerceAtMost(6) * 1.8
        value += strong.coerceAtMost(6) * 1.2
        if (best - average >= 25) value -= 7

        return value.roundToInt().coerceIn(0, 100)
    }

    private fun fuse(
        visual: Int,
        text: Int,
        barcode: String,
        model: String,
        product: ProductEntity,
        refs: List<VisualProductMatch>
    ): Int {
        if (barcode.isNotBlank() && normalizeCode(product.barcode.orEmpty()) == barcode) return 100

        return when {
            text >= 92 && visual >= MIN_VISUAL_SUPPORT -> maxOf(text, (text * .78f + visual * .22f).roundToInt())
            text >= ACCEPT_STRONG_IDENTITY && visual >= MIN_VISUAL_SUPPORT -> (text * .72f + visual * .28f).roundToInt()
            text >= ACCEPT_IDENTITY_WITH_VISUAL && visual >= 50 -> (text * .62f + visual * .38f).roundToInt()
            model.isNotBlank() && text >= 75 && visual >= 35 -> (text * .70f + visual * .30f).roundToInt()
            else -> visual
        }.coerceIn(0, 100)
    }

    private fun accept(c: RecognitionCandidate, margin: Int, barcode: String, model: String): Boolean {
        if (barcode.isNotBlank() && c.textScore >= ACCEPT_EXACT_BARCODE) return true
        if (c.textScore >= 92 && c.visualScore >= 30 && margin >= MIN_MARGIN) return true
        if (c.textScore >= ACCEPT_STRONG_IDENTITY && c.visualScore >= MIN_VISUAL_SUPPORT && margin >= MIN_MARGIN) return true
        if (model.isNotBlank() && c.textScore >= 75 && c.visualScore >= 35 && margin >= MIN_MARGIN) return true
        if (c.textScore >= ACCEPT_IDENTITY_WITH_VISUAL && c.visualScore >= 50 && margin >= MIN_MARGIN) return true
        return c.visualScore >= ACCEPT_VISUAL_ONLY && c.hasMaster && margin >= MIN_MARGIN
    }

    private fun acceptedReason(c: RecognitionCandidate, margin: Int, barcode: String, model: String): String = when {
        barcode.isNotBlank() && c.textScore >= ACCEPT_EXACT_BARCODE -> "BARCODE EXACT + identitas database"
        c.textScore >= 92 -> "Identitas OCR sangat kuat + dukungan visual + margin $margin%"
        model.isNotBlank() && c.textScore >= 75 -> "MODEL + OCR + visual master + margin $margin%"
        c.textScore >= ACCEPT_STRONG_IDENTITY -> "Identity key + visual master + margin $margin%"
        c.textScore >= ACCEPT_IDENTITY_WITH_VISUAL -> "OCR + visual master + margin $margin%"
        else -> "Visual master kuat + margin $margin%"
    }

    private fun evidence(product: ProductEntity, visual: Int, text: Int, barcode: String, model: String, refs: List<VisualProductMatch>): String = when {
        barcode.isNotBlank() && normalizeCode(product.barcode.orEmpty()) == barcode -> "BARCODE EXACT"
        model.isNotBlank() && text >= 75 -> "MODEL + OCR + visual"
        text >= ACCEPT_STRONG_IDENTITY && visual >= MIN_VISUAL_SUPPORT -> "IDENTITY KEY + visual master"
        text >= ACCEPT_IDENTITY_WITH_VISUAL && visual >= 50 -> "OCR + visual master"
        visual >= ACCEPT_VISUAL_ONLY && refs.isNotEmpty() -> "Visual master kuat"
        text > 0 && visual > 0 -> "OCR + visual"
        text > 0 -> "OCR sebagian"
        refs.isNotEmpty() -> "Visual master lemah"
        else -> "Bukti belum cukup"
    }

    private fun rejectionReason(best: RecognitionCandidate, second: RecognitionCandidate?, margin: Int, barcode: String, model: String): String = when {
        barcode.isNotBlank() && best.textScore < ACCEPT_EXACT_BARCODE -> "Barcode terdeteksi tetapi tidak cocok dengan database"
        second != null && margin < MIN_MARGIN -> "Kandidat terlalu berdekatan (margin $margin%); identitas belum aman"
        best.textScore >= ACCEPT_STRONG_IDENTITY && best.visualScore < MIN_VISUAL_SUPPORT -> "Identitas teks kuat tetapi dukungan master visual terlalu lemah"
        best.textScore < ACCEPT_IDENTITY_WITH_VISUAL && best.visualScore < ACCEPT_VISUAL_ONLY -> "Bukti identitas belum cukup kuat"
        else -> "Bukti identitas belum cukup kuat"
    }

    private fun fieldScore(ocrTokens: List<String>, fieldTokens: List<String>, weight: Int): Pair<Int, Int> {
        if (fieldTokens.isEmpty()) return 0 to 0
        val usable = fieldTokens.filter { it.length >= 3 && !STOP_WORDS.contains(it) }
        if (usable.isEmpty()) return 0 to 0
        val hits = fuzzyHits(usable, ocrTokens)
        if (hits == 0) return 0 to 0
        val ratio = hits.toFloat() / usable.size
        val score = (ratio * weight).roundToInt().coerceIn(0, weight)
        val strong = when {
            hits >= 2 -> 2
            hits == 1 && usable.size <= 2 -> 1
            else -> 0
        }
        return score to strong
    }

    private fun fuzzyHits(expected: List<String>, actual: List<String>, codeMode: Boolean = false): Int =
        expected.count { e -> actual.any { a -> if (codeMode) fuzzyCode(e, a) else fuzzyToken(e, a) } }

    private fun fuzzyToken(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length < 4 || b.length < 4) return false
        if (a.contains(b) || b.contains(a)) return true
        return levenshtein(a, b) <= if (minOf(a.length, b.length) >= 7) 2 else 1
    }

    private fun fuzzyCode(a: String, b: String): Boolean {
        val x = normalizeCode(a)
        val y = normalizeCode(b)
        if (x == y) return true
        if (x.length < 4 || y.length < 4) return false
        if (x.contains(y) || y.contains(x)) return true
        return levenshtein(x, y) <= 1
    }

    private fun identityTokens(value: String): List<String> = tokenize(normalize(value))

    private fun extractModelTokens(value: String): List<String> {
        val normalized = normalize(value)
        return Regex("\\b[A-Z]{1,4}[- ]?[0-9]{1,5}[A-Z0-9-]*\\b|\\b[0-9]{3,8}\\b")
            .findAll(normalized)
            .map { normalizeCode(it.value) }
            .filter { it.length >= 4 }
            .toList()
    }

    private fun containsCode(text: String, code: String): Boolean = normalizeCode(text).contains(code)

    private fun levenshtein(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        val curr = IntArray(b.length + 1)
        for (i in a.indices) {
            curr[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                curr[j + 1] = minOf(curr[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            for (j in prev.indices) prev[j] = curr[j]
        }
        return prev[b.length]
    }

    private fun normalize(value: String): String = value
        .uppercase()
        .replace("0", "0")
        .replace(Regex("[^A-Z0-9]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private fun normalizeCode(value: String): String = normalize(value).replace(" ", "")
    private fun tokenize(value: String): List<String> = value.split(" ").filter { it.isNotBlank() }

    private val STOP_WORDS = setOf(
        "SIZE", "MODEL", "VARIAN", "VARIANT", "KOREA", "KOREAN", "TECHNOLOGY",
        "QUALITY", "PREMIUM", "BEST", "THE", "AND", "FOR", "GO", "PCS", "PC",
        "MADE", "IN", "QTY", "QUANTITY", "COLOR", "COLOUR", "HOOK", "FISHING",
        "CHEMICALLY", "SHARPENED", "CARBON", "HIGH", "EVERYONE", "CREATING", "PLEASURE"
    )
}
