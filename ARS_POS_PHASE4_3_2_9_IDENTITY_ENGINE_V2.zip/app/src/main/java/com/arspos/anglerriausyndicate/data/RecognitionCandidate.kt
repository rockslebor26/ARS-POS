package com.arspos.anglerriausyndicate.data

import com.arspos.anglerriausyndicate.data.db.ProductEntity

/** Candidate diagnostik per produk pada Phase 4.3.2.8. */
data class RecognitionCandidate(
    val product: ProductEntity,
    val visualScore: Int,
    val textScore: Int,
    val finalScore: Int,
    val evidence: String,
    val hasMaster: Boolean
)
