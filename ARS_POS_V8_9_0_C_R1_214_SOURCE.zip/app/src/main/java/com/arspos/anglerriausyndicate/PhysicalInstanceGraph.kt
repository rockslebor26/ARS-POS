package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.max

/**
 * V8.9.0-C cross-lane quantity ownership graph.
 *
 * This layer is deliberately conservative: it does not merge identities and it
 * never grants quantity. It can only remove quantity authority from a LONG
 * hypothesis that is almost completely contained by a strong NORMAL physical
 * owner. The suppressed hypothesis remains available as identity evidence.
 */
object PhysicalInstanceGraph {
    data class Result(
        val proposals: List<ScanProposal>,
        val graphGroups: Int,
        val evidenceAttachments: Int,
        val quantityOwnerConflictsPrevented: Int
    )

    fun resolve(input: List<ScanProposal>): Result {
        if (input.size < 2) return Result(assignSelfOwners(input), 0, 0, 0)
        val proposals = assignSelfOwners(input).toMutableList()
        var groups = 0
        var attachments = 0
        var prevented = 0
        val attached = HashSet<Int>()

        val normalIndices = proposals.indices.filter { proposals[it].proposalType == ScanProposal.TYPE_NORMAL }
        val longIndices = proposals.indices.filter { proposals[it].proposalType == ScanProposal.TYPE_LONG }

        for (ni in normalIndices) {
            val normal = proposals[ni]
            if (!strongNormalOwner(normal)) continue
            for (li in longIndices) {
                if (li in attached) continue
                val long = proposals[li]
                if (!long.quantityEligible) continue
                val containment = containmentRatio(inner = long.normalizedBounds, outer = normal.normalizedBounds)
                if (containment < 0.88f) continue

                val graphId = "PIG-${stableId(normal)}"
                val ownerId = stableId(normal)
                proposals[ni] = normal.copy(
                    physicalGraphId = graphId,
                    quantityOwnerId = ownerId
                )
                proposals[li] = long.copy(
                    physicalGraphId = graphId,
                    quantityOwnerId = ownerId,
                    quantityEligible = false,
                    evidenceAttachment = true,
                    evidenceAttachmentReason = "CROSS_LANE_LONG_CONTAINED_BY_NORMAL_OWNER"
                )
                attached += li
                groups++
                attachments++
                prevented++
            }
        }
        return Result(proposals, groups, attachments, prevented)
    }

    private fun assignSelfOwners(input: List<ScanProposal>): List<ScanProposal> = input.map { proposal ->
        if (proposal.quantityOwnerId.isNotBlank() || !proposal.quantityEligible) proposal
        else proposal.copy(
            physicalGraphId = proposal.physicalGraphId.ifBlank { "PIG-${stableId(proposal)}" },
            quantityOwnerId = stableId(proposal)
        )
    }

    private fun strongNormalOwner(p: ScanProposal): Boolean =
        p.quantityEligible &&
            p.normalPurityScore >= 75 &&
            (p.normalCompletenessScore >= 70 || p.normalCompletenessState == NormalCompletenessPolicy.STATE_COMPLETE)

    private fun containmentRatio(inner: Rect, outer: Rect): Float {
        val left = max(inner.left, outer.left)
        val top = max(inner.top, outer.top)
        val right = minOf(inner.right, outer.right)
        val bottom = minOf(inner.bottom, outer.bottom)
        if (right <= left || bottom <= top) return 0f
        val intersection = (right - left).toLong() * (bottom - top).toLong()
        val innerArea = inner.width().coerceAtLeast(1).toLong() * inner.height().coerceAtLeast(1).toLong()
        return (intersection.toDouble() / innerArea.toDouble()).toFloat().coerceIn(0f, 1f)
    }

    private fun stableId(p: ScanProposal): String =
        p.canonicalPhysicalObjectId.ifBlank {
            p.physicalObjectId.ifBlank {
                p.physicalInstanceHint.ifBlank { p.proposalId }
            }
        }
}
