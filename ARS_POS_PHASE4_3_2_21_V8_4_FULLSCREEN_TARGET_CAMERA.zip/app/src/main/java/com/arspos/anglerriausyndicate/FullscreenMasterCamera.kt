package com.arspos.anglerriausyndicate

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.view.Window
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Dialog
import androidx.compose.material3.DialogProperties
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.Executor

private val CameraGold = Color(0xFFE1BC68)
private val CameraBlack = Color(0xFF050505)
private val CameraRed = Color(0xFFE57373)

private enum class MasterCameraMode { PHOTO, VIDEO }

private class FullscreenCameraController(private val context: Context) {
    private var provider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var camera: androidx.camera.core.Camera? = null
    private var previewView: PreviewView? = null
    private var owner: androidx.lifecycle.LifecycleOwner? = null
    private var lensFacing: Int = CameraSelector.LENS_FACING_BACK

    fun bind(previewView: PreviewView, owner: androidx.lifecycle.LifecycleOwner, lensFacing: Int = CameraSelector.LENS_FACING_BACK) {
        this.previewView = previewView
        this.owner = owner
        this.lensFacing = lensFacing
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            runCatching {
                val p = future.get()
                provider = p
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                val image = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(
                            Quality.HD,
                            FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
                        )
                    )
                    .build()
                val video = VideoCapture.withOutput(recorder)
                imageCapture = image
                videoCapture = video
                p.unbindAll()
                val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
                camera = p.bindToLifecycle(
                    owner,
                    selector,
                    preview,
                    image,
                    video
                )
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun capturePhoto(file: File, executor: Executor, callback: (Boolean, String?) -> Unit) {
        val capture = imageCapture ?: run {
            callback(false, "Kamera belum siap")
            return
        }
        val output = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(output, executor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                callback(true, null)
            }

            override fun onError(exception: ImageCaptureException) {
                callback(false, exception.message ?: "Gagal mengambil foto")
            }
        })
    }

    fun startVideo(file: File, executor: Executor, callback: (VideoRecordEvent) -> Unit): Boolean {
        val capture = videoCapture ?: return false
        if (recording != null) return false
        val output = FileOutputOptions.Builder(file).build()
        return runCatching {
            recording = capture.output.prepareRecording(context, output).start(executor) { event ->
                callback(event)
            }
            true
        }.getOrDefault(false)
    }

    fun stopVideo() {
        recording?.stop()
        recording = null
    }

    fun toggleTorch(): Boolean {
        val c = camera ?: return false
        val enabled = !(c.cameraInfo.torchState.value == androidx.camera.core.TorchState.ON)
        c.cameraControl.enableTorch(enabled)
        return enabled
    }

    fun switchLens(): Boolean {
        val next = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        val pv = previewView ?: return false
        val own = owner ?: return false
        lensFacing = next
        bind(pv, own, next)
        return true
    }

    fun release() {
        recording?.stop()
        recording = null
        provider?.unbindAll()
        provider = null
        camera = null
        imageCapture = null
        videoCapture = null
        previewView = null
        owner = null
    }
}

@Composable
fun FullscreenMasterCamera(
    title: String,
    subtitle: String,
    mode: String,
    isLongObject: Boolean,
    outputFile: File,
    onCaptured: (File) -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val view = LocalView.current
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val controller = remember { FullscreenCameraController(context) }
    var locked by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var seconds by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Arahkan produk ke area TARGET") }
    var cameraReady by remember { mutableStateOf(false) }
    var torchOn by remember { mutableStateOf(false) }
    var frontCamera by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val window: Window? = (view.context as? android.app.Dialog)?.window
        if (window != null) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            window.statusBarColor = android.graphics.Color.BLACK
            window.navigationBarColor = android.graphics.Color.BLACK
            WindowInsetsControllerCompat(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            if (window != null) {
                WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
            }
            controller.release()
        }
    }

    Dialog(
        onDismissRequest = { if (!recording) onCancel() },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(CameraBlack)
        ) {
            AndroidView(
                factory = { ctx ->
                    PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                        controller.bind(this, owner, if (frontCamera) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK)
                        cameraReady = true
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            Box(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 22.dp, vertical = 26.dp)
            ) {
                Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { if (!recording) onCancel() }) {
                            Text("✕", color = Color.White, fontSize = 28.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(subtitle, color = CameraGold, fontSize = 11.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { torchOn = controller.toggleTorch() }) {
                                Text(if (torchOn) "🔦" else "💡", color = CameraGold, fontSize = 18.sp)
                            }
                            IconButton(onClick = {
                                if (!recording && controller.switchLens()) {
                                    frontCamera = !frontCamera
                                    torchOn = false
                                }
                            }) {
                                Text("🔄", color = CameraGold, fontSize = 18.sp)
                            }
                        }
                    }

                    Spacer(Modifier.weight(1f))

                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(if (isLongObject) 330.dp else 280.dp)
                            .border(
                                width = if (locked) 4.dp else 2.dp,
                                color = if (locked) CameraGold else Color.White.copy(alpha = 0.85f),
                                shape = RoundedCornerShape(20.dp)
                            )
                    ) {
                        Column(
                            Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🎯", fontSize = 38.sp)
                            Text(
                                if (locked) "TARGET TERKUNCI" else "TARGET",
                                color = if (locked) CameraGold else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                if (isLongObject) "Pastikan seluruh joran masuk area" else "Tempatkan produk di dalam kotak",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Text(status, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    if (isLongObject) {
                        Text("MODE OBJEK PANJANG • siluet penuh diprioritaskan", color = CameraGold, fontSize = 10.sp)
                    }

                    Spacer(Modifier.weight(1f))

                    if (recording) {
                        Text("● MEREKAM 00:${seconds.toString().padStart(2, '0')}", color = CameraRed, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { controller.stopVideo() },
                            modifier = Modifier.fillMaxWidth(0.72f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                        ) {
                            Text("■ STOP REKAM", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    locked = !locked
                                    status = if (locked) "✓ Target dikunci — ambil hanya produk ini" else "Arahkan produk ke area TARGET"
                                }
                            ) {
                                Text(if (locked) "🔓 BUKA LOCK" else "🔒 LOCK TARGET", color = CameraGold)
                            }
                            Spacer(Modifier.size(12.dp))
                            Button(
                                enabled = cameraReady && locked,
                                onClick = {
                                    if (mode == "PHOTO") {
                                        status = "MENGAMBIL FOTO..."
                                        controller.capturePhoto(outputFile, ContextCompat.getMainExecutor(context)) { ok, error ->
                                            if (ok) onCaptured(outputFile) else status = error ?: "Foto gagal"
                                        }
                                    } else {
                                        val started = controller.startVideo(outputFile, ContextCompat.getMainExecutor(context)) { event ->
                                            if (event is VideoRecordEvent.Finalize) {
                                                recording = false
                                                if (event.hasError()) {
                                                    outputFile.delete()
                                                    status = "Rekaman gagal: ${event.error}"
                                                } else {
                                                    onCaptured(outputFile)
                                                }
                                            }
                                        }
                                        if (started) {
                                            recording = true
                                            seconds = 0
                                            scope.launch {
                                                while (recording) {
                                                    delay(1000)
                                                    seconds++
                                                    if (seconds >= 4) controller.stopVideo()
                                                }
                                            }
                                        } else status = "Kamera belum siap."
                                    }
                                },
                                modifier = Modifier.size(74.dp),
                                shape = RoundedCornerShape(40.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CameraGold)
                            ) {
                                Text(if (mode == "PHOTO") "📸" else "●", fontSize = 26.sp, color = Color.Black)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            if (mode == "PHOTO") "LOCK TARGET terlebih dahulu, lalu ambil foto master." else "LOCK TARGET terlebih dahulu, lalu rekam 2–4 detik.",
                            color = Color.White.copy(alpha = 0.72f),
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}
