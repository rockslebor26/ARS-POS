package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Phase 4.3.2.20: ARS Product Identity Engine V8.3 visual lane.
 *
 * V8.3 keeps the deterministic offline matcher but makes it more tolerant of
 * camera framing, orientation and background changes. It uses several center
 * windows plus edge/gradient descriptors. Long objects (rods) are compared at
 * 0/90/180/270 degrees and receive a small elongated-shape agreement signal.
 * This is still a reference matcher, not a trained AI model.
 */
object ProductVisualMatcher {
    private const val SIZE = 32
    private const val HASH_WIDTH = 9
    private const val HASH_HEIGHT = 8
    private const val GRID = 4
    private const val PROJECTION_BINS = 16
    private const val LONG_PROFILE_BINS = 24

    private data class Fingerprint(
        val pixels: FloatArray,
        val histogram: FloatArray,
        val hash: Long,
        val shape: FloatArray,
        val gradient: FloatArray,
        val projectionX: FloatArray,
        val projectionY: FloatArray,
        val aspect: Float
    )

    private data class FingerprintBank(
        val full: Fingerprint,
        val center90: Fingerprint,
        val center82: Fingerprint,
        val center68: Fingerprint
    )

    private val referenceCache = ConcurrentHashMap<String, FingerprintBank>()

    fun score(scan: Bitmap, referencePath: String): Int = score(scan, referencePath, false)

    /** V8.1: elongated products such as rods are orientation-agnostic. */
    fun score(scan: Bitmap, referencePath: String, longObject: Boolean): Int {
        val file = File(referencePath)
        if (!file.exists()) return 0

        val cacheKey = "${file.absolutePath}:${file.lastModified()}:${file.length()}"
        val bank = referenceCache[cacheKey]
            ?: decodeReference(referencePath)?.let(::fingerprintBank)?.also { referenceCache[cacheKey] = it }
            ?: return 0

        fun direct(source: Bitmap): Float {
            val sb = fingerprintBank(source)
            return bestBankSimilarity(sb, bank, longObject)
        }

        var best = direct(scan)

        if (longObject) {
            for (angle in intArrayOf(90, 180, 270)) {
                val rotated = rotate(scan, angle.toFloat())
                val value = direct(rotated)
                rotated.recycle()
                best = maxOf(best, value)
            }
            // Long-object lane is intentionally conservative: shape agreement
            // helps when the camera orientation changes, but never dominates.
            val reference = bank.full
            val scanFp = fingerprint(scan)
            val projection = projectionSimilarity(scanFp, reference)
            val aspect = elongatedShapeBonus(scan, reference) / 100f
            val longProfile = longObjectProfileSimilarity(scan, reference)
            val strip = longStripSimilarity(scan, referencePath)
            // V8.3: the long-object lane now emphasizes the product strip
            // (the rod itself) instead of letting the surrounding floor/background
            // dominate the fingerprint. Shape/projection remain supporting lanes.
            best = maxOf(
                best * 0.46f + longProfile * 0.24f + strip * 0.22f + projection * 100f * 0.05f + aspect * 100f * 0.03f,
                best * 0.62f + strip * 0.24f + longProfile * 0.10f + projection * 100f * 0.04f
            )
        }

        return best.roundToInt().coerceIn(0, 100)
    }

    private fun bestBankSimilarity(a: FingerprintBank, b: FingerprintBank, longObject: Boolean): Float {
        val candidates = listOf(
            compare(a.full, b.full),
            compare(a.center90, b.center90),
            compare(a.center82, b.center82),
            compare(a.center68, b.center68)
        )
        val best = candidates.maxOrNull() ?: 0f
        val sorted = candidates.sortedDescending()
        val agreement = if (sorted.size >= 2 && sorted[1] >= sorted[0] - 6f) 2.5f else 0f
        val stable = (best * 0.96f + agreement).coerceIn(0f, 100f)
        return if (longObject) stable else stable
    }

    private fun compare(a: Fingerprint, b: Fingerprint): Float = (
        structuralSimilarity(a.pixels, b.pixels) * 0.18f +
        histogramSimilarity(a.histogram, b.histogram) * 0.06f +
        hashSimilarity(a.hash, b.hash) * 0.08f +
        vectorSimilarity(a.shape, b.shape) * 0.31f +
        vectorSimilarity(a.gradient, b.gradient) * 0.25f +
        projectionSimilarity(a, b) * 0.12f
    ).coerceIn(0f, 1f) * 100f

    private fun fingerprintBank(source: Bitmap): FingerprintBank = FingerprintBank(
        full = fingerprint(source),
        center90 = fingerprintWindow(source, 0.90f),
        center82 = fingerprintWindow(source, 0.82f),
        center68 = fingerprintWindow(source, 0.68f)
    )

    private fun fingerprintWindow(source: Bitmap, fraction: Float): Fingerprint {
        val crop = centerCrop(source, fraction)
        return try {
            fingerprint(crop)
        } finally {
            if (crop !== source) crop.recycle()
        }
    }

    private fun centerCrop(source: Bitmap, fraction: Float): Bitmap {
        val f = fraction.coerceIn(0.55f, 1f)
        val w = (source.width * f).toInt().coerceAtLeast(24).coerceAtMost(source.width)
        val h = (source.height * f).toInt().coerceAtLeast(24).coerceAtMost(source.height)
        val left = (source.width - w) / 2
        val top = (source.height - h) / 2
        return Bitmap.createBitmap(source, left, top, w, h)
    }

    private fun decodeReference(path: String): Bitmap? = BitmapFactory.decodeFile(path)

    private fun fingerprint(source: Bitmap): Fingerprint {
        val scaled = Bitmap.createScaledBitmap(source, SIZE, SIZE, true)
        val pixels = FloatArray(SIZE * SIZE)
        val histogram = FloatArray(24)
        var index = 0
        var sum = 0f

        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val c = scaled.getPixel(x, y)
                val r = Color.red(c) / 255f
                val g = Color.green(c) / 255f
                val b = Color.blue(c) / 255f
                val gray = 0.299f * r + 0.587f * g + 0.114f * b
                pixels[index++] = gray
                sum += gray
                histogram[(r * 8).toInt().coerceIn(0, 7)] += 1f
                histogram[8 + (g * 8).toInt().coerceIn(0, 7)] += 1f
                histogram[16 + (b * 8).toInt().coerceIn(0, 7)] += 1f
            }
        }

        val mean = sum / pixels.size
        var variance = 0f
        for (i in pixels.indices) {
            pixels[i] -= mean
            variance += pixels[i] * pixels[i]
        }
        val std = sqrt((variance / pixels.size).toDouble()).toFloat().coerceAtLeast(0.0001f)
        for (i in pixels.indices) pixels[i] /= std

        val total = (SIZE * SIZE).toFloat()
        for (i in histogram.indices) histogram[i] /= total

        val shape = shapeDescriptor(scaled)
        val gradient = gradientDescriptor(scaled)
        val projections = edgeProjections(scaled)
        val hash = differenceHash(scaled)

        if (scaled !== source) scaled.recycle()

        val aspect = maxOf(source.width, source.height).toFloat() /
            minOf(source.width, source.height).coerceAtLeast(1)

        return Fingerprint(
            pixels, histogram, hash, shape, gradient,
            projections.first, projections.second, aspect
        )
    }

    private fun shapeDescriptor(bitmap: Bitmap): FloatArray {
        val result = FloatArray(GRID * GRID)
        for (gy in 0 until GRID) for (gx in 0 until GRID) {
            var total = 0f
            var count = 0
            val x0 = gx * SIZE / GRID
            val x1 = (gx + 1) * SIZE / GRID
            val y0 = gy * SIZE / GRID
            val y1 = (gy + 1) * SIZE / GRID
            for (y in y0 until y1) for (x in x0 until x1) {
                if (x <= 0 || y <= 0 || x >= SIZE - 1 || y >= SIZE - 1) continue
                val dx = gray(bitmap.getPixel(x + 1, y)) - gray(bitmap.getPixel(x - 1, y))
                val dy = gray(bitmap.getPixel(x, y + 1)) - gray(bitmap.getPixel(x, y - 1))
                val magnitude = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                val cx = (x - SIZE / 2f) / (SIZE / 2f)
                val cy = (y - SIZE / 2f) / (SIZE / 2f)
                val centerWeight = (1f - 0.50f * sqrt((cx * cx + cy * cy).toDouble()).toFloat()).coerceAtLeast(0.30f)
                total += magnitude * centerWeight
                count++
            }
            result[gy * GRID + gx] = if (count == 0) 0f else total / count
        }
        normalize(result)
        return result
    }

    private fun gradientDescriptor(bitmap: Bitmap): FloatArray {
        val bins = 8
        val result = FloatArray(GRID * GRID * bins)
        for (gy in 0 until GRID) for (gx in 0 until GRID) {
            val x0 = gx * SIZE / GRID
            val x1 = (gx + 1) * SIZE / GRID
            val y0 = gy * SIZE / GRID
            val y1 = (gy + 1) * SIZE / GRID
            for (y in maxOf(1, y0) until minOf(SIZE - 1, y1)) for (x in maxOf(1, x0) until minOf(SIZE - 1, x1)) {
                val dx = gray(bitmap.getPixel(x + 1, y)) - gray(bitmap.getPixel(x - 1, y))
                val dy = gray(bitmap.getPixel(x, y + 1)) - gray(bitmap.getPixel(x, y - 1))
                val magnitude = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                if (magnitude < 0.025f) continue
                var angle = atan2(dy.toDouble(), dx.toDouble())
                if (angle < 0) angle += Math.PI
                if (angle >= Math.PI) angle -= Math.PI
                val bin = ((angle / Math.PI) * bins).toInt().coerceIn(0, bins - 1)
                result[(gy * GRID + gx) * bins + bin] += magnitude
            }
        }
        normalize(result)
        return result
    }

    private fun edgeProjections(bitmap: Bitmap): Pair<FloatArray, FloatArray> {
        val x = FloatArray(PROJECTION_BINS)
        val y = FloatArray(PROJECTION_BINS)
        for (py in 1 until SIZE - 1) for (px in 1 until SIZE - 1) {
            val dx = gray(bitmap.getPixel(px + 1, py)) - gray(bitmap.getPixel(px - 1, py))
            val dy = gray(bitmap.getPixel(px, py + 1)) - gray(bitmap.getPixel(px, py - 1))
            val mag = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            val bx = (px * PROJECTION_BINS / SIZE).coerceIn(0, PROJECTION_BINS - 1)
            val by = (py * PROJECTION_BINS / SIZE).coerceIn(0, PROJECTION_BINS - 1)
            x[bx] += mag
            y[by] += mag
        }
        normalize(x)
        normalize(y)
        return x to y
    }

    private fun projectionSimilarity(a: Fingerprint, b: Fingerprint): Float {
        val direct = (vectorSimilarity(a.projectionX, b.projectionX) + vectorSimilarity(a.projectionY, b.projectionY)) / 2f
        val rotated = (vectorSimilarity(a.projectionX, b.projectionY) + vectorSimilarity(a.projectionY, b.projectionX)) / 2f
        return maxOf(direct, rotated).coerceIn(0f, 1f)
    }

    private fun normalize(values: FloatArray) {
        var sum = 0f
        for (v in values) sum += v * v
        val norm = sqrt(sum.toDouble()).toFloat().coerceAtLeast(0.0001f)
        for (i in values.indices) values[i] /= norm
    }

    private fun structuralSimilarity(a: FloatArray, b: FloatArray): Float {
        var mse = 0.0
        for (i in a.indices) {
            val d = (a[i] - b[i]).toDouble()
            mse += d * d
        }
        return (1.0 / (1.0 + (mse / a.size) / 4.0)).toFloat().coerceIn(0f, 1f)
    }

    private fun histogramSimilarity(a: FloatArray, b: FloatArray): Float {
        var distance = 0f
        for (i in a.indices) distance += abs(a[i] - b[i])
        return (1f - distance / 2f).coerceIn(0f, 1f)
    }

    private fun vectorSimilarity(a: FloatArray, b: FloatArray): Float {
        var dot = 0f
        var na = 0f
        var nb = 0f
        for (i in a.indices) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        if (na <= 0f || nb <= 0f) return 0f
        return (dot / (sqrt(na.toDouble()).toFloat() * sqrt(nb.toDouble()).toFloat())).coerceIn(0f, 1f)
    }

    private fun hashSimilarity(a: Long, b: Long): Float =
        1f - (java.lang.Long.bitCount(a xor b) / 64f)

    private fun differenceHash(bitmap: Bitmap): Long {
        val scaled = if (bitmap.width == HASH_WIDTH && bitmap.height == HASH_HEIGHT) bitmap
        else Bitmap.createScaledBitmap(bitmap, HASH_WIDTH, HASH_HEIGHT, true)
        var hash = 0L
        var bit = 0
        for (y in 0 until HASH_HEIGHT) for (x in 0 until HASH_WIDTH - 1) {
            if (gray(scaled.getPixel(x, y)) > gray(scaled.getPixel(x + 1, y))) hash = hash or (1L shl bit)
            bit++
        }
        if (scaled !== bitmap) scaled.recycle()
        return hash
    }

    private fun rotate(source: Bitmap, degrees: Float): Bitmap {
        val matrix = android.graphics.Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    /** V8.2: background-tolerant signature for rods and other elongated products.
     * It compares the distribution of strong edges along the dominant axis,
     * orientation balance and aspect ratio instead of relying on raw pixels.
     */
    private fun longObjectProfileSimilarity(scan: Bitmap, reference: Fingerprint): Float {
        val best = mutableListOf<Float>()
        val angles = floatArrayOf(0f, 90f, 180f, 270f)
        for (angle in angles) {
            val rotated = if (angle == 0f) scan else rotate(scan, angle)
            try {
                val fp = fingerprint(rotated)
                val axis = if (fp.aspect >= 1.35f) fp.projectionY else fp.projectionX
                val refAxis = if (reference.aspect >= 1.35f) reference.projectionY else reference.projectionX
                val projection = vectorSimilarity(axis, refAxis)
                val aspect = aspectSimilarity(fp.aspect, reference.aspect)
                val orientation = orientationBalance(fp)
                val refOrientation = orientationBalance(reference)
                val orientationSim = 1f - abs(orientation - refOrientation).coerceIn(0f, 1f)
                best += (projection * 0.52f + aspect * 0.28f + orientationSim * 0.20f).coerceIn(0f, 1f)
            } finally {
                if (rotated !== scan) rotated.recycle()
            }
        }
        return (best.maxOrNull() ?: 0f).coerceIn(0f, 1f) * 100f
    }


    /** V8.3: compare a narrow full-length product strip after normalizing
     * orientation. This reduces the influence of tile/background outside a rod. */
    private fun longStripSimilarity(scan: Bitmap, referencePath: String): Float {
        val ref = decodeReference(referencePath) ?: return 0f
        val scores = ArrayList<Float>()
        try {
            for (angle in floatArrayOf(0f, 90f, 180f, 270f)) {
                val scanRotated = if (angle == 0f) scan else rotate(scan, angle)
                val refRotated = if (angle == 0f) ref else rotate(ref, angle)
                try {
                    val scanStrip = verticalStrip(scanRotated)
                    val refStrip = verticalStrip(refRotated)
                    try {
                        val a = fingerprint(scanStrip)
                        val b = fingerprint(refStrip)
                        val structural = structuralSimilarity(a.pixels, b.pixels)
                        val shape = vectorSimilarity(a.shape, b.shape)
                        val gradient = vectorSimilarity(a.gradient, b.gradient)
                        val projection = projectionSimilarity(a, b)
                        scores += (structural * 0.24f + shape * 0.30f + gradient * 0.28f + projection * 0.18f).coerceIn(0f, 1f)
                    } finally {
                        scanStrip.recycle()
                        refStrip.recycle()
                    }
                } finally {
                    if (scanRotated !== scan) scanRotated.recycle()
                    if (refRotated !== ref) refRotated.recycle()
                }
            }
        } finally {
            ref.recycle()
        }
        return (scores.maxOrNull() ?: 0f) * 100f
    }

    private fun verticalStrip(source: Bitmap): Bitmap {
        val w = (source.width * 0.30f).toInt().coerceAtLeast(24).coerceAtMost(source.width)
        val h = (source.height * 0.94f).toInt().coerceAtLeast(24).coerceAtMost(source.height)
        val left = (source.width - w) / 2
        val top = (source.height - h) / 2
        return Bitmap.createBitmap(source, left, top, w, h)
    }

    private fun aspectSimilarity(a: Float, b: Float): Float {
        val aa = a.coerceAtLeast(1f)
        val bb = b.coerceAtLeast(1f)
        val delta = abs(kotlin.math.ln((aa / bb).coerceAtLeast(0.01f).toDouble())).toFloat()
        return (1f - delta / 1.6f).coerceIn(0f, 1f)
    }

    private fun orientationBalance(fp: Fingerprint): Float {
        val x = fp.projectionX.sum()
        val y = fp.projectionY.sum()
        val total = (x + y).coerceAtLeast(0.0001f)
        return abs(x - y) / total
    }

    private fun elongatedShapeBonus(scan: Bitmap, reference: Fingerprint): Float {
        val sr = maxOf(scan.width, scan.height).toFloat() / minOf(scan.width, scan.height).coerceAtLeast(1)
        val rr = reference.aspect.coerceAtLeast(1f)
        val delta = abs(kotlin.math.ln((sr / rr).coerceAtLeast(0.01f).toDouble())).toFloat()
        return (100f - delta * 28f).coerceIn(45f, 100f)
    }

    private fun gray(c: Int): Float =
        0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
}
