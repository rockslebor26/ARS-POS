# Build V8.9.0-B / 213

Use the companion GitHub Actions workflow `build-apk.yml` with source archive:

`ARS_POS_V8_9_0_B_R1_213_SOURCE.zip`

The workflow must stop if any of these invariants fail:

- source SHA-256 mismatch;
- applicationId differs from `com.arspos.anglerriausyndicate`;
- versionCode is not 213 or does not exceed 212;
- versionName is not 1.12.1;
- Room DB is not version 6 with MIGRATION_5_6;
- V8.9.0-B capture/APVD feature contracts are missing;
- any original recognition threshold changes;
- official keystore certificate differs from the ARS POS official fingerprint;
- compile/unit tests fail;
- release APK package/version/signature/alignment verification fails.

Required GitHub repository secrets remain the existing official release secrets:

- `ARS_RELEASE_KEYSTORE_BASE64`
- `ARS_RELEASE_STORE_PASSWORD`
- `ARS_RELEASE_KEY_ALIAS`
- `ARS_RELEASE_KEY_PASSWORD`
- `ARS_RELEASE_CERT_SHA256`
