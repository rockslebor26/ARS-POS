# ARS POS 1.12.1 (213) — V8.9.0-B

Phase 4.3.6.0 — SMART_CAPTURE_PRIVATE_VISUAL_DNA_TRANSACTION_RECOGNITION_R1.

This is an in-place update from 1.12.0 (212). Do not uninstall the production application.

Primary changes:
- capture-centric frozen-evidence transaction recognition;
- continuous live identity removed from critical transaction path;
- APVD runtime extraction/scanner routing enabled;
- orientation-invariant 0/90/180/270 visual descriptors;
- RAW/enhanced consensus with EVIDENCE_CONFLICT handling;
- barcode-first and selective OCR fallback;
- bounded parallel per-object recognition;
- collision-gated REBUILD SMART CATALOG for DB v6;
- accepted identity still requires unchanged production safety gates;
- physical engine remains sole authority for transaction quantity.

Official package: `com.arspos.anglerriausyndicate`
Official signer SHA-256: `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`
