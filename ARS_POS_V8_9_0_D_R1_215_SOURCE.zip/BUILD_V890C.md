# Build V8.9.0-C / 214

Use the companion GitHub Actions workflow `build-apk.yml` with source archive:

`ARS_POS_V8_9_0_C_R1_214_SOURCE.zip`

The workflow must fail closed if any of these invariants fail:

- source ZIP SHA-256 mismatch;
- applicationId differs from `com.arspos.anglerriausyndicate`;
- versionCode is not 214 or does not exceed 213;
- versionName is not 1.12.2;
- Room DB is not v6 with MIGRATION_5_6;
- V8.9.0-C APVD activation/Physical Instance Graph/Axial DNA contracts are missing;
- any of the 14 production recognition thresholds changes;
- source manifest, Python tests or gateway tests fail;
- Kotlin compile or Android unit tests fail;
- official signing certificate differs from the ARS POS official fingerprint;
- final APK package/version/signature/alignment verification fails.

Required existing GitHub repository secrets:

- `ARS_RELEASE_KEYSTORE_BASE64`
- `ARS_RELEASE_STORE_PASSWORD`
- `ARS_RELEASE_KEY_ALIAS`
- `ARS_RELEASE_KEY_PASSWORD`
- `ARS_RELEASE_CERT_SHA256`
