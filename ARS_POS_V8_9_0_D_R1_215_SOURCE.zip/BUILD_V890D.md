# Build V8.9.0-D / 215

Use companion GitHub Actions workflow `build-apk.yml` with source archive:

`ARS_POS_V8_9_0_D_R1_215_SOURCE.zip`

The workflow fails closed if package/version/signer/DB invariants change, any of the 14 recognition thresholds changes, Smart Capture minimum-two-frame contract disappears, evidence-only LONG can acquire quantity, collision audit fields disappear, static/source tests fail, Kotlin/Android tests fail, or final APK package/version/signature/alignment verification fails.

Required existing GitHub secrets:
- `ARS_RELEASE_KEYSTORE_BASE64`
- `ARS_RELEASE_STORE_PASSWORD`
- `ARS_RELEASE_KEY_ALIAS`
- `ARS_RELEASE_KEY_PASSWORD`
- `ARS_RELEASE_CERT_SHA256`
