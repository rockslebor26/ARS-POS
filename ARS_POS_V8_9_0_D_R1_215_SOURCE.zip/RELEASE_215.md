# ARS POS 1.12.3 (215) — V8.9.0-D

Phase 4.3.6.1 — `AUTHORITATIVE_INSTANCE_MASK_TRUE_MICROBURST_CROSS_LANE_HIGH_RES_R1`.

This release is an **in-place update** from `1.12.2 (214)`. Do not uninstall the production application.

Primary changes:
- true 2–3 frame frozen Smart Capture with a minimum-two-frame fail-closed gate;
- authoritative object-local instance mask for NORMAL completeness/background rejection;
- cross-lane NORMAL/LONG evidence attachment without quantity transfer;
- partial-LONG identity-only lane for uncertain elongated objects;
- multi-frame APVD fusion using unchanged score/margin gates;
- ambiguity-triggered high-resolution evidence before OCR;
- OCR expected-information-gain gate;
- explicit collision graph evaluated-pair/accepted-edge/degree telemetry;
- retained open-set KNOWN/AMBIGUOUS/UNKNOWN and Safety Kernel boundaries;
- no recognition threshold reduction.

Official package: `com.arspos.anglerriausyndicate`

Official signer SHA-256: `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`
