# Phase 4.3.6.1 / V8.9.0-D

## AUTHORITATIVE INSTANCE MASK + TRUE MICROBURST + CROSS-LANE PHYSICAL EVIDENCE FUSION + HIGH-RES AMBIGUITY RESOLUTION R1

V8.9.0-D is an evidence-quality/routing correction derived from V8.9.0-C real-device diagnostics. It does **not** lower any production recognition threshold.

## Measured V8.9.0-C blockers addressed

1. **True Smart Capture micro-burst** — a final scan is fail-closed unless at least two independently captured frames exist; maximum remains three.
2. **Authoritative Instance Mask** — NORMAL completeness and background rejection use object-local connected evidence instead of a scene-wide foreground owner.
3. **Cross-lane evidence fusion** — NORMAL and LONG hypotheses that share physical lineage may be attached as identity evidence while quantity authority remains singular or absent.
4. **Partial-LONG identity lane** — an elongated ML-owned hypothesis that is not authentic enough for quantity may still query the LONG catalog; it can never manufacture quantity.
5. **High-resolution ambiguity escalation** — APVD AMBIGUOUS/EVIDENCE_CONFLICT triggers bounded high-resolution object evidence before OCR.
6. **Multi-frame APVD fusion** — KNOWN still requires the existing APVD score/margin/evidence gates and additionally requires repeated Top-1 support across independent frames.
7. **OCR information-gain gate** — OCR is requested only when candidate identity profiles contain discriminative text likely to separate Top-K.
8. **Collision graph audit** — diagnostics distinguish all evaluated product pairs from accepted collision edges and expose max/mean graph degree.
9. **Background instance rejection** — object-local mask evidence can reject scene decoration/background before identity and quantity.
10. **Ground-truth QA gate retained** — operator-confirmed evidence remains required for meaningful accuracy claims.

## Non-negotiable safety invariants

- package: `com.arspos.anglerriausyndicate`
- app: `1.12.3 (215)`
- Room database: `v6`, non-destructive migration only
- update: in-place from `1.12.2 (214)`
- signer: official ARS signer unchanged
- Cloud Identity: `SHADOW`
- Self Learning: `ACTIVE_CONFIRMED_ONLY`
- AI Engineer: `DEV_CENTER_DIAGNOSTIC_ONLY`
- recognition thresholds: all 14 unchanged
- accepted object immutable
- AI/cloud cannot create quantity or mutate stock/payment
- evidence-only LONG cannot own quantity
- object recognition passes remain bounded to 3

## Transaction path

`CAMERA -> TRUE MICROBURST 2-3 -> FROZEN EVIDENCE -> AUTHORITATIVE INSTANCE MASK -> PHYSICAL INSTANCE GRAPH -> PER-OBJECT APVD -> HIGH-RES AMBIGUITY EVIDENCE -> OPTIONAL OCR BY INFORMATION GAIN -> OPEN-SET DECISION -> PHYSICAL QUANTITY SAFETY -> DB PRICE -> TOTAL`
