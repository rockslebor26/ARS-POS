# Phase 4.3.6.0 / V8.9.0-C

## APVD CATALOG ACTIVATION + PHYSICAL INSTANCE GRAPH + AXIAL VISUAL DNA R1

### Mission
Turn V8.9.0-B's capture-centric foundation into an actually usable prepared-knowledge runtime without lowering any production recognition threshold.

### P0 fixes implemented
1. Existing verified Product Master references are automatically compiled into the DB-v6 APVD catalog when no compatible active/ready catalog exists.
2. HIGH/CRITICAL catalog collisions no longer remove a verified product from APVD query. Collision metadata remains a decision guard; KNOWN still requires the unchanged APVD score, margin and independent-evidence gates.
3. Operator-confirmed teaching triggers a bounded APVD catalog rebuild when the product master is verified, so learning can affect the next scan instead of only adding a legacy JPEG reference.
4. Local DNA is region-consistent: stored local regions are compared to the corresponding normalized query region rather than a whole-object descriptor.
5. LONG products receive five normalized axial local-DNA segments. Direction ambiguity is handled by direct/mirrored axial-region comparison.
6. OCR/barcode may independently recall candidates missed by coarse visual retrieval. This is retrieval-only and cannot bypass final identity thresholds.
7. Physical Instance Graph adds one quantity-owner relationship across conservative NORMAL/LONG containment cases. Evidence attachments can contribute evidence but quantityEligible is forced false.
8. Frozen best-identity evidence older than the configured 1500 ms bound is excluded from the final evidence set.
9. Diagnostic database version now comes from the DB-v6 source-of-truth config instead of a stale hard-coded value.

### Preserved invariants
- applicationId: com.arspos.anglerriausyndicate
- Room DB: v6, non-destructive migration retained
- official signer fingerprint unchanged
- versionCode strictly increases: 213 -> 214
- all 14 SmartRecognitionEngine thresholds unchanged
- no threshold relaxation
- frozen RAW evidence remains authoritative/immutable
- maximum transaction evidence passes remains 3
- accepted objects are immutable
- background cannot own identity/quantity
- price is always read from POS DB
- UNKNOWN/AMBIGUOUS is preferred to false accept
- AI Engineer remains diagnostic-only
- Cloud Identity remains SHADOW
- Self Learning remains ACTIVE_CONFIRMED_ONLY

### Scope boundary
This release does not claim the entire long-term architecture is complete. A dedicated learned instance-segmentation model and a true camera-issued three-frame contemporaneous micro-burst remain later regression-gated work. V8.9.0-C closes the measured V8.9.0-B blockers first: APVD activation, regional/axial evidence, candidate recall, stale-frame safety and physical quantity ownership.
