# ARS POS 1.12.3 (215) — Phase 4.3.6.1 / V8.9.0-D

**Authoritative Instance Mask + True Microburst + Cross-Lane Physical Evidence Fusion + High-Res Ambiguity Resolution R1**

Production transaction path:

`camera -> 2–3 frame Smart Capture -> frozen evidence -> object-local instance mask -> physical instance graph -> per-object APVD -> bounded high-resolution ambiguity evidence -> selective OCR -> KNOWN/AMBIGUOUS/UNKNOWN -> Safety Kernel quantity -> price -> total`.

## Release invariants

- Package: `com.arspos.anglerriausyndicate`
- versionName/versionCode: `1.12.3 / 215`
- Room database: `v6`, no destructive migration
- Previous official build: `1.12.2 (214)`
- Update: in-place only
- Cloud Identity: `SHADOW`
- Self Learning: `ACTIVE_CONFIRMED_ONLY`
- ARS AI Engineer: `DEV_CENTER_DIAGNOSTIC_ONLY`
- AI in critical Smart Scan path: disabled
- Recognition thresholds: unchanged (14/14)
- Official signer SHA-256: `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`

See `PHASE4_3_6_1_V8_9_0_D_AUTHORITATIVE_INSTANCE_MASK_TRUE_MICROBURST_CROSS_LANE_HIGH_RES_R1.md`, `RELEASE_215.md`, and `BUILD_V890D.md`.
