# ARS POS Phase 4.3.6.0 / V8.9.0-B

## SMART_CAPTURE_PRIVATE_VISUAL_DNA_TRANSACTION_RECOGNITION_R1

Release target: ARS POS 1.12.1 (213)
Package: `com.arspos.anglerriausyndicate`
Database: ARS Catalog DB v6
Distribution: official update-in-place only

## Objective

V8.9.0-B moves transaction recognition away from continuous live identity retries. The critical path is now capture-centric:

`CAMERA -> SMART CAPTURE -> FROZEN EVIDENCE -> OBJECT EVIDENCE -> APVD -> TOP-K/RERANK -> SELECTIVE OCR/BARCODE -> BOUNDED DECISION -> PHYSICAL QUANTITY -> DB PRICE -> TOTAL`

Live camera remains responsible for preview, presence, framing and physical capture readiness. Continuous live product identity is disabled from the transaction-critical path.

## Runtime changes

- Smart Capture transaction path enabled.
- Frozen capture evidence created at final scene lock.
- Live identity critical path disabled; compatibility code remains diagnostic/non-authoritative.
- ARS Private Visual DNA runtime enabled for final scanner routing.
- APVD uses object-relative deterministic visual descriptors and dense local evidence.
- Rotation bank compares 0/90/180/270 degrees.
- RAW and bounded non-generative enhanced evidence are compared.
- APVD produces KNOWN / AMBIGUOUS / UNKNOWN / EVIDENCE_CONFLICT.
- Barcode is authoritative when available and consistent.
- OCR is selective fallback when APVD/barcode do not settle identity.
- Per-object recognition is bounded and processed with bounded parallelism.
- Existing SmartRecognitionEngine acceptance thresholds remain unchanged.
- Identity cannot create quantity; physical safety remains authoritative.

## Smart Catalog DB v6

`REBUILD SMART CATALOG` is available from Dev Center. It rebuilds recognition-ready APVD entries from operator-verified product references without uninstalling the application. HIGH/CRITICAL catalog collisions stay in STAGING / NEEDS_EVIDENCE and are not silently promoted to READY.

## Safety invariants

- Package unchanged.
- Official signer unchanged.
- versionCode strictly increases 212 -> 213.
- No destructive DB migration.
- No recognition threshold relaxation.
- Cloud Identity remains SHADOW.
- Self Learning remains ACTIVE_CONFIRMED_ONLY.
- ARS AI Engineer remains DEV_CENTER_DIAGNOSTIC_ONLY.
- AI cannot create quantity, price, stock mutation, payment or install APK.

## Required validation

CI must compile debug/release Kotlin, execute JVM/unit regression tests, build the official release APK, verify package/version, verify official signing certificate, and verify zip alignment before exposing the APK artifact.
