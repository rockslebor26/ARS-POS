# ARS POS 1.12.2 (214) — V8.9.0-C

Phase 4.3.6.0 — APVD_CATALOG_ACTIVATION_PHYSICAL_INSTANCE_GRAPH_AXIAL_VISUAL_DNA_R1.

This is an in-place update from 1.12.1 (213). **Do not uninstall the production application.**

Primary changes:
- automatic DB-v6 APVD prepared-knowledge activation from existing verified references;
- collision-guarded rather than collision-excluded APVD retrieval;
- confirmed-teach -> APVD compile path;
- region-consistent local DNA;
- axial local Visual DNA for LONG/rod references;
- independent OCR/barcode candidate union before exact rerank;
- conservative Physical Instance Graph with evidence attachments and one quantity owner;
- stale best-identity-frame veto at 1500 ms;
- database-version diagnostic corrected to DB v6 source of truth;
- all legacy recognition thresholds unchanged.

Official package: `com.arspos.anglerriausyndicate`

Official signer SHA-256: `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`
