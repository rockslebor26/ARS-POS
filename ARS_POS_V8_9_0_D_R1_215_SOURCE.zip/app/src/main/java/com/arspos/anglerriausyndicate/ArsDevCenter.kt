package com.arspos.anglerriausyndicate

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.runBlocking
import com.arspos.anglerriausyndicate.data.db.ArsDatabase
import com.arspos.anglerriausyndicate.visualdna.SmartCatalogRebuilder

/** Build-identity-safe diagnostics sourced from ArsV850Config + replay V4. */
@Composable
fun ArsDevCenterDialog(context: Context, onDismiss: () -> Unit) {
    var report by remember { mutableStateOf(ArsFlightRecorder.buildReport(context)) }
    var showProjectTarget by remember { mutableStateOf(false) }
    var videoRecording by remember { mutableStateOf(ArsDiagnosticScreenRecorder.isRecording(context)) }
    var catalogRebuilding by remember { mutableStateOf(false) }
    val mediaProjection = remember {
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }
    val projectionPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            ArsDiagnosticScreenRecorder.start(context, result.resultCode, data)
            videoRecording = true
            ArsFlightRecorder.event(
                "DIAGNOSTIC_VIDEO_PERMISSION_GRANTED",
                "Operator granted screen-capture permission for this diagnostic session"
            )
            Toast.makeText(
                context,
                "Rekam layar diagnostik aktif. Tutup Dev Center, lakukan Smart Scan, lalu tekan CHATGPT + EVIDENCE ZIP.",
                Toast.LENGTH_LONG
            ).show()
        } else {
            videoRecording = false
            ArsFlightRecorder.event(
                "DIAGNOSTIC_VIDEO_PERMISSION_DENIED",
                "Operator did not grant screen-capture permission"
            )
            Toast.makeText(context, "Rekam layar tidak dimulai.", Toast.LENGTH_SHORT).show()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("ARS DEV CENTER", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 560.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("FLIGHT RECORDER • VISUAL EVIDENCE • SCREEN VIDEO • OFFICIAL UPDATE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(
                    "${ArsV850Config.ENGINE} / ${ArsV850Config.RELEASE_REVISION}: Smart Scan transaksi sekarang capture-centric. Live camera hanya preview/presence/physical readiness; setelah Kunci, frozen evidence diproses melalui APVD runtime, RAW+enhanced consensus, bounded parallel object recognition, selective OCR/barcode, dan Physical Quantity Safety. DB v6 serta update-in-place dipertahankan; threshold recognition tidak diturunkan.",
                    fontSize = 11.sp
                )
                OutlinedButton(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { showProjectTarget = !showProjectTarget }
                ) {
                    Text(if (showProjectTarget) "TUTUP PROJECT TARGET" else "PROJECT TARGET / PHASE GATE", fontSize = 10.sp)
                }
                if (showProjectTarget) {
                    Text("ULTIMATE GOAL", fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    Text(ArsProjectCharter.ultimateGoal, fontSize = 9.sp)
                    Text("NON-NEGOTIABLE RULES", fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    Text(ArsProjectCharter.nonNegotiableRules, fontSize = 9.sp)
                    Text(ArsProjectCharter.currentMission, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                    Text(ArsProjectCharter.baseline, fontSize = 9.sp)
                    Text(ArsProjectCharter.regressionGuard, fontSize = 9.sp)
                }
                Text(report, fontSize = 9.sp)

                OutlinedButton(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !catalogRebuilding,
                    onClick = {
                        catalogRebuilding = true
                        Thread {
                            runCatching {
                                runBlocking { SmartCatalogRebuilder(ArsDatabase.get(context)).rebuild() }
                            }.onSuccess { result ->
                                ArsFlightRecorder.event(
                                    "SMART_CATALOG_REBUILD",
                                    "DB v6 Smart Catalog rebuilt from verified master references",
                                    mapOf(
                                        "catalogVersion" to result.catalogVersion,
                                        "readyProducts" to result.readyProducts,
                                        "stagingProducts" to result.stagingProducts,
                                        "skippedProducts" to result.skippedProducts,
                                        "collisionPairs" to result.collisionPairs,
                                        "collisionPairsEvaluated" to result.collisionPairsEvaluated,
                                        "collisionEdgesAccepted" to result.collisionEdgesAccepted,
                                        "maxCollisionDegree" to result.maxCollisionDegree,
                                        "meanCollisionDegree" to result.meanCollisionDegree,
                                        "checksum" to result.checksum,
                                        "thresholdChanged" to false
                                    )
                                )
                                Handler(Looper.getMainLooper()).post {
                                    catalogRebuilding = false
                                    report = ArsFlightRecorder.buildReport(context)
                                    Toast.makeText(
                                        context,
                                        "Smart Catalog selesai: ${result.readyProducts} READY, ${result.stagingProducts} perlu evidence tambahan.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }.onFailure { error ->
                                ArsFlightRecorder.event("SMART_CATALOG_REBUILD_ERROR", error.message ?: error::class.java.simpleName)
                                Handler(Looper.getMainLooper()).post {
                                    catalogRebuilding = false
                                    Toast.makeText(context, "Rebuild Smart Catalog gagal; detail tersimpan di Flight Recorder.", Toast.LENGTH_LONG).show()
                                }
                            }
                        }.start()
                    }
                ) {
                    Text(if (catalogRebuilding) "REBUILD SMART CATALOG…" else "REBUILD SMART CATALOG", fontSize = 10.sp)
                }
                Text(
                    "Membangun APVD/index dari master reference terverifikasi tanpa uninstall. Collision HIGH/CRITICAL tidak dipromosikan menjadi READY.",
                    fontSize = 9.sp
                )

                OutlinedButton(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !videoRecording,
                    onClick = {
                        projectionPermission.launch(mediaProjection.createScreenCaptureIntent())
                    }
                ) {
                    Text(
                        if (videoRecording) "VIDEO DIAGNOSTIK AKTIF" else "MULAI REKAM VIDEO DIAGNOSTIK",
                        fontSize = 10.sp
                    )
                }
                Text(
                    if (videoRecording) {
                        "Video akan dihentikan dan dimasukkan otomatis saat CHATGPT + EVIDENCE ZIP ditekan."
                    } else {
                        "Android 14 meminta izin setiap sesi MediaProjection. Tanpa video, ZIP tetap dibuat dengan log/capture/evidence yang tersedia."
                    },
                    fontSize = 9.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(onClick = {
                        videoRecording = ArsDiagnosticScreenRecorder.isRecording(context)
                        report = ArsFlightRecorder.buildReport(context)
                    }) {
                        Text("REFRESH", fontSize = 10.sp)
                    }
                    Button(onClick = { shareReportToChatGPT(context, report) }) {
                        Text("TEXT REPORT", fontSize = 10.sp)
                    }
                }
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        shareDiagnosticPackageToChatGPT(context, report)
                        videoRecording = false
                    }
                ) {
                    Text("CHATGPT + EVIDENCE ZIP", fontSize = 10.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("SELESAI") }
        },
        dismissButton = {
            TextButton(onClick = {
                ArsFlightRecorder.clear(context)
                report = ArsFlightRecorder.buildReport(context)
            }) { Text("HAPUS LOG + BUKTI") }
        }
    )
}

fun shareReportToChatGPT(context: Context, report: String) {
    val prompt = diagnosticPrompt(report)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "ARS POS Diagnostic Report ${ArsV850Config.ENGINE}-${ArsV850Config.RELEASE_REVISION}")
        putExtra(Intent.EXTRA_TEXT, prompt)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    startPreferredChatGptShare(context, intent, "Kirim report ke ChatGPT / OpenAI")
}

/**
 * One-tap diagnostic export. Active screen recording is finalized first; log,
 * screenshots/keyframes, scanner telemetry, evidence, replay, ground truth,
 * performance data and the video artifact are then packed into one ZIP.
 */
fun shareDiagnosticPackageToChatGPT(context: Context, report: String) {
    Toast.makeText(context, "Finalisasi log, capture, video dan evidence ARS POS…", Toast.LENGTH_SHORT).show()
    Thread {
        runCatching {
            val zip = ArsVisualEvidenceRecorder.buildDiagnosticPackage(context, report)
            val refreshedReport = ArsFlightRecorder.buildReport(context)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                zip
            )
            val prompt = diagnosticPrompt(refreshedReport) +
                "\n\nLampiran ZIP adalah one-tap diagnostic bundle: log + capture/keyframe + screen recording bila diaktifkan + scanner telemetry + decision ledger + ground truth + replay + integrity manifest. Cocokkan evidence berdasarkan sessionId/frame/track/physical object/timestamp, bukan sebagai gambar atau video terpisah."
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_SUBJECT, "ARS POS ${ArsV850Config.ENGINE}-${ArsV850Config.RELEASE_REVISION} Diagnostic Package")
                putExtra(Intent.EXTRA_TEXT, prompt)
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newUri(context.contentResolver, "ARS POS Diagnostic Package", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            Handler(Looper.getMainLooper()).post {
                startPreferredChatGptShare(context, intent, "Kirim report + visual evidence")
            }
        }.onFailure { error ->
            ArsFlightRecorder.event(
                "DIAGNOSTIC_EXPORT_ERROR",
                error.message ?: error::class.java.simpleName,
                mapOf("exception" to error::class.java.name)
            )
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(
                    context,
                    "Gagal membuat paket diagnostik. Report error sudah dicatat.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }.start()
}

fun shareCurrentScanEvidence(context: Context, session: String) {
    if (session.isBlank()) {
        Toast.makeText(context, "Session scan belum tersedia.", Toast.LENGTH_SHORT).show()
        return
    }
    Toast.makeText(context, "Menyiapkan laporan bergambar sesi scan…", Toast.LENGTH_SHORT).show()
    Thread {
        runCatching {
            val report = ArsFlightRecorder.buildReport(context)
            val zip = ArsVisualEvidenceRecorder.buildSessionDiagnosticPackage(context, report, session)
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", zip)
            val prompt = diagnosticPrompt(report) + "\n\nFokuskan analisis pada sessionId: $session. Lampiran hanya memuat visual evidence sesi tersebut."
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_SUBJECT, "ARS POS ${ArsV850Config.ENGINE}-${ArsV850Config.RELEASE_REVISION} Visual Scan Report")
                putExtra(Intent.EXTRA_TEXT, prompt)
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newUri(context.contentResolver, "ARS POS Visual Scan Report", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            Handler(Looper.getMainLooper()).post {
                startPreferredChatGptShare(context, intent, "Kirim laporan scan bergambar")
            }
        }.onFailure { error ->
            ArsFlightRecorder.event(
                "SCAN_VISUAL_REPORT_ERROR",
                error.message ?: error::class.java.simpleName,
                mapOf("session" to session, "exception" to error::class.java.name)
            )
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(context, "Gagal membuat laporan bergambar. Error sudah dicatat.", Toast.LENGTH_LONG).show()
            }
        }
    }.start()
}

private fun diagnosticPrompt(report: String): String = buildString {
    appendLine("Tolong analisis report ARS POS berikut sebagai software engineer Android.")
    appendLine("Build ini menggunakan Phase ${ArsV850Config.PHASE} / ${ArsV850Config.ENGINE} ${ArsV850Config.RELEASE_REVISION} + Smart Capture Frozen Evidence + APVD Runtime + RAW/Enhanced Consensus + Selective Barcode/OCR + Bounded Parallel Object Recognition + Smart Product Enrollment Foundation + Private Visual DNA Schema + Enrollment Quality/Coverage Gate + Catalog Collision Graph + Open-Set KNOWN/AMBIGUOUS/UNKNOWN + Atomic Catalog Commit + Canonical Identity Continuity + Temporal Top-K Evidence Fusion + Canonical Identity Rebind Transfer + Identity Immediately After Physical Lock + NORMAL Local Completeness V2 + Project Target Lock + Regression Guard + Identity/Quantity Decoupling + Locked Per-Object Best Evidence Carry-Forward + Identity Owner Fallback + Independent NORMAL Completeness + Shared-Foreground Merge Veto + Elongated-Ambiguous Lane + Persistent Evidence Cache + ARS Visual Diagnostic Recorder V1 + One-Tap CHATGPT Evidence Bundle + Unified Physical Object State Machine + Object Lock Before Identity + Two-Stage Top-K Candidate Retrieval + Exact Re-rank + Unified Recovery Coordinator + Guided Evidence Acquisition + ViewModel Finalization + Locked Scene Continuity + Bounded OCR Reuse + Adaptive Rod Axis Width + Identity Intelligence + Ambiguous-Visual OCR + Regulatory Text Filtering + Verified Visual Fallback + Direct Teach CTA + Confirmed HYBRID_VISUAL + Correct-Type Identity Routing + Adaptive Visual Learning + Multi-Object Checkout Intelligence + Decision Evidence Ledger + Safety Kernel + Ground Truth Enforcement + Replay V4 + Catalog Snapshot + Package Edge Firewall + NORMAL Object Purity + Rod Authenticity + Anchor Role Truth + Physical Quantity Safety. AI Engineer berada di Dev Center diagnostic only dan tidak berjalan pada critical scan path. Self Learning=${ArsV850Config.SELF_LEARNING_MODE}; Cloud Identity=${ArsV850Config.CLOUD_IDENTITY_MODE}. Threshold recognition tidak diturunkan dan AI tidak dapat membuat quantity, mengubah stok/pembayaran, signer, atau memasang APK tanpa release gate.")
    appendLine("Jika ZIP diagnostic terlampir, cocokkan sessionId, proposalId, frame/timestamp, trackId, physicalObjectId, persistentPhysicalId, canonicalIdentityId, transient identityOwner, canonical rebind/evidence-transfer/reset counters, fused Top-K candidate, candidateProductId, normalPurity/completeness/completenessEvidenceSource, decisionRuleId, screen_recording metadata, automatic_failure_bookmarks, track overlay, object crop, ground_truth.jsonl, replay_manifest.json, decision ledger, dan performance evidence. Jangan menilai gambar/video terpisah dari telemetry yang terikat padanya.")
    appendLine("Prioritaskan force close, memory/native pressure, scanner pipeline, physical-track truth, lock flicker, track switch/rebind, identity reset, false NORMAL identity, duplicate quantity, shared-foreground merge, elongated ambiguity, anti-bridge, cross-lane gate, rod authenticity, anchor identity, full-frame rescue safety, latency, dan keamanan update in-place.")
    appendLine("Jika signer/package berubah atau versionCode tidak meningkat, tandai sebagai masalah distribusi prioritas tinggi.")
    appendLine("Jangan sarankan menurunkan threshold recognition hanya agar produk terlihat dikenali.")
    appendLine()
    append(report)
}

private fun startPreferredChatGptShare(context: Context, intent: Intent, chooserTitle: String) {
    val chatGptIntent = Intent(intent).apply { setPackage("com.openai.chatgpt") }
    val manager = context.packageManager
    if (chatGptIntent.resolveActivity(manager) != null) {
        context.startActivity(chatGptIntent)
    } else {
        context.startActivity(
            Intent.createChooser(intent, chooserTitle).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
