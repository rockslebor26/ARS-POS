package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.max

/**
 * V8.9.0-D cross-lane physical evidence graph.
 *
 * Identity evidence may be attached across NORMAL/LONG lanes when lineage or
 * spatial evidence indicates one physical object. Quantity authority never
 * transfers from an evidence-only LONG hypothesis. A graph may therefore exist
 * with no quantity owner at all.
 */
object PhysicalInstanceGraph {
    data class Result(
        val proposals: List<ScanProposal>,
        val graphGroups: Int,
        val evidenceAttachments: Int,
        val quantityOwnerConflictsPrevented: Int
    )

    fun resolve(input: List<ScanProposal>): Result {
        if (input.size < 2) return Result(assignSelfOwners(input), 0, 0, 0)
        val proposals = assignSelfOwners(input).toMutableList()
        var groups = 0
        var attachments = 0
        var prevented = 0
        val attachedLong = HashSet<Int>()

        val normalIndices = proposals.indices.filter { proposals[it].proposalType == ScanProposal.TYPE_NORMAL }
        val longIndices = proposals.indices.filter { proposals[it].proposalType == ScanProposal.TYPE_LONG }

        for (ni in normalIndices) {
            var normal = proposals[ni]
            if (normal.backgroundInstanceRejected) continue
            for (li in longIndices) {
                if (li in attachedLong) continue
                val long = proposals[li]
                if (long.backgroundInstanceRejected || long.bridgeSuppressed) continue

                val sharedLineage = sharesProposalRoot(normal.proposalId, long.proposalId)
                val longInsideNormal = containmentRatio(long.normalizedBounds, normal.normalizedBounds)
                val normalInsideLong = containmentRatio(normal.normalizedBounds, long.normalizedBounds)
                val overlap = overlapOfSmaller(normal.normalizedBounds, long.normalizedBounds)
                val partialLongEvidence = long.partialLongIdentityEvidence ||
                    long.rodAuthenticityState == ScanProposal.AUTH_UNCERTAIN

                val attach = sharedLineage ||
                    (partialLongEvidence && (longInsideNormal >= 0.48f || normalInsideLong >= 0.48f || overlap >= 0.34f)) ||
                    (strongNormalOwner(normal) && longInsideNormal >= 0.82f)
                if (!attach) continue

                val graphId = normal.physicalGraphId.ifBlank { "PIG-${stableId(normal)}" }
                val ownerId = if (strongNormalOwner(normal)) stableId(normal) else normal.quantityOwnerId
                normal = normal.copy(
                    physicalGraphId = graphId,
                    quantityOwnerId = ownerId,
                    evidenceAttachment = normal.evidenceAttachment || partialLongEvidence,
                    evidenceAttachmentReason = if (partialLongEvidence) "CROSS_LANE_LONG_EVIDENCE_ATTACHED" else normal.evidenceAttachmentReason
                )
                proposals[ni] = normal

                val hadQuantity = long.quantityEligible
                proposals[li] = long.copy(
                    physicalGraphId = graphId,
                    quantityOwnerId = ownerId,
                    quantityEligible = false,
                    evidenceAttachment = true,
                    evidenceAttachmentReason = when {
                        sharedLineage -> "CROSS_LANE_SHARED_ML_LINEAGE"
                        partialLongEvidence -> "CROSS_LANE_PARTIAL_LONG_IDENTITY_EVIDENCE"
                        else -> "CROSS_LANE_LONG_CONTAINED_BY_NORMAL_OWNER"
                    }
                )
                attachedLong += li
                groups++
                attachments++
                if (hadQuantity || ownerId.isNotBlank()) prevented++
            }
        }
        return Result(proposals, groups, attachments, prevented)
    }

    private fun assignSelfOwners(input: List<ScanProposal>): List<ScanProposal> = input.map { proposal ->
        if (proposal.quantityOwnerId.isNotBlank() || !proposal.quantityEligible) proposal
        else proposal.copy(
            physicalGraphId = proposal.physicalGraphId.ifBlank { "PIG-${stableId(proposal)}" },
            quantityOwnerId = stableId(proposal)
        )
    }

    private fun strongNormalOwner(p: ScanProposal): Boolean =
        p.quantityEligible && !p.backgroundInstanceRejected &&
            p.normalPurityScore >= 75 &&
            (p.normalCompletenessScore >= 70 || p.normalCompletenessState == NormalCompletenessPolicy.STATE_COMPLETE)

    private fun sharesProposalRoot(a: String, b: String): Boolean {
        fun roots(v: String): Set<String> = Regex("ML-\\d+").findAll(v).map { it.value }.toSet()
        val ar = roots(a); val br = roots(b)
        return ar.isNotEmpty() && br.isNotEmpty() && ar.any { it in br }
    }

    private fun overlapOfSmaller(a: Rect, b: Rect): Float {
        val left = max(a.left, b.left); val top = max(a.top, b.top)
        val right = minOf(a.right, b.right); val bottom = minOf(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val inter = (right-left).toLong()*(bottom-top).toLong()
        val aa = a.width().coerceAtLeast(1).toLong()*a.height().coerceAtLeast(1).toLong()
        val bb = b.width().coerceAtLeast(1).toLong()*b.height().coerceAtLeast(1).toLong()
        return (inter.toDouble()/minOf(aa,bb).coerceAtLeast(1).toDouble()).toFloat().coerceIn(0f,1f)
    }

    private fun containmentRatio(inner: Rect, outer: Rect): Float {
        val left = max(inner.left, outer.left)
        val top = max(inner.top, outer.top)
        val right = minOf(inner.right, outer.right)
        val bottom = minOf(inner.bottom, outer.bottom)
        if (right <= left || bottom <= top) return 0f
        val intersection = (right - left).toLong() * (bottom - top).toLong()
        val innerArea = inner.width().coerceAtLeast(1).toLong() * inner.height().coerceAtLeast(1).toLong()
        return (intersection.toDouble() / innerArea.toDouble()).toFloat().coerceIn(0f, 1f)
    }

    private fun stableId(p: ScanProposal): String =
        p.canonicalPhysicalObjectId.ifBlank {
            p.physicalObjectId.ifBlank {
                p.physicalInstanceHint.ifBlank { p.proposalId }
            }
        }
}
