package com.arspos.anglerriausyndicate

import com.arspos.anglerriausyndicate.visualdna.VisualDnaQueryResult

/** Evidence scheduler only; recognition thresholds remain owned by the existing engines. */
object HighResAmbiguityPolicy {
    fun shouldEscalate(decision: String, topScore: Int, margin: Int, agreement: String, highResAvailable: Boolean): Boolean {
        if (!highResAvailable || decision == VisualDnaQueryResult.KNOWN) return false
        return decision == VisualDnaQueryResult.EVIDENCE_CONFLICT ||
            decision == VisualDnaQueryResult.AMBIGUOUS ||
            (topScore >= 68 && margin < 8) ||
            agreement == "WEAK_CONFLICT"
    }
}
