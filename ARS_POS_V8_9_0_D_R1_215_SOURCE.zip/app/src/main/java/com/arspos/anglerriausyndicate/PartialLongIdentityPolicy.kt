package com.arspos.anglerriausyndicate

/**
 * V8.9.0-D evidence-only LONG lane. This policy never grants quantity and never
 * changes identity thresholds. It only prevents useful axial evidence from being
 * discarded when physical rod authenticity is insufficient for checkout.
 */
object PartialLongIdentityPolicy {
    fun eligible(proposal: ScanProposal): Boolean {
        if (proposal.proposalType != ScanProposal.TYPE_LONG) return false
        if (proposal.trustedRod || proposal.rodAuthenticityState == ScanProposal.AUTH_TRUSTED) return false
        if (proposal.source in setOf(ScanProposal.SOURCE_BACKGROUND, ScanProposal.SOURCE_NORMAL_EDGE, ScanProposal.SOURCE_BRIDGE)) return false
        val mlOwned = proposal.proposalId.startsWith("ML-") || proposal.source == ScanProposal.SOURCE_LOCAL_RECOVERY
        val axialEvidence = proposal.axisConfidence >= 48 && proposal.rodStructureScore >= 55 && proposal.rodPositiveEvidence >= 60
        val continuityEvidence = proposal.shaftContinuity >= 0.45f || proposal.foregroundCoverage >= 0.18f
        return mlOwned && axialEvidence && continuityEvidence
    }
}
