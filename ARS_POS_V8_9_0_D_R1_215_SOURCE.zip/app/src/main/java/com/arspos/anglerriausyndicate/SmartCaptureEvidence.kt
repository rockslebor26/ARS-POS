package com.arspos.anglerriausyndicate

import android.graphics.Bitmap

/**
 * Phase 4.3.6.1 / V8.9.0-D frozen Smart Capture contract.
 *
 * A final transaction scan must contain a fresh physical-truth frame plus at
 * least one independently captured identity frame. An optional best live frame
 * may be carried in as the third item when it is fresh enough. Frames are
 * immutable after handoff; recognition may consume at most three passes.
 */
data class SmartCaptureInputFrame(
    val bitmap: Bitmap,
    val capturedAtMs: Long,
    val qualityScore: Int,
    val role: String
)

data class FrozenCaptureFrame(
    val frameId: String,
    val bitmap: Bitmap,
    val capturedAtMs: Long,
    val qualityScore: Int,
    val role: String
)

data class FrozenCaptureEvidenceSet(
    val captureId: String,
    val frames: List<FrozenCaptureFrame>,
    val masterFrameId: String,
    val createdAtMs: Long = System.currentTimeMillis()
) {
    val burstFrameCount: Int get() = frames.size
    val spanMs: Long get() = (frames.maxOfOrNull { it.capturedAtMs } ?: createdAtMs) -
        (frames.minOfOrNull { it.capturedAtMs } ?: createdAtMs)
    val minBurstSatisfied: Boolean get() = burstFrameCount >= ArsV850Config.MIN_CAPTURE_BURST_FRAMES
    fun master(): FrozenCaptureFrame = frames.firstOrNull { it.frameId == masterFrameId } ?: frames.first()
}

object SmartCaptureEvidenceFactory {
    fun fromFinalLock(
        captureId: String,
        freshPhysical: Bitmap,
        identityFrames: List<SmartCaptureInputFrame>
    ): FrozenCaptureEvidenceSet {
        val now = System.currentTimeMillis()
        val frames = ArrayList<FrozenCaptureFrame>(ArsV850Config.MAX_CAPTURE_BURST_FRAMES)
        frames += FrozenCaptureFrame("FRESH_PHYSICAL", freshPhysical, now, 100, "PHYSICAL_TRUTH")

        identityFrames.asSequence()
            .filter { !it.bitmap.isRecycled && it.bitmap !== freshPhysical }
            .filter { frame ->
                frame.role != "BEST_IDENTITY" ||
                    (now - frame.capturedAtMs).coerceAtLeast(0L) <= ArsV850Config.MAX_FINAL_IDENTITY_FRAME_AGE_MS
            }
            .sortedByDescending { it.qualityScore }
            .take((ArsV850Config.MAX_CAPTURE_BURST_FRAMES - 1).coerceAtLeast(0))
            .forEachIndexed { index, frame ->
                frames += FrozenCaptureFrame(
                    frameId = if (frame.role == "BEST_IDENTITY") "BEST_IDENTITY" else "MICROBURST_IDENTITY_${index + 1}",
                    bitmap = frame.bitmap,
                    capturedAtMs = frame.capturedAtMs,
                    qualityScore = frame.qualityScore.coerceIn(0, 100),
                    role = frame.role
                )
            }

        val master = frames.maxByOrNull { frame ->
            when (frame.role) {
                "MICROBURST_IDENTITY" -> frame.qualityScore + 24
                "BEST_IDENTITY" -> frame.qualityScore + 20
                else -> frame.qualityScore
            }
        } ?: frames.first()
        return FrozenCaptureEvidenceSet(captureId, frames, master.frameId)
    }
}
