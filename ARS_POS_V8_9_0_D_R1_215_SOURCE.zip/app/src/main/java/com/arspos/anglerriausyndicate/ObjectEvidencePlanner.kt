package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max

/** Selects the best already-captured frame for one physical object. */
object ObjectEvidencePlanner {
    data class Choice(val index: Int, val quality: Int)

    fun choose(frames: List<Bitmap>, analysisWidth: Int, analysisHeight: Int, bounds: Rect): Choice? {
        if (frames.isEmpty()) return null
        return frames.mapIndexedNotNull { index, frame ->
            if (frame.isRecycled || frame.width < 2 || frame.height < 2) null
            else index to score(frame, scale(bounds, analysisWidth, analysisHeight, frame.width, frame.height))
        }.maxByOrNull { it.second }?.let { Choice(it.first, it.second) }
    }

    fun score(bitmap: Bitmap, bounds: Rect): Int {
        val safe = Rect(
            bounds.left.coerceIn(0, bitmap.width - 1), bounds.top.coerceIn(0, bitmap.height - 1),
            bounds.right.coerceIn(1, bitmap.width), bounds.bottom.coerceIn(1, bitmap.height)
        )
        if (safe.width() < 8 || safe.height() < 8) return 0
        val stepX = max(1, safe.width() / 18); val stepY = max(1, safe.height() / 18)
        var exposure = 0L; var edge = 0L; var count = 0
        var y = safe.top
        while (y < safe.bottom) {
            var x = safe.left; var prev = -1
            while (x < safe.right) {
                val c = bitmap.getPixel(x, y)
                val lum = (((c ushr 16) and 255) * 30 + ((c ushr 8) and 255) * 59 + (c and 255) * 11) / 100
                exposure += 255 - abs(lum - 128)
                if (prev >= 0) edge += abs(lum - prev)
                prev = lum; count++; x += stepX
            }
            y += stepY
        }
        if (count == 0) return 0
        val exposureScore = ((exposure / count) / 4).toInt().coerceIn(0, 64)
        val edgeScore = ((edge / count) * 2).toInt().coerceIn(0, 72)
        val resolutionBonus = (max(bitmap.width, bitmap.height) / 80).coerceIn(0, 24)
        return (exposureScore + edgeScore + resolutionBonus).coerceIn(0, 100)
    }

    private fun scale(r: Rect, sw: Int, sh: Int, tw: Int, th: Int): Rect {
        val sx = tw.toFloat() / sw.coerceAtLeast(1); val sy = th.toFloat() / sh.coerceAtLeast(1)
        return Rect((r.left*sx).toInt(), (r.top*sy).toInt(), (r.right*sx).toInt(), (r.bottom*sy).toInt())
    }
}
