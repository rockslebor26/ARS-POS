package com.arspos.anglerriausyndicate

import android.graphics.Rect

/**
 * Phase 4.3.2.34 V8.4.14 — rod-claim ownership metadata.
 *
 * A detected LONG line is only an AXIS_HYPOTHESIS. It becomes a TRACK-* after
 * global physical-object resolution, and only a TRUSTED_ROD track may own
 * cashier quantity or block a NORMAL visual-only identity. This separates
 * geometry evidence from physical truth and prevents one long object from
 * becoming several sellable objects.
 */
data class ScanProposal(
    val proposalId: String,
    val source: String,
    val proposalType: String,
    val originalBounds: Rect,
    val normalizedBounds: Rect,
    val rotationDegrees: Int = 0,
    val lineageId: String,
    val physicalInstanceHint: String = "",
    val quantityEligible: Boolean = true,
    val bridgeSuppressed: Boolean = false,
    val normalOwnershipConflict: Boolean = false,
    val rodStructureScore: Int = 0,
    val orientation: String = "UNKNOWN",
    val strength: Int = 0,
    val axisAngleDeg: Float = 0f,
    val axisStartX: Int = 0,
    val axisStartY: Int = 0,
    val axisEndX: Int = 0,
    val axisEndY: Int = 0,
    // In V8.4.13 this is explicitly the detector corridor width, not the
    // measured physical-object width. Real width telemetry is stored below.
    val axisWidthPx: Int = 0,
    val axisConfidence: Int = 0,

    // V8.4.13 physical-object truth / rod-authenticity telemetry.
    val physicalObjectId: String = "",
    val hypothesesMerged: Int = 1,
    val physicalMergeReason: String = "",
    val measuredWidthMedianPx: Int = 0,
    val measuredWidthP10Px: Int = 0,
    val measuredWidthP90Px: Int = 0,
    val widthVariance: Float = 0f,
    val taperRatio: Float = 0f,
    val curvatureScore: Int = 0,
    val rodPositiveEvidence: Int = 0,
    val branchPenalty: Int = 0,
    val beamPenalty: Int = 0,
    val floorLinePenalty: Int = 0,
    val shadowPenalty: Int = 0,
    val rodAuthenticityScore: Int = 0,
    val rodAuthenticityState: String = AUTH_UNKNOWN,
    val trustedRod: Boolean = false,

    // Raw geometric claim is diagnostic only. It grants neither ownership nor
    // quantity; trusted authenticity and product identity remain independent.
    val rodClaim: Boolean = false,
    val rodClaimScore: Int = 0,
    val crossThroughIntersections: Int = 0,
    val trueBranchIntersections: Int = 0,

    // Cross-category firewall metadata. Barcode/strong OCR remain independent
    // evidence and these flags never lower any recognition threshold.
    val crossCategoryConflict: Boolean = false,
    val crossCategoryConflictScore: Int = 0,
    val rodTrackHits: Int = 0,
    val visualOnlyBlocked: Boolean = false,
    val crossCategoryReason: String = "",
    val segmentSupport: Boolean = false,
    val shaftVariation: Float = 0f,
    val shaftContinuity: Float = 0f,
    val foregroundSupported: Boolean = false,
    val foregroundCoverage: Float = 0f,
    val foregroundBodyCoverage: Float = 0f,
    val foregroundReason: String = "NOT_MEASURED",
    val rodTipVisible: Boolean = false,

    // V8.4.20 NORMAL foreground ownership and LONG package-edge firewall.
    val normalForegroundComponent: Int = 0,
    val normalForegroundCoverage: Float = 0f,
    val normalForegroundLeft: Int = 0,
    val normalForegroundTop: Int = 0,
    val normalForegroundRight: Int = 0,
    val normalForegroundBottom: Int = 0,

    // V8.4.21 NORMAL proposal purity. This never relaxes identity thresholds;
    // it only decides whether a proposal may own cashier quantity.
    val normalPurityScore: Int = 0,
    val normalPurityState: String = "NOT_MEASURED",
    val normalPurityReason: String = "",
    val normalCropAreaRatio: Float = 0f,
    val normalOwnerAreaRatio: Float = 0f,

    // V8.8.5 post-recovery canonical NORMAL truth. Purity and completeness are
    // intentionally separate: a clean crop can still be only a fragment of a
    // larger foreground owner. These fields never lower recognition thresholds.
    val canonicalPhysicalObjectId: String = "",
    val normalCompletenessScore: Int = 0,
    val normalCompletenessState: String = NormalCompletenessPolicy.STATE_NOT_MEASURED,
    val normalCompletenessReason: String = "",
    val normalFragmentState: String = "UNKNOWN",

    // V8.8.6 elongated-ambiguous diagnostic lane. This flag does not create a
    // new quantity lane and never relaxes NORMAL/LONG identity thresholds.
    val elongatedAmbiguous: Boolean = false,
    val elongatedAmbiguousReason: String = "",

    // V8.9.0-D physical-instance graph + authoritative instance evidence.
    // Evidence attachments may contribute identity evidence but can never own cashier quantity.
    val physicalGraphId: String = "",
    val quantityOwnerId: String = "",
    val evidenceAttachment: Boolean = false,
    val evidenceAttachmentReason: String = "",
    val partialLongIdentityEvidence: Boolean = false,
    val instanceMaskScore: Int = 0,
    val instanceMaskCoverage: Float = 0f,
    val instanceMaskOutsideLeak: Float = 0f,
    val instanceMaskTouchesRoiEdge: Boolean = false,
    val instanceMaskState: String = "NOT_MEASURED",
    val backgroundInstanceRejected: Boolean = false,

    val physicalOwnershipState: String = "UNKNOWN",
    val physicalOwnershipOwnerId: String = "",
    val packageEdgeScore: Int = 0,
    val packageEdgeBoundaryDistancePx: Float = 0f,
    val packageEdgeParallelEvidence: Float = 0f,
    val packageEdgeRectangularScore: Float = 0f,
    val packageEdgeTrackInsideOwnerRatio: Float = 0f,

    // V8.4.20 bidirectional endpoint role truth.
    val anchorHandleOnLeft: Boolean? = null,
    val anchorEndpointLeftScore: Int = 0,
    val anchorEndpointRightScore: Int = 0,
    val anchorRoleMargin: Int = 0,
    val anchorRoleConfidence: Int = 0,
    val anchorRoleState: String = "ANCHOR_ROLE_NOT_MEASURED"
) {
    val hasResolvedAxis: Boolean
        get() = axisConfidence > 0 &&
            (axisStartX != axisEndX || axisStartY != axisEndY)

    companion object {
        const val TYPE_NORMAL = "NORMAL_OBJECT"
        const val TYPE_LONG = "LONG_OBJECT"
        const val TYPE_RESCUE = "FULL_FRAME_RESCUE"
        const val TYPE_AMBIGUOUS_CONTAINER = "AMBIGUOUS_CONTAINER"

        const val SOURCE_MLKIT = "MLKIT"
        const val SOURCE_LONG = "LONG_ANALYZER"
        const val SOURCE_MERGED = "MERGED"
        const val SOURCE_RESCUE = "FULL_FRAME_RESCUE"
        const val SOURCE_SCENE_BARCODE = "SCENE_BARCODE"
        const val SOURCE_BRIDGE = "BRIDGE_SUPPRESSED"
        const val SOURCE_CROSS_LANE = "CROSS_LANE_SUPPRESSED"
        const val SOURCE_BACKGROUND = "BACKGROUND_REJECTED"
        const val SOURCE_TRACK = "PHYSICAL_TRACK"
        const val SOURCE_AUTHENTICITY = "ROD_AUTHENTICITY_REJECTED"
        const val SOURCE_NORMAL_EDGE = "NORMAL_BOUNDARY_EDGE_REJECTED"
        const val SOURCE_TEMPORAL_SEED = "TEMPORAL_ML_SEED"
        const val SOURCE_LOCAL_RECOVERY = "ML_GUIDED_LOCAL_RECOVERY"
        const val SOURCE_NON_ROD_NORMAL_RESCUE = "NON_ROD_TO_NORMAL_RESCUE"
        const val SOURCE_ML_NORMAL_PREVIEW = "ML_TALL_NORMAL_PREVIEW_FALLBACK"
        const val SOURCE_PARTIAL_LONG_IDENTITY = "PARTIAL_LONG_IDENTITY_EVIDENCE"
        const val SOURCE_BACKGROUND_INSTANCE_REJECTED = "BACKGROUND_INSTANCE_REJECTED"

        const val AUTH_UNKNOWN = "AUTH_UNKNOWN"
        const val AUTH_NON_ROD = "NON_ROD"
        const val AUTH_UNCERTAIN = "ROD_UNCERTAIN"
        const val AUTH_TRUSTED = "TRUSTED_ROD"
        const val OWNERSHIP_ROD_CLAIM = "ROD_CLAIM"
    }
}
