package com.arspos.anglerriausyndicate

import com.arspos.anglerriausyndicate.visualdna.VisualDnaQueryResult

/**
 * V8.9.0-D OCR gate. OCR is requested only when candidate identity profiles
 * contain mutually discriminative text. APVD ambiguity alone is not sufficient.
 */
object OcrInformationGainPolicy {
    data class Decision(val request: Boolean, val score: Int, val reason: String)

    fun decide(barcode: String, apvdDecision: String, candidateTokenSets: List<Set<String>>): Decision {
        if (barcode.isNotBlank()) return Decision(false, 100, "BARCODE_AUTHORITATIVE")
        if (apvdDecision == VisualDnaQueryResult.KNOWN) return Decision(false, 100, "APVD_KNOWN")
        val useful = candidateTokenSets.filter { it.isNotEmpty() }.take(5)
        if (useful.isEmpty()) return Decision(false, 0, "NO_CANDIDATE_TEXT_SIGNATURE")
        val union = useful.flatten().toSet()
        if (union.isEmpty()) return Decision(false, 0, "NO_DISTINCTIVE_TEXT")
        val common = useful.reduce { a, b -> a intersect b }
        val discriminative = (union - common).size
        val score = (discriminative * 14 + useful.size * 4).coerceIn(0, 100)
        return if (score >= 28) Decision(true, score, "CANDIDATE_TEXT_CAN_SEPARATE_TOP_K")
        else Decision(false, score, "LOW_EXPECTED_INFORMATION_GAIN")
    }
}
