package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * V8.9.0-D authoritative object-local instance mask.
 *
 * This is deliberately bounded and non-generative. It estimates background from
 * the expanded ROI border, finds connected foreground material that overlaps the
 * detector object, and measures only that instance. Scene-wide foreground is
 * never allowed to decide completeness or cashier quantity.
 */
object AuthoritativeInstanceMask {
    const val STATE_COMPLETE = "COMPLETE"
    const val STATE_PARTIAL = "PARTIAL"
    const val STATE_BACKGROUND_REJECTED = "BACKGROUND_REJECTED"
    const val STATE_NOT_MEASURED = "NOT_MEASURED"

    data class Result(
        val state: String,
        val completenessScore: Int,
        val safeForQuantity: Boolean,
        val instanceCoverage: Float,
        val outsideLeakRatio: Float,
        val centerCoverage: Float,
        val edgeCoverage: Float,
        val touchesRoiEdge: Boolean,
        val componentBounds: Rect?,
        val backgroundRejected: Boolean,
        val reason: String
    )

    fun evaluate(bitmap: Bitmap, objectBounds: Rect): Result? {
        if (bitmap.width < 8 || bitmap.height < 8 || objectBounds.width() < 8 || objectBounds.height() < 8) return null
        val safe = Rect(
            objectBounds.left.coerceIn(0, bitmap.width - 1),
            objectBounds.top.coerceIn(0, bitmap.height - 1),
            objectBounds.right.coerceIn(1, bitmap.width),
            objectBounds.bottom.coerceIn(1, bitmap.height)
        )
        if (safe.width() < 8 || safe.height() < 8) return null

        val expansion = max(12, (max(safe.width(), safe.height()) * 0.20f).roundToInt())
        val roi = Rect(
            (safe.left - expansion).coerceAtLeast(0),
            (safe.top - expansion).coerceAtLeast(0),
            (safe.right + expansion).coerceAtMost(bitmap.width),
            (safe.bottom + expansion).coerceAtMost(bitmap.height)
        )
        if (roi.width() < 12 || roi.height() < 12) return null

        val scale = min(1f, 192f / max(roi.width(), roi.height()).coerceAtLeast(1).toFloat())
        val w = max(8, (roi.width() * scale).roundToInt())
        val h = max(8, (roi.height() * scale).roundToInt())
        val pixels = IntArray(w * h)
        val border = ArrayList<Int>((w + h) * 4)
        for (y in 0 until h) for (x in 0 until w) {
            val sx = (roi.left + x / scale).roundToInt().coerceIn(0, bitmap.width - 1)
            val sy = (roi.top + y / scale).roundToInt().coerceIn(0, bitmap.height - 1)
            val c = bitmap.getPixel(sx, sy)
            pixels[y * w + x] = c
            if (x < 2 || y < 2 || x >= w - 2 || y >= h - 2) border += c
        }
        if (border.isEmpty()) return null

        fun ch(c: Int, shift: Int) = (c ushr shift) and 255
        fun median(shift: Int): Int = border.map { ch(it, shift) }.sorted().let { it[it.size / 2] }
        val br = median(16); val bg = median(8); val bb = median(0)
        val foreground = BooleanArray(w * h)
        for (i in pixels.indices) {
            val c = pixels[i]
            val colorDistance = (abs(ch(c, 16) - br) + abs(ch(c, 8) - bg) + abs(ch(c, 0) - bb)) / 765f
            foreground[i] = colorDistance >= 0.17f
        }

        // One closing pass reconnects package faces without allowing thin scene
        // lines to become a large object instance.
        val dilated = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            var hit = false
            loop@ for (dy in -1..1) for (dx in -1..1) {
                if (foreground[(y + dy) * w + x + dx]) { hit = true; break@loop }
            }
            dilated[y * w + x] = hit
        }
        val mask = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            var count = 0
            for (dy in -1..1) for (dx in -1..1) if (dilated[(y + dy) * w + x + dx]) count++
            mask[y * w + x] = count >= 6
        }

        val localBox = Rect(
            ((safe.left - roi.left) * scale).roundToInt().coerceIn(0, w - 1),
            ((safe.top - roi.top) * scale).roundToInt().coerceIn(0, h - 1),
            ((safe.right - roi.left) * scale).roundToInt().coerceIn(1, w),
            ((safe.bottom - roi.top) * scale).roundToInt().coerceIn(1, h)
        )
        if (localBox.width() < 4 || localBox.height() < 4) return null

        val labels = IntArray(w * h)
        val queue = IntArray(w * h)
        data class Comp(var size: Int = 0, var inside: Int = 0, var minX: Int = Int.MAX_VALUE, var minY: Int = Int.MAX_VALUE, var maxX: Int = -1, var maxY: Int = -1)
        val comps = mutableListOf(Comp())
        var next = 0
        for (i in mask.indices) {
            if (!mask[i] || labels[i] != 0) continue
            next++
            val comp = Comp()
            var head = 0; var tail = 1
            queue[0] = i; labels[i] = next
            while (head < tail) {
                val at = queue[head++]; val x = at % w; val y = at / w
                comp.size++
                if (x in localBox.left until localBox.right && y in localBox.top until localBox.bottom) comp.inside++
                comp.minX = min(comp.minX, x); comp.maxX = max(comp.maxX, x)
                comp.minY = min(comp.minY, y); comp.maxY = max(comp.maxY, y)
                fun add(n: Int) { if (mask[n] && labels[n] == 0) { labels[n] = next; queue[tail++] = n } }
                if (x > 0) add(at - 1); if (x < w - 1) add(at + 1); if (y > 0) add(at - w); if (y < h - 1) add(at + w)
            }
            comps += comp
        }
        if (next == 0) return Result(STATE_BACKGROUND_REJECTED, 0, false, 0f, 1f, 0f, 0f, false, null, true, "NO_LOCAL_INSTANCE_FOREGROUND")

        val chosenId = (1..next).maxByOrNull { id ->
            val c = comps[id]
            c.inside * 3 + min(c.size, c.inside * 2)
        } ?: 0
        if (chosenId <= 0) return null
        val chosen = comps[chosenId]
        val boxArea = localBox.width().coerceAtLeast(1) * localBox.height().coerceAtLeast(1)
        val coverage = chosen.inside.toFloat() / boxArea.toFloat()
        val outside = (chosen.size - chosen.inside).coerceAtLeast(0)
        val outsideLeak = outside.toFloat() / chosen.size.coerceAtLeast(1).toFloat()
        val touchesEdge = chosen.minX <= 1 || chosen.minY <= 1 || chosen.maxX >= w - 2 || chosen.maxY >= h - 2

        val center = Rect(
            localBox.left + localBox.width() / 4,
            localBox.top + localBox.height() / 4,
            localBox.right - localBox.width() / 4,
            localBox.bottom - localBox.height() / 4
        )
        var centerFg = 0; var centerTotal = 0; var edgeFg = 0; var edgeTotal = 0
        for (y in localBox.top until localBox.bottom) for (x in localBox.left until localBox.right) {
            val isCenter = x in center.left until center.right && y in center.top until center.bottom
            val hit = labels[y * w + x] == chosenId
            if (isCenter) { centerTotal++; if (hit) centerFg++ } else { edgeTotal++; if (hit) edgeFg++ }
        }
        val centerCoverage = centerFg.toFloat() / centerTotal.coerceAtLeast(1)
        val edgeCoverage = edgeFg.toFloat() / edgeTotal.coerceAtLeast(1)

        val backgroundRejected = coverage < 0.055f ||
            chosen.inside < max(10, boxArea / 40) ||
            (centerCoverage < 0.06f && edgeCoverage > 0.28f && outsideLeak > 0.30f)

        val score = when {
            backgroundRejected -> 0
            touchesEdge && outsideLeak > 0.18f -> 45
            outsideLeak <= 0.16f -> 100
            outsideLeak <= 0.24f -> 88
            outsideLeak <= 0.34f -> 68
            else -> 35
        }
        val complete = !backgroundRejected && !touchesEdge && outsideLeak <= 0.24f && coverage >= 0.08f
        val state = when {
            backgroundRejected -> STATE_BACKGROUND_REJECTED
            complete -> STATE_COMPLETE
            else -> STATE_PARTIAL
        }
        val componentBounds = if (chosen.maxX >= chosen.minX && chosen.maxY >= chosen.minY) Rect(
            (roi.left + chosen.minX / scale).roundToInt().coerceIn(0, bitmap.width - 1),
            (roi.top + chosen.minY / scale).roundToInt().coerceIn(0, bitmap.height - 1),
            (roi.left + (chosen.maxX + 1) / scale).roundToInt().coerceIn(1, bitmap.width),
            (roi.top + (chosen.maxY + 1) / scale).roundToInt().coerceIn(1, bitmap.height)
        ) else null

        val reason = when {
            backgroundRejected -> "BACKGROUND_INSTANCE_NOT_OBJECT_LIKE"
            complete -> "AUTHORITATIVE_INSTANCE_MASK_COMPLETE"
            touchesEdge -> "INSTANCE_MASK_TOUCHES_LOCAL_ROI_EDGE"
            else -> "INSTANCE_MASK_EXTENDS_BEYOND_OBJECT_CROP"
        }
        return Result(state, score, complete, coverage, outsideLeak, centerCoverage, edgeCoverage, touchesEdge, componentBounds, backgroundRejected, reason)
    }
}
