package com.arspos.anglerriausyndicate

/**
 * Persistent development target lock shown in ARS Dev Center.
 * This is documentation/diagnostics only and is never used as recognition logic.
 */
object ArsProjectCharter {
    val ultimateGoal = """
        CAMERA → SMART CAPTURE → FROZEN OBJECT EVIDENCE → APVD IDENTITY → SAFE QUANTITY → DATABASE PRICE → TOTAL

        Live camera hanya menyiapkan framing/focus/physical readiness. Satu tindakan Capture/Kunci membekukan evidence, lalu setiap physical instance dianalisis secara bounded. Accepted object tidak diproses ulang hanya karena object lain ambiguous.
    """.trimIndent()

    val nonNegotiableRules = """
        • Recognition threshold/margin tidak boleh diturunkan agar terlihat berhasil.
        • Identity accepted tidak otomatis berarti quantity accepted.
        • Cloud/AI tidak boleh membuat quantity, mengubah stok/pembayaran, signer, atau memasang APK.
        • Canonical physical truth, Safety Kernel, Decision Ledger, Ground Truth, Replay, Rod Authenticity, Package Edge Firewall, dan update in-place tetap dilindungi.
        • Package resmi tetap com.arspos.anglerriausyndicate; versionCode wajib meningkat; signer resmi wajib sama.
    """.trimIndent()

    val currentMission = """
        V8.9.0-D CURRENT MISSION

        Tutup blocker V8.9.0-C dengan Authoritative Instance Mask, true 2–3 frame micro-burst, cross-lane NORMAL/LONG evidence attachment, partial-LONG identity-only routing, APVD multi-frame fusion, ambiguity-triggered high-resolution evidence sebelum OCR, candidate-specific discriminative rerank, OCR information-gain gate, background-instance rejection, dan collision-graph audit. Semua quantity authority tetap berasal dari physical truth; recognition threshold tidak berubah.
    """.trimIndent()

    val baseline = """
        BASELINE V8.8.7 — real-device diagnostic 2026-09-28
        • Scan sessions: 12/12 complete; crash/ANR/native crash/evidence error: 0.
        • Average completed scan: 1826 ms; object end-to-end: 1147 ms; crop OCR: 816 ms.
        • Latest first candidate: 4789 ms; another observed first candidate: 8019 ms; live MATCHED: 0.
        • Live/final comparable: 9; consistent: 5; mismatch: 4.
        • Verified failure: 2 NORMAL proposals sharing coarse foreground were merged into 1 canonical MERGED_FRAGMENT.
        • Ground-truth annotations: 0. PSS high-water: 323 MB; native high-water: 179 MB.
    """.trimIndent()

    val regressionGuard = """
        PHASE GATE
        IMPLEMENTED → TESTING → EVIDENCE VERIFIED → TARGET PASSED → CLOSED

        Target V8.9.0-D: setiap transaksi Smart Capture memiliki minimal 2 frame independen; completeness NORMAL memakai authoritative object-local instance mask; background/dekorasi tidak boleh menjadi object transaksi; partial LONG boleh memakai katalog LONG hanya sebagai identity evidence tanpa quantity; Physical Instance Graph harus dapat mengikat NORMAL/LONG evidence satu physical instance; APVD ambiguous/conflict memakai bounded high-resolution multi-frame evidence sebelum OCR; OCR hanya bila expected information gain cukup; collisionPairsEvaluated dipisahkan dari collisionEdgesAccepted; object identity pass maksimal 3; accepted object immutable; seluruh 14 recognition threshold tetap identik; AI-created quantity = 0; false/duplicate automatic quantity = 0.
    """.trimIndent()

}
