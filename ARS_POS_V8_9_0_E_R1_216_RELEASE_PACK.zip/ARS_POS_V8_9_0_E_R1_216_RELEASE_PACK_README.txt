ARS POS V8.9.0-E / 1.12.4 (216)
Phase 4.3.6.2 — PHYSICAL_INSTANCE_AUTHORITY_APVD_DETERMINISTIC_LATENCY_DISCRIMINATIVE_EVIDENCE_CONVERGENCE_R1

1. Upload ARS_POS_V8_9_0_E_R1_216_SOURCE.zip to the root of the GitHub repository.
2. Replace .github/workflows/build-apk.yml with the companion build-apk.yml.
3. Commit/push, or run workflow_dispatch.
4. GitHub Actions must compile/test, assemble release, and verify package/version/signer/alignment before producing the official APK artifact.
5. Install 1.12.4 (216) as an in-place update over 1.12.3 (215). Do not uninstall production app.

Official package: com.arspos.anglerriausyndicate
Official signer SHA-256: AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB
Recognition thresholds: unchanged 14/14
DB: v6 non-destructive
