package com.arspos.anglerriausyndicate.data

/**
 * Phase 4.3.2.13: persistent product identity profile.
 * Barcode is optional. Aliases are collected from manual data and OCR/master enrollment.
 */
data class ProductIdentityProfile(
    val productId: Long,
    val rawText: String = "",
    val brand: String = "",
    val name: String = "",
    val variant: String = "",
    val modelCode: String = "",
    val barcode: String = "",
    val aliases: List<String> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)
