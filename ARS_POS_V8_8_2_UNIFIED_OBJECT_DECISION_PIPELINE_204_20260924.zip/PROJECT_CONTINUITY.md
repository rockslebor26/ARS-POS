# ARS POS Project Continuity

Current source candidate: **1.10.4 (204) / Phase 4.3.5.2 / V8.8.2 — Unified Object Decision Pipeline**.

Direct source predecessor: **1.10.3 (203) / Phase 4.3.5.1 / V8.8.1-R2 Compile Contract Recovery**. Package, Room v5, official signer and all 14 recognition thresholds remain unchanged.

## Current architecture direction

Smart Scan must solve physical-object continuity before SKU identity. The production order is: physical localization → persistent state/lock → best evidence → bounded Top-K catalog recall → exact recognition/reranking → unified recovery/decision → physical quantity safety → cashier review.

V8.8.2 replaces overlapping temporal object/identity decisions with `PhysicalObjectStateMachine`; bounds candidate work using `CatalogCandidatePolicy`; prevents stacked rescue with `UnifiedRecoveryCoordinator`; exposes missing-evidence guidance; and makes `UnifiedDecisionKernel` the final coordination point after existing recognition and Safety Kernel decisions.

ARS AI Engineer is now `DEV_CENTER_DIAGNOSTIC_ONLY`. It can inspect evidence and support engineering diagnosis but does not run automatically inside the cashier scan critical path and cannot create quantity, modify stock/payment, relax recognition thresholds, change signer, or authorize an update.

Cloud Identity remains `SHADOW`; Self Learning remains `ACTIVE_CONFIRMED_ONLY`.

## Finish criteria

The project is not finished until signed-build and device evidence demonstrate stable object lock, correct exact-SKU identity, no false NORMAL acceptance, no duplicate physical quantity, safe LONG/rod authenticity and anchor ownership, bounded memory/native pressure, acceptable live/final latency, and safe in-place upgrade behavior.
