package com.arspos.anglerriausyndicate

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UnifiedDecisionKernelTest {
    @Test fun exactRequiresRecognitionAndPhysicalSafety() {
        val d = UnifiedDecisionKernel.decide(true, true, 94, 12)
        assertEquals(UnifiedDecisionKernel.CONFIRMED_EXACT, d.state)
        assertTrue(d.mayCreateQuantity)
    }

    @Test fun acceptedIdentityCannotBypassQuantitySafety() {
        val d = UnifiedDecisionKernel.decide(true, false, 94, 12)
        assertEquals(UnifiedDecisionKernel.REJECTED_PHYSICAL_SAFETY, d.state)
        assertFalse(d.mayCreateQuantity)
    }

    @Test fun closeHighVisualCandidatesRemainAmbiguous() {
        val d = UnifiedDecisionKernel.decide(false, false, 90, 2)
        assertEquals(UnifiedDecisionKernel.AMBIGUOUS, d.state)
        assertFalse(d.mayCreateQuantity)
    }
}
