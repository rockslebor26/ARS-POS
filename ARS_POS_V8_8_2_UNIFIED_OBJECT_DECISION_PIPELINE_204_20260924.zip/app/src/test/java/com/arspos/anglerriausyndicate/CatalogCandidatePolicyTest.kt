package com.arspos.anglerriausyndicate

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CatalogCandidatePolicyTest {
    @Test fun normalRecallIsBoundedToTopK() {
        val scores = (1L..20L).map { it to it.toInt() }
        val ids = CatalogCandidatePolicy.selectProductIds(scores, longLane = false)
        assertEquals(CatalogCandidatePolicy.NORMAL_RECALL_TOP_K, ids.size)
        assertTrue(20L in ids)
        assertTrue(9L in ids)
    }

    @Test fun smallCatalogKeepsEveryProduct() {
        val scores = listOf(1L to 10, 2L to 99, 3L to 30)
        assertEquals(setOf(1L, 2L, 3L), CatalogCandidatePolicy.selectProductIds(scores, longLane = false))
    }
}
