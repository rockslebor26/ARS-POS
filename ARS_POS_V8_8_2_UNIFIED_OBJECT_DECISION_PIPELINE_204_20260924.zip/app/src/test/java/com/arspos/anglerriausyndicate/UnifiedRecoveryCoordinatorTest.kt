package com.arspos.anglerriausyndicate

import org.junit.Assert.assertEquals
import org.junit.Test

class UnifiedRecoveryCoordinatorTest {
    @Test fun localRecoveryPreventsStackedFullFrameRescue() {
        val d = UnifiedRecoveryCoordinator.selectFinalEvidencePath(1, 0, true)
        assertEquals(UnifiedRecoveryCoordinator.PATH_LOCAL_LONG, d.path)
    }

    @Test fun typeRoutingRecoveryPreventsStackedFullFrameRescue() {
        val d = UnifiedRecoveryCoordinator.selectFinalEvidencePath(0, 1, true)
        assertEquals(UnifiedRecoveryCoordinator.PATH_NON_ROD_TO_NORMAL, d.path)
    }

    @Test fun fullFrameIsLastEvidenceOnlyFallback() {
        val d = UnifiedRecoveryCoordinator.selectFinalEvidencePath(0, 0, true)
        assertEquals(UnifiedRecoveryCoordinator.PATH_FULL_FRAME_EVIDENCE, d.path)
    }
}
