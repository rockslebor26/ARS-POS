package com.arspos.anglerriausyndicate

/**
 * Final decision vocabulary for ARS POS.
 *
 * SmartRecognitionEngine still owns all recognition thresholds. This kernel
 * does not create a match; it only combines an already accepted recognition
 * with physical/quantity safety and exposes a deterministic final state.
 */
object UnifiedDecisionKernel {
    const val CONFIRMED_EXACT = "CONFIRMED_EXACT"
    const val AMBIGUOUS = "AMBIGUOUS"
    const val UNKNOWN = "UNKNOWN"
    const val REJECTED_PHYSICAL_SAFETY = "REJECTED_PHYSICAL_SAFETY"

    data class Decision(
        val state: String,
        val mayCreateQuantity: Boolean,
        val reason: String
    )

    fun decide(
        recognitionAccepted: Boolean,
        quantitySafetyAllowed: Boolean,
        topVisualScore: Int,
        visualMargin: Int
    ): Decision = when {
        recognitionAccepted && quantitySafetyAllowed -> Decision(
            CONFIRMED_EXACT,
            true,
            "RECOGNITION_ACCEPTED_AND_PHYSICAL_QUANTITY_SAFE"
        )
        recognitionAccepted -> Decision(
            REJECTED_PHYSICAL_SAFETY,
            false,
            "IDENTITY_ACCEPTED_BUT_PHYSICAL_QUANTITY_GATE_BLOCKED"
        )
        topVisualScore >= LiveIdentityPolicy.MIN_VISUAL_FOR_NORMAL_IDENTITY &&
            visualMargin < LiveIdentityPolicy.AMBIGUOUS_VISUAL_MARGIN -> Decision(
            AMBIGUOUS,
            false,
            "TOP_CANDIDATES_TOO_CLOSE_REQUIRE_MORE_EVIDENCE"
        )
        else -> Decision(
            UNKNOWN,
            false,
            "IDENTITY_EVIDENCE_NOT_SUFFICIENT"
        )
    }
}
