package com.arspos.anglerriausyndicate

/**
 * Tells the operator what evidence is missing instead of repeatedly running the
 * same expensive recognition pass against an unchanged weak frame.
 */
object GuidedEvidencePolicy {
    const val NONE = ""

    fun message(
        physicalState: String,
        identityState: String,
        proposalType: String,
        visualScore: Int,
        margin: Int,
        missingFrames: Int
    ): String = when {
        missingFrames > 0 -> "Tampilkan kembali objek ke kamera"
        physicalState != PhysicalObjectStateMachine.STATE_LOCKED -> "Tahan objek stabil sampai kotak terkunci"
        identityState == "CONFIRMED_PREVIEW" -> NONE
        identityState == "AMBIGUOUS" && proposalType == ScanProposal.TYPE_LONG ->
            "Arahkan kamera ke HANDLE / logo / kode model joran"
        identityState == "AMBIGUOUS" && margin < LiveIdentityPolicy.AMBIGUOUS_VISUAL_MARGIN ->
            "Arahkan kamera ke logo, nama model, atau varian produk"
        visualScore < LiveIdentityPolicy.MIN_VISUAL_FOR_NORMAL_IDENTITY ->
            "Dekatkan kamera dan pastikan produk tajam serta tidak silau"
        else -> "Putar sedikit produk agar label/model terlihat"
    }
}
