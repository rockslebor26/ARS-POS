package com.arspos.anglerriausyndicate

/**
 * Two-stage retrieval policy inspired by large visual-search systems:
 * coarse visual recall first, exact ARS recognition second. The coarse pass
 * never accepts identity and never changes SmartRecognitionEngine thresholds.
 */
object CatalogCandidatePolicy {
    const val NORMAL_RECALL_TOP_K = 12
    const val LONG_RECALL_TOP_K = 8

    fun selectProductIds(
        productScores: List<Pair<Long, Int>>,
        longLane: Boolean
    ): Set<Long> {
        val topK = if (longLane) LONG_RECALL_TOP_K else NORMAL_RECALL_TOP_K
        if (productScores.size <= topK) return productScores.map { it.first }.toSet()
        return productScores
            .sortedWith(compareByDescending<Pair<Long, Int>> { it.second }.thenBy { it.first })
            .take(topK)
            .map { it.first }
            .toSet()
    }
}
