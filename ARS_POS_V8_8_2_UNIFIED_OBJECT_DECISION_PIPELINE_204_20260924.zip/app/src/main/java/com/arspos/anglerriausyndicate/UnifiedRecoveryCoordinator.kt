package com.arspos.anglerriausyndicate

/**
 * One recovery coordinator for the final scanner.
 *
 * Existing specialized recovery algorithms remain as implementation details,
 * but the runtime is not allowed to stack a full-frame rescue after a useful
 * local or type-routing recovery has already produced evidence.
 */
object UnifiedRecoveryCoordinator {
    const val PATH_NONE = "NONE"
    const val PATH_LOCAL_LONG = "LOCAL_LONG"
    const val PATH_NON_ROD_TO_NORMAL = "NON_ROD_TO_NORMAL"
    const val PATH_FULL_FRAME_EVIDENCE = "FULL_FRAME_EVIDENCE"

    data class Decision(val path: String, val reason: String)

    fun selectFinalEvidencePath(
        localRecoveryRecovered: Int,
        nonRodNormalRescued: Int,
        fullFramePolicyAllows: Boolean
    ): Decision = when {
        localRecoveryRecovered > 0 -> Decision(PATH_LOCAL_LONG, "LOCAL_RECOVERY_ALREADY_PRODUCED_EVIDENCE")
        nonRodNormalRescued > 0 -> Decision(PATH_NON_ROD_TO_NORMAL, "TYPE_ROUTING_RECOVERY_ALREADY_PRODUCED_EVIDENCE")
        fullFramePolicyAllows -> Decision(PATH_FULL_FRAME_EVIDENCE, "NO_BETTER_OBJECT_LOCAL_RECOVERY")
        else -> Decision(PATH_NONE, "NO_SAFE_RECOVERY_PATH")
    }
}
