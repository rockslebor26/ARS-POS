package com.arspos.anglerriausyndicate

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider

/** Build-identity-safe diagnostics sourced from ArsV850Config + replay V4. */
@Composable
fun ArsDevCenterDialog(context: Context, onDismiss: () -> Unit) {
    var report by remember { mutableStateOf(ArsFlightRecorder.buildReport(context)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("ARS DEV CENTER", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 520.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("FLIGHT RECORDER • VISUAL EVIDENCE • OFFICIAL UPDATE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(
                    "${ArsV850Config.ENGINE} / ${ArsV850Config.RELEASE_REVISION}: Smart Scan sekarang memisahkan physical object lock, Top-K candidate retrieval, exact re-rank, unified recovery, guided evidence acquisition, dan quantity. AI Engineer dipindahkan keluar dari critical scan path ke Dev Center diagnostic only. OCR ambigu, regulatory-text filtering, verified visual fallback, confirmed learning, Package Edge Firewall, NORMAL Purity, Rod Authenticity, Anchor Role Truth, Safety Kernel, Ground Truth/Replay, dan Physical Quantity Safety tetap aktif. Threshold recognition tidak diturunkan; Cloud Identity tetap SHADOW dan Self Learning tetap ACTIVE_CONFIRMED_ONLY.",
                    fontSize = 11.sp
                )
                Text(report, fontSize = 9.sp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(onClick = { report = ArsFlightRecorder.buildReport(context) }) {
                        Text("REFRESH", fontSize = 10.sp)
                    }
                    Button(onClick = { shareReportToChatGPT(context, report) }) {
                        Text("TEXT REPORT", fontSize = 10.sp)
                    }
                }
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { shareDiagnosticPackageToChatGPT(context, report) }
                ) {
                    Text("CHATGPT + EVIDENCE ZIP", fontSize = 10.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("SELESAI") }
        },
        dismissButton = {
            TextButton(onClick = {
                ArsFlightRecorder.clear(context)
                report = ArsFlightRecorder.buildReport(context)
            }) { Text("HAPUS LOG + BUKTI") }
        }
    )
}

fun shareReportToChatGPT(context: Context, report: String) {
    val prompt = diagnosticPrompt(report)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "ARS POS Diagnostic Report ${ArsV850Config.ENGINE}-${ArsV850Config.RELEASE_REVISION}")
        putExtra(Intent.EXTRA_TEXT, prompt)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    startPreferredChatGptShare(context, intent, "Kirim report ke ChatGPT / OpenAI")
}

/**
 * Builds the diagnostic ZIP off the UI thread, then shares it with ChatGPT when
 * the Android client accepts file sharing. The ZIP contains report.txt plus the
 * evidence folders captured from the same scan pipeline.
 */
fun shareDiagnosticPackageToChatGPT(context: Context, report: String) {
    Toast.makeText(context, "Menyiapkan visual evidence ARS POS…", Toast.LENGTH_SHORT).show()
    Thread {
        runCatching {
            val zip = ArsVisualEvidenceRecorder.buildDiagnosticPackage(context, report)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                zip
            )
            val prompt = diagnosticPrompt(report) + "\n\nLampiran ZIP berisi visual evidence yang terikat ke session/track/decision pada report ini."
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_SUBJECT, "ARS POS ${ArsV850Config.ENGINE}-${ArsV850Config.RELEASE_REVISION} Diagnostic Package")
                putExtra(Intent.EXTRA_TEXT, prompt)
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newUri(context.contentResolver, "ARS POS Diagnostic Package", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            Handler(Looper.getMainLooper()).post {
                startPreferredChatGptShare(context, intent, "Kirim report + visual evidence")
            }
        }.onFailure { error ->
            ArsFlightRecorder.event(
                "DIAGNOSTIC_EXPORT_ERROR",
                error.message ?: error::class.java.simpleName,
                mapOf("exception" to error::class.java.name)
            )
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(
                    context,
                    "Gagal membuat paket diagnostik. Report error sudah dicatat.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }.start()
}

fun shareCurrentScanEvidence(context: Context, session: String) {
    if (session.isBlank()) {
        Toast.makeText(context, "Session scan belum tersedia.", Toast.LENGTH_SHORT).show()
        return
    }
    Toast.makeText(context, "Menyiapkan laporan bergambar sesi scan…", Toast.LENGTH_SHORT).show()
    Thread {
        runCatching {
            val report = ArsFlightRecorder.buildReport(context)
            val zip = ArsVisualEvidenceRecorder.buildSessionDiagnosticPackage(context, report, session)
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", zip)
            val prompt = diagnosticPrompt(report) + "\n\nFokuskan analisis pada sessionId: $session. Lampiran hanya memuat visual evidence sesi tersebut."
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_SUBJECT, "ARS POS ${ArsV850Config.ENGINE}-${ArsV850Config.RELEASE_REVISION} Visual Scan Report")
                putExtra(Intent.EXTRA_TEXT, prompt)
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newUri(context.contentResolver, "ARS POS Visual Scan Report", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            Handler(Looper.getMainLooper()).post {
                startPreferredChatGptShare(context, intent, "Kirim laporan scan bergambar")
            }
        }.onFailure { error ->
            ArsFlightRecorder.event(
                "SCAN_VISUAL_REPORT_ERROR",
                error.message ?: error::class.java.simpleName,
                mapOf("session" to session, "exception" to error::class.java.name)
            )
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(context, "Gagal membuat laporan bergambar. Error sudah dicatat.", Toast.LENGTH_LONG).show()
            }
        }
    }.start()
}

private fun diagnosticPrompt(report: String): String = buildString {
    appendLine("Tolong analisis report ARS POS berikut sebagai software engineer Android.")
    appendLine("Build ini menggunakan Phase ${ArsV850Config.PHASE} / ${ArsV850Config.ENGINE} ${ArsV850Config.RELEASE_REVISION} + Unified Physical Object State Machine + Object Lock Before Identity + Two-Stage Top-K Candidate Retrieval + Exact Re-rank + Unified Recovery Coordinator + Guided Evidence Acquisition + ViewModel Finalization + Locked Scene Continuity + Bounded OCR Reuse + Adaptive Rod Axis Width + Identity Intelligence + Ambiguous-Visual OCR + Regulatory Text Filtering + Verified Visual Fallback + Direct Teach CTA + Confirmed HYBRID_VISUAL + Correct-Type Identity Routing + Adaptive Visual Learning + Multi-Object Checkout Intelligence + Decision Evidence Ledger + Safety Kernel + Ground Truth + Replay V4 + Catalog Snapshot + Package Edge Firewall + NORMAL Object Purity + Rod Authenticity + Anchor Role Truth + Physical Quantity Safety. AI Engineer berada di Dev Center diagnostic only dan tidak berjalan pada critical scan path. Self Learning=${ArsV850Config.SELF_LEARNING_MODE}; Cloud Identity=${ArsV850Config.CLOUD_IDENTITY_MODE}. Threshold recognition tidak diturunkan dan AI tidak dapat membuat quantity, mengubah stok/pembayaran, signer, atau memasang APK tanpa release gate.")
    appendLine("Jika ZIP visual evidence terlampir, cocokkan sessionId, proposalId, physicalObjectId, persistentPhysicalId, normalPurityScore/state/reason, track overlay, object crop, anchor HANDLE/SIDE/TIP, ground_truth.jsonl, replay_manifest.json, dan decisionRuleId dengan event report. Jangan menilai gambar terpisah dari telemetry yang terikat padanya.")
    appendLine("Prioritaskan force close, memory/native pressure, scanner pipeline, physical-track truth, false NORMAL identity, duplicate quantity, anti-bridge, cross-lane gate, rod authenticity, anchor identity, full-frame rescue safety, latency, dan keamanan update in-place.")
    appendLine("Jika signer/package berubah atau versionCode tidak meningkat, tandai sebagai masalah distribusi prioritas tinggi.")
    appendLine("Jangan sarankan menurunkan threshold recognition hanya agar produk terlihat dikenali.")
    appendLine()
    append(report)
}

private fun startPreferredChatGptShare(context: Context, intent: Intent, chooserTitle: String) {
    val chatGptIntent = Intent(intent).apply { setPackage("com.openai.chatgpt") }
    val manager = context.packageManager
    if (chatGptIntent.resolveActivity(manager) != null) {
        context.startActivity(chatGptIntent)
    } else {
        context.startActivity(
            Intent.createChooser(intent, chooserTitle).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
