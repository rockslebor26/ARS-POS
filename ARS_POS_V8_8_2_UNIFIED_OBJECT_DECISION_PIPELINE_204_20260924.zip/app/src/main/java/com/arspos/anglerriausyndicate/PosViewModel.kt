package com.arspos.anglerriausyndicate

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Rect
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arspos.anglerriausyndicate.data.*
import com.arspos.anglerriausyndicate.data.db.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

class PosViewModel(app:Application):AndroidViewModel(app){
    private val repo=ProductionRepository(ArsDatabase.get(app))
    val query=MutableStateFlow("")
    val products=query.flatMapLatest(repo::search).stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val catalog=repo.search("").stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    private val _cart=MutableStateFlow<List<CartLine>>(emptyList())
    val cart=_cart.asStateFlow()
    private val scanCommitLock = Any()
    private val committedScanSessions = LinkedHashSet<String>()
    private var reviewSessionId = ""
    private var reviewProducts = emptyMap<Long, ProductEntity>()
    private val _finalSmartScan: MutableStateFlow<FinalSmartScanState> = MutableStateFlow(FinalSmartScanState())
    val finalSmartScan: StateFlow<FinalSmartScanState> = _finalSmartScan.asStateFlow()
    private var finalScanJob: Job? = null
    val subtotal=_cart.map{it.sumOf(CartLine::subtotal)}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0L)
    private val start=Calendar.getInstance().apply{
        set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)
    }.timeInMillis
    val revenue=repo.revenue(start).stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0L)
    val transactions=repo.transactionCount(start).stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0)
    val cashBalance=repo.cashBalance().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0L)
    val sales=repo.sales().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val customers=repo.customers().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    init{viewModelScope.launch{repo.seed()}}
    fun search(s:String){query.value=s}
    fun add(p:ProductEntity): Unit = synchronized(scanCommitLock){
        if(p.stock<=0) return@synchronized
        val x=_cart.value.find{it.product.id==p.id}
        if(x==null){
            _cart.value=_cart.value+CartLine(p,1)
        }else if(x.quantity < p.stock){
            _cart.value=_cart.value.map{if(it.product.id==p.id)it.copy(quantity=it.quantity+1)else it}
        }
    }
    /**
     * V8.4.21 atomic quantity confirmation + duplicate-session guard.
     * One scan session can mutate the cart only once, even if the operator
     * double-taps CONFIRM. A new scan session may legitimately add more units.
     */
    fun commitScanQuantities(sessionId:String, drafts:List<ScanQuantityDraft>):ScanCartCommitResult = synchronized(scanCommitLock){
        val session = sessionId.trim()
        val requested = drafts.filter { it.quantity > 0 }
        val rejection = ScanCommitPolicy.rejection(
            session, reviewSessionId, committedScanSessions.contains(session),
            drafts.map { it.product.id to it.quantity }, reviewProducts.mapValues { it.value.stock },
            _cart.value.associate { it.product.id to it.quantity }
        )
        if(rejection != null){
            ArsFlightRecorder.event("SCAN_CART_COMMIT_BLOCKED", rejection, mapOf("session" to session, "reason" to rejection))
            val message = when(rejection){
                "DUPLICATE_SESSION" -> "Hasil scan ini sudah ditambahkan. Penambahan ulang diblokir."
                "STOCK_LIMIT_REVIEW_REQUIRED" -> "Jumlah melebihi sisa stok setelah isi keranjang. Kurangi jumlah; belum ada item yang ditambahkan."
                "EMPTY_REVIEW" -> "Tidak ada jumlah yang dipilih."
                else -> "Hasil scan atau pilihan tidak lagi valid. Silakan scan ulang."
            }
            return@synchronized ScanCartCommitResult(false,rejection == "DUPLICATE_SESSION",0,0,message)
        }

        val cartBefore = _cart.value
        var nextCart = cartBefore
        var added = 0
        var affected = 0
        requested.forEach { draft ->
            // Identity and price come from the accepted scan snapshot, not
            // editable draft fields. Checkout still revalidates the Room DB.
            val product = reviewProducts.getValue(draft.product.id)
            if(product.stock <= 0) return@forEach
            val currentQty = nextCart.firstOrNull { it.product.id == product.id }?.quantity ?: 0
            val room = (product.stock - currentQty).coerceAtLeast(0)
            val addQty = draft.quantity.coerceAtMost(room)
            if(addQty <= 0) return@forEach
            nextCart = if(currentQty == 0){
                nextCart + CartLine(product, addQty)
            } else {
                nextCart.map { line -> if(line.product.id == product.id) line.copy(quantity = line.quantity + addQty) else line }
            }
            added += addQty
            affected++
        }

        if(added <= 0){
            return@synchronized ScanCartCommitResult(false,false,0,0,"Quantity tidak dapat ditambahkan karena batas stok.")
        }

        _cart.value = nextCart
        committedScanSessions += session
        while(committedScanSessions.size > 100){
            val first = committedScanSessions.firstOrNull() ?: break
            committedScanSessions.remove(first)
        }
        ArsFlightRecorder.event(
            "SCAN_CART_COMMIT",
            "Confirmed scan quantities committed once",
            mapOf("session" to session,"addedQuantity" to added,"affectedProducts" to affected,"requestedProducts" to requested.size,
                "productIds" to requested.map { it.product.id }.joinToString(","),
                "cartBefore" to cartBefore.joinToString(",") { "${it.product.id}:${it.quantity}" },
                "cartAfter" to nextCart.joinToString(",") { "${it.product.id}:${it.quantity}" })
        )
        ScanCartCommitResult(true,false,added,affected,"$added item dari hasil scan ditambahkan ke keranjang.")
    }

    fun qty(id:Long,d:Int): Unit = synchronized(scanCommitLock){
        _cart.value=_cart.value.mapNotNull{line ->
            if(line.product.id!=id) line
            else {
                val next=(line.quantity+d).coerceIn(0,line.product.stock)
                line.copy(quantity=next).takeIf{it.quantity>0}
            }
        }
    }
    fun remove(id:Long): Unit = synchronized(scanCommitLock){
        _cart.value=_cart.value.filterNot{it.product.id==id}
    }
    fun clear(){synchronized(scanCommitLock){
        _cart.value=emptyList()
        reviewSessionId = ""
        reviewProducts = emptyMap()
    }}
    suspend fun login(u:String,p:String)=repo.login(u,p)
    suspend fun checkout(paid:Long,method:String)=runCatching{repo.checkout(_cart.value,paid,method).also{clear()}}
    suspend fun addProduct(n:String,s:String,b:String?,c:String,cost:Long,price:Long,stock:Int,brand:String?=null,variant:String?=null)=runCatching{repo.addProduct(n,s,b,c,cost,price,stock,brand,variant)}
    fun productPhotos(productId:Long)=repo.productPhotos(productId)
    suspend fun findVisualMatches(bitmap:android.graphics.Bitmap)=repo.visualProductMatches(bitmap)
    suspend fun liveScenePreview(bitmap:android.graphics.Bitmap, identityEnabled:Boolean=true)=
        repo.liveScenePreview(bitmap, identityEnabled)
    suspend fun smartVisualScan(
        bitmap:android.graphics.Bitmap,
        diagnosticSession:String="",
        liveLock:LiveSceneLockSnapshot?=null,
        identityBitmap:android.graphics.Bitmap?=null
    ):List<VisualScanObject>{
        synchronized(scanCommitLock){reviewSessionId=diagnosticSession.trim();reviewProducts=emptyMap()}
        val results=repo.smartVisualScan(bitmap, diagnosticSession, liveLock, identityBitmap)
        synchronized(scanCommitLock){
            if(reviewSessionId == diagnosticSession.trim()){
                reviewProducts=results.filter { it.canCommitQuantity }.distinctBy { it.physicalObjectId }
                    .mapNotNull { it.match?.product }.associateBy { it.id }
            }
        }
        return results
    }
    /**
     * V8.8.2 unified object-decision finalization.
     *
     * The final scan is owned by this ViewModel rather than a Compose-bound
     * coroutine scope. A private immutable frame copy also protects the locked
     * scene from UI disposal/recycling while the camera dialog leaves composition.
     */
    fun startFinalSmartScan(bitmap: Bitmap, liveLock: LiveSceneLockSnapshot): String {
        finalScanJob?.takeIf { it.isActive }?.let { return _finalSmartScan.value.sessionId }

        val scanSession = ArsFlightRecorder.newSession("smart-scan")
        val ownedPreview = runCatching {
            bitmap.copy(Bitmap.Config.ARGB_8888, false)
        }.getOrNull()

        _finalSmartScan.value = FinalSmartScanState(
            status = FinalSmartScanState.STATUS_RUNNING,
            sessionId = scanSession,
            message = "Finalisasi scene terkunci sedang berjalan."
        )
        ArsFlightRecorder.event(
            "SCAN_START",
            "Scene locked; ViewModel-owned final Smart Shopping Scan started",
            mapOf(
                "session" to scanSession,
                "previewWidth" to bitmap.width,
                "previewHeight" to bitmap.height,
                "source" to "LIVE_SCENE_LOCK",
                "lifecycleOwner" to "VIEW_MODEL_SCOPE",
                "ownedFrameCopy" to (ownedPreview != null)
            )
        )

        if (ownedPreview == null) {
            ArsFlightRecorder.event("SCAN_ERROR", "Failed to copy locked scene", mapOf("session" to scanSession))
            _finalSmartScan.value = FinalSmartScanState(
                status = FinalSmartScanState.STATUS_ERROR,
                sessionId = scanSession,
                message = "Scanner tidak dapat mengunci salinan frame. Scan ulang.",
                completedAtMs = System.currentTimeMillis()
            )
            return scanSession
        }

        finalScanJob = viewModelScope.launch {
            val started = System.currentTimeMillis()
            var analysisBitmap: Bitmap? = null
            var evidenceOpened = false
            try {
                analysisBitmap = withContext(Dispatchers.Default) { BitmapSafety.scaledForScan(ownedPreview) }
                if (analysisBitmap == null) error("Failed to allocate analysis bitmap")

                withContext(Dispatchers.IO) {
                    ArsVisualEvidenceRecorder.beginSession(scanSession, analysisBitmap!!)
                }
                evidenceOpened = true

                val rawObjects = withContext(Dispatchers.Default) {
                    smartVisualScan(
                        bitmap = analysisBitmap!!,
                        diagnosticSession = scanSession,
                        liveLock = liveLock,
                        identityBitmap = ownedPreview
                    )
                }
                val finalObjects = bindUnreservedLiveIds(scanSession, liveLock, rawObjects)
                val duration = System.currentTimeMillis() - started
                val recognized = finalObjects.count { it.match != null }

                ArsFlightRecorder.event(
                    "SCAN_COMPLETE",
                    "ViewModel-owned Smart Shopping Scan completed from locked scene lineage",
                    mapOf(
                        "session" to scanSession,
                        "objects" to finalObjects.size,
                        "recognized" to recognized,
                        "durationMs" to duration,
                        "lifecycleOwner" to "VIEW_MODEL_SCOPE"
                    )
                )
                withContext(Dispatchers.IO) {
                    ArsVisualEvidenceRecorder.completeSession(scanSession, finalObjects.size, recognized, duration)
                }
                _finalSmartScan.value = FinalSmartScanState(
                    status = FinalSmartScanState.STATUS_COMPLETE,
                    sessionId = scanSession,
                    objects = finalObjects,
                    message = if (finalObjects.isEmpty()) "Scene selesai diverifikasi tetapi belum ada objek final yang aman." else "Final scan selesai.",
                    durationMs = duration,
                    completedAtMs = System.currentTimeMillis()
                )

            } catch (oom: OutOfMemoryError) {
                val duration = System.currentTimeMillis() - started
                ArsFlightRecorder.event(
                    "SCAN_FATAL",
                    "OutOfMemoryError during ViewModel-owned Smart Shopping Scan",
                    mapOf("session" to scanSession, "durationMs" to duration)
                )
                if (evidenceOpened) withContext(NonCancellable + Dispatchers.IO) {
                    ArsVisualEvidenceRecorder.completeSession(scanSession, 0, 0, duration, "FATAL_OOM")
                }
                _finalSmartScan.value = FinalSmartScanState(
                    status = FinalSmartScanState.STATUS_FATAL,
                    sessionId = scanSession,
                    message = "Scan dihentikan aman karena tekanan memori perangkat.",
                    durationMs = duration,
                    completedAtMs = System.currentTimeMillis()
                )
            } catch (cancelled: CancellationException) {
                val duration = System.currentTimeMillis() - started
                ArsFlightRecorder.event(
                    "SCAN_CANCELLED",
                    "ViewModel final scan cancelled by lifecycle owner",
                    mapOf("session" to scanSession, "durationMs" to duration, "owner" to "VIEW_MODEL_SCOPE")
                )
                if (evidenceOpened) withContext(NonCancellable + Dispatchers.IO) {
                    ArsVisualEvidenceRecorder.completeSession(scanSession, 0, 0, duration, "VIEWMODEL_CANCELLED")
                }
                _finalSmartScan.value = FinalSmartScanState(
                    status = FinalSmartScanState.STATUS_CANCELLED,
                    sessionId = scanSession,
                    message = "Final scan dibatalkan oleh lifecycle aplikasi.",
                    durationMs = duration,
                    completedAtMs = System.currentTimeMillis()
                )
                throw cancelled
            } catch (t: Throwable) {
                val duration = System.currentTimeMillis() - started
                ArsFlightRecorder.event(
                    "SCAN_ERROR",
                    t.message ?: t::class.java.simpleName,
                    mapOf(
                        "session" to scanSession,
                        "exception" to t::class.java.name,
                        "stack" to t.stackTraceToString().take(12000),
                        "durationMs" to duration,
                        "lifecycleOwner" to "VIEW_MODEL_SCOPE"
                    )
                )
                if (evidenceOpened) withContext(NonCancellable + Dispatchers.IO) {
                    ArsVisualEvidenceRecorder.completeSession(scanSession, 0, 0, duration, "SCAN_ERROR")
                }
                _finalSmartScan.value = FinalSmartScanState(
                    status = FinalSmartScanState.STATUS_ERROR,
                    sessionId = scanSession,
                    message = "Smart Shopping Scan gagal. Diagnostic tersimpan di ARS Dev Center; AI tidak dijalankan di jalur scan.",
                    durationMs = duration,
                    completedAtMs = System.currentTimeMillis()
                )
            } finally {
                analysisBitmap?.takeIf { !it.isRecycled }?.recycle()
                if (!ownedPreview.isRecycled) ownedPreview.recycle()
            }
        }
        return scanSession
    }

    private fun bindUnreservedLiveIds(
        session: String,
        liveLock: LiveSceneLockSnapshot,
        objects: List<VisualScanObject>
    ): List<VisualScanObject> {
        val reservedPersistentIds = objects.map { it.persistentPhysicalId }.filter { it.isNotBlank() }.toSet()
        val liveTracks = liveLock.tracks
            .filterNot { it.trackId in reservedPersistentIds }
            .map { track ->
                PersistentPhysicalIdBinder.LockedTrack(
                    trackId = track.trackId,
                    bounds = Rect(track.bounds),
                    frameWidth = liveLock.frameWidth,
                    frameHeight = liveLock.frameHeight,
                    proposalType = track.proposalType,
                    state = track.state,
                    temporalPhysicalState = track.temporalPhysicalState
                )
            }
        val unbound = objects.filter { it.persistentPhysicalId.isBlank() }
        val bindings = PersistentPhysicalIdBinder.bind(liveTracks, unbound)
        val byIndex = bindings.associateBy { it.objectIndex }
        val result = objects.map { obj ->
            val binding = byIndex[obj.index]
            obj.copy(
                persistentPhysicalId = obj.persistentPhysicalId.ifBlank {
                    binding?.persistentPhysicalId ?: "FINAL-${obj.physicalObjectId.ifBlank { obj.index.toString() }}"
                }
            )
        }
        bindings.forEach { binding ->
            ArsFlightRecorder.event(
                "SCAN_LIVE_FINAL_BIND",
                "Persistent physical object bridged from locked live scene to final scan",
                mapOf(
                    "session" to session,
                    "object" to binding.objectIndex,
                    "physicalObjectId" to binding.physicalObjectId,
                    "persistentPhysicalId" to binding.persistentPhysicalId,
                    "normalizedIou" to binding.normalizedIou
                )
            )
            ArsVisualEvidenceRecorder.recordPersistentBinding(
                session = session,
                objectIndex = binding.objectIndex,
                physicalObjectId = binding.physicalObjectId,
                persistentPhysicalId = binding.persistentPhysicalId,
                normalizedIou = binding.normalizedIou
            )
        }
        return result
    }

    suspend fun verifyProductMaster(productId:Long,bitmap:android.graphics.Bitmap)=repo.verifyProductMaster(productId,bitmap)
    suspend fun isMasterVerified(productId:Long)=repo.isMasterVerified(productId)
    suspend fun productIdentityProfile(productId:Long)=repo.productIdentityProfile(productId)
    suspend fun setProductRecognitionMode(productId:Long,mode:String,isLongObject:Boolean)=runCatching{repo.setProductRecognitionMode(productId,mode,isLongObject)}
    suspend fun invalidateMasterVerification(productId:Long)=repo.invalidateMasterVerification(productId)
    suspend fun mergeProductIdentityProfile(productId:Long,rawText:String="",brand:String="",name:String="",variant:String="",modelCode:String="",barcode:String="",recognitionMode:String="HYBRID",isLongObject:Boolean=false)=runCatching{repo.mergeProductIdentityProfile(productId,rawText,brand,name,variant,modelCode,barcode,recognitionMode,isLongObject)}
    suspend fun addProductPhoto(productId:Long,path:String,primary:Boolean=false,captureAngle:String="UNKNOWN")=runCatching{repo.addProductPhoto(productId,path,primary,captureAngle)}
    suspend fun teachVisualIdentity(
        source: android.graphics.Bitmap,
        obj: VisualScanObject,
        product: ProductEntity,
        sessionId: String
    ): Result<String> = runCatching {
        require(obj.match == null) { "Objek sudah dikenali; gunakan Master Studio bila ingin memperbarui referensi." }
        val saved = ArsAdaptiveLearning.saveConfirmedObjectCrop(getApplication(), source, obj, product.id).getOrThrow()
        try {
            repo.addConfirmedLearnedPhoto(product.id, saved.path)
            val masterVerified = repo.isMasterVerified(product.id)
            val confirmedHybridVisual = if (masterVerified) repo.enableConfirmedHybridVisual(product.id) else false
            val profile = repo.productIdentityProfile(product.id)
            val visualOnlyReady = masterVerified && (
                profile?.recognitionMode.equals("VISUAL_ONLY", ignoreCase = true) ||
                    profile?.recognitionMode.equals("HYBRID_VISUAL", ignoreCase = true)
                )
            ArsVisualEvidenceRecorder.recordGroundTruth(
                session = sessionId,
                objectIndex = obj.index,
                physicalObjectId = obj.physicalObjectId,
                persistentPhysicalId = obj.persistentPhysicalId,
                verdict = "TEACH_PRODUCT_IDENTITY",
                predictedProductId = obj.candidates.firstOrNull()?.product?.id,
                predictedProductName = obj.candidates.firstOrNull()?.product?.name.orEmpty(),
                note = "operatorConfirmedProductId=${product.id}; operatorConfirmedProduct=${product.name}; learnedRef=${saved.path.substringAfterLast('/')}"
            )
            ArsFlightRecorder.event(
                "ADAPTIVE_VISUAL_LEARNING",
                "Operator-confirmed unknown object added as bounded visual reference",
                mapOf(
                    "session" to sessionId,
                    "object" to obj.index,
                    "physicalObjectId" to obj.physicalObjectId,
                    "persistentPhysicalId" to obj.persistentPhysicalId,
                    "productId" to product.id,
                    "product" to product.name,
                    "masterVerified" to masterVerified,
                    "visualOnlyReady" to visualOnlyReady,
                    "confirmedHybridVisual" to confirmedHybridVisual,
                    "thresholdChanged" to false,
                    "quantityChanged" to false
                )
            )
            when {
                visualOnlyReady -> "ARS sudah mempelajari objek sebagai ${product.name}. Mode HYBRID_VISUAL aman aktif; scan ulang untuk verifikasi dengan threshold yang sama."
                !masterVerified -> "Referensi tersimpan untuk ${product.name}, tetapi master belum terverifikasi. Selesaikan Product Master Studio agar pembelajaran dapat dipakai."
                else -> "ARS sudah menyimpan contoh ${product.name}. Scan ulang; Safety Kernel dan threshold recognition tetap berlaku."
            }
        } catch (t: Throwable) {
            runCatching { java.io.File(saved.path).delete() }
            throw t
        }
    }
    suspend fun clearProductPhotoAngle(productId:Long,angle:String)=runCatching{repo.clearProductPhotoAngle(productId,angle)}
    suspend fun setPrimaryProductPhoto(productId:Long,photoId:Long)=runCatching{repo.setPrimaryProductPhoto(productId,photoId)}
    suspend fun deleteProductPhoto(photo:ProductPhotoEntity)=runCatching{repo.deleteProductPhoto(photo)}
    suspend fun stockIn(productId:Long,qty:Int,cost:Long,supplier:String?,invoice:String?)=runCatching{repo.stockIn(productId,qty,cost,supplier,invoice)}
    suspend fun saleItems(id:Long)=repo.saleItems(id)
    suspend fun processReturn(saleId:Long,reason:String)=runCatching{repo.processReturn(saleId,reason)}
    suspend fun profitSummary():ProfitSummary {
        val start=Calendar.getInstance().apply{
            set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)
        }.timeInMillis
        return repo.profitSummary(start)
    }
}
