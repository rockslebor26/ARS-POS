# Phase 4.3.5.2 / V8.8.2 — Unified Object Decision Pipeline

## Objective

V8.8.2 restructures Smart Scan around a strict sequence: **localize physical object → stabilize/lock → recall bounded catalog candidates → exact ARS recognition → unified recovery/decision → physical quantity safety**. The release removes overlapping runtime decision paths without lowering any recognition threshold.

## Core changes

1. **Physical Object State Machine**
   - One authoritative lifecycle: NEW → DETECTED → TRACKING/STABILIZING → LOCKED → LOST_GRACE → EXITED.
   - Heavy live identity does not start until a physical track has stabilized.
   - Short occlusion does not immediately manufacture a new physical identity.
   - SKU switching uses hysteresis, especially after a previously matched identity.

2. **Two-stage catalog candidate retrieval**
   - Cheap coarse visual recall first.
   - NORMAL recall bounded to Top-12 products; LONG recall bounded to Top-8 products.
   - Exact deterministic visual/anchor scoring and `SmartRecognitionEngine` operate only on the recalled set.
   - Coarse similarity can never accept a SKU and does not change thresholds.

3. **Unified Recovery Coordinator**
   - Local LONG recovery, NON-ROD→NORMAL recovery, and full-frame evidence rescue no longer compete as independent final decisions.
   - Full-frame rescue is evidence-only and cannot stack after a useful object-local recovery.

4. **Unified Decision Kernel**
   - Final states are `CONFIRMED_EXACT`, `AMBIGUOUS`, `UNKNOWN`, or `REJECTED_PHYSICAL_SAFETY`.
   - Quantity is possible only after existing recognition accepts identity **and** `ArsSafetyKernel` accepts the physical quantity decision.

5. **Guided Evidence Acquisition**
   - Live UI tells the cashier what evidence is missing: stabilize object, expose logo/model/variant, improve sharpness, show LONG handle/label, or return an occluded object.
   - The scanner avoids repeatedly running the same expensive inference when no new evidence is available.

6. **ARS AI Engineer removed from critical scan path**
   - Mode is `DEV_CENTER_DIAGNOSTIC_ONLY`.
   - Scanner failures are recorded for Dev Center diagnostics; they do not automatically invoke AI during cashier recognition.
   - AI remains unable to create quantity, change stock/payment, relax thresholds, or authorize an APK.

7. **Build identity source of truth**
   - Dev Center report identity uses `ArsV850Config` rather than a hard-coded R1/R2 label, preventing release-header mismatch.

## Release identity

- Package: `com.arspos.anglerriausyndicate`
- Phase: `4.3.5.2`
- Engine: `V8.8.2`
- Revision: `UNIFIED_OBJECT_DECISION_PIPELINE`
- versionName: `1.10.4`
- versionCode: `204`
- Room DB: `5`
- Cloud Identity: `SHADOW`
- Self Learning: `ACTIVE_CONFIRMED_ONLY`
- AI Engineer: `DEV_CENTER_DIAGNOSTIC_ONLY`

## Preserved safety invariants

- Official package/applicationId is unchanged.
- Official release signing configuration is unchanged.
- Room database remains v5 with no destructive migration.
- All 14 recognition thresholds remain byte-for-value unchanged from the prior release.
- Visual-only identity still requires verified master/confirmed learning paths.
- Cloud identity cannot create quantity.
- Recovery cannot bypass physical-object truth, NORMAL purity, rod authenticity, anchor-role truth, or package-edge safety.
- Final cart quantity remains one-to-one physical-object owned and cashier-reviewed.

## Validation status before packaging

- Static release invariants: PASS (181 checks).
- Kotlin lexical/sanity checks: PASS.
- Pure Kotlin V8.8.2 policy compile: PASS.
- Python validation tests: PASS.
- Gateway JavaScript syntax check: PASS.
- Full Android debug/release Kotlin compilation, signed APK generation, signer verification, zipalign, and device QA are intentionally performed by the supplied GitHub Actions workflow and must pass before declaring the APK production-finished.
