# ARS POS Release 204

**1.10.4 (204) — Phase 4.3.5.2 / V8.8.2 — UNIFIED_OBJECT_DECISION_PIPELINE**

Release 204 continues directly from V8.8.1-R2 (203). It is not a new application and must be installed as an in-place update through the official signer path.

The release consolidates object continuity into `PhysicalObjectStateMachine`, adds bounded coarse catalog recall before exact scoring, introduces one `UnifiedRecoveryCoordinator`, exposes operator guidance for missing evidence, and adds a `UnifiedDecisionKernel` so quantity can only follow accepted recognition plus physical safety.

`ARS AI Engineer` remains available for Dev Center diagnostics but is removed from the automatic cashier scan failure path. Dev Center build identity is now sourced from `ArsV850Config`, eliminating the prior possibility of an R1 label being shown by an R2-or-later build.

Safety is unchanged: package `com.arspos.anglerriausyndicate`, Room v5, official signer, all 14 recognition thresholds, Cloud Identity `SHADOW`, Self Learning `ACTIVE_CONFIRMED_ONLY`, Package Edge Firewall, NORMAL Object Purity, Rod Authenticity, Anchor Role Truth, Decision Evidence Ledger and Physical Quantity Safety remain enforced.

Do not uninstall the production application before installing this build. Full signed APK acceptance requires the supplied GitHub Actions workflow to pass compile, tests, package/version verification, signer fingerprint verification, zipalign, and subsequent real-device Smart Scan regression tests.
