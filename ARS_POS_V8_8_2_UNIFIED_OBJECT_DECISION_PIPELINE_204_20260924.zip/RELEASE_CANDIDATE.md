# Current Release Candidate

ARS POS **1.10.4 (204)** — Phase **4.3.5.2** / **V8.8.2 Unified Object Decision Pipeline**.

Primary acceptance focus: stable persistent object lock before heavy identity, Top-K candidate retrieval before exact scoring, non-stacked recovery, guided evidence acquisition, exact decision state, and quantity only after recognition plus physical safety.

Recognition thresholds, package, Room v5 and official signer are unchanged. Cloud Identity remains `SHADOW`; Self Learning remains `ACTIVE_CONFIRMED_ONLY`; ARS AI Engineer is `DEV_CENTER_DIAGNOSTIC_ONLY` and outside the automatic cashier scan path.

Install only as an in-place update from the official signed application. The release is not device-finished until the supplied GitHub Actions build passes and real-device regression evidence is reviewed.
