# ARS POS 1.10.4 (204) — Phase 4.3.5.2 / V8.8.2

**Unified Object Decision Pipeline**

ARS POS Smart Scan now follows a strict decision order:

`detect physical object → stabilize/lock → bounded catalog recall → exact recognition → unified decision → physical quantity → cashier review`.

The release is focused on object-lock stability and decision quality rather than adding more independent rescue layers. `PhysicalObjectStateMachine` owns object lifecycle and identity-switch hysteresis. Coarse visual similarity only recalls Top-K candidates; it never accepts a SKU. Exact recognition still uses the existing `SmartRecognitionEngine` thresholds, all of which remain unchanged.

`UnifiedRecoveryCoordinator` prevents local recovery, NON-ROD→NORMAL recovery and full-frame evidence rescue from competing as simultaneous final decisions. `GuidedEvidencePolicy` tells the operator which evidence is missing. `UnifiedDecisionKernel` allows quantity only after recognition acceptance and physical safety agree.

ARS AI Engineer is `DEV_CENTER_DIAGNOSTIC_ONLY`: it remains available for structured diagnostics but no longer runs automatically in the cashier Smart Scan critical path.

## Release invariants

- Package: `com.arspos.anglerriausyndicate`
- versionName/versionCode: `1.10.4 / 204`
- Room database: `v5`, no destructive migration
- Cloud Identity: `SHADOW`
- Self Learning: `ACTIVE_CONFIRMED_ONLY`
- Recognition thresholds: unchanged (14/14)
- Official signer SHA-256: `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`
- Update method: in-place only; do not uninstall production data.

See `PHASE4_3_5_2_V8_8_2_UNIFIED_OBJECT_DECISION_PIPELINE.md` and `RELEASE_204.md`.
