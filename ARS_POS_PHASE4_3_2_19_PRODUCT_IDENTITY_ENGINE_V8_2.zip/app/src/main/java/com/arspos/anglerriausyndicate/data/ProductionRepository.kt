package com.arspos.anglerriausyndicate.data

import com.arspos.anglerriausyndicate.SmartProductInput
import com.arspos.anglerriausyndicate.ProductVisualMatcher
import com.arspos.anglerriausyndicate.VisualProductMatch
import androidx.room.withTransaction
import kotlinx.coroutines.flow.first
import com.arspos.anglerriausyndicate.data.db.*
import java.text.SimpleDateFormat
import java.util.*

data class ProfitSummary(val revenue:Long,val cost:Long,val grossProfit:Long)
data class LoginResult(val userId:Long,val role:String,val displayName:String)

class ProductionRepository(private val db:ArsDatabase){
    private val dao=db.dao()

    fun products()=dao.products()
    fun search(q:String)=if(q.isBlank())products() else dao.search(q)
    fun sales()=dao.sales()
    fun customers()=dao.customers()
    suspend fun saleItems(id:Long)=dao.saleItems(id)
    fun revenue(start:Long)=dao.revenue(start)
    fun transactionCount(start:Long)=dao.transactionCount(start)
    fun cashBalance()=dao.cashBalance()

    suspend fun login(username:String,pin:String):Result<LoginResult> = runCatching{
        val user=dao.user(username.trim()) ?: error("Username tidak ditemukan")
        require(PinHasher.matches(user.pinHash,pin)){"PIN salah"}
        if (!user.pinHash.startsWith("sha256\$")) dao.updateUser(user.copy(pinHash=PinHasher.hash(pin)))
        LoginResult(user.id,user.role,user.displayName)
    }

    suspend fun seed(){
        if(dao.countProducts()==0){
            listOf(
                ProductEntity(sku="JRG001",barcode="899000000001",name="Joran BC Elito Sidat 180",category="JORAN",brand="Elito",costPrice=95000,sellPrice=150000,wholesalePrice=135000,stock=15,minimumStock=5),
                ProductEntity(sku="REL001",barcode="899000000002",name="Reel Shimano FX 2500",category="REEL",brand="Shimano",costPrice=210000,sellPrice=275000,stock=8,minimumStock=3),
                ProductEntity(sku="SNR001",barcode="899000000003",name="PE Jabrik X9 2.0",category="SENAR",brand="Jabrik",costPrice=55000,sellPrice=85000,stock=12,minimumStock=4),
                ProductEntity(sku="LDR001",barcode="899000000004",name="Leader Relix 40lb",category="LEADER",brand="Relix",costPrice=28000,sellPrice=45000,stock=9,minimumStock=4),
                ProductEntity(sku="KIL001",barcode="899000000005",name="Kail BKK 1/0",category="KAIL",brand="BKK",costPrice=11000,sellPrice=18000,stock=20,minimumStock=5)
            ).forEach{dao.insertProduct(it)}
        }
        dao.insertUser(UserEntity(username="admin",displayName="Administrator",role="ADMIN",pinHash=PinHasher.hash("0000")))
        dao.setSetting(SettingEntity("store_name","ANGLER RIAU SYNDICATE"))
        dao.setSetting(SettingEntity("store_tagline","FISHING STORE"))
    }

    suspend fun addProduct(name:String,sku:String,barcode:String?,category:String,cost:Long,price:Long,stock:Int,brand:String?=null,variant:String?=null)=db.withTransaction{
        require(name.isNotBlank()) { "Nama produk wajib diisi" }
        val normalizedSku = sku.trim().ifBlank { SmartProductInput.generateSku(brand.orEmpty(), name, variant.orEmpty()) }
        val productId = dao.insertProduct(ProductEntity(
            sku=normalizedSku,
            barcode=barcode?.trim()?.ifBlank { null },
            name=name.trim(),
            category=category.trim().ifBlank { "LAINNYA" },
            brand=brand?.trim()?.ifBlank { null },
            variant=variant?.trim()?.ifBlank { null },
            costPrice=cost,
            sellPrice=price,
            stock=stock
        ))
        mergeProductIdentityProfile(
            productId = productId,
            brand = brand.orEmpty(),
            name = name,
            variant = variant.orEmpty(),
            barcode = barcode.orEmpty()
        )
        productId
    }

    fun productPhotos(productId:Long)=dao.productPhotos(productId)

    suspend fun visualProductMatches(bitmap: android.graphics.Bitmap):List<com.arspos.anglerriausyndicate.VisualProductMatch> {
        val photos=dao.allProductPhotos()
        if(photos.isEmpty()) return emptyList()
        val products=HashMap<Long,ProductEntity?>()
        val bestByProduct=HashMap<Long,com.arspos.anglerriausyndicate.VisualProductMatch>()
        for(photo in photos){
            val product=if(products.containsKey(photo.productId)) products[photo.productId] else dao.product(photo.productId).also{products[photo.productId]=it}
            if(product==null || !product.active) continue
            val score=com.arspos.anglerriausyndicate.ProductVisualMatcher.score(bitmap,photo.localPath)
            val match=com.arspos.anglerriausyndicate.VisualProductMatch(product,photo,score)
            val previous=bestByProduct[product.id]
            if(previous==null || score>previous.score) bestByProduct[product.id]=match
        }
        return bestByProduct.values.sortedByDescending { it.score }.take(8)
    }

    /** Phase 4.3.2: object crop + OCR + visual fusion with strict acceptance. */
    suspend fun smartVisualScan(bitmap: android.graphics.Bitmap): List<com.arspos.anglerriausyndicate.VisualScanObject> {
        // V8.2 HYBRID: barcode + OCR + identity profile + master visual + long-object rescue.
        // Object detection proposes regions; the identity engine decides SKU.
        val photos = dao.allProductPhotos()
        val allProducts = dao.products().first().filter { it.active }
        if (allProducts.isEmpty()) return emptyList()

        var objects = com.arspos.anglerriausyndicate.SmartVisualScanner.detectObjects(bitmap)
        val identityProfiles = loadIdentityProfiles()
        val verifiedProductIds = loadVerifiedProductIds()
        val productsById = allProducts.associateBy { it.id }

        // If the detector misses the scene, barcode or a verified long-object
        // master may safely use the full image as a proposal.
        if (objects.isEmpty()) {
            val sceneOcr = runCatching {
                com.arspos.anglerriausyndicate.SmartProductInput.analyzeMultiOrientation(bitmap)
            }.getOrElse { com.arspos.anglerriausyndicate.SmartProductInput.Draft() }
            val hasSafeLong = identityProfiles.values.any {
                it.isLongObject && verifiedProductIds.contains(it.productId)
            }
            if (sceneOcr.barcode.isBlank() && !hasSafeLong) return emptyList()
            objects = listOf(android.graphics.Rect(0, 0, bitmap.width, bitmap.height))
        }

        val result = ArrayList<com.arspos.anglerriausyndicate.VisualScanObject>()

        suspend fun analyze(bounds: android.graphics.Rect, index: Int, allowSceneOcr: Boolean): com.arspos.anglerriausyndicate.VisualScanObject? {
            val crop = com.arspos.anglerriausyndicate.SmartVisualScanner.crop(bitmap, bounds) ?: return null
            val ocr = runCatching {
                com.arspos.anglerriausyndicate.SmartProductInput.analyzeMultiOrientation(crop)
            }.getOrElse { com.arspos.anglerriausyndicate.SmartProductInput.Draft() }

            val effectiveOcr = if (allowSceneOcr && ocr.barcode.isBlank()) {
                runCatching {
                    com.arspos.anglerriausyndicate.SmartProductInput.analyzeMultiOrientation(bitmap)
                }.getOrElse { ocr }
            } else ocr

            val references = ArrayList<com.arspos.anglerriausyndicate.VisualProductMatch>()
            for (photo in photos) {
                val product = productsById[photo.productId] ?: continue
                val profile = identityProfiles[product.id]
                val longObject = profile?.isLongObject == true || isLikelyLongProduct(product)
                val score = com.arspos.anglerriausyndicate.ProductVisualMatcher.score(
                    crop, photo.localPath, longObject = longObject
                )
                references += com.arspos.anglerriausyndicate.VisualProductMatch(product, photo, score)
            }

            val recognized = SmartRecognitionEngine.recognize(
                crop = crop,
                products = allProducts,
                references = references,
                ocr = effectiveOcr,
                identityProfiles = identityProfiles,
                verifiedProductIds = verifiedProductIds
            )

            crop.recycle()
            return com.arspos.anglerriausyndicate.VisualScanObject(
                index = index,
                bounds = bounds,
                match = recognized.match,
                bestScore = recognized.finalScore,
                visualScore = recognized.visualScore,
                textScore = recognized.textScore,
                finalScore = recognized.finalScore,
                ocrText = recognized.ocrText,
                barcode = recognized.barcode,
                reason = recognized.reason,
                candidates = recognized.candidates
            )
        }

        objects.forEachIndexed { index, bounds ->
            analyze(bounds, index + 1, allowSceneOcr = objects.size == 1)?.let { result += it }
        }

        // V8.2 LONG OBJECT LANE: when a verified rod master exists, also test
        // the complete photo. This rescues long products that the generic
        // detector cropped too tightly. It is visual-only and therefore still
        // passes the strict verified-master + margin gate.
        val hasVerifiedLongMaster = allProducts.any { product ->
            val profile = identityProfiles[product.id]
            (profile?.isLongObject == true || isLikelyLongProduct(product)) && verifiedProductIds.contains(product.id)
        }
        if (hasVerifiedLongMaster && result.none { it.match != null && isLikelyLongProduct(it.match.product) && verifiedProductIds.contains(it.match.product.id) }) {
            // V8.2 LONG OBJECT RESCUE: test the whole frame plus centered
            // windows. A rod may be too thin for ML Kit to box correctly, so
            // identity gets several safe full-frame proposals instead of one
            // arbitrary detector crop. Only an accepted long-master result is
            // exposed to the cashier.
            val longProposals = listOf(
                android.graphics.Rect(0, 0, bitmap.width, bitmap.height),
                centeredRect(bitmap.width, bitmap.height, 0.90f),
                centeredRect(bitmap.width, bitmap.height, 0.78f),
                centeredRect(bitmap.width, bitmap.height, 0.64f)
            )
            val acceptedLong = ArrayList<com.arspos.anglerriausyndicate.VisualScanObject>()
            longProposals.distinctBy { "${it.left}:${it.top}:${it.right}:${it.bottom}" }.forEachIndexed { offset, rect ->
                analyze(rect, result.size + offset + 1, allowSceneOcr = false)?.let { candidate ->
                    if (candidate.match != null &&
                        isLikelyLongProduct(candidate.match.product) &&
                        verifiedProductIds.contains(candidate.match.product.id)
                    ) {
                        acceptedLong += candidate
                    }
                }
            }
            acceptedLong.maxByOrNull { it.finalScore }?.let { result += it }
        }

        return result.take(12)
    }

    private fun centeredRect(width: Int, height: Int, fraction: Float): android.graphics.Rect {
        val f = fraction.coerceIn(0.50f, 1f)
        val w = (width * f).toInt().coerceAtLeast(24).coerceAtMost(width)
        val h = (height * f).toInt().coerceAtLeast(24).coerceAtMost(height)
        val left = (width - w) / 2
        val top = (height - h) / 2
        return android.graphics.Rect(left, top, left + w, top + h)
    }

    private fun isLikelyLongProduct(product: ProductEntity): Boolean {
        val hay = "${product.name} ${product.category} ${product.brand.orEmpty()} ${product.variant.orEmpty()}".uppercase()
        return listOf("JORAN", "ROD", "PANCING FIBER", "TELESCOPIC", "TELESCOP", "STICK ROD").any { hay.contains(it) }
    }

    suspend fun verifyProductMaster(productId: Long, bitmap: android.graphics.Bitmap): MasterVerificationResult {
        val product = dao.product(productId) ?: return MasterVerificationResult(
            productId = productId,
            productName = "",
            sku = "",
            barcode = "",
            referenceCount = 0,
            visualScore = 0,
            textScore = 0,
            finalScore = 0,
            ocrText = "",
            detectedBarcode = "",
            accepted = false,
            reason = "Produk tidak ditemukan"
        )
        val profile = ProductIdentityProfileCodec.decode(product.id, dao.setting("identity_profile_${product.id}"))
        val refs = dao.allProductPhotos()
            .filter { it.productId == productId }
            .map { photo ->
                VisualProductMatch(
                    product = product,
                    photo = photo,
                    score = ProductVisualMatcher.score(bitmap, photo.localPath, longObject = profile?.isLongObject == true)
                )
            }
        if (refs.isEmpty()) return MasterVerificationResult(
            productId = product.id, productName = product.name, sku = product.sku,
            barcode = product.barcode.orEmpty(), referenceCount = 0, visualScore = 0,
            textScore = 0, finalScore = 0, ocrText = "", detectedBarcode = "",
            accepted = false, reason = "Belum ada referensi master visual"
        )
        val ocr = runCatching { SmartProductInput.analyzeMultiOrientation(bitmap) }
            .getOrElse { SmartProductInput.Draft() }
        val recognized = SmartRecognitionEngine.recognize(
            crop = bitmap, products = listOf(product), references = refs, ocr = ocr,
            identityProfiles = profile?.let { mapOf(product.id to it) }.orEmpty()
        )
        val exactBarcode = ocr.barcode.isNotBlank() &&
            product.barcode.orEmpty().replace(Regex("\\D"), "") == ocr.barcode.replace(Regex("\\D"), "")
        val longObject = profile?.isLongObject == true || isLikelyLongProduct(product)
        val accepted = (refs.size >= (if (longObject) 5 else 3)) && when {
            exactBarcode && recognized.visualScore >= 45 -> true
            recognized.textScore >= 82 && recognized.visualScore >= 30 -> true
            recognized.textScore >= 72 && recognized.visualScore >= 40 -> true
            longObject && recognized.visualScore >= 72 -> true
            recognized.visualScore >= 82 -> true
            else -> false
        }
        val reason = when {
            refs.size < if (longObject) 5 else 3 -> "Referensi terlalu sedikit; minimal ${if (longObject) 5 else 3} frame master diperlukan"
            accepted && exactBarcode -> "Barcode cocok + visual master terverifikasi"
            accepted && recognized.textScore >= 82 -> "Identitas master + OCR + visual terverifikasi"
            accepted && recognized.textScore >= 72 -> "OCR + visual master terverifikasi"
            accepted -> "Visual master terverifikasi"
            else -> "Bukti master belum cukup kuat; tambah frame atau foto uji lebih jelas"
        }
        if (accepted) {
            dao.setSetting(SettingEntity("master_verified_${product.id}", "1"))
            dao.setSetting(SettingEntity("master_verified_score_${product.id}", recognized.finalScore.toString()))
            dao.setSetting(SettingEntity("master_verified_at_${product.id}", System.currentTimeMillis().toString()))
        }
        return MasterVerificationResult(
            productId = product.id, productName = product.name, sku = product.sku,
            barcode = product.barcode.orEmpty(), referenceCount = refs.size,
            visualScore = recognized.visualScore, textScore = recognized.textScore,
            finalScore = recognized.finalScore, ocrText = ocr.rawText,
            detectedBarcode = ocr.barcode, accepted = accepted, reason = reason
        )
    }

    private suspend fun loadVerifiedProductIds(): Set<Long> =
        dao.masterVerificationSettings().mapNotNull { setting ->
            if (setting.key.startsWith("master_verified_") && setting.value == "1") {
                setting.key.removePrefix("master_verified_").toLongOrNull()
            } else null
        }.toSet()

    private suspend fun loadIdentityProfiles(): Map<Long, ProductIdentityProfile> =
        dao.identityProfileSettings().mapNotNull { setting ->
            val id = setting.key.removePrefix("identity_profile_").toLongOrNull() ?: return@mapNotNull null
            ProductIdentityProfileCodec.decode(id, setting.value)?.let { id to it }
        }.toMap()

    suspend fun mergeProductIdentityProfile(
        productId: Long,
        rawText: String = "",
        brand: String = "",
        name: String = "",
        variant: String = "",
        modelCode: String = "",
        barcode: String = "",
        recognitionMode: String = "HYBRID",
        isLongObject: Boolean = false
    ) {
        val key = "identity_profile_$productId"
        val old = ProductIdentityProfileCodec.decode(productId, dao.setting(key))
        val mergedText = (listOf(old?.rawText.orEmpty(), rawText)
            .flatMap { it.lines() }
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.length >= 2 }
            .distinct()
            .takeLast(80)
            .joinToString("\n"))
        val mergedBrand = if (brand.isNotBlank()) brand.trim() else old?.brand.orEmpty()
        val mergedName = if (name.isNotBlank()) name.trim() else old?.name.orEmpty()
        val mergedVariant = if (variant.isNotBlank()) variant.trim() else old?.variant.orEmpty()
        val mergedModel = if (modelCode.isNotBlank()) modelCode.trim() else old?.modelCode.orEmpty()
        val mergedBarcode = if (barcode.isNotBlank()) barcode.trim() else old?.barcode.orEmpty()
        val aliasSource = buildList {
            addAll(old?.aliases.orEmpty())
            addAll(rawText.lines())
            add(mergedBrand)
            add(mergedName)
            add(mergedVariant)
            add(mergedModel)
        }
        val aliases = aliasSource
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.length >= 2 }
            .distinct()
            .takeLast(80)

        val oldLong = old?.isLongObject ?: false
        val merged = ProductIdentityProfile(
            productId = productId,
            rawText = mergedText,
            brand = mergedBrand,
            name = mergedName,
            variant = mergedVariant,
            modelCode = mergedModel,
            barcode = mergedBarcode,
            aliases = aliases,
            recognitionMode = recognitionMode.ifBlank { old?.recognitionMode ?: "HYBRID" },
            isLongObject = isLongObject || oldLong
        )
        dao.setSetting(SettingEntity(key, ProductIdentityProfileCodec.encode(merged)))
    }

    suspend fun productIdentityProfile(productId: Long): ProductIdentityProfile? =
        ProductIdentityProfileCodec.decode(productId, dao.setting("identity_profile_$productId"))

    suspend fun setProductRecognitionMode(productId: Long, mode: String, isLongObject: Boolean) {
        val old = productIdentityProfile(productId)
        val profile = (old ?: ProductIdentityProfile(productId = productId)).copy(
            recognitionMode = mode.ifBlank { "HYBRID" },
            isLongObject = isLongObject,
            updatedAt = System.currentTimeMillis()
        )
        dao.setSetting(SettingEntity("identity_profile_$productId", ProductIdentityProfileCodec.encode(profile)))
        invalidateMasterVerification(productId)
    }

    suspend fun clearProductIdentityProfile(productId: Long) {
        dao.setSetting(SettingEntity("identity_profile_$productId", ""))
    }

    suspend fun isMasterVerified(productId:Long):Boolean = dao.setting("master_verified_${productId}") == "1"
    suspend fun invalidateMasterVerification(productId:Long) { dao.setSetting(SettingEntity("master_verified_${productId}", "0")) }

    suspend fun addProductPhoto(productId:Long, localPath:String, primary:Boolean=false, captureAngle:String="UNKNOWN"):Long {
        if(primary) dao.clearPrimaryPhoto(productId)
        return dao.insertProductPhoto(ProductPhotoEntity(productId=productId, localPath=localPath, isPrimary=primary, captureAngle=captureAngle))
    }

    suspend fun clearProductPhotoAngle(productId:Long, angle:String) = dao.deleteProductPhotosForAngle(productId, angle)

    suspend fun setPrimaryProductPhoto(productId:Long, photoId:Long) {
        dao.clearPrimaryPhoto(productId)
        dao.setPrimaryPhoto(photoId)
    }

    suspend fun deleteProductPhoto(photo:ProductPhotoEntity) = dao.deleteProductPhoto(photo)

    suspend fun stockIn(productId:Long,qty:Int,cost:Long,supplier:String?,invoice:String?) {
        require(qty>0){"Jumlah harus > 0"}
        require(cost>=0){"Harga modal tidak valid"}
        db.withTransaction{
            val p=dao.product(productId) ?: error("Produk tidak ditemukan")
            val receipt=dao.insertReceipt(StockReceiptEntity(supplier=supplier,invoice=invoice,totalCost=cost*qty))
            dao.insertReceiptItems(listOf(StockReceiptItemEntity(0,receipt,productId,qty,cost)))
            dao.changeStock(productId,qty)
            dao.insertMovement(StockMovementEntity(
                productId=productId,
                type="PURCHASE",
                quantity=qty,
                stockBefore=p.stock,
                stockAfter=p.stock+qty,
                note=invoice
            ))
            dao.audit(AuditLogEntity(action="STOCK_IN",referenceId=receipt,detail="${p.name} +$qty"))
        }
    }

    suspend fun cashOut(amount:Long,category:String,description:String?) {
        require(amount>0){"Nominal harus > 0"}
        dao.insertCash(CashTransactionEntity(type="OUT",category=category,amount=amount,description=description))
        dao.audit(AuditLogEntity(action="CASH_OUT",detail="$category Rp $amount"))
    }

    suspend fun checkout(cart:List<CartLine>,paid:Long,method:String):CheckoutResult{
        require(cart.isNotEmpty()){"Keranjang kosong"}
        require(method in setOf("CASH","QRIS","TRANSFER","DEBIT")){"Metode pembayaran tidak valid"}
        val total=cart.sumOf{it.subtotal}
        require(paid>=total){"Uang pembayaran kurang"}
        if(method!="CASH") require(paid==total){"Pembayaran non-CASH harus sesuai total"}
        return db.withTransaction{
            cart.forEach{
                val p=dao.product(it.product.id)?:error("Produk tidak ditemukan")
                require(p.stock>=it.quantity){"Stok ${p.name} tidak mencukupi"}
            }
            val invoice="ARS-"+SimpleDateFormat("yyyyMMdd-HHmmssSSS",Locale.US).format(Date())
            val id=dao.insertSale(SaleEntity(invoiceNumber=invoice,subtotal=total,discount=0,grandTotal=total,
                paidAmount=paid,changeAmount=paid-total,paymentMethod=method))
            dao.insertItems(cart.map{SaleItemEntity(saleId=id,productId=it.product.id,productName=it.product.name,
                quantity=it.quantity,costPrice=it.product.costPrice,sellPrice=it.product.sellPrice,discount=0,subtotal=it.subtotal)})
            cart.forEach{
                val p=dao.product(it.product.id)!!
                dao.changeStock(p.id,-it.quantity)
                dao.insertMovement(StockMovementEntity(
                    productId=p.id,
                    type="SALE",
                    quantity=-it.quantity,
                    stockBefore=p.stock,
                    stockAfter=p.stock-it.quantity,
                    referenceId=id,
                    note=invoice
                ))
            }
            if(method=="CASH") dao.insertCash(CashTransactionEntity(type="IN",category="PENJUALAN",amount=total,referenceId=id))
            dao.audit(AuditLogEntity(action="SALE",referenceId=id,detail="$invoice | $method | Rp $total"))
            CheckoutResult(id,invoice,cart,total,paid,paid-total,method)
        }
    }

    suspend fun processReturn(saleId:Long, reason:String):Long {
        return db.withTransaction {
            val sale=dao.sale(saleId) ?: error("Transaksi tidak ditemukan")
            require(sale.status=="PAID"){"Transaksi tidak dapat diretur"}
            val existing=dao.returnsForSale(saleId).sumOf{it.total}
            require(existing < sale.grandTotal){"Transaksi sudah diretur penuh"}
            val items=dao.saleItems(saleId)
            val refund=items.sumOf{it.subtotal}
            val returnId=dao.insertReturn(ReturnEntity(saleId=saleId,reason=reason,total=refund))
            dao.insertReturnItems(items.map{ReturnItemEntity(returnId=returnId,productId=it.productId,quantity=it.quantity,amount=it.subtotal)})
            items.forEach{
                val p=dao.product(it.productId) ?: error("Produk retur tidak ditemukan")
                val before=p.stock
                dao.changeStock(p.id,it.quantity)
                dao.insertMovement(StockMovementEntity(
                    productId=p.id,
                    type="RETURN",
                    quantity=it.quantity,
                    stockBefore=before,
                    stockAfter=before+it.quantity,
                    referenceId=returnId,
                    note=sale.invoiceNumber
                ))
            }
            if(sale.paymentMethod=="CASH") dao.insertCash(CashTransactionEntity(type="OUT",category="RETUR",amount=refund,referenceId=returnId))
            dao.audit(AuditLogEntity(action="RETURN",referenceId=returnId,detail="${sale.invoiceNumber} | Rp $refund | $reason"))
            refund
        }
    }

    suspend fun profitSummary(start:Long):ProfitSummary{
        val sales=dao.sales().first()
        val relevant=sales.filter{it.status=="PAID"&&it.createdAt>=start}
        val grossSales=relevant.sumOf{it.grandTotal}
        var cost=0L
        relevant.forEach{s->cost+=dao.saleItems(s.id).sumOf{it.costPrice*it.quantity}}
        val returned=relevant.sumOf{s->dao.returnsForSale(s.id).sumOf{it.total}}
        return ProfitSummary(grossSales-returned,cost,(grossSales-returned)-cost)
    }
}
