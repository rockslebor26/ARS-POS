package com.arspos.anglerriausyndicate

import java.text.NumberFormat
import java.util.Locale

/**
 * Format nominal Rupiah Indonesia untuk tampilan POS.
 * Contoh: 1376000 -> "Rp 1.376.000"
 * Nilai penyimpanan/transaksi tetap Long; fungsi ini hanya mengubah tampilan.
 */
fun formatRupiah(amount: Long): String {
    val formatter = NumberFormat.getNumberInstance(Locale("id", "ID"))
    formatter.isGroupingUsed = true
    formatter.maximumFractionDigits = 0
    formatter.minimumFractionDigits = 0
    return "Rp ${formatter.format(amount)}"
}

fun formatRupiah(amount: Int): String = formatRupiah(amount.toLong())
