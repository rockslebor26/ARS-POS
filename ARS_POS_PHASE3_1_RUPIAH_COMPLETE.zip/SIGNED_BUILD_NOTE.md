# ARS POS 1.0.0 — FIXED4

This package fixes the installability problem from `app-release-unsigned.apk`.

The release build is signed with the standard Android debug signing key so it can
be installed for testing. This is NOT the final production signing identity.
Before publishing ARS POS publicly, create and protect a dedicated ARS POS
release keystore and switch the release signing configuration to it.

GitHub Actions also verifies the APK with `apksigner` and uploads:
`ARS-POS-1.0.0-signed.apk`.
