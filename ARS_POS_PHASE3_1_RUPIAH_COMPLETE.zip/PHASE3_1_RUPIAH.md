# ARS POS — Phase 3.1: Format Rupiah

Versi ini mempertahankan seluruh fungsi Phase 3 Payment V1 dan Phase 2 Cart V1.

## Perubahan
- Format nominal tampilan menggunakan pemisah ribuan Indonesia.
- Contoh: `Rp 1376000` menjadi `Rp 1.376.000`.
- Formatter terpusat di `Money.kt` menggunakan locale Indonesia.
- Dashboard, Kasir, Pembayaran, Transaksi Berhasil, Produk, Laporan, Retur, dan struk menggunakan formatter.
- Perhitungan database/transaksi tetap menggunakan `Long`; perubahan hanya pada tampilan.
- Version code: 101.
- Version name: 1.0.1.

## Pengujian yang disarankan
1. Total transaksi tampil dengan titik ribuan.
2. Uang pelanggan tetap dapat dimasukkan sebagai angka digit.
3. Nominal dibayar tampil terformat di bawah input.
4. Kembalian dan uang kurang terformat.
5. Transaksi CASH tetap tersimpan.
6. QRIS/TRANSFER/DEBIT tetap dapat dipilih.
7. Laporan menampilkan nominal terformat.
8. Struk Bluetooth menggunakan nominal terformat.
