# ARS POS — PHASE 3 PAYMENT V1

Implemented:
- CASH / QRIS / TRANSFER / DEBIT payment selection.
- CASH amount input with numeric keyboard.
- Automatic change calculation.
- Insufficient-cash validation blocks checkout.
- Non-CASH methods automatically use the transaction total.
- Successful transaction confirmation with invoice, method, total, paid and change.
- Existing stock deduction, database transaction, reports and printer integration retained.
- Checkout validates supported payment methods.
