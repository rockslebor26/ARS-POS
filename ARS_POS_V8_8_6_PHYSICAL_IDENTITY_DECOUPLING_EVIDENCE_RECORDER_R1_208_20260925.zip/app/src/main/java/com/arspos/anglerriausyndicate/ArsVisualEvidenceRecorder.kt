package com.arspos.anglerriausyndicate

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import org.json.JSONObject
import org.json.JSONArray
import com.arspos.anglerriausyndicate.data.ProductIdentityProfile
import com.arspos.anglerriausyndicate.data.db.ProductEntity
import com.arspos.anglerriausyndicate.data.db.ProductPhotoEntity
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.Collections
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max

/**
 * Phase 4.3.5.6 V8.8.6 — Identity/Quantity Decoupling + One-Tap Visual Diagnostic Recorder + Replay-Ready Diagnostic Package V5.
 * Diagnostic-only: it never changes recognition scores, thresholds, quantity,
 * product identity, transaction state, or database contents.
 */
object ArsVisualEvidenceRecorder {
    private const val ROOT = "ars_diagnostics/evidence"
    private const val EXPORT_DIR = "ars_diagnostic_exports"
    private const val JPEG_QUALITY = 82
    private const val MAX_IMAGE_DIMENSION = 1280
    private const val MAX_SESSIONS = 40
    private const val MAX_TOTAL_BYTES = 80L * 1024L * 1024L
    private const val MAX_OBJECT_EVIDENCE = 8
    private const val MAX_TRACK_EVIDENCE = 8

    data class Summary(val sessions: Int, val files: Int, val bytes: Long, val latestSession: String)

    private data class TrackSnapshot(
        val proposalId: String,
        val physicalObjectId: String,
        val bounds: Rect,
        val axisStartX: Int,
        val axisStartY: Int,
        val axisEndX: Int,
        val axisEndY: Int,
        val authenticityState: String,
        val authenticityScore: Int,
        val rodClaim: Boolean,
        val quantityEligible: Boolean,
        val mergeReason: String
    )

    private val executor = ThreadPoolExecutor(
        1, 1, 30L, TimeUnit.SECONDS,
        ArrayBlockingQueue(24),
        ThreadPoolExecutor.AbortPolicy()
    )
    @Volatile private var appContext: Context? = null
    private val manifestLock = Any()
    private val trackSnapshots = ConcurrentHashMap<String, MutableList<TrackSnapshot>>()
    private val sessionFailures = ConcurrentHashMap<String, AtomicInteger>()

    fun install(context: Context) {
        appContext = context.applicationContext
        File(context.filesDir, ROOT).mkdirs()
        File(context.cacheDir, EXPORT_DIR).mkdirs()
    }

    fun beginSession(session: String, analysisBitmap: Bitmap) {
        val context = appContext ?: return
        if (session.isBlank()) return
        val dir = sessionDir(context, session).apply { mkdirs() }
        dir.setLastModified(System.currentTimeMillis())
        trackSnapshots[session] = Collections.synchronizedList(mutableListOf<TrackSnapshot>())
        sessionFailures[session] = AtomicInteger(0)
        val meta = JSONObject().apply {
            put("sessionId", session)
            put("scanId", session)
            put("phase", ArsV850Config.PHASE)
            put("engine", ArsV850Config.ENGINE)
            put("feature", "EVENT_DRIVEN_VISUAL_RETRIEVAL_LIVE_FINAL_CONVERGENCE_GROUND_TRUTH_REPLAY_V4")
            put("analysisWidth", analysisBitmap.width)
            put("analysisHeight", analysisBitmap.height)
            put("status", "STARTED")
            put("startedAt", System.currentTimeMillis())
        }
        runCatching {
            File(dir, "session.json").writeText(meta.toString(2))
            val groundTruth = File(dir, "ground_truth.jsonl")
            if (!groundTruth.exists()) groundTruth.writeText("")
        }.onFailure {
            recordFailure(mapOf("session" to session, "artifactType" to "SESSION_METADATA", "stage" to "WRITE"), it)
        }
        ArsFlightRecorder.event(
            "EVIDENCE_SESSION_START",
            "Visual evidence session opened",
            mapOf("session" to session, "analysisWidth" to analysisBitmap.width, "analysisHeight" to analysisBitmap.height)
        )
        enqueueBitmapSnapshot(
            analysisBitmap,
            File(dir, "scene/analysis_scene.jpg"),
            mapOf("type" to "SCENE_ANALYSIS", "session" to session, "source" to "ANALYSIS_BITMAP")
        )
        // Lossless, replay-ready input. This is diagnostic-only and never feeds
        // the current scan decision, so recorder activity cannot alter identity.
        enqueuePngSnapshot(
            analysisBitmap,
            File(dir, "replay/analysis_replay.png"),
            mapOf("type" to "REPLAY_INPUT", "session" to session, "source" to "ANALYSIS_BITMAP_LOSSLESS")
        )
    }

    /** Captures every physical-track truth state before display pruning. */
    fun captureTrackAudit(session: String, scene: Bitmap, proposal: ScanProposal) {
        val context = appContext ?: return
        if (session.isBlank()) return
        val list = trackSnapshots.getOrPut(session) {
            Collections.synchronizedList(mutableListOf<TrackSnapshot>())
        }
        synchronized(list) {
            if (list.size >= MAX_TRACK_EVIDENCE) return
            list += TrackSnapshot(
                proposal.proposalId,
                proposal.physicalObjectId,
                Rect(proposal.normalizedBounds),
                proposal.axisStartX, proposal.axisStartY,
                proposal.axisEndX, proposal.axisEndY,
                proposal.rodAuthenticityState,
                proposal.rodAuthenticityScore,
                proposal.rodClaim,
                proposal.quantityEligible,
                proposal.physicalMergeReason
            )
        }
        val crop = safeCrop(scene, proposal.normalizedBounds) ?: run {
            recordFailure(mapOf("session" to session, "artifactType" to "TRACK_AUDIT_CROP", "proposalId" to proposal.proposalId), IllegalStateException("Track crop unavailable"))
            return
        }
        val id = safeName(proposal.physicalObjectId.ifBlank { proposal.proposalId })
        enqueueOwnedBitmap(
            crop,
            File(sessionDir(context, session), "tracks/${id}_${safeName(proposal.rodAuthenticityState)}.jpg"),
            mapOf(
                "type" to "TRACK_AUDIT_CROP", "session" to session,
                "proposalId" to proposal.proposalId,
                "physicalObjectId" to proposal.physicalObjectId,
                "authenticity" to proposal.rodAuthenticityState,
                "authenticityScore" to proposal.rodAuthenticityScore,
                "rodClaim" to proposal.rodClaim,
                "rodClaimScore" to proposal.rodClaimScore,
                "foregroundSupported" to proposal.foregroundSupported,
                "foregroundReason" to proposal.foregroundReason,
                "rodStructureScore" to proposal.rodStructureScore,
                "rodTipVisible" to proposal.rodTipVisible,
                "physicalOwnershipState" to proposal.physicalOwnershipState,
                "physicalOwnershipOwnerId" to proposal.physicalOwnershipOwnerId,
                "packageEdgeScore" to proposal.packageEdgeScore,
                "packageEdgeBoundaryDistancePx" to proposal.packageEdgeBoundaryDistancePx,
                "packageEdgeParallelEvidence" to proposal.packageEdgeParallelEvidence,
                "packageEdgeRectangularScore" to proposal.packageEdgeRectangularScore,
                "packageEdgeTrackInsideOwnerRatio" to proposal.packageEdgeTrackInsideOwnerRatio,
                "quantityEligible" to proposal.quantityEligible,
                "bounds" to "${proposal.normalizedBounds.left},${proposal.normalizedBounds.top},${proposal.normalizedBounds.right},${proposal.normalizedBounds.bottom}",
                "axis" to "${proposal.axisStartX},${proposal.axisStartY},${proposal.axisEndX},${proposal.axisEndY}",
                "axisConfidence" to proposal.axisConfidence,
                "measuredWidthMedianPx" to proposal.measuredWidthMedianPx,
                "widthVariance" to proposal.widthVariance,
                "curvatureScore" to proposal.curvatureScore,
                "branchPenalty" to proposal.branchPenalty,
                "segmentSupport" to proposal.segmentSupport,
                "shaftVariation" to proposal.shaftVariation,
                "shaftContinuity" to proposal.shaftContinuity,
                "mergeReason" to proposal.physicalMergeReason
            )
        )
        // Rejected tracks need endpoint evidence too. These are geometric role
        // hypotheses, not SKU anchors that have passed recognition.
        if (proposal.hasResolvedAxis) capturePreIdentityAnchors(session, scene, proposal)
    }

    private fun capturePreIdentityAnchors(session: String, scene: Bitmap, proposal: ScanProposal) {
        val context = appContext ?: return
        val fields = mapOf<String, Any?>(
            "session" to session, "artifactType" to "PRE_IDENTITY_ANCHORS",
            "proposalId" to proposal.proposalId, "physicalObjectId" to proposal.physicalObjectId,
            "stage" to "PRE_IDENTITY", "authenticity" to proposal.rodAuthenticityState
        )
        val owned = SmartVisualScanner.crop(scene, proposal.copy(proposalType = ScanProposal.TYPE_LONG)) ?: run {
            recordFailure(fields, IllegalStateException("Oriented track crop unavailable")); return
        }
        enqueueTask(fields, onRejected = { if (!owned.isRecycled) owned.recycle() }) {
            try {
                val anchors = RodAnchorExtractor.extract(owned) ?: error("Track anchors unavailable")
                try {
                    val dir = sessionDir(context, session)
                    val prefix = safeName(proposal.physicalObjectId.ifBlank { proposal.proposalId })
                    val handle = File(dir, "anchors/${prefix}_pre_handle.jpg")
                    val side = File(dir, "anchors/${prefix}_pre_side.jpg")
                    val tip = File(dir, "anchors/${prefix}_pre_tip.jpg")
                    writeJpeg(anchors.handle, handle)
                    writeJpeg(anchors.side, side)
                    if (proposal.rodTipVisible) writeJpeg(anchors.tip, tip)
                    appendManifest(dir, fields + mapOf(
                        "type" to "PRE_IDENTITY_ANCHORS",
                        "roleAssignment" to if (anchors.physicalHandleOnLeft != null) "PHYSICAL_BIDIRECTIONAL_ENDPOINT" else "GEOMETRIC_HYPOTHESIS_NOT_IDENTITY",
                        "handleOnLeft" to anchors.handleOnLeft,
                        "physicalHandleOnLeft" to anchors.physicalHandleOnLeft,
                        "anchorEndpointLeftScore" to anchors.endpointLeftScore,
                        "anchorEndpointRightScore" to anchors.endpointRightScore,
                        "anchorRoleMargin" to anchors.roleMargin,
                        "anchorRoleConfidence" to anchors.roleConfidence,
                        "anchorRoleState" to anchors.roleState,
                        "handle" to relativeEvidencePath(handle), "side" to relativeEvidencePath(side),
                        "tip" to if (proposal.rodTipVisible) relativeEvidencePath(tip) else "",
                        "tipStatus" to if (proposal.rodTipVisible) "VISIBLE_ENDPOINT_HYPOTHESIS" else "NOT_VISIBLE",
                        "recognitionAccepted" to false, "quantityAccepted" to false
                    ))
                } finally { anchors.recycle() }
            } finally { if (!owned.isRecycled) owned.recycle() }
        }
    }

    /** Draws all audited physical tracks over the exact scanner analysis scene. */
    fun captureTrackOverlay(session: String, scene: Bitmap) {
        val context = appContext ?: return
        if (session.isBlank()) return
        val tracks = trackSnapshots[session]?.let { list -> synchronized(list) { list.toList() } }.orEmpty()
        if (tracks.isEmpty()) return
        val sourceW = scene.width.coerceAtLeast(1)
        val sourceH = scene.height.coerceAtLeast(1)
        val owned = snapshotBitmap(scene, mutable = true) ?: run {
            recordFailure(mapOf("session" to session, "artifactType" to "PHYSICAL_TRACK_OVERLAY", "stage" to "SNAPSHOT"), IllegalStateException("Overlay bitmap unavailable")); return
        }
        val target = File(sessionDir(context, session), "overlay/physical_track_overlay.jpg")
        enqueueTask(errorContext = mapOf("session" to session, "artifactType" to "PHYSICAL_TRACK_OVERLAY"), onRejected = { if (!owned.isRecycled) owned.recycle() }) {
            try {
                val canvas = Canvas(owned)
                val sx = owned.width.toFloat() / sourceW.toFloat()
                val sy = owned.height.toFloat() / sourceH.toFloat()
                val box = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = max(3f, owned.width / 300f)
                    color = Color.YELLOW
                }
                val axis = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = max(2f, owned.width / 420f)
                    color = Color.CYAN
                }
                val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.FILL
                    textSize = max(18f, owned.width / 42f)
                    color = Color.WHITE
                    setShadowLayer(3f, 1f, 1f, Color.BLACK)
                }
                tracks.forEachIndexed { i, t ->
                    val r = Rect(
                        (t.bounds.left * sx).toInt(), (t.bounds.top * sy).toInt(),
                        (t.bounds.right * sx).toInt(), (t.bounds.bottom * sy).toInt()
                    )
                    canvas.drawRect(r, box)
                    if (t.axisStartX != t.axisEndX || t.axisStartY != t.axisEndY) {
                        canvas.drawLine(t.axisStartX * sx, t.axisStartY * sy, t.axisEndX * sx, t.axisEndY * sy, axis)
                    }
                    val label = "${t.physicalObjectId.ifBlank { t.proposalId }} • ${t.authenticityState} • Q=${if (t.quantityEligible) 1 else 0}"
                    canvas.drawText(label, r.left.coerceAtLeast(4).toFloat(), (r.top - 8).coerceAtLeast((i + 1) * 24).toFloat(), text)
                }
                writeJpeg(owned, target)
                appendManifest(sessionDir(context, session), mapOf(
                    "type" to "PHYSICAL_TRACK_OVERLAY", "session" to session,
                    "trackCount" to tracks.size, "file" to relativeEvidencePath(target)
                ))
            } finally {
                if (!owned.isRecycled) owned.recycle()
            }
        }
    }

    /**
     * Final pipeline hook used by ProductionRepository after track resolution.
     * Physical overlay pixels come from the pre-pruning audited tracks, while
     * the final proposal set is also persisted as structured evidence.
     */
    fun recordTrackOverlay(session: String, scene: Bitmap, proposals: List<ScanProposal>) {
        val context = appContext ?: return
        if (session.isBlank()) return
        val dir = sessionDir(context, session)
        proposals.forEachIndexed { index, proposal ->
            appendManifest(dir, mapOf(
                "type" to "FINAL_PROPOSAL",
                "session" to session,
                "index" to index + 1,
                "proposalId" to proposal.proposalId,
                "physicalObjectId" to proposal.physicalObjectId,
                "canonicalPhysicalObjectId" to proposal.canonicalPhysicalObjectId,
                "physicalInstanceHint" to proposal.physicalInstanceHint,
                "proposalType" to proposal.proposalType,
                "source" to proposal.source,
                "quantityEligible" to proposal.quantityEligible,
                "normalCompletenessScore" to proposal.normalCompletenessScore,
                "normalCompletenessState" to proposal.normalCompletenessState,
                "normalCompletenessReason" to proposal.normalCompletenessReason,
                "normalFragmentState" to proposal.normalFragmentState,
                "elongatedAmbiguous" to proposal.elongatedAmbiguous,
                "elongatedAmbiguousReason" to proposal.elongatedAmbiguousReason,
                "rodClaim" to proposal.rodClaim,
                "rodAuthenticityState" to proposal.rodAuthenticityState,
                "visualOnlyBlocked" to proposal.visualOnlyBlocked,
                "bounds" to "${proposal.normalizedBounds.left},${proposal.normalizedBounds.top},${proposal.normalizedBounds.right},${proposal.normalizedBounds.bottom}",
                "axis" to "${proposal.axisStartX},${proposal.axisStartY},${proposal.axisEndX},${proposal.axisEndY}"
            ))
        }
        captureFinalProposalOverlay(session, scene, proposals)
        captureTrackOverlay(session, scene)
    }

    /** Final overlay also covers NORMAL-only scenes and visual-only firewall state. */
    private fun captureFinalProposalOverlay(session: String, scene: Bitmap, proposals: List<ScanProposal>) {
        val context = appContext ?: return
        if (session.isBlank() || proposals.isEmpty()) return
        val sourceW = scene.width.coerceAtLeast(1)
        val sourceH = scene.height.coerceAtLeast(1)
        val owned = snapshotBitmap(scene, mutable = true) ?: run {
            recordFailure(mapOf("session" to session, "artifactType" to "FINAL_PROPOSAL_OVERLAY", "stage" to "SNAPSHOT"), IllegalStateException("Overlay bitmap unavailable")); return
        }
        val target = File(sessionDir(context, session), "overlay/final_proposal_overlay.jpg")
        enqueueTask(errorContext = mapOf("session" to session, "artifactType" to "FINAL_PROPOSAL_OVERLAY"), onRejected = { if (!owned.isRecycled) owned.recycle() }) {
            try {
                val canvas = Canvas(owned)
                val sx = owned.width.toFloat() / sourceW.toFloat()
                val sy = owned.height.toFloat() / sourceH.toFloat()
                val box = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = max(3f, owned.width / 300f)
                }
                val axis = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = max(2f, owned.width / 420f)
                }
                val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.FILL
                    textSize = max(18f, owned.width / 44f)
                    color = Color.WHITE
                    setShadowLayer(3f, 1f, 1f, Color.BLACK)
                }
                proposals.forEachIndexed { i, proposal ->
                    val color = when {
                        proposal.visualOnlyBlocked -> Color.MAGENTA
                        proposal.bridgeSuppressed || proposal.proposalType == ScanProposal.TYPE_AMBIGUOUS_CONTAINER -> Color.RED
                        proposal.trustedRod -> Color.GREEN
                        proposal.rodClaim -> Color.YELLOW
                        proposal.proposalType == ScanProposal.TYPE_NORMAL -> Color.CYAN
                        else -> Color.WHITE
                    }
                    box.color = color
                    axis.color = color
                    val b = proposal.normalizedBounds
                    val r = Rect(
                        (b.left * sx).toInt(), (b.top * sy).toInt(),
                        (b.right * sx).toInt(), (b.bottom * sy).toInt()
                    )
                    canvas.drawRect(r, box)
                    if (proposal.hasResolvedAxis) {
                        canvas.drawLine(
                            proposal.axisStartX * sx, proposal.axisStartY * sy,
                            proposal.axisEndX * sx, proposal.axisEndY * sy, axis
                        )
                    }
                    val id = proposal.physicalObjectId.ifBlank { proposal.physicalInstanceHint.ifBlank { proposal.proposalId } }
                    val gate = when {
                        proposal.visualOnlyBlocked -> "VISUAL_BLOCKED"
                        !proposal.quantityEligible -> "Q0"
                        else -> "Q1"
                    }
                    canvas.drawText(
                        "$id • ${proposal.proposalType} • $gate",
                        r.left.coerceAtLeast(4).toFloat(),
                        (r.top - 8).coerceAtLeast((i + 1) * 24).toFloat(),
                        text
                    )
                }
                writeJpeg(owned, target)
                appendManifest(sessionDir(context, session), mapOf(
                    "type" to "FINAL_PROPOSAL_OVERLAY",
                    "session" to session,
                    "proposalCount" to proposals.size,
                    "file" to relativeEvidencePath(target)
                ))
            } finally {
                if (!owned.isRecycled) owned.recycle()
            }
        }
    }

    /** Binds a recognition decision to the exact object crop and rod anchors. */
    fun captureDecision(
        session: String,
        objectIndex: Int,
        proposal: ScanProposal,
        crop: Bitmap,
        decisionRuleId: String,
        candidate: String,
        visualScore: Int,
        finalScore: Int,
        margin: Int,
        anchorScore: Int,
        anchorMargin: Int,
        recognitionAccepted: Boolean,
        quantityAccepted: Boolean
    ) {
        val context = appContext ?: return
        if (session.isBlank() || objectIndex !in 1..MAX_OBJECT_EVIDENCE) return
        val owned = snapshotBitmap(crop) ?: run {
            recordFailure(mapOf("session" to session, "artifactType" to "DECISION_OBJECT", "proposalId" to proposal.proposalId, "physicalObjectId" to proposal.physicalObjectId, "stage" to "SNAPSHOT"), IllegalStateException("Decision bitmap unavailable")); return
        }
        val dir = sessionDir(context, session)
        val prefix = "obj${objectIndex}_${safeName(proposal.proposalId)}_${safeName(decisionRuleId)}"
        val objectFile = File(dir, "objects/$prefix.jpg")
        enqueueTask(
            errorContext = mapOf(
                "session" to session,
                "artifactType" to "DECISION_OBJECT",
                "proposalId" to proposal.proposalId,
                "physicalObjectId" to proposal.physicalObjectId,
                "decisionRuleId" to decisionRuleId
            ),
            onRejected = { if (!owned.isRecycled) owned.recycle() }
        ) {
            try {
                writeJpeg(owned, objectFile)
                val common = linkedMapOf<String, Any?>(
                    "session" to session, "object" to objectIndex,
                    "proposalId" to proposal.proposalId,
                    "physicalObjectId" to proposal.physicalObjectId,
                    "proposalType" to proposal.proposalType,
                    "decisionRuleId" to decisionRuleId,
                    "candidate" to candidate,
                    "visual" to visualScore, "final" to finalScore,
                    "margin" to margin, "anchor" to anchorScore,
                    "anchorMargin" to anchorMargin,
                    "recognitionAccepted" to recognitionAccepted,
                    "quantityAccepted" to quantityAccepted,
                    "file" to relativeEvidencePath(objectFile)
                )
                appendManifest(dir, common + mapOf("type" to "DECISION_OBJECT"))
                if (proposal.proposalType == ScanProposal.TYPE_LONG) {
                    RodAnchorExtractor.extract(owned, proposal.anchorHandleOnLeft)?.let { anchors ->
                        try {
                            val anchorDir = File(dir, "anchors").apply { mkdirs() }
                            val handle = File(anchorDir, "${prefix}_handle.jpg")
                            val side = File(anchorDir, "${prefix}_side.jpg")
                            val tip = File(anchorDir, "${prefix}_tip.jpg")
                            writeJpeg(anchors.handle, handle)
                            writeJpeg(anchors.side, side)
                            if (proposal.rodTipVisible) writeJpeg(anchors.tip, tip)
                            appendManifest(dir, common + mapOf(
                                "type" to "ROD_ANCHORS",
                                "roleAssignment" to if (proposal.anchorHandleOnLeft != null) "CANDIDATE_SCORING_ASSIGNMENT" else "GEOMETRIC_HYPOTHESIS_NOT_IDENTITY",
                                "handle" to relativeEvidencePath(handle),
                                "side" to relativeEvidencePath(side),
                                "tip" to if (proposal.rodTipVisible) relativeEvidencePath(tip) else "",
                                "tipStatus" to if (proposal.rodTipVisible) "VISIBLE_ENDPOINT_HYPOTHESIS" else "NOT_VISIBLE",
                                "handleOnLeft" to anchors.handleOnLeft,
                                "physicalHandleOnLeft" to anchors.physicalHandleOnLeft,
                                "anchorEndpointLeftScore" to anchors.endpointLeftScore,
                                "anchorEndpointRightScore" to anchors.endpointRightScore,
                                "anchorRoleMargin" to anchors.roleMargin,
                                "anchorRoleConfidence" to anchors.roleConfidence,
                                "anchorRoleState" to anchors.roleState
                            ))
                        } finally { anchors.recycle() }
                    }
                }
            } finally { if (!owned.isRecycled) owned.recycle() }
        }
    }

    /**
     * Rich decision hook. Image/anchor capture remains delegated to the bounded
     * async capture path; textual OCR/barcode/candidate context is persisted in
     * the same session manifest for 1:1 evidence-to-log correlation.
     */
    fun recordDecision(
        session: String,
        objectIndex: Int,
        proposal: ScanProposal,
        crop: Bitmap,
        decisionRuleId: String,
        decisionReason: String = "",
        candidate: String,
        secondCandidate: String = "",
        visualScore: Int,
        finalScore: Int,
        margin: Int,
        anchorScore: Int,
        anchorMargin: Int,
        recognitionAccepted: Boolean,
        quantityAccepted: Boolean,
        barcode: String = "",
        ocrText: String = ""
    ) {
        captureDecision(
            session = session,
            objectIndex = objectIndex,
            proposal = proposal,
            crop = crop,
            decisionRuleId = decisionRuleId,
            candidate = candidate,
            visualScore = visualScore,
            finalScore = finalScore,
            margin = margin,
            anchorScore = anchorScore,
            anchorMargin = anchorMargin,
            recognitionAccepted = recognitionAccepted,
            quantityAccepted = quantityAccepted
        )
        val context = appContext ?: return
        if (session.isBlank()) return
        appendManifest(sessionDir(context, session), mapOf(
            "type" to "DECISION_CONTEXT",
            "session" to session,
            "object" to objectIndex,
            "proposalId" to proposal.proposalId,
            "physicalObjectId" to proposal.physicalObjectId,
            "canonicalPhysicalObjectId" to proposal.canonicalPhysicalObjectId,
            "trackId" to proposal.physicalObjectId.ifBlank { proposal.physicalInstanceHint },
            "decisionRuleId" to decisionRuleId,
            "decisionReason" to decisionReason,
            "candidate" to candidate,
            "secondCandidate" to secondCandidate,
            "visual" to visualScore,
            "final" to finalScore,
            "margin" to margin,
            "anchor" to anchorScore,
            "anchorMargin" to anchorMargin,
            "anchorHandleOnLeft" to proposal.anchorHandleOnLeft,
            "anchorEndpointLeftScore" to proposal.anchorEndpointLeftScore,
            "anchorEndpointRightScore" to proposal.anchorEndpointRightScore,
            "anchorRoleMargin" to proposal.anchorRoleMargin,
            "anchorRoleConfidence" to proposal.anchorRoleConfidence,
            "anchorRoleState" to proposal.anchorRoleState,
            "normalPurityScore" to proposal.normalPurityScore,
            "normalPurityState" to proposal.normalPurityState,
            "normalPurityReason" to proposal.normalPurityReason,
            "normalCropAreaRatio" to proposal.normalCropAreaRatio,
            "normalOwnerAreaRatio" to proposal.normalOwnerAreaRatio,
            "normalCompletenessScore" to proposal.normalCompletenessScore,
            "normalCompletenessState" to proposal.normalCompletenessState,
            "normalCompletenessReason" to proposal.normalCompletenessReason,
            "normalFragmentState" to proposal.normalFragmentState,
            "elongatedAmbiguous" to proposal.elongatedAmbiguous,
            "elongatedAmbiguousReason" to proposal.elongatedAmbiguousReason,
            "physicalOwnershipState" to proposal.physicalOwnershipState,
            "physicalOwnershipOwnerId" to proposal.physicalOwnershipOwnerId,
            "packageEdgeScore" to proposal.packageEdgeScore,
            "rodTipVisible" to proposal.rodTipVisible,
            "foregroundSupported" to proposal.foregroundSupported,
            "foregroundReason" to proposal.foregroundReason,
            "recognitionAccepted" to recognitionAccepted,
            "quantityAccepted" to quantityAccepted,
            "barcode" to barcode,
            "ocr" to ocrText.take(220)
        ))
    }

    /** Bind one final scan object to its persistent live temporal track. */
    fun recordPersistentBinding(
        session: String,
        objectIndex: Int,
        physicalObjectId: String,
        persistentPhysicalId: String,
        normalizedIou: Float
    ) {
        val context = appContext ?: return
        if (session.isBlank() || persistentPhysicalId.isBlank()) return
        appendManifest(sessionDir(context, session), mapOf(
            "type" to "PERSISTENT_PHYSICAL_BINDING",
            "session" to session,
            "object" to objectIndex,
            "physicalObjectId" to physicalObjectId,
            "persistentPhysicalId" to persistentPhysicalId,
            "normalizedIou" to normalizedIou
        ))
    }

    /**
     * V8.8.1 privacy-bounded catalog snapshot. This proves which product masters
     * and visual references were actually available to the scanner for a session.
     * Prices, stock, payment data, customer data and secrets are intentionally
     * excluded. Reference SHA-256 is computed asynchronously and never affects
     * the recognition critical path.
     */
    fun recordCatalogSnapshot(
        session: String,
        products: List<ProductEntity>,
        photos: List<ProductPhotoEntity>,
        selectedReferenceIds: Set<Long>,
        identityProfiles: Map<Long, ProductIdentityProfile>,
        verifiedProductIds: Set<Long>
    ) {
        val context = appContext ?: return
        if (session.isBlank()) return
        val productsSnapshot = products.map { it.copy() }
        val photosSnapshot = photos.map { it.copy() }
        val profilesSnapshot = identityProfiles.toMap()
        val verifiedSnapshot = verifiedProductIds.toSet()
        val selectedSnapshot = selectedReferenceIds.toSet()
        val fields = mapOf<String, Any?>(
            "session" to session,
            "artifactType" to "CATALOG_SNAPSHOT",
            "products" to productsSnapshot.size,
            "references" to photosSnapshot.size
        )
        enqueueTask(fields) {
            val dir = sessionDir(context, session).apply { mkdirs() }
            val refsByProduct = photosSnapshot.groupBy { it.productId }
            val productArray = JSONArray()
            productsSnapshot.sortedBy { it.id }.forEach { product ->
                val profile = profilesSnapshot[product.id]
                val refs = refsByProduct[product.id].orEmpty().sortedBy { it.id }
                val refArray = JSONArray()
                refs.forEach { photo ->
                    val file = File(photo.localPath)
                    refArray.put(JSONObject().apply {
                        put("referenceId", photo.id)
                        put("captureAngle", photo.captureAngle)
                        put("isPrimary", photo.isPrimary)
                        put("selectedForRecognition", photo.id in selectedSnapshot)
                        put("fileName", file.name)
                        put("fileExists", file.isFile)
                        put("fileBytes", if (file.isFile) file.length() else 0L)
                        put("referenceSha256", if (file.isFile && photo.id in selectedSnapshot) sha256(file) else "")
                    })
                }
                productArray.put(JSONObject().apply {
                    put("productId", product.id)
                    put("sku", product.sku)
                    put("name", product.name)
                    put("category", product.category)
                    put("brand", product.brand ?: "")
                    put("variant", product.variant ?: "")
                    put("active", product.active)
                    put("recognitionMode", profile?.recognitionMode ?: "HYBRID")
                    put("isLongObject", profile?.isLongObject ?: false)
                    put("verifiedMaster", product.id in verifiedSnapshot)
                    put("referenceCount", refs.size)
                    put("selectedReferenceCount", refs.count { it.id in selectedSnapshot })
                    put("references", refArray)
                })
            }
            val snapshot = JSONObject().apply {
                put("sessionId", session)
                put("phase", ArsV850Config.PHASE)
                put("engine", ArsV850Config.ENGINE)
                put("version", ArsV850Config.VERSION_NAME)
                put("versionCode", ArsV850Config.VERSION_CODE)
                put("createdAt", System.currentTimeMillis())
                put("privacy", "NO_PRICE_NO_STOCK_NO_PAYMENT_NO_CUSTOMER")
                put("productCount", productsSnapshot.size)
                put("referenceCount", photosSnapshot.size)
                put("selectedReferenceCount", selectedSnapshot.size)
                put("products", productArray)
            }
            File(dir, "catalog_snapshot.json").writeText(snapshot.toString(2))
            appendManifest(dir, fields + mapOf(
                "type" to "CATALOG_SNAPSHOT",
                "file" to "catalog_snapshot.json",
                "selectedReferences" to selectedSnapshot.size
            ))
        }
    }

    /**
     * Human ground-truth annotation used only for engineering evaluation.
     * verdict examples: CORRECT, WRONG_SKU, REAL_OBJECT_UNRECOGNIZED,
     * FALSE_OBJECT, MISSED_OBJECT. It never changes the product database or cart.
     */
    fun recordGroundTruth(
        session: String,
        objectIndex: Int? = null,
        physicalObjectId: String = "",
        persistentPhysicalId: String = "",
        verdict: String,
        predictedProductId: Long? = null,
        predictedProductName: String = "",
        note: String = ""
    ) {
        val context = appContext ?: return
        if (session.isBlank() || verdict.isBlank()) return
        val dir = sessionDir(context, session).apply { mkdirs() }
        val obj = JSONObject().apply {
            put("ts", System.currentTimeMillis())
            put("sessionId", session)
            put("objectIndex", objectIndex ?: JSONObject.NULL)
            put("physicalObjectId", physicalObjectId)
            put("persistentPhysicalId", persistentPhysicalId)
            put("verdict", verdict)
            put("predictedProductId", predictedProductId ?: JSONObject.NULL)
            put("predictedProductName", predictedProductName)
            put("note", note)
            put("phase", ArsV850Config.PHASE)
            put("engine", ArsV850Config.ENGINE)
        }
        synchronized(manifestLock) {
            File(dir, "ground_truth.jsonl").appendText(obj.toString() + "\n")
            appendManifest(dir, mapOf(
                "type" to "GROUND_TRUTH",
                "session" to session,
                "object" to objectIndex,
                "physicalObjectId" to physicalObjectId,
                "persistentPhysicalId" to persistentPhysicalId,
                "verdict" to verdict,
                "predictedProductId" to predictedProductId,
                "predictedProductName" to predictedProductName
            ))
        }
        ArsFlightRecorder.event(
            "SCAN_GROUND_TRUTH",
            "Human ground truth recorded",
            mapOf(
                "session" to session,
                "object" to objectIndex,
                "physicalObjectId" to physicalObjectId,
                "persistentPhysicalId" to persistentPhysicalId,
                "verdict" to verdict,
                "predictedProductId" to predictedProductId,
                "predictedProductName" to predictedProductName
            )
        )
    }

    fun completeSession(session: String, objects: Int, recognized: Int, durationMs: Long, status: String = "COMPLETE") {
        val context = appContext ?: return
        if (session.isBlank()) return
        val dir = sessionDir(context, session).apply { mkdirs() }
        fun finish(forcedPartial: Boolean = false) {
            val failures = sessionFailures[session]?.get() ?: 0
            val evidenceStatus = if (forcedPartial || failures > 0) "PARTIAL" else "COMPLETE"
            val completion = JSONObject().apply {
                put("sessionId", session); put("status", if (status == "COMPLETE") evidenceStatus else status)
                put("scanStatus", status); put("evidenceStatus", evidenceStatus); put("evidenceFailures", failures)
                put("objects", objects); put("recognized", recognized)
                put("durationMs", durationMs); put("completedAt", System.currentTimeMillis())
            }
            File(dir, "completion.json").writeText(completion.toString(2))
            val sessionMetaFile = File(dir, "session.json")
            val finalSessionMeta = runCatching { JSONObject(sessionMetaFile.readText()) }.getOrElse { JSONObject() }.apply {
                put("sessionId", session)
                put("scanId", session)
                put("phase", ArsV850Config.PHASE)
                put("engine", ArsV850Config.ENGINE)
                put("status", if (status == "COMPLETE") evidenceStatus else status)
                put("scanStatus", status)
                put("evidenceStatus", evidenceStatus)
                put("evidenceFailures", failures)
                put("completedAt", System.currentTimeMillis())
            }
            sessionMetaFile.writeText(finalSessionMeta.toString(2))
            val replayManifest = JSONObject().apply {
                put("sessionId", session)
                put("phase", ArsV850Config.PHASE)
                put("engine", ArsV850Config.ENGINE)
                put("input", "replay/analysis_replay.png")
                val replayInput = File(dir, "replay/analysis_replay.png")
                put("inputSha256", if (replayInput.exists()) sha256(replayInput) else "")
                put("objects", objects)
                put("recognized", recognized)
                put("scanStatus", status)
                put("evidenceStatus", evidenceStatus)
                put("status", if (status == "COMPLETE") evidenceStatus else status)
                put("purpose", "DETERMINISTIC_ENGINE_REGRESSION_INPUT_V4")
                put("identityThresholdsRelaxed", false)
                put("persistentBindingStage", "PRE_IDENTITY_SCORING")
                put("sourceVersion", "${ArsV850Config.VERSION_NAME} (${ArsV850Config.VERSION_CODE})")
                put("releaseRevision", ArsV850Config.RELEASE_REVISION)
            }
            File(dir, "replay_manifest.json").writeText(replayManifest.toString(2))
            if (status != "COMPLETE" || recognized < objects) {
                val failure = JSONObject().apply {
                    put("sessionId", session)
                    put("status", status)
                    put("objects", objects)
                    put("recognized", recognized)
                    put("unrecognized", (objects - recognized).coerceAtLeast(0))
                    put("replayInput", "replay/analysis_replay.png")
                    put("groundTruthFile", "ground_truth.jsonl")
                    put("purpose", "SMART_FAILURE_EVIDENCE")
                }
                File(dir, "failure_summary.json").writeText(failure.toString(2))
            }
            dir.setLastModified(System.currentTimeMillis())
            trackSnapshots.remove(session)
            prune(context)
            ArsFlightRecorder.event("EVIDENCE_SESSION_COMPLETE", "Visual evidence session closed", mapOf(
                "session" to session, "status" to completion.getString("status"),
                "scanStatus" to status, "evidenceStatus" to evidenceStatus, "evidenceFailures" to failures,
                "objects" to objects, "recognized" to recognized, "durationMs" to durationMs, "bytes" to directoryBytes(dir)
            ))
        }
        // FIFO completion occurs AFTER all images submitted by this scan.
        // Never report evidence COMPLETE merely because recognition completed.
        enqueueTask(mapOf("session" to session, "artifactType" to "COMPLETION", "stage" to "WRITE"),
            onRejected = { runCatching { finish(true) } }, block = { finish() })
    }

    fun summary(context: Context): Summary {
        install(context)
        val root = File(context.filesDir, ROOT)
        val sessions = root.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.lastModified() }.orEmpty()
        return Summary(
            sessions.size,
            sessions.sumOf { countFiles(it) },
            sessions.sumOf { directoryBytes(it) },
            sessions.firstOrNull()?.name.orEmpty()
        )
    }

    /**
     * V8.8.6 one-tap diagnostic bundle.
     *
     * Finalizes the optional MediaProjection screen video, tolerates partial
     * recorder/evidence failure, snapshots the current flight log, extracts
     * scanner/performance/bookmark streams, copies replay/ground-truth visual
     * evidence, generates keyframes and writes a SHA-256 integrity manifest.
     */
    fun buildDiagnosticPackage(context: Context, report: String): File {
        install(context)
        val videoArtifact = ArsDiagnosticScreenRecorder.stopAndFinalizeForExport(context, 4_500L)
        val evidenceFlushed = flushPending(4_000L)
        if (!evidenceFlushed) {
            ArsFlightRecorder.event(
                "EVIDENCE_EXPORT_PARTIAL",
                "Evidence queue did not fully drain before one-tap export",
                mapOf("pending" to executor.queue.size, "active" to executor.activeCount)
            )
        }

        val exportDir = File(context.cacheDir, EXPORT_DIR).apply { mkdirs() }
        exportDir.listFiles()?.filter { it.extension.equals("zip", true) }
            ?.sortedByDescending { it.lastModified() }?.drop(2)?.forEach { runCatching { it.delete() } }

        val createdAt = System.currentTimeMillis()
        val stage = File(exportDir, "stage_${createdAt}").apply {
            deleteRecursively()
            mkdirs()
        }
        val out = File(exportDir, "ARS_DIAGNOSTIC_${ArsV850Config.ENGINE.replace(".", "_")}_${createdAt}.zip")

        try {
            val finalReport = redactDiagnosticText(ArsFlightRecorder.buildReport(context).ifBlank { report })
            writeStageText(stage, "report/diagnostic_report.txt", finalReport)
            writeStageText(
                stage,
                "report/diagnostic_report.json",
                JSONObject().apply {
                    put("phase", ArsV850Config.PHASE)
                    put("engine", ArsV850Config.ENGINE)
                    put("revision", ArsV850Config.RELEASE_REVISION)
                    put("version", ArsV850Config.VERSION_NAME)
                    put("versionCode", ArsV850Config.VERSION_CODE)
                    put("generatedAt", createdAt)
                    put("report", finalReport)
                }.toString(2)
            )

            val flightLog = File(File(context.filesDir, "ars_diagnostics"), "flight_recorder.jsonl")
            val safeFlightText = if (flightLog.exists()) redactDiagnosticText(flightLog.readText()) else ""
            val coveredSessionIds = diagnosticSessionIds(
                safeFlightText,
                videoArtifact.startedAtMs,
                videoArtifact.finishedAtMs.takeIf { it > 0L } ?: createdAt
            )
            if (safeFlightText.isNotBlank()) {
                writeStageText(stage, "logs/flight_recorder.jsonl", safeFlightText)
                writeStageText(stage, "scanner/events.jsonl", filterDiagnosticEvents(safeFlightText) { type ->
                    type.startsWith("SCAN_") || type.startsWith("LIVE_") || type.startsWith("EVIDENCE_")
                })
                writeStageText(stage, "performance/events.jsonl", filterDiagnosticEvents(safeFlightText) { type ->
                    type.contains("MEMORY") || type.contains("SCORING") || type.contains("LATENCY") ||
                        type == "SCAN_COMPLETE" || type == "LIVE_SCENE_UPDATE"
                })
                writeStageText(
                    stage,
                    "bookmarks/automatic_failure_bookmarks.jsonl",
                    buildDiagnosticBookmarks(safeFlightText, videoArtifact.startedAtMs)
                )
            }

            val root = File(context.filesDir, ROOT)
            root.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.lastModified() }
                ?.take(MAX_SESSIONS)?.forEach { source ->
                    val destination = File(stage, "evidence/${source.name}")
                    source.copyRecursively(destination, overwrite = true)
                }

            // Top-level keyframes make video/log review faster while the canonical
            // originals remain under evidence/<session>/... for replay integrity.
            val keyframeCandidates = root.walkTopDown()
                .filter { it.isFile && it.extension.lowercase() in setOf("jpg", "jpeg", "png") }
                .sortedByDescending { it.lastModified() }
                .take(12)
                .toList()
            keyframeCandidates.forEachIndexed { index, source ->
                val ext = source.extension.lowercase().ifBlank { "jpg" }
                val safeBase = safeName(source.nameWithoutExtension).take(48)
                val target = File(stage, "screenshots/keyframe_${(index + 1).toString().padStart(2, '0')}_${safeBase}.$ext")
                target.parentFile?.mkdirs()
                runCatching { source.copyTo(target, overwrite = true) }
            }

            val videoMetadata = JSONObject(ArsDiagnosticScreenRecorder.metadataJson(videoArtifact)).apply {
                put("coveredSessionIds", JSONArray(coveredSessionIds))
                put("sessionBindingMode", "TIMESTAMP_CORRELATED")
            }
            writeStageText(stage, "screen_recording/metadata.json", videoMetadata.toString(2))
            if (videoArtifact.status == ArsDiagnosticScreenRecorder.STATUS_RECORDED && videoArtifact.file != null) {
                val target = File(stage, "screen_recording/${videoArtifact.file.name}")
                target.parentFile?.mkdirs()
                videoArtifact.file.copyTo(target, overwrite = true)
            }

            val packageInfo = JSONObject().apply {
                put("phase", ArsV850Config.PHASE)
                put("engine", ArsV850Config.ENGINE)
                put("revision", ArsV850Config.RELEASE_REVISION)
                put("version", ArsV850Config.VERSION_NAME)
                put("versionCode", ArsV850Config.VERSION_CODE)
                put("package", context.packageName)
                put("createdAt", createdAt)
                put("bundleMode", "ONE_TAP_CHATGPT_EVIDENCE")
                put("description", "Log + capture/keyframes + optional screen video + scanner telemetry + decision evidence + ground truth + replay + integrity")
                put("evidenceFlushComplete", evidenceFlushed)
                put("screenRecordingStatus", videoArtifact.status)
                put("screenRecordingReason", videoArtifact.reason)
                put("coveredSessionIds", JSONArray(coveredSessionIds))
                put("partialFailureTolerant", true)
                put("secretsRedacted", true)
                put("retentionSessions", MAX_SESSIONS)
                put("retentionBytes", MAX_TOTAL_BYTES)
            }
            writeStageText(stage, "package_manifest.json", packageInfo.toString(2))
            writeStageText(stage, "package_info.json", packageInfo.toString(2))

            writeIntegrityManifest(stage)
            ZipOutputStream(FileOutputStream(out)).use { zip -> addDirectoryRoot(zip, stage) }
            check(out.exists() && out.length() > 0L) { "Diagnostic ZIP kosong" }
            ArsDiagnosticScreenRecorder.markExported(context, videoArtifact)

            ArsFlightRecorder.event(
                "EVIDENCE_EXPORT",
                "One-tap diagnostic report + log + capture + screen video + evidence ZIP exported",
                mapOf(
                    "file" to out.name,
                    "bytes" to out.length(),
                    "videoStatus" to videoArtifact.status,
                    "keyframes" to keyframeCandidates.size,
                    "evidenceFlushComplete" to evidenceFlushed
                )
            )
            return out
        } finally {
            runCatching { stage.deleteRecursively() }
        }
    }

    /** Lightweight cashier-facing report: report + flight log + only the selected scan session. */
    fun buildSessionDiagnosticPackage(context: Context, report: String, session: String): File {
        install(context)
        require(session.isNotBlank()) { "sessionId kosong" }
        check(flushPending(4_000L)) { "Gambar diagnostik masih diproses. Coba ekspor ulang sebentar lagi." }
        val focusDir = sessionDir(context, session)
        require(focusDir.exists()) { "Evidence session tidak ditemukan: $session" }
        val exportDir = File(context.cacheDir, EXPORT_DIR).apply { mkdirs() }
        val out = File(exportDir, "ARS_SCAN_REPORT_${ArsV850Config.ENGINE.replace(".", "_")}_${safeName(session)}_${System.currentTimeMillis()}.zip")
        ZipOutputStream(FileOutputStream(out)).use { zip ->
            addText(zip, "report.txt", report)
            val packageInfo = JSONObject().apply {
                put("phase", ArsV850Config.PHASE); put("engine", ArsV850Config.ENGINE)
                put("version", ArsV850Config.VERSION_NAME); put("versionCode", ArsV850Config.VERSION_CODE)
                put("package", context.packageName); put("createdAt", System.currentTimeMillis())
                put("focusSessionId", session)
                put("description", "Cashier visual scan report bound to one sessionId")
            }.toString(2)
            addText(zip, "package_manifest.json", packageInfo)
            val flightLog = File(File(context.filesDir, "ars_diagnostics"), "flight_recorder.jsonl")
            if (flightLog.exists()) addFile(zip, flightLog, "flight_recorder.jsonl")
            addDirectory(zip, focusDir, "evidence/${focusDir.name}")
        }
        ArsFlightRecorder.event(
            "SCAN_VISUAL_REPORT_EXPORT",
            "Focused visual scan report exported",
            mapOf("session" to session, "file" to out.name, "bytes" to out.length())
        )
        return out
    }

    fun exportPackage(context: Context): File? =
        runCatching { buildDiagnosticPackage(context, ArsFlightRecorder.buildReport(context)) }.getOrNull()

    fun clear(context: Context) {
        install(context)
        flushPending(2_000L)
        runCatching { File(context.filesDir, ROOT).deleteRecursively() }
        File(context.filesDir, ROOT).mkdirs()
        runCatching { File(context.cacheDir, EXPORT_DIR).deleteRecursively() }
        trackSnapshots.clear()
    }

    private fun enqueuePngSnapshot(source: Bitmap, target: File, manifest: Map<String, Any?>) {
        val owned = snapshotBitmap(source)
        if (owned == null) {
            recordFailure(manifest + mapOf("artifactType" to manifest["type"], "stage" to "SNAPSHOT"), IllegalStateException("Replay bitmap unavailable"))
            return
        }
        val context = appContext
        val errorContext = linkedMapOf<String, Any?>()
        manifest["session"]?.let { errorContext["session"] = it }
        errorContext["artifactType"] = manifest["type"] ?: "REPLAY_INPUT"
        enqueueTask(errorContext = errorContext, onRejected = { if (!owned.isRecycled) owned.recycle() }) {
            try {
                target.parentFile?.mkdirs()
                FileOutputStream(target).use { out -> check(owned.compress(Bitmap.CompressFormat.PNG, 100, out)) }
                val session = manifest["session"]?.toString().orEmpty()
                if (context != null && session.isNotBlank()) {
                    appendManifest(sessionDir(context, session), manifest + mapOf("file" to relativeEvidencePath(target)))
                }
            } finally { if (!owned.isRecycled) owned.recycle() }
        }
    }

    private fun enqueueBitmapSnapshot(source: Bitmap, target: File, manifest: Map<String, Any?>) {
        val owned = snapshotBitmap(source)
        if (owned == null) recordFailure(manifest + mapOf("artifactType" to manifest["type"], "stage" to "SNAPSHOT"), IllegalStateException("Evidence bitmap unavailable"))
        else enqueueOwnedBitmap(owned, target, manifest)
    }

    private fun enqueueOwnedBitmap(owned: Bitmap, target: File, manifest: Map<String, Any?>) {
        val context = appContext
        val errorContext = linkedMapOf<String, Any?>()
        manifest["session"]?.let { errorContext["session"] = it }
        errorContext["artifactType"] = manifest["type"] ?: "BITMAP_EVIDENCE"
        manifest["proposalId"]?.let { errorContext["proposalId"] = it }
        manifest["physicalObjectId"]?.let { errorContext["physicalObjectId"] = it }
        enqueueTask(errorContext = errorContext, onRejected = { if (!owned.isRecycled) owned.recycle() }) {
            try {
                writeJpeg(owned, target)
                val session = manifest["session"]?.toString().orEmpty()
                if (context != null && session.isNotBlank()) {
                    appendManifest(sessionDir(context, session), manifest + mapOf("file" to relativeEvidencePath(target)))
                }
            } finally { if (!owned.isRecycled) owned.recycle() }
        }
    }

    private fun writeStageText(stage: File, relative: String, value: String) {
        val target = File(stage, relative)
        target.parentFile?.mkdirs()
        target.writeText(value)
    }

    private fun redactDiagnosticText(raw: String): String {
        var out = raw
        out = Regex("sk-[A-Za-z0-9_-]{16,}").replace(out, "<REDACTED_OPENAI_KEY>")
        out = Regex("(?i)(authorization\\s*[:=]\\s*bearer\\s+)[^\\s\\\"']+").replace(out, "$1<REDACTED>")
        out = Regex("(?i)((?:api[_-]?key|gateway[_-]?token|access[_-]?token|password|secret)\\s*[=:]\\s*)[^\\s,;}]+")
            .replace(out, "$1<REDACTED>")
        out = Regex("(?i)(\\\"(?:api[_-]?key|gateway[_-]?token|access[_-]?token|password|secret)\\\"\\s*:\\s*\\\")[^\\\"]+")
            .replace(out, "$1<REDACTED>")
        return out
    }

    private fun filterDiagnosticEvents(raw: String, keep: (String) -> Boolean): String =
        raw.lineSequence().mapNotNull { line ->
            val obj = runCatching { JSONObject(line) }.getOrNull() ?: return@mapNotNull null
            if (keep(obj.optString("type"))) obj.toString() else null
        }.joinToString("\n").let { if (it.isBlank()) "" else "$it\n" }

    private fun diagnosticSessionIds(raw: String, startedAtMs: Long, finishedAtMs: Long): List<String> {
        if (raw.isBlank()) return emptyList()
        val sessions = LinkedHashSet<String>()
        raw.lineSequence().forEach { line ->
            val obj = runCatching { JSONObject(line) }.getOrNull() ?: return@forEach
            val ts = obj.optLong("ts", 0L)
            if (startedAtMs > 0L && ts > 0L && (ts < startedAtMs || ts > finishedAtMs)) return@forEach
            val session = obj.optString("session").ifBlank {
                obj.optJSONObject("data")?.optString("session").orEmpty()
            }
            if (session.isNotBlank()) sessions += session
        }
        return sessions.toList()
    }

    private fun buildDiagnosticBookmarks(raw: String, videoStartedAtMs: Long): String {
        val keywords = listOf(
            "LOCK", "TRACK", "CANDIDATE", "MATCH", "REJECT", "DUPLICATE", "TIMEOUT",
            "STALL", "ERROR", "FATAL", "SCAN_OBJECT", "SCAN_COMPLETE", "SCAN_AGGREGATION"
        )
        return raw.lineSequence().mapNotNull { line ->
            val obj = runCatching { JSONObject(line) }.getOrNull() ?: return@mapNotNull null
            val type = obj.optString("type")
            if (keywords.none { key -> type.contains(key) }) return@mapNotNull null
            if (videoStartedAtMs > 0L) {
                val eventTs = obj.optLong("ts", 0L)
                if (eventTs >= videoStartedAtMs) obj.put("videoTimestampMs", eventTs - videoStartedAtMs)
            }
            obj.toString()
        }.joinToString("\n").let { if (it.isBlank()) "" else "$it\n" }
    }

    private fun writeIntegrityManifest(stage: File) {
        val entries = JSONArray()
        stage.walkTopDown().filter { it.isFile }.sortedBy { it.relativeTo(stage).path }.forEach { file ->
            val relative = file.relativeTo(stage).path.replace(File.separatorChar, '/')
            if (relative == "integrity/sha256_manifest.json") return@forEach
            entries.put(JSONObject().apply {
                put("path", relative)
                put("bytes", file.length())
                put("sha256", sha256(file))
            })
        }
        val root = JSONObject().apply {
            put("algorithm", "SHA-256")
            put("createdAt", System.currentTimeMillis())
            put("entries", entries)
        }
        writeStageText(stage, "integrity/sha256_manifest.json", root.toString(2))
    }

    private fun addDirectoryRoot(zip: ZipOutputStream, dir: File) {
        dir.walkTopDown().filter { it.isFile }.forEach { file ->
            val rel = file.relativeTo(dir).path.replace(File.separatorChar, '/')
            zip.putNextEntry(ZipEntry(rel))
            file.inputStream().use { it.copyTo(zip) }
            zip.closeEntry()
        }
    }

    private fun enqueueTask(
        errorContext: Map<String, Any?> = emptyMap(),
        onRejected: () -> Unit = {},
        block: () -> Unit
    ) {
        try {
            executor.execute {
                runCatching(block).onFailure { e ->
                    recordFailure(errorContext, e)
                }
            }
        } catch (_: RejectedExecutionException) {
            errorContext["session"]?.toString()?.let { sessionFailures[it]?.incrementAndGet() }
            onRejected()
            ArsFlightRecorder.event("EVIDENCE_DROPPED", "Diagnostic evidence queue full", errorContext)
        }
    }

    private fun recordFailure(fields: Map<String, Any?>, failure: Throwable) {
        fields["session"]?.toString()?.let { sessionFailures[it]?.incrementAndGet() }
        ArsFlightRecorder.event("EVIDENCE_ERROR", failure.message ?: failure::class.java.simpleName,
            mapOf("stage" to "WRITE", "proposalId" to "", "physicalObjectId" to "") + fields +
                mapOf("exception" to failure::class.java.name))
    }

    private fun snapshotBitmap(source: Bitmap, mutable: Boolean = false): Bitmap? {
        if (source.isRecycled || source.width <= 0 || source.height <= 0) return null
        return runCatching {
            val scale = minOf(1f, MAX_IMAGE_DIMENSION.toFloat() / max(source.width, source.height).toFloat())
            val w = max(1, (source.width * scale).toInt())
            val h = max(1, (source.height * scale).toInt())
            val scaled = if (w != source.width || h != source.height) Bitmap.createScaledBitmap(source, w, h, true) else source
            val config = if (mutable) Bitmap.Config.ARGB_8888 else Bitmap.Config.RGB_565
            try { scaled.copy(config, mutable) }
            finally { if (scaled !== source && !scaled.isRecycled) scaled.recycle() }
        }.getOrNull()
    }

    private fun safeCrop(bitmap: Bitmap, bounds: Rect): Bitmap? {
        if (bitmap.isRecycled) return null
        val left = bounds.left.coerceIn(0, max(0, bitmap.width - 1))
        val top = bounds.top.coerceIn(0, max(0, bitmap.height - 1))
        val right = bounds.right.coerceIn(left + 1, bitmap.width)
        val bottom = bounds.bottom.coerceIn(top + 1, bitmap.height)
        if (right - left < 8 || bottom - top < 8) return null
        return runCatching {
            val created = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
            if (created === bitmap) bitmap.copy(Bitmap.Config.RGB_565, false) else created
        }.getOrNull()
    }

    private fun writeJpeg(bitmap: Bitmap, target: File) {
        target.parentFile?.mkdirs()
        FileOutputStream(target).use { out -> check(bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)) }
    }

    private fun appendManifest(dir: File, fields: Map<String, Any?>) {
        synchronized(manifestLock) {
            dir.mkdirs()
            val obj = JSONObject().apply {
                put("ts", System.currentTimeMillis())
                fields.forEach { (k, v) -> put(k, v ?: JSONObject.NULL) }
            }
            File(dir, "evidence_manifest.jsonl").appendText(obj.toString() + "\n")
        }
    }

    private fun sessionDir(context: Context, session: String) = File(File(context.filesDir, ROOT), safeName(session))
    private fun safeName(value: String) = value.ifBlank { "unknown" }.replace(Regex("[^A-Za-z0-9._-]"), "_").take(96)

    private fun relativeEvidencePath(file: File): String {
        val context = appContext ?: return file.name
        return runCatching { file.relativeTo(File(context.filesDir, ROOT)).path }.getOrElse { file.name }
    }

    private fun prune(context: Context) {
        val root = File(context.filesDir, ROOT)
        val sessions = root.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.lastModified() }?.toMutableList() ?: return
        sessions.drop(MAX_SESSIONS).forEach { runCatching { it.deleteRecursively() } }
        val kept = sessions.take(MAX_SESSIONS).toMutableList()
        var total = kept.sumOf { directoryBytes(it) }
        while (total > MAX_TOTAL_BYTES && kept.size > 1) {
            val oldest = kept.removeAt(kept.lastIndex)
            total -= directoryBytes(oldest)
            runCatching { oldest.deleteRecursively() }
        }
        val retainedNames = kept.map { it.name }.toSet()
        sessionFailures.keys.removeAll { safeName(it) !in retainedNames && !trackSnapshots.containsKey(it) }
    }

    private fun directoryBytes(dir: File) = dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    private fun countFiles(dir: File) = dir.walkTopDown().count { it.isFile }

    private fun sha256(file: File): String = runCatching {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    }.getOrDefault("")

    private fun flushPending(timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while ((executor.activeCount > 0 || executor.queue.isNotEmpty()) && System.currentTimeMillis() < deadline) {
            try { Thread.sleep(40L) } catch (_: InterruptedException) { Thread.currentThread().interrupt(); break }
        }
        return executor.activeCount == 0 && executor.queue.isEmpty()
    }

    private fun addText(zip: ZipOutputStream, name: String, text: String) {
        zip.putNextEntry(ZipEntry(name)); zip.write(text.toByteArray(Charsets.UTF_8)); zip.closeEntry()
    }
    private fun addFile(zip: ZipOutputStream, file: File, name: String) {
        zip.putNextEntry(ZipEntry(name)); file.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
    }
    private fun addDirectory(zip: ZipOutputStream, dir: File, prefix: String) {
        dir.walkTopDown().filter { it.isFile }.forEach { file ->
            val rel = file.relativeTo(dir).path.replace(File.separatorChar, '/')
            zip.putNextEntry(ZipEntry("$prefix/$rel")); file.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
        }
    }
}
