package com.arspos.anglerriausyndicate.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "product_photos",
    indices = [Index(value = ["productId"])]
)
data class ProductPhotoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val localPath: String,
    val isPrimary: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
