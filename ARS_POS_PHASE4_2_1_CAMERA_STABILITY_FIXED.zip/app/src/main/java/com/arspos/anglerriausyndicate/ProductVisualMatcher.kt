package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import java.io.File
import kotlin.math.sqrt
import java.util.concurrent.ConcurrentHashMap

/**
 * Offline visual matcher Phase 4.2.
 *
 * Ini bukan model AI/cloud dan tidak mengirim foto ke internet. Mesin ini
 * membuat fingerprint visual sederhana dari foto referensi dan foto scan,
 * lalu memberi skor kecocokan 0..100. SKU, harga, stok dan transaksi tetap
 * bersumber dari database produk ARS POS.
 */
object ProductVisualMatcher {
    private const val SIZE = 24
    private const val HASH_WIDTH = 9
    private const val HASH_HEIGHT = 8

    private data class Fingerprint(
        val pixels: FloatArray,
        val histogram: FloatArray,
        val hash: Long
    )

    private val referenceCache = ConcurrentHashMap<String, Fingerprint>()

    fun score(scan: Bitmap, referencePath: String): Int {
        val file = File(referencePath)
        if (!file.exists()) return 0
        val cacheKey = "${file.absolutePath}:${file.lastModified()}:${file.length()}"
        val a = fingerprint(scan)
        val b = referenceCache[cacheKey] ?: decodeReference(referencePath)?.let(::fingerprint)?.also {
            referenceCache[cacheKey] = it
        } ?: return 0
        return ((0.60f * structuralSimilarity(a.pixels, b.pixels)) +
                (0.25f * histogramSimilarity(a.histogram, b.histogram)) +
                (0.15f * hashSimilarity(a.hash, b.hash)))
            .coerceIn(0f, 1f)
            .times(100f)
            .toInt()
    }

    private fun decodeReference(path: String): Bitmap? {
        val file = File(path)
        if (!file.exists()) return null
        return BitmapFactory.decodeFile(path)
    }

    private fun fingerprint(source: Bitmap): Fingerprint {
        val scaled = Bitmap.createScaledBitmap(source, SIZE, SIZE, true)
        val pixels = FloatArray(SIZE * SIZE)
        val histogram = FloatArray(24)
        var index = 0
        var sum = 0f

        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val c = scaled.getPixel(x, y)
                val r = Color.red(c) / 255f
                val g = Color.green(c) / 255f
                val b = Color.blue(c) / 255f
                val gray = (0.299f * r + 0.587f * g + 0.114f * b)
                pixels[index++] = gray
                sum += gray

                histogram[(r * 8).toInt().coerceIn(0, 7)] += 1f
                histogram[8 + (g * 8).toInt().coerceIn(0, 7)] += 1f
                histogram[16 + (b * 8).toInt().coerceIn(0, 7)] += 1f
            }
        }

        val mean = sum / pixels.size
        var variance = 0f
        for (i in pixels.indices) {
            pixels[i] -= mean
            variance += pixels[i] * pixels[i]
        }
        val std = sqrt((variance / pixels.size).toDouble()).toFloat().coerceAtLeast(0.0001f)
        for (i in pixels.indices) pixels[i] /= std

        val histogramTotal = (SIZE * SIZE).toFloat()
        for (i in histogram.indices) histogram[i] /= histogramTotal

        val hash = differenceHash(source)
        if (scaled !== source) scaled.recycle()
        return Fingerprint(pixels, histogram, hash)
    }

    private fun structuralSimilarity(a: FloatArray, b: FloatArray): Float {
        var mse = 0.0
        for (i in a.indices) {
            val d = (a[i] - b[i]).toDouble()
            mse += d * d
        }
        val normalized = mse / a.size
        return (1.0 / (1.0 + normalized / 4.0)).toFloat().coerceIn(0f, 1f)
    }

    private fun histogramSimilarity(a: FloatArray, b: FloatArray): Float {
        var distance = 0f
        for (i in a.indices) distance += kotlin.math.abs(a[i] - b[i])
        return (1f - distance / 2f).coerceIn(0f, 1f)
    }

    private fun hashSimilarity(a: Long, b: Long): Float {
        val distance = java.lang.Long.bitCount(a xor b)
        return 1f - (distance / 64f)
    }

    private fun differenceHash(source: Bitmap): Long {
        val scaled = Bitmap.createScaledBitmap(source, HASH_WIDTH, HASH_HEIGHT, true)
        var hash = 0L
        var bit = 0
        for (y in 0 until HASH_HEIGHT) {
            for (x in 0 until HASH_WIDTH - 1) {
                val left = gray(scaled.getPixel(x, y))
                val right = gray(scaled.getPixel(x + 1, y))
                if (left > right) hash = hash or (1L shl bit)
                bit++
            }
        }
        scaled.recycle()
        return hash
    }

    private fun gray(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c))
}
