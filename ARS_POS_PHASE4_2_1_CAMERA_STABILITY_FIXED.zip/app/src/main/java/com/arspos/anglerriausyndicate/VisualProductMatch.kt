package com.arspos.anglerriausyndicate

import com.arspos.anglerriausyndicate.data.db.ProductEntity
import com.arspos.anglerriausyndicate.data.db.ProductPhotoEntity

/**
 * Satu kandidat hasil pencocokan foto produk secara offline.
 *
 * product  : master produk ARS POS yang akan masuk ke keranjang.
 * photo    : foto referensi lokal yang menghasilkan skor terbaik.
 * score    : tingkat kecocokan visual 0..100.
 */
data class VisualProductMatch(
    val product: ProductEntity,
    val photo: ProductPhotoEntity,
    val score: Int
)
