# ARS POS — PHASE 4.2

## Product Visual Scanner — Offline

Phase 4.2 menambahkan **SCAN FOTO PRODUK** pada menu KASIR.

### Alur

1. Kasir menekan **SCAN FOTO PRODUK**.
2. ARS POS meminta izin kamera bila belum diberikan.
3. Kasir mengambil foto barang pelanggan.
4. Foto diproses **secara lokal/offline**.
5. Fingerprint visual dibandingkan dengan foto referensi produk di database.
6. ARS POS menampilkan maksimal 5 kandidat terbaik beserta:
   - nama produk
   - SKU
   - stok
   - harga jual
   - persentase kecocokan visual
7. Kasir wajib memilih **TAMBAH** sebelum produk masuk keranjang.
8. Stok, harga, pembayaran, laporan, dan transaksi tetap memakai database POS yang sudah ada.

### Catatan keamanan

Persentase pada Phase 4.2 adalah **skor kecocokan visual**, bukan klaim confidence AI. Sistem tidak mengirim foto ke server dan tidak membutuhkan internet.

Jika hasil tidak cocok, kasir dapat **SCAN ULANG** atau kembali ke pencarian nama/SKU/barcode.

### Batas Phase 4.2

Mesin visual saat ini adalah fingerprint matcher offline. Ini sengaja dibuat sebagai fondasi yang stabil sebelum ARS POS memakai model pengenalan produk khusus yang lebih canggih pada fase berikutnya.
