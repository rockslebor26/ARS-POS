# ARS POS Phase 4.2.1 — Camera Stability Fix

Perbaikan khusus untuk crash saat membuka pengambilan foto produk.

## Perubahan utama
- Mengganti `TakePicturePreview()` dengan `TakePicture()`.
- Menggunakan `FileProvider` dan file sementara di `cacheDir/camera_capture`.
- Menambahkan permission flow kamera untuk input produk.
- Menambahkan pemeriksaan error saat URI/file kamera dibuat.
- Menambahkan decoding foto dengan sampling maksimum 1600 px untuk mengurangi risiko OutOfMemory.
- Tetap offline; foto referensi produk disimpan lokal.
- Visual scanner kasir tetap menggunakan matcher offline.
- Fitur pembayaran, stok, laporan, Rupiah, dan printer dipertahankan.

## Build
- versionCode: 106
- versionName: 1.0.6
- Gradle: 8.9
- Java: 17
- compileSdk/targetSdk: 35
- minSdk: 26
