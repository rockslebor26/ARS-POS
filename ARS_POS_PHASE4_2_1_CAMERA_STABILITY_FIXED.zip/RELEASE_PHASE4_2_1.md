# ARS POS 1.0.6 — Phase 4.2.1 Camera Stability

Build ini memperbaiki jalur kamera untuk:
1. Tambah Produk → Ambil Foto Produk
2. Produk → Foto → Ambil Foto
3. Kasir → Scan Foto Produk

Kamera sekarang menulis hasil ke URI lokal melalui AndroidX FileProvider dan ARS POS membaca hasilnya dengan aman.
