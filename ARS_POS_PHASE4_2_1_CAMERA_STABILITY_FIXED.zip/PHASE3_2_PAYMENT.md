# ARS POS — Phase 3.2 Payment

## Tujuan
Menyempurnakan alur pembayaran tanpa mengubah perhitungan transaksi yang sudah berjalan.

## Perubahan
- Input uang pelanggan tetap menerima angka saja agar cepat diketik.
- Preview nominal otomatis menggunakan format `Rp 1.316.000`.
- Tombol cepat: UANG PAS, Rp 50.000, Rp 100.000, Rp 200.000, Rp 500.000.
- Kembalian dan uang kurang dihitung otomatis.
- Tombol KONFIRMASI BAYAR nonaktif jika keranjang kosong atau pembayaran CASH belum cukup.
- Saat pembayaran diproses, tombol menjadi MEMPROSES... untuk mencegah double-tap checkout.
- QRIS, TRANSFER, dan DEBIT tetap menggunakan nominal total transaksi.
- Nomor invoice memakai milidetik untuk mengurangi risiko nomor transaksi kembar.
- Checkout database tetap atomik; stok dikurangi di dalam transaksi database dan cart dikosongkan hanya setelah checkout berhasil.
- Format Rupiah tetap konsisten di UI dan struk.

## Versi
- versionCode: 102
- versionName: 1.0.2
