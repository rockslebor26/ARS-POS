package com.arspos.anglerriausyndicate.data

import android.util.Base64

/** Compact settings-backed codec so Phase 4.3.2.10 needs no destructive DB migration. */
object ProductIdentityProfileCodec {
    private const val VERSION = "1"

    fun encode(p: ProductIdentityProfile): String = listOf(
        VERSION, p.rawText, p.brand, p.name, p.variant, p.modelCode, p.barcode
    ).joinToString("\n") { Base64.encodeToString(it.toByteArray(Charsets.UTF_8), Base64.NO_WRAP) }

    fun decode(productId: Long, value: String?): ProductIdentityProfile? {
        if (value.isNullOrBlank()) return null
        val parts = value.split('\n').mapNotNull {
            runCatching { String(Base64.decode(it, Base64.DEFAULT), Charsets.UTF_8) }.getOrNull()
        }
        if (parts.size < 7 || parts[0] != VERSION) return null
        return ProductIdentityProfile(
            productId = productId,
            rawText = parts[1], brand = parts[2], name = parts[3], variant = parts[4],
            modelCode = parts[5], barcode = parts[6]
        )
    }
}
