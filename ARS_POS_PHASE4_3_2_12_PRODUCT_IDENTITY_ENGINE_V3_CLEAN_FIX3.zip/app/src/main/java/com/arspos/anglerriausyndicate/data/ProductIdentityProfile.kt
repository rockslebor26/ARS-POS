package com.arspos.anglerriausyndicate.data

/**
 * Phase 4.3.2.10: persistent identity memory built from the product master.
 * Barcode is optional. OCR aliases remain useful even when a package has no barcode.
 */
data class ProductIdentityProfile(
    val productId: Long,
    val rawText: String = "",
    val brand: String = "",
    val name: String = "",
    val variant: String = "",
    val modelCode: String = "",
    val barcode: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
