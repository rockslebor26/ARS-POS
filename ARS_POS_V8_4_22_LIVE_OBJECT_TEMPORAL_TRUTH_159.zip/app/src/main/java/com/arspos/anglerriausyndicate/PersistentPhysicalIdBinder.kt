package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * V8.4.22 continuity bridge from LIVE temporal tracks to final locked scan.
 * It is diagnostic identity only and cannot alter recognition/quantity/cart.
 */
object PersistentPhysicalIdBinder {
    data class LockedTrack(
        val trackId: String,
        val bounds: Rect,
        val frameWidth: Int,
        val frameHeight: Int,
        val proposalType: String,
        val state: String
    )

    data class Binding(
        val objectIndex: Int,
        val physicalObjectId: String,
        val persistentPhysicalId: String,
        val normalizedIou: Float
    )

    private data class Score(val track: LockedTrack, val iou: Float, val total: Float)

    fun bind(tracks: List<LockedTrack>, objects: List<VisualScanObject>): List<Binding> {
        if (tracks.isEmpty() || objects.isEmpty()) return emptyList()
        // Do not resurrect a preview track which was already missing when the
        // operator locked the scene.
        val remaining = tracks.filter { it.state != LiveSceneTrack.STATE_OCCLUDED }.toMutableList()
        val result = ArrayList<Binding>()

        objects.forEach { obj ->
            val objectLong = obj.proposalType == ScanProposal.TYPE_LONG
            val best = remaining.mapNotNull { track ->
                val trackLong = track.proposalType == ScanProposal.TYPE_LONG
                if (trackLong != objectLong) return@mapNotNull null // cross-lane bind forbidden

                val iou = normalizedIou(
                    track.bounds, track.frameWidth, track.frameHeight,
                    obj.normalizedBounds, obj.frameWidth, obj.frameHeight
                )
                val centre = normalizedCentreSimilarity(
                    track.bounds, track.frameWidth, track.frameHeight,
                    obj.normalizedBounds, obj.frameWidth, obj.frameHeight
                )
                val size = normalizedAreaSimilarity(
                    track.bounds, track.frameWidth, track.frameHeight,
                    obj.normalizedBounds, obj.frameWidth, obj.frameHeight
                )
                if (iou < 0.08f && (centre < 0.62f || size < 0.42f)) return@mapNotNull null
                val total = iou * 0.60f + centre * 0.25f + size * 0.15f
                if (total < 0.31f) null else Score(track, iou, total)
            }.maxByOrNull { it.total }

            if (best != null) {
                remaining.remove(best.track)
                result += Binding(
                    objectIndex = obj.index,
                    physicalObjectId = obj.physicalObjectId,
                    persistentPhysicalId = best.track.trackId,
                    normalizedIou = best.iou.coerceIn(0f, 1f)
                )
            }
        }
        return result
    }

    private data class NRect(val l: Float, val t: Float, val r: Float, val b: Float)

    private fun norm(rect: Rect, w: Int, h: Int): NRect? {
        if (w <= 0 || h <= 0) return null
        return NRect(
            rect.left.toFloat() / w,
            rect.top.toFloat() / h,
            rect.right.toFloat() / w,
            rect.bottom.toFloat() / h
        )
    }

    private fun normalizedIou(a: Rect, aw: Int, ah: Int, b: Rect, bw: Int, bh: Int): Float {
        val x = norm(a, aw, ah) ?: return 0f
        val y = norm(b, bw, bh) ?: return 0f
        val l = max(x.l, y.l); val t = max(x.t, y.t); val r = min(x.r, y.r); val bot = min(x.b, y.b)
        if (r <= l || bot <= t) return 0f
        val inter = (r - l) * (bot - t)
        val areaA = (x.r - x.l).coerceAtLeast(0f) * (x.b - x.t).coerceAtLeast(0f)
        val areaB = (y.r - y.l).coerceAtLeast(0f) * (y.b - y.t).coerceAtLeast(0f)
        val union = areaA + areaB - inter
        return if (union <= 0f) 0f else inter / union
    }

    private fun normalizedCentreSimilarity(a: Rect, aw: Int, ah: Int, b: Rect, bw: Int, bh: Int): Float {
        val x = norm(a, aw, ah) ?: return 0f
        val y = norm(b, bw, bh) ?: return 0f
        val ax=(x.l+x.r)/2f; val ay=(x.t+x.b)/2f; val bx=(y.l+y.r)/2f; val by=(y.t+y.b)/2f
        val distance = hypot(ax-bx, ay-by)
        return (1f - distance / 0.55f).coerceIn(0f,1f)
    }

    private fun normalizedAreaSimilarity(a: Rect, aw: Int, ah: Int, b: Rect, bw: Int, bh: Int): Float {
        val x = norm(a, aw, ah) ?: return 0f
        val y = norm(b, bw, bh) ?: return 0f
        val areaA=((x.r-x.l).coerceAtLeast(0f)*(x.b-x.t).coerceAtLeast(0f)).coerceAtLeast(0.000001f)
        val areaB=((y.r-y.l).coerceAtLeast(0f)*(y.b-y.t).coerceAtLeast(0f)).coerceAtLeast(0.000001f)
        return min(areaA,areaB)/max(areaA,areaB)
    }
}
