package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Rect
import com.arspos.anglerriausyndicate.data.db.ProductEntity
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.42 / V8.4.22 — Live Object Temporal Truth contracts.
 *
 * Live boxes and candidates are advisory only. They never mutate cart quantity
 * and never bypass the final SmartVisualScanner / SmartRecognitionEngine gates.
 */
data class LiveSceneDetection(
    val bounds: Rect,
    val proposalType: String,
    val product: ProductEntity? = null,
    val visualScore: Int = 0,
    val secondVisualScore: Int = 0,
    val margin: Int = 0,
    val identityAccepted: Boolean = false,
    val reason: String = "OBJECT_DETECTED"
)

data class LiveSceneLockSnapshot(
    val frameWidth: Int,
    val frameHeight: Int,
    val tracks: List<LiveSceneTrack>
)

data class LiveSceneTrack(
    val trackId: String,
    val bounds: Rect,
    val proposalType: String,
    val product: ProductEntity?,
    val visualScore: Int,
    val margin: Int,
    val hitStreak: Int,
    val missingFrames: Int,
    val state: String,
    val quantityPreviewEligible: Boolean,
    val reason: String
) {
    companion object {
        const val STATE_TRACKING = "TRACKING"
        const val STATE_ANALYZING = "ANALYZING"
        const val STATE_MATCHED = "MATCHED"
        const val STATE_CANDIDATE = "CANDIDATE"
        const val STATE_UNKNOWN = "UNKNOWN"
        const val STATE_OCCLUDED = "OCCLUDED"
    }
}

/**
 * V8.4.22 temporal physical ledger.
 *
 * Key safety changes from V8.4.21:
 * 1. NORMAL/LONG lanes are never rebound across lanes.
 * 2. Track continuity uses IoU + centre motion + area similarity, so small
 *    camera/object motion does not allocate a new LIVE id merely because IoU
 *    briefly falls.
 * 3. Candidate identity uses hysteresis. One noisy frame cannot replace a
 *    stable database candidate.
 * 4. MATCHED requires repeated accepted identity for the same temporal track.
 * 5. This is still preview-only; cashier quantity remains final-scan owned.
 */
class LiveSceneLedger(
    private val stableHits: Int = 3,
    private val maxMissingFrames: Int = 3,
    private val minimumMatchScore: Float = 0.34f
) {
    private data class State(
        val id: Int,
        var bounds: Rect,
        var proposalType: String,
        var product: ProductEntity?,
        var visualScore: Int,
        var margin: Int,
        var identityAccepted: Boolean,
        var hitStreak: Int,
        var missingFrames: Int,
        var reason: String,
        var candidateProductId: Long?,
        var candidateAgreement: Int,
        var acceptedAgreement: Int,
        var pendingProduct: ProductEntity?,
        var pendingProductId: Long?,
        var pendingAgreement: Int
    )

    private var nextId = 1
    private val tracks = LinkedHashMap<Int, State>()

    fun clear() {
        tracks.clear()
        nextId = 1
    }

    fun update(detections: List<LiveSceneDetection>): List<LiveSceneTrack> {
        val available = tracks.values.toMutableList()
        val touched = HashSet<Int>()

        detections.sortedByDescending { area(it.bounds) }.forEach { detection ->
            val candidate = available
                .map { state -> state to matchScore(state, detection) }
                .filter { it.second >= minimumMatchScore }
                .maxByOrNull { it.second }
                ?.first

            if (candidate == null) {
                val productId = detection.product?.id
                val state = State(
                    id = nextId++,
                    bounds = Rect(detection.bounds),
                    proposalType = detection.proposalType,
                    product = detection.product,
                    visualScore = detection.visualScore,
                    margin = detection.margin,
                    identityAccepted = detection.identityAccepted,
                    hitStreak = 1,
                    missingFrames = 0,
                    reason = detection.reason,
                    candidateProductId = productId,
                    candidateAgreement = if (productId != null) 1 else 0,
                    acceptedAgreement = if (productId != null && detection.identityAccepted) 1 else 0,
                    pendingProduct = null,
                    pendingProductId = null,
                    pendingAgreement = 0
                )
                tracks[state.id] = state
                touched += state.id
            } else {
                available.remove(candidate)
                touched += candidate.id
                candidate.bounds = smooth(candidate.bounds, detection.bounds)
                candidate.visualScore = detection.visualScore
                candidate.margin = detection.margin
                candidate.identityAccepted = detection.identityAccepted
                candidate.hitStreak += 1
                candidate.missingFrames = 0
                candidate.reason = detection.reason

                val nextProduct = detection.product
                val nextProductId = nextProduct?.id
                when {
                    nextProductId == null -> {
                        // Keep a proven candidate through one weak/noisy frame,
                        // but decay confidence so stale identities disappear.
                        candidate.candidateAgreement = max(0, candidate.candidateAgreement - 1)
                        candidate.acceptedAgreement = max(0, candidate.acceptedAgreement - 1)
                        candidate.pendingProduct = null
                        candidate.pendingProductId = null
                        candidate.pendingAgreement = 0
                        if (candidate.candidateAgreement == 0) {
                            candidate.product = null
                            candidate.candidateProductId = null
                        }
                    }
                    nextProductId == candidate.candidateProductId -> {
                        candidate.product = nextProduct
                        candidate.candidateAgreement += 1
                        candidate.acceptedAgreement = if (detection.identityAccepted) {
                            candidate.acceptedAgreement + 1
                        } else {
                            max(0, candidate.acceptedAgreement - 1)
                        }
                        candidate.pendingProduct = null
                        candidate.pendingProductId = null
                        candidate.pendingAgreement = 0
                    }
                    else -> {
                        // Do not switch a stable LIVE id to another SKU because
                        // of a single visual/OCR wobble. Require two frames.
                        if (candidate.pendingProductId == nextProductId) {
                            candidate.pendingAgreement += 1
                            candidate.pendingProduct = nextProduct
                        } else {
                            candidate.pendingProductId = nextProductId
                            candidate.pendingProduct = nextProduct
                            candidate.pendingAgreement = 1
                        }
                        if (candidate.pendingAgreement >= 2) {
                            candidate.candidateProductId = nextProductId
                            candidate.product = nextProduct
                            candidate.candidateAgreement = candidate.pendingAgreement
                            candidate.acceptedAgreement = if (detection.identityAccepted) 1 else 0
                            candidate.pendingProduct = null
                            candidate.pendingProductId = null
                            candidate.pendingAgreement = 0
                        } else {
                            candidate.candidateAgreement = max(0, candidate.candidateAgreement - 1)
                            candidate.acceptedAgreement = max(0, candidate.acceptedAgreement - 1)
                        }
                    }
                }
            }
        }

        tracks.values.forEach { state ->
            if (state.id !in touched) {
                state.missingFrames += 1
                state.hitStreak = max(0, state.hitStreak - 1)
                state.acceptedAgreement = max(0, state.acceptedAgreement - 1)
            }
        }
        tracks.entries.removeAll { it.value.missingFrames > maxMissingFrames }
        return snapshot()
    }

    fun snapshot(): List<LiveSceneTrack> = tracks.values
        .sortedWith(compareBy<State> { it.bounds.top }.thenBy { it.bounds.left })
        .map { state ->
            val stable = state.hitStreak >= stableHits
            val sameCandidateStable = state.candidateAgreement >= 2
            val acceptedStable = state.acceptedAgreement >= 2
            val previewIdentity = stable && sameCandidateStable && acceptedStable && state.product != null
            val stateName = when {
                state.missingFrames > 0 -> LiveSceneTrack.STATE_OCCLUDED
                !stable -> LiveSceneTrack.STATE_TRACKING
                previewIdentity -> LiveSceneTrack.STATE_MATCHED
                state.product != null -> LiveSceneTrack.STATE_CANDIDATE
                stable -> LiveSceneTrack.STATE_UNKNOWN
                else -> LiveSceneTrack.STATE_ANALYZING
            }
            LiveSceneTrack(
                trackId = "LIVE-${state.id}",
                bounds = Rect(state.bounds),
                proposalType = state.proposalType,
                product = state.product,
                visualScore = state.visualScore,
                margin = state.margin,
                hitStreak = state.hitStreak,
                missingFrames = state.missingFrames,
                state = stateName,
                quantityPreviewEligible = previewIdentity,
                reason = state.reason
            )
        }

    private fun matchScore(state: State, detection: LiveSceneDetection): Float {
        val stateLong = state.proposalType == ScanProposal.TYPE_LONG
        val detectionLong = detection.proposalType == ScanProposal.TYPE_LONG
        if (stateLong != detectionLong) return 0f // typed-lane invariant

        val overlap = iou(state.bounds, detection.bounds)
        val centre = centreSimilarity(state.bounds, detection.bounds)
        val size = areaSimilarity(state.bounds, detection.bounds)

        // Require either meaningful geometric overlap or a plausible short
        // motion of a similarly-sized object. This prevents background jumps.
        if (overlap < 0.08f && (centre < 0.58f || size < 0.40f)) return 0f

        val productFactor = when {
            state.candidateProductId == null || detection.product == null -> 1f
            state.candidateProductId == detection.product.id -> 1.06f
            else -> 0.90f
        }
        return ((overlap * 0.55f + centre * 0.30f + size * 0.15f) * productFactor).coerceIn(0f, 1f)
    }

    private fun smooth(old: Rect, next: Rect): Rect = Rect(
        ((old.left * 2 + next.left) / 3f).toInt(),
        ((old.top * 2 + next.top) / 3f).toInt(),
        ((old.right * 2 + next.right) / 3f).toInt(),
        ((old.bottom * 2 + next.bottom) / 3f).toInt()
    )

    private fun centreSimilarity(a: Rect, b: Rect): Float {
        val ax = (a.left + a.right) / 2f; val ay = (a.top + a.bottom) / 2f
        val bx = (b.left + b.right) / 2f; val by = (b.top + b.bottom) / 2f
        val scale = max(max(a.width(), a.height()), max(b.width(), b.height())).coerceAtLeast(1).toFloat()
        return (1f - hypot(ax - bx, ay - by) / (scale * 1.75f)).coerceIn(0f, 1f)
    }

    private fun areaSimilarity(a: Rect, b: Rect): Float {
        val aa = area(a).coerceAtLeast(1L).toFloat()
        val bb = area(b).coerceAtLeast(1L).toFloat()
        return min(aa, bb) / max(aa, bb)
    }

    private fun iou(a: Rect, b: Rect): Float {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val intersection = (right - left).toLong() * (bottom - top).toLong()
        val union = area(a) + area(b) - intersection
        return if (union <= 0L) 0f else intersection.toFloat() / union.toFloat()
    }

    private fun area(rect: Rect): Long = rect.width().coerceAtLeast(0).toLong() * rect.height().coerceAtLeast(0).toLong()
}

/** Cheap scene-change trigger. Motion is never identity evidence by itself. */
object LiveFrameDifference {
    private const val GRID = 20

    fun signature(bitmap: Bitmap): IntArray {
        if (bitmap.width <= 0 || bitmap.height <= 0) return IntArray(0)
        val out = IntArray(GRID * GRID)
        var index = 0
        for (gy in 0 until GRID) {
            val y = ((gy + 0.5f) * bitmap.height / GRID).toInt().coerceIn(0, bitmap.height - 1)
            for (gx in 0 until GRID) {
                val x = ((gx + 0.5f) * bitmap.width / GRID).toInt().coerceIn(0, bitmap.width - 1)
                val p = bitmap.getPixel(x, y)
                val r = (p shr 16) and 0xff
                val g = (p shr 8) and 0xff
                val b = p and 0xff
                out[index++] = (r * 30 + g * 59 + b * 11) / 100
            }
        }
        return out
    }

    fun score(previous: IntArray?, current: IntArray): Float {
        if (previous == null || previous.size != current.size || current.isEmpty()) return 1f
        var total = 0L
        current.indices.forEach { total += abs(current[it] - previous[it]).toLong() }
        return (total.toFloat() / current.size.toFloat() / 255f).coerceIn(0f, 1f)
    }
}
