# ARS POS 1.5.6 (156) — V8.4.20-A

Phase 4.3.2.40. Kelanjutan in-place dari source resmi 1.5.5 (155), bukan aplikasi baru.
Package: `com.arspos.anglerriausyndicate`. Database Room tetap v5.

V8.4.20-A adalah slice pertama Physical Truth V2. Fokusnya **Package Edge Firewall** dan **Bidirectional Anchor Role Truth**. Bukti V8.4.19 menunjukkan garis tepi kemasan dapat menjadi `TRUSTED_ROD`, sementara joran nyata dapat kehilangan status rod karena endpoint HANDLE salah. Versi A memperbaiki physical ownership dan role endpoint **tanpa menurunkan 14 threshold recognition SKU**.

## Build melalui GitHub

1. Unggah **ARS_POS_V8_4_20A_PACKAGE_EDGE_ANCHOR_156.zip** ke root repository dengan nama persis itu. Workflow memeriksa SHA-256 arsip.
2. Salin isi file pendamping **ARS_POS_V8_4_20A_PACKAGE_EDGE_ANCHOR_156.yml** ke **.github/workflows/build-apk.yml**.
3. Gunakan secrets resmi yang sama: `ARS_RELEASE_KEYSTORE_BASE64`, `ARS_RELEASE_STORE_PASSWORD`, `ARS_RELEASE_KEY_ALIAS`, `ARS_RELEASE_KEY_PASSWORD`, `ARS_RELEASE_CERT_SHA256`.
4. Jalankan Actions → **ARS POS V8.4.20-A Package Edge Anchor 156** → Run workflow.
5. Ambil artifact resmi dan pasang **sebagai update in-place** di atas 1.5.5 (155). Jangan uninstall.

Signer wajib:
`AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`.

Workflow berhenti bila package/version/signer berubah, source integrity gagal, regression evidence gagal, kompilasi gagal, atau test gagal. Tidak ada fallback signer debug dan keystore tidak disertakan dalam source.

## Gate V8.4.20-A

- Package edge pada captured KTN V8.4.19 harus menjadi `NORMAL_BOUNDARY_EDGE`, bukan `TRUSTED_ROD`.
- LONG tanpa planar NORMAL owner tidak boleh diblokir oleh Package Edge Firewall.
- HANDLE/TIP physical role hanya dipaksa bila endpoint evidence mempunyai margin cukup; endpoint ambigu tetap unknown.
- Recognition thresholds tetap identik dengan V8.4.19.
- Device test tetap wajib sebelum melanjutkan V8.4.20-B.

Detail: `PHASE4_3_2_40_V8_4_20A_PACKAGE_EDGE_BIDIRECTIONAL_ANCHOR.md` dan `RELEASE_156.md`.
