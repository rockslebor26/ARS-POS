# ARS POS Phase 4.2.2 — Fresh Scan Session & Result Reset

Perbaikan ini memastikan setiap `SCAN FOTO PRODUK` / `SCAN ULANG` memulai sesi baru.

## Perubahan
- Preview foto scan sebelumnya dibersihkan sebelum kamera baru dibuka.
- `visualMatches` dikosongkan sebelum scan baru.
- Status `scanningVisual` di-reset.
- File kamera sementara tetap menggunakan mekanisme Phase 4.2.1.
- Tidak mengubah database produk, stok, pembayaran, laporan, atau printer.

## Target
Mencegah kandidat dari scan sebelumnya muncul kembali pada sesi scan berikutnya.

## Versi
- versionCode: 107
- versionName: 1.0.7
