# ARS POS Phase 4.3.1 — Smart Recognition Refinement + OCR

## Fokus
- Memperbaiki dialog TAMBAH PRODUK agar seluruh form dapat discroll tanpa menabrak tombol SIMPAN/BATAL.
- Menambahkan OCR offline berbasis bundled ML Kit untuk membaca teks dari foto produk.
- Menambahkan barcode recognition offline berbasis bundled ML Kit.
- Menambahkan field Merek dan Varian/Model.
- Menyarankan SKU otomatis dari merek/nama/varian/model dan suffix unik.
- SKU tetap dapat diedit manual sebelum disimpan.
- Foto referensi tetap disimpan ke database product_photos.
- Recognition scanner Phase 4.3 tetap ketat: object-level, minimum score 82 dan margin 8.

## Prinsip keselamatan transaksi
OCR/recognition hanya memberi saran. Kasir tetap memeriksa data sebelum produk disimpan atau dimasukkan ke keranjang.

## Offline
Text Recognition dan Barcode Scanning menggunakan bundled ML Kit models sehingga model ditautkan saat build APK dan tersedia tanpa download model saat runtime. Ukuran APK bertambah sebagai konsekuensi model bundled.

## Versi
- versionCode: 109
- versionName: 1.0.9

## APK artifact
`ARS-POS-1.0.9-PHASE4.3.1-SMART-PRODUCT-RECOGNITION-OCR-SIGNED.apk`
