package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import com.arspos.anglerriausyndicate.data.db.ProductEntity

/**
 * Phase 4.3.2: product recognition fusion engine.
 *
 * Combines object-level visual similarity with OCR evidence from each crop.
 * Barcode/model/SKU evidence is treated as a strong identity signal.
 * Weak evidence is rejected instead of being promoted to a false-positive sale.
 */
object SmartRecognitionEngine {
    data class Result(
        val match: VisualProductMatch?,
        val visualScore: Int,
        val textScore: Int,
        val finalScore: Int,
        val ocrText: String,
        val barcode: String = "",
        val reason: String
    )

    private const val MIN_FINAL_SCORE = 82
    private const val MIN_VISUAL_WITH_TEXT = 55
    private const val STRONG_TEXT = 72

    suspend fun recognize(
        crop: Bitmap,
        products: List<ProductEntity>,
        references: List<VisualProductMatch>,
        ocr: SmartProductInput.Draft
    ): Result {
        if (products.isEmpty()) return Result(null, 0, 0, 0, ocr.rawText, ocr.barcode, "Katalog kosong")

        val normalizedOcr = normalize(ocr.rawText)
        val barcode = normalizeCode(ocr.barcode)
        val model = normalizeCode(ocr.modelCode)

        var best: VisualProductMatch? = null
        var bestText = 0
        var bestVisual = 0
        var bestFinal = 0
        var bestReason = ""

        for (candidate in references) {
            val p = candidate.product
            val text = textScore(p, normalizedOcr, barcode, model)
            val final = fuse(candidate.score, text, barcode, model, p)
            if (final > bestFinal) {
                best = candidate
                bestText = text
                bestVisual = candidate.score
                bestFinal = final
                bestReason = reason(candidate.score, text, barcode, model)
            }
        }

        val accepted = when {
            best == null -> false
            bestFinal < MIN_FINAL_SCORE -> false
            barcode.isNotBlank() && bestText >= 80 -> true
            bestText >= STRONG_TEXT && bestVisual >= MIN_VISUAL_WITH_TEXT -> true
            bestVisual >= MIN_FINAL_SCORE -> true
            else -> false
        }

        return Result(
            if (accepted) best else null,
            bestVisual,
            bestText,
            bestFinal,
            ocr.rawText,
            ocr.barcode,
            if (accepted) bestReason else "Bukti belum cukup kuat"
        )
    }

    fun textScore(product: ProductEntity, ocrText: String, barcode: String = "", model: String = ""): Int {
        val productCode = normalizeCode(product.barcode.orEmpty())
        if (barcode.isNotBlank() && productCode.isNotBlank() && barcode == productCode) return 100

        val modelUpper = model.trim()
        if (modelUpper.isNotBlank()) {
            val productFields = normalize("${product.name} ${product.brand.orEmpty()} ${product.variant.orEmpty()} ${product.sku} ${product.barcode.orEmpty()}")
            if (productFields.contains(modelUpper)) return 95
        }

        if (ocrText.isBlank()) return 0
        val fieldTokens = tokenize(normalize(
            "${product.name} ${product.brand.orEmpty()} ${product.variant.orEmpty()} ${product.sku} ${product.barcode.orEmpty()}"
        ))
        if (fieldTokens.isEmpty()) return 0

        val ocrTokens = tokenize(ocrText)
        val meaningful = fieldTokens.filter { it.length >= 3 && !STOP_WORDS.contains(it) }
        if (meaningful.isEmpty()) return 0

        val hits = meaningful.count { token ->
            ocrTokens.any { it == token || (token.length >= 5 && (it.contains(token) || token.contains(it))) }
        }
        return ((hits.toFloat() / meaningful.size.toFloat()) * 100f).toInt().coerceIn(0, 100)
    }

    private fun fuse(visual: Int, text: Int, barcode: String, model: String, product: ProductEntity): Int {
        if (barcode.isNotBlank() && normalizeCode(product.barcode.orEmpty()) == barcode) return 100
        if (model.isNotBlank() && text >= 95) return maxOf(visual, text)
        return if (text > 0) {
            (visual * 0.45f + text * 0.55f).toInt()
        } else visual
    }

    private fun reason(visual: Int, text: Int, barcode: String, model: String): String = when {
        barcode.isNotBlank() && text >= 80 -> "Barcode + OCR + visual"
        model.isNotBlank() && text >= 90 -> "Model + OCR + visual"
        text >= STRONG_TEXT && visual >= MIN_VISUAL_WITH_TEXT -> "OCR + visual"
        visual >= MIN_FINAL_SCORE -> "Visual kuat"
        else -> "Bukti gabungan"
    }

    private fun normalize(value: String): String = value
        .uppercase()
        .replace(Regex("[^A-Z0-9]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private fun normalizeCode(value: String): String = normalize(value).replace(" ", "")

    private fun tokenize(value: String): List<String> = value.split(" ").filter { it.isNotBlank() }

    private val STOP_WORDS = setOf(
        "SIZE", "MODEL", "VARIAN", "VARIANT", "KOREA", "KOREAN", "TECHNOLOGY",
        "QUALITY", "PREMIUM", "BEST", "THE", "AND", "FOR", "GO", "PCS", "PC"
    )
}
