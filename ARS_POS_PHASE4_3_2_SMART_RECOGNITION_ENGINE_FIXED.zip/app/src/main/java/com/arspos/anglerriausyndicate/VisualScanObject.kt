package com.arspos.anglerriausyndicate

import android.graphics.Rect

/** Hasil deteksi + pengenalan satu objek pada Phase 4.3.2. */
data class VisualScanObject(
    val index: Int,
    val bounds: Rect,
    val match: VisualProductMatch?,
    val bestScore: Int = match?.score ?: 0,
    val visualScore: Int = bestScore,
    val textScore: Int = 0,
    val finalScore: Int = bestScore,
    val ocrText: String = "",
    val barcode: String = "",
    val reason: String = ""
)
