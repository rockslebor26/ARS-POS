package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3: object-level visual search.
 *
 * ML Kit dipakai sebagai frontend untuk memisahkan objek pada foto (maks. 5
 * objek). Setiap crop kemudian dibandingkan dengan foto referensi produk.
 * Hasil yang tidak melewati gerbang ketat tidak dikembalikan ke UI.
 * Semua proses tetap di perangkat.
 */
object SmartVisualScanner {
    private const val MAX_OBJECTS = 5
    private const val MIN_SCORE = 82
    private const val MIN_MARGIN = 8
    private const val PADDING_RATIO = 0.10f
    private const val MIN_OBJECT_AREA_RATIO = 0.025f

    private val options = ObjectDetectorOptions.Builder()
        .setDetectorMode(ObjectDetectorOptions.SINGLE_IMAGE_MODE)
        .enableMultipleObjects()
        .build()

    private val detector by lazy { ObjectDetection.getClient(options) }

    suspend fun detectObjects(bitmap: Bitmap): List<Rect> {
        val image = InputImage.fromBitmap(bitmap, 0)
        val objects = detector.process(image).await()
        val imageArea = bitmap.width.toLong() * bitmap.height.toLong()
        return objects
            .asSequence()
            .map { it.boundingBox }
            .map { expandAndClamp(it, bitmap.width, bitmap.height) }
            .filter { rect ->
                val area = rect.width().toLong() * rect.height().toLong()
                area.toDouble() / imageArea.toDouble() >= MIN_OBJECT_AREA_RATIO
            }
            .sortedByDescending { it.width().toLong() * it.height().toLong() }
            .take(MAX_OBJECTS)
            .toList()
    }

    fun crop(bitmap: Bitmap, bounds: Rect): Bitmap? {
        val safe = expandAndClamp(bounds, bitmap.width, bitmap.height)
        if (safe.width() < 24 || safe.height() < 24) return null
        return runCatching {
            Bitmap.createBitmap(bitmap, safe.left, safe.top, safe.width(), safe.height())
        }.getOrNull()
    }

    fun acceptBest(candidates: List<VisualProductMatch>): VisualProductMatch? {
        if (candidates.isEmpty()) return null
        val ranked = candidates.sortedByDescending { it.score }
        val best = ranked.first()
        val second = ranked.getOrNull(1)
        if (best.score < MIN_SCORE) return null
        if (second != null && best.score - second.score < MIN_MARGIN) return null
        return best
    }

    private fun expandAndClamp(rect: Rect, width: Int, height: Int): Rect {
        val padX = max(8, (rect.width() * PADDING_RATIO).toInt())
        val padY = max(8, (rect.height() * PADDING_RATIO).toInt())
        return Rect(
            max(0, rect.left - padX),
            max(0, rect.top - padY),
            min(width, rect.right + padX),
            min(height, rect.bottom + padY)
        )
    }

    private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T =
        suspendCancellableCoroutine { continuation ->
            addOnSuccessListener { value ->
                if (continuation.isActive) continuation.resume(value)
            }
            addOnFailureListener { error ->
                if (continuation.isActive) continuation.resumeWithException(error)
            }
            addOnCanceledListener {
                continuation.cancel()
            }
        }
}
