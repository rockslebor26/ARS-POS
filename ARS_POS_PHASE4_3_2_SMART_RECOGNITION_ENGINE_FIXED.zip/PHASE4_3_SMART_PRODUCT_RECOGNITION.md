# ARS POS — Phase 4.3 Smart Product Recognition

Phase 4.3 mengubah scanner foto dari pencocokan satu foto penuh menjadi **pencarian berbasis objek**.

## Tujuan
- Foto baru dimulai sebagai sesi scan baru.
- ML Kit Object Detection mendeteksi sampai 5 objek pada satu foto.
- Setiap objek dipotong (crop) dan dicocokkan secara terpisah dengan foto referensi produk di database lokal.
- Hanya kandidat yang melewati standar kecocokan ketat yang dikirim ke UI.
- Jika objek tidak cukup mirip atau hasil terlalu ambigu, objek dianggap **tidak dikenali** dan tidak ditampilkan sebagai kandidat.
- Jika ada dua produk dalam satu foto, masing-masing objek dinilai sendiri.
- Kasir tetap menekan `TAMBAH` sebelum produk masuk keranjang.

## Aturan kecocokan ketat
- Minimum skor kecocokan: **82%**.
- Jika ada kandidat kedua, kandidat terbaik harus unggul minimal **8 poin**.
- Tidak ada fallback ke pencocokan seluruh foto. Jika object detector tidak menemukan objek, scanner tidak menampilkan kandidat.
- Skor yang tampil tetap disebut **Kecocokan kuat**, bukan confidence AI.

## Offline
Dependency object detection menggunakan artifact bundled ML Kit sehingga model tersedia di APK dan dapat digunakan tanpa menunggu download model saat runtime. Internet tidak diperlukan untuk proses scan setelah aplikasi terpasang.

## Batasan penting
Phase 4.3 adalah fondasi object-level recognition, bukan model klasifikasi khusus toko pancing. Untuk tingkat pengenalan SKU/varian yang lebih tinggi, foto referensi yang baik dan Phase 4.4 (OCR + barcode + pembentukan SKU) tetap diperlukan. Model klasifikasi custom khusus katalog ARS POS dapat ditambahkan setelah dataset foto produk terkumpul.

## Versi
- versionCode: `108`
- versionName: `1.0.8`
