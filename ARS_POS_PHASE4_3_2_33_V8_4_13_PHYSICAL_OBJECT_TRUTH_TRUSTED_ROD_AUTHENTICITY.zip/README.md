# ARS POS — ANGLER RIAU SYNDICATE

Current development release candidate:

- Phase **4.3.2.33**
- Engine **V8.4.13 — Physical Object Truth + Trusted Rod Authenticity + Deterministic Track Quantity**
- Version **1.4.8**
- versionCode **148**
- Database **5 (unchanged)**
- Package **com.arspos.anglerriausyndicate**
- Signing channel **ARS POS OFFICIAL RELEASE**

## V8.4.13 focus
Field diagnostics from V8.4.12 showed that stability and update continuity were healthy, while one elongated physical object could still generate several angle-aware `TRACK-*` hypotheses. V8.4.13 therefore changes the order of truth:

`PIXEL -> AXIS_HYPOTHESIS -> PHYSICAL_OBJECT -> ROD_AUTHENTICITY -> CATEGORY_FIREWALL -> IDENTITY -> QUANTITY`

Key changes:
- Physical Object Truth Resolver V2 consolidates compatible axis hypotheses before TRACK IDs become inventory-relevant.
- Explicit interior-crossing protection preserves two crossed rods.
- RodAuthenticityEvaluator classifies resolved LONG objects as `NON_ROD`, `ROD_UNCERTAIN`, or `TRUSTED_ROD`.
- Only `TRUSTED_ROD` can own LONG quantity or block NORMAL visual-only identity.
- measured physical width is separated from the detector corridor width.
- oriented LONG crop becomes width-adaptive.
- barcode/OCR strong evidence remains independent.
- full-frame rescue remains evidence-only.
- LONG visual and anchor thresholds remain unchanged.
- rolling Java/native/PSS telemetry remains enabled.

Install V8.4.13 directly over V8.4.12 Official. Do **not** uninstall the official app. The package and official signer must remain identical.

See `PHASE4_3_2_33_V8_4_13_PHYSICAL_OBJECT_TRUTH_TRUSTED_ROD_AUTHENTICITY.md`.
