# ARS POS PROJECT CONTINUITY

Baseline pengembangan resmi berikutnya: **Phase 4.3.2.33 / V8.4.13 / 1.4.8 (148)**.

Update chain resmi:
- V8.4.6 Official: 1.4.1 (141)
- V8.4.7: 1.4.2 (142) — IN_PLACE_UPDATE terbukti berhasil
- V8.4.8: 1.4.3 (143) — multi-object physical-instance separation + scanner hardening
- V8.4.9: 1.4.4 (144) — rod anchor identity + cross-lane scene gate + cached long matcher
- V8.4.10: 1.4.5 (145) — anchor-preserving rod shortlist + deterministic identity evidence
- V8.4.11: 1.4.6 (146) — angle-aware physical tracks + LONG-vs-LONG cross-axis separation + live HANDLE/SIDE/TIP anchors
- V8.4.12: 1.4.7 (147) — cross-category identity firewall + bidirectional HANDLE/TIP role consensus + rolling memory telemetry
- V8.4.13: 1.4.8 (148) — Physical Object Truth Resolver V2 + Trusted Rod Authenticity + trusted-track quantity/firewall

Aturan permanen:
- applicationId tetap `com.arspos.anglerriausyndicate`
- ARS POS OFFICIAL RELEASE signer harus tetap identik
- versionCode selalu meningkat
- jangan uninstall official app ketika menguji update berikutnya
- UNKNOWN lebih aman daripada salah SKU
- jangan menurunkan recognition threshold hanya agar produk terlihat dikenali
- axis hypothesis bukan quantity
- hanya final `TRUSTED_ROD` physical object yang boleh menjadi LONG quantity / NORMAL firewall owner
- `NON_ROD` dan `ROD_UNCERTAIN` tidak boleh membuat LONG quantity
- barcode exact / OCR kuat tetap boleh membuktikan produk NORMAL asli
- AMBIGUOUS_CONTAINER/bridge/CROSS_LANE/FULL_FRAME_RESCUE tidak boleh membuat quantity baru
- same SKU + physical object berbeda boleh menjadi quantity > 1
- database tetap version 5 kecuali ada migration yang benar-benar diperlukan

Fokus validasi V8.4.13:
1. satu rod -> satu physical object, bukan empat axis-hypothesis quantities
2. dua rod sejajar -> dua physical objects
3. dua rod silang -> dua physical objects, crossing tidak di-merge
4. ranting/balok/nat lantai -> bukan TRUSTED_ROD
5. ranting + produk NORMAL -> ranting tidak boleh memblokir produk NORMAL
6. false NORMAL pada trusted rod -> visual-only diblokir firewall
7. ambiguous rod identity -> UNKNOWN; threshold tetap
8. full-frame rescue tetap quantityEligible=false
9. telemetry physical-object/authenticity lengkap di ARS DEV CENTER
10. tidak ada force close / incomplete session
11. temporary crop recycle 100%
12. native/PSS tidak tumbuh runaway
13. update 1.4.7 (147) -> 1.4.8 (148) harus IN_PLACE_UPDATE dengan package/signer sama

Lihat `PHASE4_3_2_33_V8_4_13_PHYSICAL_OBJECT_TRUTH_TRUSTED_ROD_AUTHENTICITY.md`.
