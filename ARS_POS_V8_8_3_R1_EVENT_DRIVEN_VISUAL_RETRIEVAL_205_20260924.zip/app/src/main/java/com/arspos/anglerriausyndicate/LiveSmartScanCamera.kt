package com.arspos.anglerriausyndicate

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Paint
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.max

private val LiveGold = Color(0xFFE1BC68)
private val LiveGreen = Color(0xFF69D28A)
private val LiveYellow = Color(0xFFFFD166)
private val LiveGray = Color(0xFFB0B0B0)
private val LiveRed = Color(0xFFE57373)

private class LivePreviewController(private val context: Context) {
    private var provider: ProcessCameraProvider? = null

    fun bind(previewView: PreviewView, owner: androidx.lifecycle.LifecycleOwner, onReady: (Boolean) -> Unit) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            val ok = runCatching {
                val p = future.get()
                provider = p
                val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
                p.unbindAll()
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview)
            }.isSuccess
            onReady(ok)
        }, ContextCompat.getMainExecutor(context))
    }

    fun release() {
        runCatching { provider?.unbindAll() }
        provider = null
    }
}

/**
 * V8.8.3 Event-Driven Visual Retrieval camera with atomic persistent physical-ID handoff.
 *
 * Live boxes and database candidates are advisory. No live track can mutate the
 * cart. onLock returns one camera snapshot which must still pass the production
 * final scanner and Cashier Scan Review.
 */
@Composable
fun LiveSmartScanCamera(
    vm: PosViewModel,
    onLock: (Bitmap, LiveSceneLockSnapshot) -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val controller = remember { LivePreviewController(context) }
    val ledger = remember { LiveSceneLedger() }
    val identityScheduler = remember { LiveIdentityScheduler(maxTargetsPerCycle = 1) }
    val bestFrameStore = remember { LiveBestFrameStore() }

    var previewView by remember { mutableStateOf<PreviewView?>(null) }
    var cameraReady by remember { mutableStateOf(false) }
    var tracks by remember { mutableStateOf<List<LiveSceneTrack>>(emptyList()) }
    var frameWidth by remember { mutableStateOf(1) }
    var frameHeight by remember { mutableStateOf(1) }
    var status by remember { mutableStateOf("Menyiapkan kamera…") }
    var lastSignature by remember { mutableStateOf<IntArray?>(null) }
    var lastAnalysisAt by remember { mutableLongStateOf(0L) }
    var lastTelemetryAt by remember { mutableLongStateOf(0L) }
    var analysisBusy by remember { mutableStateOf(false) }
    var selectedTrackId by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            controller.release()
            ledger.clear()
            identityScheduler.clear()
            bestFrameStore.clear()
        }
    }

    LaunchedEffect(cameraReady, previewView) {
        val pv = previewView ?: return@LaunchedEffect
        if (!cameraReady) return@LaunchedEffect
        status = "Arahkan produk ke kamera"
        val liveStartedAt = System.currentTimeMillis()
        var firstCandidateObservedAt = 0L
        var firstMatchedObservedAt = 0L
        while (isActive) {
            delay(ArsV850Config.LIVE_LOOP_DELAY_MS)
            if (analysisBusy) continue
            val captureStartedAt = System.currentTimeMillis()
            val raw = runCatching { pv.bitmap }.getOrNull() ?: continue
            val frameAcquireMs = System.currentTimeMillis() - captureStartedAt
            val liveFrame = scaleLiveFrame(raw, 640)
            val signature = LiveFrameDifference.signature(liveFrame)
            val sceneChange = LiveFrameDifference.score(lastSignature, signature)
            lastSignature = signature
            val now = System.currentTimeMillis()
            val analysisGapMs = if (lastAnalysisAt > 0L) now - lastAnalysisAt else 0L
            val periodicRefresh = now - lastAnalysisAt >= ArsV850Config.LIVE_STABLE_REFRESH_MS
            val changed = sceneChange >= 0.030f
            if (!changed && !periodicRefresh) {
                recycleFramePair(raw, liveFrame)
                continue
            }

            analysisBusy = true
            lastAnalysisAt = now
            try {
                val identityTargets = identityScheduler.selectTargets(
                    tracks = tracks,
                    sceneChange = sceneChange,
                    nowMs = now,
                    selectedTrackId = selectedTrackId
                )
                val analysisStarted = System.currentTimeMillis()
                val detections = withContext(Dispatchers.Default) {
                    vm.liveScenePreview(
                        bitmap = liveFrame,
                        identityTargets = identityTargets,
                        identityBitmap = raw.takeIf { identityTargets.any { target -> target.stage == LiveIdentityStage.HIGH_RES } }
                    )
                }
                val analysisDurationMs = System.currentTimeMillis() - analysisStarted
                frameWidth = liveFrame.width
                frameHeight = liveFrame.height
                tracks = ledger.update(detections)
                if (selectedTrackId != null && tracks.none { it.trackId == selectedTrackId && it.missingFrames == 0 }) {
                    selectedTrackId = null
                }
                bestFrameStore.consider(raw, liveFrame, tracks, sceneChange, System.currentTimeMillis())

                val matched = tracks.count { it.state == LiveSceneTrack.STATE_MATCHED }
                val candidate = tracks.count { it.state == LiveSceneTrack.STATE_CANDIDATE }
                val unknown = tracks.count { it.state == LiveSceneTrack.STATE_UNKNOWN }
                val locked = tracks.count { it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED }
                val observedNow = System.currentTimeMillis()
                if ((candidate > 0 || matched > 0) && firstCandidateObservedAt == 0L) firstCandidateObservedAt = observedNow
                if (matched > 0 && firstMatchedObservedAt == 0L) firstMatchedObservedAt = observedNow
                status = when {
                    tracks.isEmpty() -> "Belum ada objek stabil"
                    locked == 0 -> "${tracks.size} objek terdeteksi • tahan stabil sampai terkunci"
                    matched > 0 -> "$locked terkunci • $matched dikenali • $candidate kandidat"
                    candidate > 0 -> "$locked terkunci • $candidate kandidat • evidence sedang dipilih"
                    identityTargets.any { it.stage == LiveIdentityStage.HIGH_RES } -> "$locked terkunci • mengambil bukti resolusi tinggi"
                    else -> "$locked objek terkunci • mencari kandidat database"
                }
                if (now - lastTelemetryAt >= 2_000L) {
                    lastTelemetryAt = now
                    ArsFlightRecorder.event(
                        "LIVE_SCENE_UPDATE",
                        "V8.8.3 event-driven object-scoped preview updated",
                        mapOf(
                            "tracks" to tracks.size,
                            "matched" to matched,
                            "candidate" to candidate,
                            "unknown" to unknown,
                            "sceneChange" to sceneChange,
                            "analysisDurationMs" to analysisDurationMs,
                            "frameAcquireMs" to frameAcquireMs,
                            "analysisGapMs" to analysisGapMs,
                            "identityTargets" to identityTargets.size,
                            "identityStages" to identityTargets.map { it.stage }.distinct().joinToString(","),
                            "selectedTrackId" to (selectedTrackId ?: ""),
                            "lockedTracks" to tracks.count { it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED },
                            "loopDelayMs" to ArsV850Config.LIVE_LOOP_DELAY_MS,
                            "stableRefreshMs" to ArsV850Config.LIVE_STABLE_REFRESH_MS,
                            "quantityPreview" to tracks.count { it.quantityPreviewEligible },
                            "stableTracks" to tracks.count { it.hitStreak >= 2 && it.missingFrames == 0 },
                            "firstCandidateMs" to if (firstCandidateObservedAt > 0L) firstCandidateObservedAt - liveStartedAt else 0L,
                            "firstMatchedMs" to if (firstMatchedObservedAt > 0L) firstMatchedObservedAt - liveStartedAt else 0L,
                            "longAxisTracked" to tracks.count { it.proposalType == ScanProposal.TYPE_LONG && it.axisConfidence > 0 },
                            "identityAttempts" to detections.count { it.identityAttempted },
                            "ocrRequested" to detections.count { it.ocrRequested },
                            "identityOcrPresent" to detections.count { it.identityOcrPresent },
                            "highResIdentityUsed" to detections.count { it.highResolutionIdentityUsed },
                            "candidateDemotions" to tracks.sumOf { it.candidateDemotions },
                            "ambiguousOcrTriggered" to detections.count { it.ocrGateReason.contains("AMBIGUOUS_VISUAL_REQUIRES_OCR") },
                            "ocrGateReasons" to detections.map { it.ocrGateReason }.distinct().joinToString(","),
                            "topK" to tracks.filter { it.candidateProductIds.isNotEmpty() }.joinToString(";") { track ->
                                "${track.trackId}:${track.candidateProductIds.zip(track.candidateScores).joinToString("/") { pair -> "${pair.first}:${pair.second}" }}"
                            }
                        )
                    )
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (t: Throwable) {
                status = "Live analysis aman dihentikan sementara"
                ArsFlightRecorder.event(
                    "LIVE_SCENE_ERROR",
                    t.message ?: t::class.java.simpleName,
                    mapOf("exception" to t::class.java.name)
                )
            } finally {
                recycleFramePair(raw, liveFrame)
                analysisBusy = false
            }
        }
    }

    Dialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { ctx ->
                    PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FIT_CENTER
                        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                        previewView = this
                        controller.bind(this, owner) { ready ->
                            cameraReady = ready
                            if (!ready) status = "Kamera tidak dapat diinisialisasi"
                        }
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            Canvas(Modifier.fillMaxSize()) {
                val mapping = ScanPreviewMapping.fit(frameWidth, frameHeight, size.width, size.height)
                val labelPaint = Paint().apply {
                    isAntiAlias = true
                    textSize = 28f
                    color = android.graphics.Color.WHITE
                    style = Paint.Style.FILL
                }
                tracks.forEach { track ->
                    val left = mapping.left + track.bounds.left * mapping.scale
                    val top = mapping.top + track.bounds.top * mapping.scale
                    val right = mapping.left + track.bounds.right * mapping.scale
                    val bottom = mapping.top + track.bounds.bottom * mapping.scale
                    val color = when (track.state) {
                        LiveSceneTrack.STATE_MATCHED -> LiveGreen
                        LiveSceneTrack.STATE_CANDIDATE -> LiveYellow
                        LiveSceneTrack.STATE_UNKNOWN -> LiveRed
                        else -> LiveGray
                    }
                    drawRect(
                        color = color,
                        topLeft = androidx.compose.ui.geometry.Offset(left, top),
                        size = androidx.compose.ui.geometry.Size((right - left).coerceAtLeast(1f), (bottom - top).coerceAtLeast(1f)),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                    )
                    val label = when {
                        track.state == LiveSceneTrack.STATE_MATCHED && track.product != null -> "✓ ${track.product.name}"
                        track.state == LiveSceneTrack.STATE_CANDIDATE && track.product != null -> "◐ ${track.product.name}"
                        track.state == LiveSceneTrack.STATE_UNKNOWN -> "? OBJEK"
                        else -> track.trackId
                    }.take(34)
                    drawContext.canvas.nativeCanvas.drawText(label, left + 4f, max(top - 8f, mapping.top + 30f), labelPaint)
                }
            }

            Column(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.72f))
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Text("ARS SMART SCAN LIVE", color = LiveGold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    "V8.8.3 • Detect Many → Identify Selectively → Converge",
                    color = Color.White.copy(alpha = 0.72f),
                    fontSize = 10.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(status, color = Color.White, fontSize = 12.sp)
            }

            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.82f))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (tracks.isNotEmpty()) {
                    val visible = tracks.take(4)
                    Text("OBJECT TARGETS • sentuh untuk prioritas identity", color = Color.White.copy(alpha = 0.70f), fontSize = 8.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        visible.forEach { track ->
                            val selected = selectedTrackId == track.trackId
                            Box(
                                Modifier
                                    .weight(1f)
                                    .clickable { selectedTrackId = track.trackId }
                                    .border(
                                        if (selected) 2.dp else 1.dp,
                                        if (selected) LiveGold else Color.White.copy(alpha = 0.18f),
                                        RoundedCornerShape(7.dp)
                                    )
                                    .padding(6.dp)
                            ) {
                                Column {
                                    Text(track.trackId, color = if (selected) LiveGold else Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    Text(
                                        track.product?.name?.take(15) ?: track.state,
                                        color = when (track.state) {
                                            LiveSceneTrack.STATE_MATCHED -> LiveGreen
                                            LiveSceneTrack.STATE_CANDIDATE -> LiveYellow
                                            LiveSceneTrack.STATE_UNKNOWN -> LiveRed
                                            else -> LiveGray
                                        },
                                        fontSize = 7.sp, maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                    visible.forEach { track ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { selectedTrackId = track.trackId }
                                .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                when (track.state) {
                                    LiveSceneTrack.STATE_MATCHED -> "✓"
                                    LiveSceneTrack.STATE_CANDIDATE -> "◐"
                                    LiveSceneTrack.STATE_UNKNOWN -> "?"
                                    LiveSceneTrack.STATE_OCCLUDED -> "…"
                                    else -> "•"
                                },
                                color = when (track.state) {
                                    LiveSceneTrack.STATE_MATCHED -> LiveGreen
                                    LiveSceneTrack.STATE_CANDIDATE -> LiveYellow
                                    LiveSceneTrack.STATE_UNKNOWN -> LiveRed
                                    else -> LiveGray
                                },
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    if (track.state in setOf(LiveSceneTrack.STATE_MATCHED, LiveSceneTrack.STATE_CANDIDATE)) {
                                        track.product?.name ?: "Objek belum teridentifikasi"
                                    } else "Objek sedang dilacak",
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp,
                                    maxLines = 1
                                )
                                Text(
                                    "${track.trackId} • ${track.physicalState} • ${track.identityDecision} • ${track.lastIdentityStage} • visual ${track.visualScore}% • margin ${track.margin}%",
                                    color = Color.White.copy(alpha = 0.58f),
                                    fontSize = 8.sp,
                                    maxLines = 1
                                )
                                if (track.guidance.isNotBlank()) {
                                    Text(
                                        track.guidance,
                                        color = LiveYellow,
                                        fontSize = 8.sp,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }

                Text(
                    "Live result hanya preview. Quantity final baru dihitung setelah scene dikunci dan lolos Physical Object Truth.",
                    color = Color.White.copy(alpha = 0.60f),
                    fontSize = 9.sp
                )

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onCancel,
                        modifier = Modifier.weight(1f)
                    ) { Text("BATAL") }
                    Button(
                        onClick = {
                            val pv = previewView ?: return@Button
                            val currentSnapshot = runCatching { pv.bitmap }.getOrNull() ?: return@Button
                            val lockedKey = tracks.filter { it.missingFrames == 0 && it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED }
                                .sortedBy { it.trackId }.joinToString("|") { "${it.trackId}:${it.proposalType}" }
                            val bestSnapshot = bestFrameStore.snapshot(lockedKey)
                            val snapshot = bestSnapshot ?: currentSnapshot
                            if (bestSnapshot != null && currentSnapshot !== bestSnapshot && !currentSnapshot.isRecycled) currentSnapshot.recycle()
                            ArsFlightRecorder.event(
                                "LIVE_SCENE_LOCK",
                                "Operator locked scene for final Smart Scan",
                                mapOf(
                                    "liveTracks" to tracks.size,
                                    "liveMatched" to tracks.count { it.state == LiveSceneTrack.STATE_MATCHED },
                                    "liveCandidates" to tracks.count { it.product != null },
                                    "bestEvidenceFrameUsed" to (bestSnapshot != null),
                                    "candidateDemotions" to tracks.sumOf { it.candidateDemotions }
                                )
                            )
                            onLock(
                                snapshot,
                                LiveSceneLockSnapshot(
                                    frameWidth = frameWidth,
                                    frameHeight = frameHeight,
                                    lockedAtMs = System.currentTimeMillis(),
                                    sceneEpoch = lastAnalysisAt,
                                    tracks = tracks.map { it.copy(bounds = android.graphics.Rect(it.bounds)) },
                                    decisions = tracks.filter { it.missingFrames == 0 }.map { it.toPersistentDecisionState() }
                                )
                            )
                        },
                        enabled = cameraReady && !analysisBusy &&
                            PhysicalObjectStateMachine.canLockScene(tracks.map { it.physicalState }),
                        modifier = Modifier.weight(1.6f),
                        colors = ButtonDefaults.buttonColors(containerColor = LiveGold)
                    ) {
                        Text("KUNCI & TINJAU HASIL", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

private fun recycleFramePair(raw: Bitmap, analysis: Bitmap) {
    if (analysis !== raw && !analysis.isRecycled) analysis.recycle()
    if (!raw.isRecycled) raw.recycle()
}

private fun scaleLiveFrame(source: Bitmap, maxSide: Int): Bitmap {
    val largest = max(source.width, source.height)
    if (largest <= maxSide) return source
    val scale = maxSide.toFloat() / largest.toFloat()
    val width = (source.width * scale).toInt().coerceAtLeast(1)
    val height = (source.height * scale).toInt().coerceAtLeast(1)
    return Bitmap.createScaledBitmap(source, width, height, true)
}
