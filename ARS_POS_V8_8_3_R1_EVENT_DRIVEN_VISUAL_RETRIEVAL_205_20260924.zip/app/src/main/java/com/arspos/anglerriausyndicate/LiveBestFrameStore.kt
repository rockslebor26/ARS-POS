package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max

/** One bounded best-quality full scene snapshot for the current locked object set. */
class LiveBestFrameStore {
    private var frame: Bitmap? = null
    private var quality: Int = Int.MIN_VALUE
    private var continuityKey: String = ""
    private var storedAtMs: Long = 0L

    fun consider(raw: Bitmap, analysis: Bitmap, tracks: List<LiveSceneTrack>, sceneChange: Float, nowMs: Long) {
        val locked = tracks.filter { it.missingFrames == 0 && it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED }
        if (locked.isEmpty()) return
        val key = locked.sortedBy { it.trackId }.joinToString("|") { "${it.trackId}:${it.proposalType}" }
        val q = qualityScore(analysis, locked, sceneChange)
        val stale = nowMs - storedAtMs > 2_500L
        if (frame == null || key != continuityKey || q > quality + 4 || stale) {
            val replacement = boundedCopy(raw, 1280) ?: return
            frame?.takeIf { !it.isRecycled }?.recycle()
            frame = replacement
            quality = q
            continuityKey = key
            storedAtMs = nowMs
        }
    }

    fun snapshot(expectedKey: String): Bitmap? {
        val source = frame ?: return null
        if (source.isRecycled || continuityKey != expectedKey) return null
        return runCatching { source.copy(Bitmap.Config.ARGB_8888, false) }.getOrNull()
    }

    fun clear() {
        frame?.takeIf { !it.isRecycled }?.recycle()
        frame = null
        quality = Int.MIN_VALUE
        continuityKey = ""
        storedAtMs = 0L
    }

    private fun qualityScore(bitmap: Bitmap, tracks: List<LiveSceneTrack>, sceneChange: Float): Int {
        val gridX = 16
        val gridY = 20
        var edge = 0L
        var exposure = 0L
        var count = 0
        var previousRow = IntArray(gridX)
        for (gy in 0 until gridY) {
            val row = IntArray(gridX)
            val y = ((gy + 0.5f) * bitmap.height / gridY).toInt().coerceIn(0, bitmap.height - 1)
            for (gx in 0 until gridX) {
                val x = ((gx + 0.5f) * bitmap.width / gridX).toInt().coerceIn(0, bitmap.width - 1)
                val p = bitmap.getPixel(x, y)
                val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
                val l = (r * 30 + g * 59 + b * 11) / 100
                row[gx] = l
                exposure += 255 - abs(l - 128)
                if (gx > 0) edge += abs(l - row[gx - 1])
                if (gy > 0) edge += abs(l - previousRow[gx])
                count++
            }
            previousRow = row
        }
        val imageScore = if (count == 0) 0 else ((edge / count) + (exposure / count) / 4).toInt()
        val stability = ((1f - (sceneChange / 0.10f).coerceIn(0f, 1f)) * 80f).toInt()
        val identity = tracks.maxOfOrNull { it.bestVisualScore + it.bestMargin.coerceAtLeast(0) } ?: 0
        return imageScore + stability + identity
    }

    private fun boundedCopy(source: Bitmap, maxSide: Int): Bitmap? = runCatching {
        val largest = max(source.width, source.height)
        if (largest <= maxSide) source.copy(Bitmap.Config.ARGB_8888, false) else {
            val scale = maxSide.toFloat() / largest.toFloat()
            Bitmap.createScaledBitmap(
                source,
                (source.width * scale).toInt().coerceAtLeast(1),
                (source.height * scale).toInt().coerceAtLeast(1),
                true
            )
        }
    }.getOrNull()
}
