package com.arspos.anglerriausyndicate

/**
 * Tells the operator what evidence is missing instead of repeatedly running the
 * same expensive recognition pass against an unchanged weak frame.
 */
object GuidedEvidencePolicy {
    const val NONE = ""

    fun message(
        physicalState: String,
        identityState: String,
        proposalType: String,
        visualScore: Int,
        margin: Int,
        missingFrames: Int,
        identityStage: String = LiveIdentityStage.NONE,
        identityOcrPresent: Boolean = false
    ): String = when {
        missingFrames > 0 -> "Tampilkan kembali objek ke kamera"
        physicalState != PhysicalObjectStateMachine.STATE_LOCKED -> "Tahan objek stabil sampai kotak terkunci"
        identityState == "CONFIRMED_PREVIEW" -> NONE
        identityStage == LiveIdentityStage.HIGH_RES && !identityOcrPresent ->
            "Bukti tetap ambigu; ubah sudut agar logo/model atau bentuk pembeda terlihat"
        identityStage == LiveIdentityStage.OCR && !identityOcrPresent ->
            "Teks pembeda belum terbaca; tahan stabil atau tampilkan sisi berlogo/model"
        identityState == "AMBIGUOUS" && proposalType == ScanProposal.TYPE_LONG ->
            "Arahkan kamera ke HANDLE / logo / kode model joran"
        identityState == "AMBIGUOUS" && margin < LiveIdentityPolicy.AMBIGUOUS_VISUAL_MARGIN ->
            "Arahkan kamera ke logo, nama model, atau varian produk"
        visualScore < LiveIdentityPolicy.MIN_VISUAL_FOR_NORMAL_IDENTITY ->
            "Dekatkan kamera dan pastikan produk tajam serta tidak silau"
        else -> "Putar sedikit produk agar label/model terlihat"
    }
}
