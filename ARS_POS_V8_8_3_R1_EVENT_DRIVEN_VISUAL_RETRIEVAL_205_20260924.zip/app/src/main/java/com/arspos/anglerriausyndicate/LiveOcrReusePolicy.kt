package com.arspos.anglerriausyndicate

/** V8.8.3 object-scoped compute-budget policy for reusing OCR on the same live object hypothesis. */
object LiveOcrReusePolicy {
    const val IDENTITY_TTL_MS = 4_000L
    const val EMPTY_TTL_MS = 3_000L
    const val VISUAL_IMPROVEMENT_RESCAN = 3

    fun mayReuse(
        ageMs: Long,
        hasIdentityText: Boolean,
        cachedVisualScore: Int,
        currentVisualScore: Int
    ): Boolean {
        val ttl = if (hasIdentityText) IDENTITY_TTL_MS else EMPTY_TTL_MS
        if (ageMs !in 0..ttl) return false
        // A materially better frame earns a fresh OCR attempt immediately.
        return currentVisualScore <= cachedVisualScore + VISUAL_IMPROVEMENT_RESCAN
    }
}
