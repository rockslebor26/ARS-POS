package com.arspos.anglerriausyndicate

/** Event-driven per-object evidence scheduling for V8.8.3. */
object LiveIdentityStage {
    const val NONE = "NONE"
    const val RETRIEVE = "RETRIEVE"
    const val OCR = "OCR"
    const val HIGH_RES = "HIGH_RES"
    const val GUIDANCE = "GUIDANCE"
}

/**
 * Pure scheduling snapshot. Android graphics objects are intentionally excluded
 * so the scheduler can be regression-tested on the local JVM without depending
 * on mockable android.jar behavior.
 */
data class LiveIdentityObservation(
    val trackId: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val proposalType: String,
    val productIdHint: Long = 0L,
    val visualScore: Int = 0,
    val firstSeenAtMs: Long = 0L,
    val missingFrames: Int = 0,
    val state: String = LiveSceneTrack.STATE_UNKNOWN,
    val physicalState: String = PhysicalObjectStateMachine.STATE_DETECTED,
    val identityAttemptCount: Int = 0,
    val lastIdentityStage: String = LiveIdentityStage.NONE
)

data class LiveIdentityTarget(
    val trackId: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val proposalType: String,
    val stage: String,
    val productIdHint: Long = 0L,
    val force: Boolean = false
) {
    fun width(): Int = (right - left).coerceAtLeast(0)
    fun height(): Int = (bottom - top).coerceAtLeast(0)
}

/**
 * Detection may run for every object. Expensive identity is granted to at most
 * [maxTargetsPerCycle] locked physical objects, so multi-object scenes cannot
 * multiply OCR cost. A skipped pass is not negative identity evidence.
 */
class LiveIdentityScheduler(
    private val maxTargetsPerCycle: Int = 1,
    private val retrieveCooldownMs: Long = 450L,
    private val ocrCooldownMs: Long = 900L,
    private val highResCooldownMs: Long = 1_250L,
    private val guidanceCooldownMs: Long = 2_500L
) {
    private data class State(
        var stage: String = LiveIdentityStage.RETRIEVE,
        var lastAttemptAtMs: Long = 0L,
        var observedAttemptCount: Int = 0
    )

    private val states = LinkedHashMap<String, State>()

    fun clear() = states.clear()

    /** Android-facing adapter. All scheduling decisions happen in the pure path below. */
    fun selectTargets(
        tracks: List<LiveSceneTrack>,
        sceneChange: Float,
        nowMs: Long,
        selectedTrackId: String? = null
    ): List<LiveIdentityTarget> = selectObservations(
        observations = tracks.map { track ->
            LiveIdentityObservation(
                trackId = track.trackId,
                left = track.bounds.left,
                top = track.bounds.top,
                right = track.bounds.right,
                bottom = track.bounds.bottom,
                proposalType = track.proposalType,
                productIdHint = track.product?.id ?: track.bestEvidenceProductId,
                visualScore = track.visualScore,
                firstSeenAtMs = track.firstSeenAtMs,
                missingFrames = track.missingFrames,
                state = track.state,
                physicalState = track.physicalState,
                identityAttemptCount = track.identityAttemptCount,
                lastIdentityStage = track.lastIdentityStage
            )
        },
        sceneChange = sceneChange,
        nowMs = nowMs,
        selectedTrackId = selectedTrackId
    )

    /** Pure JVM-testable scheduling path. */
    fun selectObservations(
        observations: List<LiveIdentityObservation>,
        sceneChange: Float,
        nowMs: Long,
        selectedTrackId: String? = null
    ): List<LiveIdentityTarget> {
        val visibleIds = observations.filter { it.missingFrames == 0 }.map { it.trackId }.toSet()
        states.keys.retainAll(visibleIds)

        val eligible = observations.filter {
            it.missingFrames == 0 &&
                it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED &&
                it.state != LiveSceneTrack.STATE_MATCHED
        }
        if (eligible.isEmpty()) return emptyList()

        val ordered = eligible.sortedWith(
            compareByDescending<LiveIdentityObservation> { it.trackId == selectedTrackId }
                .thenByDescending { it.state == LiveSceneTrack.STATE_CANDIDATE }
                .thenByDescending { it.visualScore }
                .thenBy { it.firstSeenAtMs }
        )
        val result = ArrayList<LiveIdentityTarget>(maxTargetsPerCycle)
        for (observation in ordered) {
            if (result.size >= maxTargetsPerCycle) break
            val state = states.getOrPut(observation.trackId) { State() }
            if (observation.identityAttemptCount > state.observedAttemptCount) {
                state.observedAttemptCount = observation.identityAttemptCount
                state.stage = nextStage(observation)
            }
            if (state.stage == LiveIdentityStage.GUIDANCE && sceneChange >= 0.055f) {
                state.stage = LiveIdentityStage.RETRIEVE
            }
            val forced = observation.trackId == selectedTrackId
            val cooldown = when (state.stage) {
                LiveIdentityStage.RETRIEVE -> retrieveCooldownMs
                LiveIdentityStage.OCR -> ocrCooldownMs
                LiveIdentityStage.HIGH_RES -> highResCooldownMs
                else -> guidanceCooldownMs
            }
            val due = forced || state.lastAttemptAtMs == 0L || nowMs - state.lastAttemptAtMs >= cooldown
            if (!due || state.stage == LiveIdentityStage.GUIDANCE || state.stage == LiveIdentityStage.NONE) continue
            state.lastAttemptAtMs = nowMs
            result += LiveIdentityTarget(
                trackId = observation.trackId,
                left = observation.left,
                top = observation.top,
                right = observation.right,
                bottom = observation.bottom,
                proposalType = observation.proposalType,
                stage = state.stage,
                productIdHint = observation.productIdHint,
                force = forced
            )
        }
        return result
    }

    /**
     * Evidence escalation is deterministic: RETRIEVE -> OCR -> HIGH_RES -> GUIDANCE.
     * A weak/empty retrieval result must not skip OCR, because OCR is an independent
     * modality that can recover exact package identity (for example LIGHTS).
     */
    private fun nextStage(observation: LiveIdentityObservation): String = when {
        observation.state == LiveSceneTrack.STATE_MATCHED -> LiveIdentityStage.NONE
        observation.lastIdentityStage == LiveIdentityStage.RETRIEVE -> LiveIdentityStage.OCR
        observation.lastIdentityStage == LiveIdentityStage.OCR -> LiveIdentityStage.HIGH_RES
        observation.lastIdentityStage == LiveIdentityStage.HIGH_RES -> LiveIdentityStage.GUIDANCE
        observation.identityAttemptCount <= 0 -> LiveIdentityStage.RETRIEVE
        else -> LiveIdentityStage.GUIDANCE
    }
}
