package com.arspos.anglerriausyndicate

/** Advisory live identity snapshot handed to final recall; it never creates quantity. */
data class PersistentDecisionState(
    val persistentPhysicalId: String,
    val candidateProductId: Long,
    val visualScore: Int,
    val margin: Int,
    val decision: String,
    val lastIdentityStage: String,
    val identityAttempts: Int,
    val candidateDemotions: Int,
    val acceptedPreview: Boolean
)

fun LiveSceneTrack.toPersistentDecisionState() = PersistentDecisionState(
    persistentPhysicalId = trackId,
    candidateProductId = product?.id ?: bestEvidenceProductId,
    visualScore = visualScore,
    margin = margin,
    decision = identityDecision,
    lastIdentityStage = lastIdentityStage,
    identityAttempts = identityAttemptCount,
    candidateDemotions = candidateDemotions,
    acceptedPreview = state == LiveSceneTrack.STATE_MATCHED
)
