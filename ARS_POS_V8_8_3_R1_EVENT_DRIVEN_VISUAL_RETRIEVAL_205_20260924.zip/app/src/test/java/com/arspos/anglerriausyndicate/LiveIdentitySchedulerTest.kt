package com.arspos.anglerriausyndicate

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LiveIdentitySchedulerTest {
    private fun observation(
        id: String,
        physical: String = PhysicalObjectStateMachine.STATE_LOCKED,
        state: String = LiveSceneTrack.STATE_UNKNOWN,
        attempts: Int = 0,
        lastStage: String = LiveIdentityStage.NONE,
        score: Int = 0,
        productIdHint: Long = 0L
    ) = LiveIdentityObservation(
        trackId = id,
        left = 10,
        top = 10,
        right = 110,
        bottom = 160,
        proposalType = ScanProposal.TYPE_NORMAL,
        productIdHint = productIdHint,
        visualScore = score,
        firstSeenAtMs = 100L,
        missingFrames = 0,
        state = state,
        physicalState = physical,
        identityAttemptCount = attempts,
        lastIdentityStage = lastStage
    )

    @Test fun identityWaitsForPhysicalLockAndBudgetsOneObject() {
        val scheduler = LiveIdentityScheduler(maxTargetsPerCycle = 1)
        assertTrue(
            scheduler.selectObservations(
                listOf(observation("A", PhysicalObjectStateMachine.STATE_DETECTED)),
                0f,
                1_000L
            ).isEmpty()
        )
        val targets = scheduler.selectObservations(listOf(observation("A"), observation("B")), 0f, 1_000L)
        assertEquals(1, targets.size)
        assertEquals(LiveIdentityStage.RETRIEVE, targets.single().stage)
    }

    @Test fun evidenceEscalatesRetrieveToOcrThenHighRes() {
        val scheduler = LiveIdentityScheduler(
            maxTargetsPerCycle = 1,
            retrieveCooldownMs = 0L,
            ocrCooldownMs = 0L,
            highResCooldownMs = 0L
        )
        scheduler.selectObservations(listOf(observation("A")), 0f, 1_000L)

        val afterRetrieve = observation(
            "A",
            state = LiveSceneTrack.STATE_CANDIDATE,
            attempts = 1,
            lastStage = LiveIdentityStage.RETRIEVE,
            score = 82,
            productIdHint = 6L
        )
        assertEquals(
            LiveIdentityStage.OCR,
            scheduler.selectObservations(listOf(afterRetrieve), 0f, 1_001L).single().stage
        )

        val afterOcr = afterRetrieve.copy(identityAttemptCount = 2, lastIdentityStage = LiveIdentityStage.OCR)
        assertEquals(
            LiveIdentityStage.HIGH_RES,
            scheduler.selectObservations(listOf(afterOcr), 0f, 1_002L).single().stage
        )
    }

    @Test fun matchedIdentityIsFrozenAndManualTargetWins() {
        val scheduler = LiveIdentityScheduler(maxTargetsPerCycle = 1)
        val matched = observation("A", state = LiveSceneTrack.STATE_MATCHED)
        val other = observation("B")
        val targets = scheduler.selectObservations(listOf(matched, other), 0f, 1_000L, selectedTrackId = "B")
        assertEquals("B", targets.single().trackId)
        assertTrue(scheduler.selectObservations(listOf(matched), 0f, 2_000L).isEmpty())
    }

    @Test fun guidanceRequiresNewViewBeforeRestartingRetrieval() {
        val scheduler = LiveIdentityScheduler(
            maxTargetsPerCycle = 1,
            retrieveCooldownMs = 0L,
            ocrCooldownMs = 0L,
            highResCooldownMs = 0L,
            guidanceCooldownMs = 0L
        )
        scheduler.selectObservations(listOf(observation("A")), 0f, 1_000L)
        scheduler.selectObservations(
            listOf(observation("A", attempts = 1, lastStage = LiveIdentityStage.RETRIEVE)),
            0f,
            1_001L
        )
        scheduler.selectObservations(
            listOf(observation("A", attempts = 2, lastStage = LiveIdentityStage.OCR)),
            0f,
            1_002L
        )
        val guided = observation("A", attempts = 3, lastStage = LiveIdentityStage.HIGH_RES)
        assertTrue(scheduler.selectObservations(listOf(guided), 0.01f, 1_003L).isEmpty())
        assertEquals(
            LiveIdentityStage.RETRIEVE,
            scheduler.selectObservations(listOf(guided), 0.08f, 1_004L).single().stage
        )
    }
}
