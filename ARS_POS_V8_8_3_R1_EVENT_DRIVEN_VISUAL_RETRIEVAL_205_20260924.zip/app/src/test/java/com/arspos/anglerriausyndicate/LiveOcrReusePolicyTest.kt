package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test

class LiveOcrReusePolicyTest {
    @Test fun identityOcrMayBeReusedInsideBoundedTtl() {
        assertTrue(LiveOcrReusePolicy.mayReuse(3_500, true, 78, 79))
        assertFalse(LiveOcrReusePolicy.mayReuse(4_100, true, 78, 79))
    }

    @Test fun negativeOcrIsCachedButBetterFrameForcesRefresh() {
        assertTrue(LiveOcrReusePolicy.mayReuse(2_500, false, 75, 75))
        assertFalse(LiveOcrReusePolicy.mayReuse(3_100, false, 75, 75))
        assertFalse(LiveOcrReusePolicy.mayReuse(300, true, 75, 80))
        assertFalse(LiveOcrReusePolicy.mayReuse(300, false, 75, 80))
    }
}
