# ARS POS 1.10.5 (205) — Phase 4.3.5.3 / V8.8.3

**Event-Driven Visual Retrieval + Live/Final Decision Convergence**

ARS POS Smart Scan now follows an event-driven decision order:

`detect many → physical lock → identify selectively → Top-K retrieval → discriminative evidence → candidate memory → exact final verification → physical quantity → cashier review`.

The key V8.8.3 change is compute scheduling. Detection/tracking remains continuous, but OCR and high-resolution identity are no longer globally repeated for every track. A per-object scheduler grants expensive evidence work to locked targets, preserves candidate identity across perception-only frames, escalates evidence only when the previous modality is insufficient, and hands the advisory live decision into final recall without allowing live state to create quantity.

## Release invariants

- Package: `com.arspos.anglerriausyndicate`
- versionName/versionCode: `1.10.5 / 205`
- Room database: `v5`, no destructive migration
- Cloud Identity: `SHADOW`
- Self Learning: `ACTIVE_CONFIRMED_ONLY`
- ARS AI Engineer: `DEV_CENTER_DIAGNOSTIC_ONLY`, outside critical scan path
- Recognition thresholds: unchanged (14/14)
- Official signer SHA-256: `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`
- Update method: in-place only; do not uninstall production data.

See `PHASE4_3_5_3_V8_8_3_EVENT_DRIVEN_VISUAL_RETRIEVAL.md` and `RELEASE_205.md`.
