# Current Release Candidate

ARS POS **1.10.5 (205)** — Phase **4.3.5.3** / **V8.8.3 Event-Driven Visual Retrieval + Live/Final Decision Convergence**.

Primary acceptance focus: fast physical perception, stable object lock, bounded one-object-at-a-time identity work, persistent Top-K candidate memory, no candidate demotion from unscheduled passes, single-flight OCR, negative OCR reuse, high-resolution ambiguity recovery, best-frame final lock, and measured live/final candidate convergence.

Recognition thresholds, package, Room v5 and official signer policy are unchanged. Cloud Identity remains `SHADOW`; Self Learning remains `ACTIVE_CONFIRMED_ONLY`; ARS AI Engineer remains `DEV_CENTER_DIAGNOSTIC_ONLY` and outside the automatic cashier scan path.

Install only as an in-place update from the official signed application. Release 205 is not device-finished until the supplied release workflow builds successfully and real-device regression evidence is reviewed.
