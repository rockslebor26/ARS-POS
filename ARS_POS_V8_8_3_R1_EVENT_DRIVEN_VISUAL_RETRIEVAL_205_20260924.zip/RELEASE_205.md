# ARS POS 1.10.5 (205) — V8.8.3 Release 205

Phase: `4.3.5.3`
Engine: `V8.8.3`
Revision: `EVENT_DRIVEN_VISUAL_RETRIEVAL_LIVE_FINAL_CONVERGENCE`

This source is an in-place successor to official 1.10.4 (204). Do not uninstall the production application to test this release. Build and sign through the official release workflow so the package ID and certificate fingerprint remain identical.

Release 205 changes the Smart Scan critical path from global repeated identity work to object-scoped event-driven identity. It adds candidate persistence, single-flight/negative OCR reuse, best-frame selection, adaptive/high-resolution evidence acquisition, manual multi-object target priority and live/final candidate convergence. Exact recognition and quantity are still controlled by the existing production recognition thresholds, physical truth gates and Safety Kernel.

Static source validation must pass before build. The signed APK must then pass real-device regression using single NORMAL, visually ambiguous NORMAL, two-object NORMAL, LONG/rod, crossing LONG, and repeated enter/exit scenes. Record `firstCandidateMs`, `firstMatchedMs`, `identityTargets`, `identityAttempts`, `ocrRequested`, `highResIdentityUsed`, `candidateDemotions`, `topK`, and `SCAN_LIVE_FINAL_CONVERGENCE` in the diagnostic report.


## R1 — regression/build fix

The first V8.8.3/205 GitHub run did not produce an APK because the combined regression/build job failed after Android compilation. R1 keeps versionCode 205 because 205 was never released/installed. It hardens the event scheduler and local JVM regression boundary without changing production recognition thresholds.

R1 changes:
- pure `LiveIdentityObservation` scheduler test contract; no `android.graphics.Rect` construction in local JVM tests;
- deterministic `RETRIEVE -> OCR -> HIGH_RES -> GUIDANCE` evidence escalation;
- workflow splits physical-truth tests, Android unit tests, and release assembly into separate steps so future failures identify the exact stage;
- release revision reports `EVENT_DRIVEN_VISUAL_RETRIEVAL_LIVE_FINAL_CONVERGENCE_R1_BUILD_FIX`.
