# ARS POS Project Continuity

Current source candidate: **1.10.5 (205) / Phase 4.3.5.3 / V8.8.3 — Event-Driven Visual Retrieval + Live/Final Decision Convergence**.

Direct source predecessor: **1.10.4 (204) / Phase 4.3.5.2 / V8.8.2 — Unified Object Decision Pipeline**. Package, Room v5, official signer policy and all 14 recognition thresholds remain unchanged.

## Current architecture direction

Smart Scan separates continuous perception from expensive identity. The production order is: physical localization/tracking → stable lock → one object receives an identity budget → bounded Top-K retrieval → discriminative OCR/high-resolution evidence only when required → temporal candidate memory → final exact re-rank/decision → physical quantity safety → cashier review.

V8.8.3 prevents unscheduled live frames from becoming negative identity evidence, adds positive/negative OCR reuse and single-flight suppression, preserves best evidence, allows the operator to prioritize an object in multi-object scenes, and carries advisory live identity into final recall. Final recognition remains authoritative and quantity is never granted by live preview, Cloud Identity or ARS AI Engineer.

Cloud Identity remains `SHADOW`; Self Learning remains `ACTIVE_CONFIRMED_ONLY`; ARS AI Engineer remains `DEV_CENTER_DIAGNOSTIC_ONLY`.

## Finish criteria

The project is not finished until a signed release demonstrates on the target device: low-latency first candidate, stable candidate persistence, correct exact-SKU identity, no false NORMAL acceptance, no duplicate physical quantity, safe LONG/rod authenticity and anchor ownership, bounded memory/native pressure, live/final convergence, and safe in-place upgrade behavior.
