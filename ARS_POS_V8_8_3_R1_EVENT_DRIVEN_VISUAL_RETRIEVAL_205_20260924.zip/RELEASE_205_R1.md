# ARS POS 1.10.5 (205) — V8.8.3 R1 Build Fix

Phase 4.3.5.3 / V8.8.3 remains the production target. This R1 corrects the regression/build contract discovered by the first GitHub Actions run before an APK was produced.

- Package: `com.arspos.anglerriausyndicate`
- Version: `1.10.5 (205)`
- Engine: `V8.8.3`
- Revision: `EVENT_DRIVEN_VISUAL_RETRIEVAL_LIVE_FINAL_CONVERGENCE_R1_BUILD_FIX`
- Database: v5
- Cloud Identity: SHADOW
- Self Learning: ACTIVE_CONFIRMED_ONLY
- AI Engineer: DEV_CENTER_DIAGNOSTIC_ONLY
- Recognition thresholds: unchanged (14/14)
- Quantity safety: unchanged
- Install policy: in-place from official 204; do not uninstall.

## Build fix

1. Scheduler regression tests no longer construct Android `Rect` on the local JVM.
2. Retrieval failure no longer skips OCR; escalation is deterministic `RETRIEVE -> OCR -> HIGH_RES -> GUIDANCE`.
3. GitHub workflow separates JVM physical-truth tests, Android unit tests, and release assembly for precise diagnostics.
