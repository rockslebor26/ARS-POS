package com.arspos.anglerriausyndicate

import android.graphics.Rect

/** Identity ROI is allowed to differ from the detector ROI without changing physical ownership. */
object LiveIdentityRoiPolicy {
    fun forStage(bounds: Rect, frameWidth: Int, frameHeight: Int, stage: String): Rect {
        val padding = when (stage) {
            LiveIdentityStage.HIGH_RES -> 0.08f
            LiveIdentityStage.OCR -> 0.04f
            else -> 0.02f
        }
        val dx = (bounds.width() * padding).toInt().coerceAtLeast(2)
        val dy = (bounds.height() * padding).toInt().coerceAtLeast(2)
        return Rect(
            (bounds.left - dx).coerceIn(0, frameWidth - 1),
            (bounds.top - dy).coerceIn(0, frameHeight - 1),
            (bounds.right + dx).coerceIn(1, frameWidth),
            (bounds.bottom + dy).coerceIn(1, frameHeight)
        )
    }

    fun map(bounds: Rect, fromWidth: Int, fromHeight: Int, toWidth: Int, toHeight: Int): Rect {
        val sx = toWidth.toFloat() / fromWidth.coerceAtLeast(1).toFloat()
        val sy = toHeight.toFloat() / fromHeight.coerceAtLeast(1).toFloat()
        return Rect(
            (bounds.left * sx).toInt().coerceIn(0, toWidth - 1),
            (bounds.top * sy).toInt().coerceIn(0, toHeight - 1),
            (bounds.right * sx).toInt().coerceIn(1, toWidth),
            (bounds.bottom * sy).toInt().coerceIn(1, toHeight)
        )
    }
}
