package com.arspos.anglerriausyndicate.data

import android.graphics.Bitmap
import com.arspos.anglerriausyndicate.SmartProductInput
import com.arspos.anglerriausyndicate.VisualProductMatch
import com.arspos.anglerriausyndicate.data.db.ProductEntity
import kotlin.math.roundToInt

/**
 * Phase 4.3.2.8: ARS Recognition Engine V3.
 *
 * Decision model:
 * 1) Barcode exact match is the strongest identity proof.
 * 2) OCR is normalized and evaluated using distinctive identity tokens.
 * 3) Visual evidence is aggregated across many master frames, not one frame.
 * 4) A large score is never enough by itself: the winner must also beat the
 *    second candidate by a meaningful margin.
 * 5) The final score is an identity-confidence score, not a raw OCR score.
 */
object SmartRecognitionEngine {
    data class Result(
        val match: VisualProductMatch?,
        val visualScore: Int,
        val textScore: Int,
        val finalScore: Int,
        val ocrText: String,
        val barcode: String = "",
        val reason: String,
        val candidates: List<RecognitionCandidate> = emptyList()
    )

    private const val ACCEPT_BARCODE = 92
    private const val ACCEPT_DISTINCTIVE_TEXT = 84
    private const val ACCEPT_TEXT_WITH_VISUAL = 72
    private const val ACCEPT_VISUAL = 86
    private const val MIN_VISUAL_SUPPORT = 45
    private const val MIN_MARGIN = 12

    suspend fun recognize(
        crop: Bitmap,
        products: List<ProductEntity>,
        references: List<VisualProductMatch>,
        ocr: SmartProductInput.Draft
    ): Result {
        if (products.isEmpty()) {
            return Result(null, 0, 0, 0, ocr.rawText, ocr.barcode, "Katalog kosong")
        }

        val normalizedOcr = normalize(ocr.rawText)
        val detectedBarcode = normalizeCode(ocr.barcode)
        val detectedModel = normalizeCode(ocr.modelCode)
        val refsByProduct = references.groupBy { it.product.id }

        val candidates = products.map { product ->
            val refs = refsByProduct[product.id].orEmpty().sortedByDescending { it.score }
            val visual = aggregateVisual(refs)
            val text = textScore(product, normalizedOcr, detectedBarcode, detectedModel)
            val final = fuse(visual, text, detectedBarcode, detectedModel, product, refs)
            RecognitionCandidate(
                product = product,
                visualScore = visual,
                textScore = text,
                finalScore = final,
                evidence = evidence(product, visual, text, detectedBarcode, detectedModel, refs),
                hasMaster = refs.isNotEmpty()
            )
        }.sortedWith(
            compareByDescending<RecognitionCandidate> { it.finalScore }
                .thenByDescending { it.textScore }
                .thenByDescending { it.visualScore }
        ).take(5)

        val best = candidates.firstOrNull()
        val second = candidates.getOrNull(1)
        val margin = if (best != null && second != null) best.finalScore - second.finalScore else 100
        val accepted = best != null && accept(best, margin, detectedBarcode, detectedModel)
        val bestReference = best?.let { refsByProduct[it.product.id].orEmpty().maxByOrNull { ref -> ref.score } }

        val reason = when {
            best == null -> "Tidak ada kandidat katalog"
            accepted -> acceptedReason(best, margin, detectedBarcode, detectedModel)
            else -> rejectionReason(best, second, margin, detectedBarcode, detectedModel)
        }

        return Result(
            match = if (accepted) bestReference else null,
            visualScore = best?.visualScore ?: 0,
            textScore = best?.textScore ?: 0,
            finalScore = best?.finalScore ?: 0,
            ocrText = ocr.rawText,
            barcode = ocr.barcode,
            reason = reason,
            candidates = candidates
        )
    }

    fun textScore(product: ProductEntity, ocrText: String, barcode: String = "", model: String = ""): Int {
        val productBarcode = normalizeCode(product.barcode.orEmpty())
        val detectedBarcode = normalizeCode(barcode)
        if (detectedBarcode.isNotBlank() && productBarcode.isNotBlank() && detectedBarcode == productBarcode) return 100
        if (ocrText.isBlank()) return 0

        val normalized = normalize(ocrText)
        val brand = normalize(product.brand.orEmpty())
        val name = normalize(product.name)
        val variant = normalize(product.variant.orEmpty())
        val sku = normalize(product.sku)
        val detectedModel = normalizeCode(model)

        var score = 0
        var distinctiveHits = 0

        if (brand.isNotBlank() && containsPhrase(normalized, brand)) {
            score += 24
            distinctiveHits++
        }

        val nameResult = fieldTokenScoreDetailed(normalized, name, 40)
        score += nameResult.first
        distinctiveHits += nameResult.second

        val variantResult = fieldTokenScoreDetailed(normalized, variant, 22)
        score += variantResult.first
        distinctiveHits += variantResult.second

        if (detectedModel.isNotBlank()) {
            val productIdentityTokens = buildList {
                addAll(tokenize(variant))
                addAll(tokenize(name))
                addAll(tokenize(sku))
            }.map(::normalizeCode)
            if (productIdentityTokens.any { it.length >= 3 && it == detectedModel }) {
                score += 22
                distinctiveHits++
            }
        }

        if (sku.isNotBlank() && containsPhrase(normalized, sku)) {
            score += 18
            distinctiveHits++
        }

        if (productBarcode.isNotBlank() && containsPhrase(normalized, productBarcode)) {
            score += 25
            distinctiveHits++
        }

        // Distinctive two-or-more-token identity is stronger than a long generic OCR string.
        if (distinctiveHits >= 2 && score >= 70) score += 8
        if (distinctiveHits >= 3 && score >= 78) score += 8

        return score.coerceIn(0, 100)
    }

    /**
     * Uses the best master frame plus supporting frames. A single lucky visual
     * hit is deliberately discounted; repeated support increases confidence.
     */
    private fun aggregateVisual(refs: List<VisualProductMatch>): Int {
        if (refs.isEmpty()) return 0
        val scores = refs.map { it.score }.sortedDescending()
        val best = scores.first()
        val top = scores.take(5)
        val supportCount = top.count { it >= 60 }
        val strongCount = top.count { it >= 70 }
        val median = scores[scores.size / 2]
        val topAverage = top.average()

        var score = best * 0.45 + topAverage * 0.30 + median * 0.10
        score += (supportCount.coerceAtMost(5) * 2.0)
        score += (strongCount.coerceAtMost(5) * 1.5)

        // If the best frame is an outlier, do not let it dominate the result.
        if (best - topAverage >= 22) score -= 8.0

        return score.roundToInt().coerceIn(0, 100)
    }

    private fun fuse(
        visual: Int,
        text: Int,
        barcode: String,
        model: String,
        product: ProductEntity,
        refs: List<VisualProductMatch>
    ): Int {
        if (barcode.isNotBlank() && normalizeCode(product.barcode.orEmpty()) == barcode) return 100

        val hasStrongIdentity = text >= ACCEPT_DISTINCTIVE_TEXT
        return when {
            hasStrongIdentity && visual >= MIN_VISUAL_SUPPORT ->
                (text * 0.68f + visual * 0.32f).roundToInt()
            hasStrongIdentity && refs.isNotEmpty() ->
                (text * 0.72f + visual * 0.28f).roundToInt().coerceAtLeast(text - 8)
            text >= ACCEPT_TEXT_WITH_VISUAL && visual >= MIN_VISUAL_SUPPORT ->
                (text * 0.58f + visual * 0.42f).roundToInt()
            model.isNotBlank() && text >= 80 && visual >= 40 ->
                (text * 0.65f + visual * 0.35f).roundToInt()
            else -> visual
        }.coerceIn(0, 100)
    }

    private fun accept(
        candidate: RecognitionCandidate,
        margin: Int,
        barcode: String,
        model: String
    ): Boolean {
        if (barcode.isNotBlank() && candidate.textScore >= ACCEPT_BARCODE) return true
        if (candidate.textScore >= ACCEPT_DISTINCTIVE_TEXT && candidate.visualScore >= MIN_VISUAL_SUPPORT && margin >= MIN_MARGIN) return true
        if (model.isNotBlank() && candidate.textScore >= 90 && candidate.visualScore >= 40 && margin >= MIN_MARGIN) return true
        if (candidate.textScore >= ACCEPT_TEXT_WITH_VISUAL && candidate.visualScore >= 60 && margin >= MIN_MARGIN) return true
        return candidate.visualScore >= ACCEPT_VISUAL && candidate.hasMaster && margin >= MIN_MARGIN
    }

    private fun acceptedReason(c: RecognitionCandidate, margin: Int, barcode: String, model: String): String = when {
        barcode.isNotBlank() && c.textScore >= ACCEPT_BARCODE -> "BARCODE EXACT + identitas katalog"
        model.isNotBlank() && c.textScore >= 90 -> "MODEL/OCR kuat + visual master + margin $margin%"
        c.textScore >= ACCEPT_DISTINCTIVE_TEXT -> "Identity key OCR kuat + visual master + margin $margin%"
        c.textScore >= ACCEPT_TEXT_WITH_VISUAL -> "OCR + visual master + margin $margin%"
        else -> "Visual master kuat + margin $margin%"
    }

    private fun evidence(
        product: ProductEntity,
        visual: Int,
        text: Int,
        barcode: String,
        model: String,
        refs: List<VisualProductMatch>
    ): String = when {
        barcode.isNotBlank() && normalizeCode(product.barcode.orEmpty()) == barcode -> "BARCODE EXACT"
        model.isNotBlank() && text >= 90 -> "MODEL + OCR + visual"
        text >= ACCEPT_DISTINCTIVE_TEXT && visual >= MIN_VISUAL_SUPPORT -> "IDENTITY KEY + visual master"
        text >= ACCEPT_TEXT_WITH_VISUAL && visual >= MIN_VISUAL_SUPPORT -> "OCR + visual master"
        visual >= ACCEPT_VISUAL && refs.isNotEmpty() -> "Visual master kuat"
        text > 0 && visual > 0 -> "OCR + visual lemah"
        text > 0 -> "OCR sebagian"
        refs.isNotEmpty() -> "Visual master lemah"
        else -> "Bukti belum cukup"
    }

    private fun rejectionReason(
        best: RecognitionCandidate,
        second: RecognitionCandidate?,
        margin: Int,
        barcode: String,
        model: String
    ): String = when {
        barcode.isNotBlank() && best.textScore < ACCEPT_BARCODE -> "Barcode terdeteksi tetapi tidak cukup cocok dengan kandidat"
        second != null && margin < MIN_MARGIN -> "Kandidat terlalu berdekatan (margin $margin%); identitas belum aman"
        best.textScore >= ACCEPT_DISTINCTIVE_TEXT && best.visualScore < MIN_VISUAL_SUPPORT -> "Identity key kuat tetapi bukti visual master terlalu lemah"
        best.visualScore >= ACCEPT_VISUAL && !best.hasMaster -> "Visual tinggi tetapi master produk belum tersedia"
        best.textScore < ACCEPT_TEXT_WITH_VISUAL && best.visualScore < ACCEPT_VISUAL -> "Bukti OCR dan visual belum melewati standar pengenalan"
        else -> "Bukti identitas belum cukup kuat"
    }

    private fun fieldTokenScoreDetailed(ocr: String, field: String, weight: Int): Pair<Int, Int> {
        if (field.isBlank()) return 0 to 0
        if (containsPhrase(ocr, field)) return weight to tokenize(field).count { it.length >= 3 }
        val tokens = tokenize(field).filter { it.length >= 3 && !STOP_WORDS.contains(it) }
        if (tokens.isEmpty()) return 0 to 0
        val ocrTokens = tokenize(ocr)
        val hits = tokens.count { token ->
            ocrTokens.any { scanned ->
                scanned == token || (token.length >= 5 && (scanned.contains(token) || token.contains(scanned)))
            }
        }
        return (((hits.toFloat() / tokens.size) * weight).roundToInt().coerceIn(0, weight)) to hits
    }

    private fun containsPhrase(text: String, phrase: String): Boolean =
        phrase.isNotBlank() && text.contains(phrase)

    private fun normalize(value: String): String = value
        .uppercase()
        .replace(Regex("[^A-Z0-9]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private fun normalizeCode(value: String): String = normalize(value).replace(" ", "")
    private fun tokenize(value: String): List<String> = value.split(" ").filter { it.isNotBlank() }

    private val STOP_WORDS = setOf(
        "SIZE", "MODEL", "VARIAN", "VARIANT", "KOREA", "KOREAN", "TECHNOLOGY",
        "QUALITY", "PREMIUM", "BEST", "THE", "AND", "FOR", "GO", "PCS", "PC",
        "MADE", "IN", "QTY", "QUANTITY", "COLOR", "COLOUR", "HOOK", "FISHING"
    )
}
