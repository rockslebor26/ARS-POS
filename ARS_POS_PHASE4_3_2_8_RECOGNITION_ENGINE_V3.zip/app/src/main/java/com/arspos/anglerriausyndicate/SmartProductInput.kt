package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Phase 4.3.1: offline OCR + barcode helper for product intake.
 * This is an assistant only: the operator still reviews the generated fields
 * before saving a product.
 */
object SmartProductInput {
    data class Draft(
        val rawText: String = "",
        val brand: String = "",
        val name: String = "",
        val variant: String = "",
        val barcode: String = "",
        val modelCode: String = "",
        val suggestedSku: String = ""
    )

    private val textRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val barcodeScanner by lazy {
        BarcodeScanning.getClient()
    }

    suspend fun analyze(bitmap: Bitmap): Draft {
        val image = InputImage.fromBitmap(bitmap, 0)
        val text = textRecognizer.process(image).await()
        val barcode = barcodeScanner.process(image).await().firstOrNull()?.rawValue.orEmpty()
        return buildDraft(text.text, barcode)
    }


    /** Phase 4.3.2.7.1: OCR + barcode across four orientations.
     * The scanner still captures one photo; the image is rotated in memory only
     * so labels photographed sideways/upside-down can still be read.
     */
    suspend fun analyzeMultiOrientation(bitmap: Bitmap): Draft {
        // Process each orientation explicitly instead of relying on nested lambda
        // inference. This also makes the merge deterministic for Kotlin 2.x.
        val rotations = intArrayOf(0, 90, 180, 270)
        val drafts = ArrayList<Draft>()

        for (angle in rotations) {
            val draft = runCatching {
                analyze(rotate(bitmap, angle))
            }.getOrNull()

            if (draft != null) {
                drafts += draft
            }
        }

        if (drafts.isEmpty()) return Draft()

        var barcode = ""
        for (draft in drafts) {
            val value = draft.barcode.trim()
            if (value.isNotBlank()) {
                barcode = value
                break
            }
        }

        var bestText = drafts[0]
        var bestMeaningful = -1

        for (draft in drafts) {
            val meaningful = draft.rawText
                .uppercase()
                .split(Regex("[^A-Z0-9]+"))
                .count { token -> token.length >= 3 }

            val quality = meaningful * 4 + draft.rawText.length.coerceAtMost(160)

            if (quality > bestMeaningful) {
                bestMeaningful = quality
                bestText = draft
            }
        }

        val mergedLines = ArrayList<String>()

        for (draft in drafts) {
            for (line in draft.rawText.lines()) {
                val clean = line.trim()

                if (clean.length >= 2 && !mergedLines.contains(clean)) {
                    mergedLines += clean
                }
            }
        }

        var modelCode = ""
        for (draft in drafts) {
            val value = draft.modelCode.trim()
            if (value.isNotBlank()) {
                modelCode = value
                break
            }
        }

        if (barcode.isBlank()) {
            barcode = bestText.barcode
        }

        return Draft(
            rawText = if (mergedLines.isNotEmpty()) {
                mergedLines.joinToString("\n")
            } else {
                bestText.rawText
            },
            brand = bestText.brand,
            name = bestText.name,
            variant = bestText.variant,
            barcode = barcode,
            modelCode = modelCode,
            // This field is only a product-input suggestion. The shopping
            // recognition engine never uses OCR to invent a SKU.
            suggestedSku = bestText.suggestedSku
        )
    }

    private fun rotate(source: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return source
        val matrix = android.graphics.Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    fun buildDraft(raw: String, detectedBarcode: String = ""): Draft {
        val lines = raw.lines()
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.length >= 2 }
            .distinct()

        val barcode = detectedBarcode.ifBlank {
            lines.firstOrNull { it.matches(Regex("\\d{8,14}")) }.orEmpty()
        }

        val size = Regex("(?i)\\b(?:SIZE|SZ|UKURAN)\\s*[:.-]?\\s*([A-Z0-9]+)")
            .find(lines.joinToString(" "))?.groupValues?.getOrNull(1).orEmpty()

        val modelCode = lines.firstOrNull {
            it.matches(Regex("\\d{4,8}")) && it != barcode
        }.orEmpty()

        val brand = lines.firstOrNull { line ->
            line.any(Char::isLetter) &&
                !line.contains("SILICONE", ignoreCase = true) &&
                !line.contains("SIZE", ignoreCase = true) &&
                !line.contains("KOREA", ignoreCase = true) &&
                !line.contains("TECHNOLOGY", ignoreCase = true) &&
                !line.contains("QUALITY", ignoreCase = true)
        }.orEmpty()

        val ignored = setOf(
            brand.uppercase(),
            "KOREA", "KOREAN", "TECHNOLOGY", "SILICONE", "SKIRT",
            "QUALITY", "PREMIUM", "BEST", "GO", "SIZE", barcode.uppercase(), modelCode.uppercase()
        )

        val nameParts = lines.filter { line ->
            val upper = line.uppercase()
            line.any(Char::isLetter) &&
                upper != brand.uppercase() &&
                !upper.contains("SIZE") &&
                !upper.matches(Regex(".*\\d{2,}.*")) &&
                !upper.split(" ").all { it in ignored }
        }.take(2)

        val name = when {
            nameParts.isNotEmpty() -> listOf(brand, *nameParts.toTypedArray())
                .filter { it.isNotBlank() }
                .distinct()
                .joinToString(" ")
            brand.isNotBlank() -> brand
            else -> lines.firstOrNull().orEmpty()
        }

        val variantParts = buildList {
            if (size.isNotBlank()) add(size)
            val colorLine = lines.firstOrNull { line ->
                val u = line.uppercase()
                u.contains("GREEN") || u.contains("ORANGE") || u.contains("RED") ||
                    u.contains("BLUE") || u.contains("BLACK") || u.contains("WHITE") ||
                    u.contains("YELLOW") || u.contains("PINK")
            }
            if (!colorLine.isNullOrBlank()) add(colorLine)
            if (modelCode.isNotBlank()) add(modelCode)
        }
        val variant = variantParts.distinct().joinToString(" ")

        val suggestedSku = generateSku(brand, name, variant, modelCode)

        return Draft(
            rawText = lines.joinToString("\n"),
            brand = brand,
            name = name,
            variant = variant,
            barcode = barcode,
            modelCode = modelCode,
            suggestedSku = suggestedSku
        )
    }

    fun generateSku(brand: String, name: String, variant: String, modelCode: String = ""): String {
        val source = listOf(brand, name, variant, modelCode)
            .filter { it.isNotBlank() }
            .joinToString(" ")
            .uppercase()
            .replace(Regex("[^A-Z0-9]+"), " ")
            .trim()
        val tokens = source.split(" ").filter { it.isNotBlank() }
        val initials = tokens.take(3).joinToString("") { it.take(3) }
        val code = modelCode.filter(Char::isDigit).take(8)
        val suffix = (System.currentTimeMillis() % 10000).toString().padStart(4, '0')
        return listOf(initials.take(9), code, suffix)
            .filter { it.isNotBlank() }
            .joinToString("-")
            .ifBlank { "PRD-$suffix" }
    }

    private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T =
        suspendCancellableCoroutine { continuation ->
            addOnSuccessListener { value ->
                if (continuation.isActive) continuation.resume(value)
            }
            addOnFailureListener { error ->
                if (continuation.isActive) continuation.resumeWithException(error)
            }
            addOnCanceledListener { continuation.cancel() }
        }
}
