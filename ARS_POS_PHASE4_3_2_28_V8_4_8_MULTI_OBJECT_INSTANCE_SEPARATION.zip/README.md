# ARS POS — ANGLER RIAU SYNDICATE

Current official development baseline:

- Phase **4.3.2.28**
- Engine **V8.4.8**
- Version **1.4.3**
- versionCode **143**
- Package **com.arspos.anglerriausyndicate**
- Signing channel **ARS POS OFFICIAL RELEASE**

## V8.4.8 focus
Multi-Object Physical Instance Separation + Scanner Performance Hardening.

Main protections:
- lane-aware NORMAL/LONG aggregation;
- anti-bridge AMBIGUOUS_CONTAINER suppression;
- physical-instance hints for long objects;
- full-frame rescue stays evidence-only;
- long-reference shortlist without lowering recognition thresholds;
- current-build Flight Recorder summary and memory telemetry.

Install V8.4.8 directly over V8.4.7 Official. Do **not** uninstall the official app.

See `PHASE4_3_2_28_V8_4_8_MULTI_OBJECT_INSTANCE_SEPARATION.md`.
