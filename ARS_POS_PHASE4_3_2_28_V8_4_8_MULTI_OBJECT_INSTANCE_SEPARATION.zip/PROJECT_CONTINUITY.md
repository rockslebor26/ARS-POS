# ARS POS PROJECT CONTINUITY

Baseline resmi saat ini: **Phase 4.3.2.28 / V8.4.8 / 1.4.3 (143)**.

Update chain resmi:
- V8.4.6 Official: 1.4.1 (141)
- V8.4.7: 1.4.2 (142) — IN_PLACE_UPDATE terbukti berhasil
- V8.4.8: 1.4.3 (143) — multi-object physical-instance separation + scanner hardening

Aturan permanen:
- applicationId tetap `com.arspos.anglerriausyndicate`
- ARS POS OFFICIAL RELEASE signer harus tetap identik
- versionCode selalu meningkat
- jangan uninstall official app ketika menguji update berikutnya
- UNKNOWN lebih aman daripada salah SKU
- jangan menurunkan recognition threshold hanya agar produk terlihat dikenali

Fokus validasi V8.4.8:
1. 1 rod -> Qty 1
2. 2 rod sama -> Qty 2
3. 2 rod SKU berbeda -> masing-masing 1 physical instance
4. rod + LIGHTS -> LONG dan NORMAL tidak saling merge
5. 2 LIGHTS -> Qty 2 jika kedua OCR/identity cukup kuat
6. bridge/container proposal tidak menambah quantity
7. full-frame rescue quantityEligible=false
8. scanner latency dan memory telemetry tercatat pada report ChatGPT
