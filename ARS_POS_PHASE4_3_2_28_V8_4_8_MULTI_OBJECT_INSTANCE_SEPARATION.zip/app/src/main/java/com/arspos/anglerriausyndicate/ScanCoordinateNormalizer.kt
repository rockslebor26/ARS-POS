package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min

/**
 * V8.4.8 canonical coordinate conversion.
 *
 * Proposal engines may inspect a rotated view, but aggregation must always use
 * coordinates from the original customer photo. Current V8.4.8 sources mostly
 * run at rotation=0; the 90/180/270 mappings are kept here so future rotated
 * proposal passes cannot create duplicate physical objects by coordinate drift.
 */
object ScanCoordinateNormalizer {
    fun normalize(
        rect: Rect,
        rotationDegrees: Int,
        originalWidth: Int,
        originalHeight: Int
    ): Rect {
        val rotation = ((rotationDegrees % 360) + 360) % 360
        val mapped = when (rotation) {
            90 -> Rect(
                rect.top,
                originalHeight - rect.right,
                rect.bottom,
                originalHeight - rect.left
            )
            180 -> Rect(
                originalWidth - rect.right,
                originalHeight - rect.bottom,
                originalWidth - rect.left,
                originalHeight - rect.top
            )
            270 -> Rect(
                originalWidth - rect.bottom,
                rect.left,
                originalWidth - rect.top,
                rect.right
            )
            else -> Rect(rect)
        }
        return clamp(mapped, originalWidth, originalHeight)
    }

    fun clamp(rect: Rect, width: Int, height: Int): Rect {
        val left = min(max(0, rect.left), width)
        val top = min(max(0, rect.top), height)
        val right = min(max(left, rect.right), width)
        val bottom = min(max(top, rect.bottom), height)
        return Rect(left, top, right, bottom)
    }
}
