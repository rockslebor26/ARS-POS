package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.28 V8.4.8 scanner proposal frontend.
 *
 * V8.4.8 keeps NORMAL and LONG lanes separate, tightens same-axis merging and
 * adds anti-bridge classification. A broad proposal that spans two distinct rod
 * axes is treated as AMBIGUOUS_CONTAINER (evidence only, never quantity).
 * Physical-instance hints are assigned before recognition so downstream
 * aggregation can preserve two real rods while still collapsing duplicate crops
 * from one physical rod.
 */
object SmartVisualScanner {
    private const val MAX_OBJECTS = 6
    private const val MIN_OBJECT_AREA_RATIO = 0.012f
    private const val MAX_BOX_IOU = 0.32f
    private const val LONG_ASPECT = 2.15f

    private val options = ObjectDetectorOptions.Builder()
        .setDetectorMode(ObjectDetectorOptions.SINGLE_IMAGE_MODE)
        .enableMultipleObjects()
        .build()

    private val detector by lazy { ObjectDetection.getClient(options) }

    suspend fun detectProposals(bitmap: Bitmap): List<ScanProposal> {
        val rects = detectObjectRects(bitmap)
        return rects.mapIndexed { index, rect ->
            val normalized = ScanCoordinateNormalizer.normalize(rect, 0, bitmap.width, bitmap.height)
            val longLike = isLongRect(normalized)
            ScanProposal(
                proposalId = "ML-${index + 1}",
                source = ScanProposal.SOURCE_MLKIT,
                proposalType = if (longLike) ScanProposal.TYPE_LONG else ScanProposal.TYPE_NORMAL,
                originalBounds = Rect(rect),
                normalizedBounds = normalized,
                rotationDegrees = 0,
                lineageId = if (longLike) longLineage(normalized, bitmap.width, bitmap.height) else "ML-${index + 1}",
                physicalInstanceHint = if (longLike) "" else "NORMAL-ML-${index + 1}",
                quantityEligible = true,
                orientation = orientationOf(normalized),
                strength = 70
            )
        }
    }

    /** Backward-compatible helper for older callers. */
    suspend fun detectObjects(bitmap: Bitmap): List<Rect> =
        detectProposals(bitmap).map { Rect(it.normalizedBounds) }

    private suspend fun detectObjectRects(bitmap: Bitmap): List<Rect> {
        val imageW = bitmap.width
        val imageH = bitmap.height
        val imageArea = imageW.toLong() * imageH.toLong()
        val regions = listOf(
            Rect(0, 0, imageW, imageH),
            tile(imageW, imageH, 0, 0),
            tile(imageW, imageH, 1, 0),
            tile(imageW, imageH, 0, 1),
            tile(imageW, imageH, 1, 1)
        )

        val all = ArrayList<Rect>()
        for (region in regions.distinctBy { "${it.left}:${it.top}:${it.right}:${it.bottom}" }) {
            val crop = runCatching {
                Bitmap.createBitmap(bitmap, region.left, region.top, region.width(), region.height())
            }.getOrNull() ?: continue
            val detected = runCatching {
                detector.process(InputImage.fromBitmap(crop, 0)).await()
            }.getOrElse { emptyList() }
            detected.forEach { obj ->
                val b = obj.boundingBox
                val mapped = Rect(
                    region.left + b.left,
                    region.top + b.top,
                    region.left + b.right,
                    region.top + b.bottom
                )
                val safe = expandAndClamp(mapped, imageW, imageH)
                val proposalArea = safe.width().toLong() * safe.height().toLong()
                if (
                    safe.width() >= 24 &&
                    safe.height() >= 24 &&
                    proposalArea.toDouble() / imageArea.toDouble() >= MIN_OBJECT_AREA_RATIO
                ) {
                    all += safe
                }
            }
            if (crop !== bitmap && !crop.isRecycled) crop.recycle()
        }

        val selected = ArrayList<Rect>()
        all.sortedByDescending { it.width().toLong() * it.height().toLong() }.forEach { candidate ->
            if (selected.none { samePhysicalProposal(it, candidate) }) selected += candidate
        }

        return selected.sortedWith(
            compareBy<Rect> { fullFramePenalty(it, imageW, imageH) }
                .thenByDescending { it.width().toLong() * it.height().toLong() }
        ).take(MAX_OBJECTS)
    }

    /**
     * V8.4.8 typed merge + physical-instance hinting.
     *
     * NORMAL and LONG are never collapsed into the same proposal. Long proposals
     * use a stricter same-axis merge than V8.4.7, then broad bridge/container
     * proposals are suppressed before quantity decisions.
     */
    fun mergeProposalMetadata(
        base: List<ScanProposal>,
        extra: List<ScanProposal>,
        maxObjects: Int = MAX_OBJECTS
    ): List<ScanProposal> {
        val normal = ArrayList<ScanProposal>()
        val long = ArrayList<ScanProposal>()

        (base + extra).forEach { candidate ->
            when (candidate.proposalType) {
                ScanProposal.TYPE_LONG -> {
                    val existingIndex = long.indexOfFirst { sameTypedLongProposal(it, candidate) }
                    if (existingIndex >= 0) long[existingIndex] = mergeMetadata(long[existingIndex], candidate)
                    else long += candidate
                }
                ScanProposal.TYPE_RESCUE, ScanProposal.TYPE_AMBIGUOUS_CONTAINER -> Unit
                else -> {
                    val existingIndex = normal.indexOfFirst {
                        samePhysicalProposal(it.normalizedBounds, candidate.normalizedBounds)
                    }
                    if (existingIndex >= 0) normal[existingIndex] = mergeMetadata(normal[existingIndex], candidate)
                    else normal += candidate
                }
            }
        }

        val refinedLong = assignPhysicalHintsAndSuppressBridges(long)
        val realLong = refinedLong.filterNot { it.bridgeSuppressed || it.proposalType == ScanProposal.TYPE_AMBIGUOUS_CONTAINER }
        val bridge = refinedLong.filter { it.bridgeSuppressed || it.proposalType == ScanProposal.TYPE_AMBIGUOUS_CONTAINER }

        val normalSelected = normal
            .mapIndexed { index, item ->
                item.copy(
                    physicalInstanceHint = item.physicalInstanceHint.ifBlank { "NORMAL-${index + 1}" }
                )
            }
            .sortedByDescending { area(it.normalizedBounds) }
            .take(4)

        val longSelected = realLong
            .sortedWith(
                compareByDescending<ScanProposal> { it.strength }
                    .thenByDescending { longAxisLength(it.normalizedBounds) }
            )
            .take(4)

        val combined = ArrayList<ScanProposal>()
        // Reserve normal slots when compact products are present.
        combined += normalSelected.take(min(2, normalSelected.size))
        combined += longSelected
        normalSelected.drop(min(2, normalSelected.size)).forEach { combined += it }

        // Keep at most one evidence-only bridge if there is spare capacity so the
        // Flight Recorder can explain why a broad container was suppressed.
        if (combined.size < maxObjects && bridge.isNotEmpty()) {
            combined += bridge.maxByOrNull { area(it.normalizedBounds) }!!
        }

        return combined
            .distinctBy { it.proposalId + ":" + it.physicalInstanceHint + ":" + rectKey(it.normalizedBounds) }
            .take(maxObjects.coerceIn(1, MAX_OBJECTS))
    }

    /** Legacy V8.4.5 API retained for compatibility. */
    fun mergeProposals(base: List<Rect>, extra: List<Rect>, maxObjects: Int = MAX_OBJECTS): List<Rect> {
        val selected = ArrayList<Rect>()
        (base + extra)
            .sortedByDescending { it.width().toLong() * it.height().toLong() }
            .forEach { candidate ->
                if (selected.none { samePhysicalProposal(it, candidate) }) selected += candidate
            }
        return selected.take(maxObjects.coerceIn(1, MAX_OBJECTS))
    }

    fun crop(bitmap: Bitmap, bounds: Rect): Bitmap? {
        val safe = expandAndClamp(bounds, bitmap.width, bitmap.height)
        if (safe.width() < 24 || safe.height() < 24) return null
        return runCatching {
            Bitmap.createBitmap(bitmap, safe.left, safe.top, safe.width(), safe.height())
        }.getOrNull()
    }

    fun acceptBest(candidates: List<VisualProductMatch>): VisualProductMatch? {
        if (candidates.isEmpty()) return null
        val ranked = candidates.sortedByDescending { it.score }
        val best = ranked.first()
        val second = ranked.getOrNull(1)
        if (best.score < 82) return null
        if (second != null && best.score - second.score < 8) return null
        return best
    }

    private fun assignPhysicalHintsAndSuppressBridges(input: List<ScanProposal>): List<ScanProposal> {
        if (input.isEmpty()) return emptyList()

        // First suppress broad same-axis containers that cover two narrower,
        // physically separated candidates. This breaks the V8.4.7 bridge chain.
        val sameAxisClassified = input.map { candidate ->
            if (isParallelContainer(candidate, input)) {
                candidate.copy(
                    proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                    source = ScanProposal.SOURCE_BRIDGE,
                    physicalInstanceHint = "BRIDGE-${candidate.proposalId}",
                    quantityEligible = false,
                    bridgeSuppressed = true
                )
            } else candidate
        }

        val usable = sameAxisClassified.filterNot { it.bridgeSuppressed }
        val vertical = usable.filter { isVertical(it.normalizedBounds) }
        val horizontal = usable.filter { isHorizontal(it.normalizedBounds) }

        val verticalHints = clusterSameAxis(vertical, "PHYS-V")
        val horizontalHints = clusterSameAxis(horizontal, "PHYS-H")
        val assigned = sameAxisClassified.map { proposal ->
            if (proposal.bridgeSuppressed) return@map proposal
            val hint = verticalHints[proposal.proposalId]
                ?: horizontalHints[proposal.proposalId]
                ?: "PHYS-${proposal.proposalId}"
            proposal.copy(physicalInstanceHint = hint)
        }.toMutableList()

        // Choose one orientation as the physical anchor. The orientation with
        // more distinct axis clusters wins; ties prefer the family with the
        // longer average axis. This prevents a single crossing floor/tile band
        // from rewriting two real rod instance IDs into one bridge lineage.
        val verticalCount = verticalHints.values.distinct().size
        val horizontalCount = horizontalHints.values.distinct().size
        val verticalAvgLength = vertical.map { longAxisLength(it.normalizedBounds) }.average().takeIf { !it.isNaN() } ?: 0.0
        val horizontalAvgLength = horizontal.map { longAxisLength(it.normalizedBounds) }.average().takeIf { !it.isNaN() } ?: 0.0
        val anchorVertical = when {
            verticalCount > horizontalCount -> true
            horizontalCount > verticalCount -> false
            else -> verticalAvgLength >= horizontalAvgLength
        }

        // Only non-anchor proposals may inherit an anchor physical ID. If a
        // non-anchor band touches two or more anchor instances it is a bridge.
        for (i in assigned.indices) {
            val candidate = assigned[i]
            if (candidate.bridgeSuppressed) continue
            val candidateVertical = isVertical(candidate.normalizedBounds)
            val candidateHorizontal = isHorizontal(candidate.normalizedBounds)
            if (!candidateVertical && !candidateHorizontal) continue

            val isAnchorFamily = (anchorVertical && candidateVertical) || (!anchorVertical && candidateHorizontal)
            if (isAnchorFamily) continue

            val anchors = assigned.filter { other ->
                other !== candidate && !other.bridgeSuppressed &&
                    ((anchorVertical && isVertical(other.normalizedBounds)) ||
                        (!anchorVertical && isHorizontal(other.normalizedBounds)))
            }
            val hits = anchors
                .filter { crossAxisSupportsSameRegion(candidate.normalizedBounds, it.normalizedBounds) }
                .map { it.physicalInstanceHint }
                .filter { it.isNotBlank() }
                .distinct()

            if (hits.size >= 2) {
                assigned[i] = candidate.copy(
                    proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                    source = ScanProposal.SOURCE_BRIDGE,
                    physicalInstanceHint = "BRIDGE-${candidate.proposalId}",
                    quantityEligible = false,
                    bridgeSuppressed = true
                )
            } else if (hits.size == 1) {
                assigned[i] = candidate.copy(physicalInstanceHint = hits.first())
            }
        }

        return assigned
    }

    private fun clusterSameAxis(items: List<ScanProposal>, prefix: String): Map<String, String> {
        if (items.isEmpty()) return emptyMap()
        val vertical = prefix.endsWith("V")
        val sorted = items.sortedBy { if (vertical) centerX(it.normalizedBounds) else centerY(it.normalizedBounds) }
        val groups = mutableListOf<MutableList<ScanProposal>>()

        sorted.forEach { candidate ->
            val group = groups.firstOrNull { existing ->
                existing.all { current -> samePhysicalAxis(current.normalizedBounds, candidate.normalizedBounds) }
            }
            if (group != null) group += candidate else groups += mutableListOf(candidate)
        }

        val result = HashMap<String, String>()
        groups.forEachIndexed { index, group ->
            val id = "$prefix-${index + 1}"
            group.forEach { result[it.proposalId] = id }
        }
        return result
    }

    private fun isParallelContainer(candidate: ScanProposal, all: List<ScanProposal>): Boolean {
        val r = candidate.normalizedBounds
        if (!isVertical(r) && !isHorizontal(r)) return false
        val sameOrientationPeers = all.filter { other ->
            other !== candidate && sameOrientation(r, other.normalizedBounds)
        }
        if (sameOrientationPeers.size < 2) return false

        val candidateShort = shortAxisSize(r).coerceAtLeast(1)
        val contained = sameOrientationPeers.filter { peer ->
            val pr = peer.normalizedBounds
            val peerShort = shortAxisSize(pr).coerceAtLeast(1)
            val longOverlap = longAxisOverlapRatio(r, pr)
            val centerInside = if (isVertical(r)) {
                centerX(pr) in r.left.toFloat()..r.right.toFloat()
            } else {
                centerY(pr) in r.top.toFloat()..r.bottom.toFloat()
            }
            candidateShort >= peerShort * 1.55f && centerInside && longOverlap >= 0.45f
        }
        if (contained.size < 2) return false

        val centers = contained.map { if (isVertical(r)) centerX(it.normalizedBounds) else centerY(it.normalizedBounds) }.sorted()
        val widestGap = centers.zipWithNext { a, b -> abs(b - a) }.maxOrNull() ?: 0f
        val peerShort = contained.map { shortAxisSize(it.normalizedBounds).toFloat() }.minOrNull() ?: candidateShort.toFloat()
        return widestGap >= max(28f, peerShort * 0.75f)
    }

    private fun samePhysicalAxis(a: Rect, b: Rect): Boolean {
        if (!sameOrientation(a, b)) return false
        val shortA = shortAxisSize(a).coerceAtLeast(1)
        val shortB = shortAxisSize(b).coerceAtLeast(1)
        val shortRatio = max(shortA, shortB).toFloat() / min(shortA, shortB).toFloat()
        if (shortRatio > 1.75f) return false

        val centerGap = if (isVertical(a)) abs(centerX(a) - centerX(b)) else abs(centerY(a) - centerY(b))
        val gapLimit = min(shortA, shortB) * 0.72f + 14f
        return centerGap <= gapLimit && longAxisOverlapRatio(a, b) >= 0.40f
    }

    private fun crossAxisSupportsSameRegion(a: Rect, b: Rect): Boolean {
        val intersection = intersectionArea(a, b)
        if (intersection <= 0L) return false
        val smaller = min(area(a), area(b)).coerceAtLeast(1L)
        return intersection.toFloat() / smaller.toFloat() >= 0.10f
    }

    private fun mergeMetadata(a: ScanProposal, b: ScanProposal): ScanProposal {
        val preferred = if (a.strength >= b.strength) a else b
        val mergedBounds = union(a.normalizedBounds, b.normalizedBounds)
        return preferred.copy(
            proposalId = "${preferred.proposalId}+${if (preferred === a) b.proposalId else a.proposalId}",
            source = if (a.source == b.source) a.source else ScanProposal.SOURCE_MERGED,
            proposalType = if (a.proposalType == ScanProposal.TYPE_LONG || b.proposalType == ScanProposal.TYPE_LONG) ScanProposal.TYPE_LONG else preferred.proposalType,
            originalBounds = union(a.originalBounds, b.originalBounds),
            normalizedBounds = mergedBounds,
            lineageId = if (a.lineageId == b.lineageId) a.lineageId else preferred.lineageId,
            physicalInstanceHint = if (a.physicalInstanceHint == b.physicalInstanceHint) a.physicalInstanceHint else preferred.physicalInstanceHint,
            orientation = if (preferred.orientation != "UNKNOWN") preferred.orientation else orientationOf(mergedBounds),
            strength = max(a.strength, b.strength)
        )
    }

    private fun sameTypedLongProposal(a: ScanProposal, b: ScanProposal): Boolean {
        if (orientationFamily(a.orientation) != orientationFamily(b.orientation)) return false
        // Do not merge merely because V8.4.7 bucket lineage matches. Physical
        // separation now wins over old H/V bucket lineage.
        return samePhysicalAxis(a.normalizedBounds, b.normalizedBounds)
    }

    private fun longLineage(rect: Rect, width: Int, height: Int): String {
        val vertical = isVertical(rect)
        val axisSize = if (vertical) width else height
        val center = if (vertical) centerX(rect) else centerY(rect)
        val bucketSize = (axisSize * 0.18f).coerceAtLeast(24f)
        val bucket = (center / bucketSize).toInt()
        return "LONG-${if (vertical) "V" else "H"}-$bucket"
    }

    private fun tile(w: Int, h: Int, col: Int, row: Int): Rect {
        val tw = (w * 0.62f).toInt().coerceAtLeast(64).coerceAtMost(w)
        val th = (h * 0.62f).toInt().coerceAtLeast(64).coerceAtMost(h)
        val left = if (col == 0) 0 else w - tw
        val top = if (row == 0) 0 else h - th
        return Rect(left, top, min(w, left + tw), min(h, top + th))
    }

    private fun samePhysicalProposal(a: Rect, b: Rect): Boolean {
        val overlap = iou(a, b)
        if (overlap >= MAX_BOX_IOU) return true

        val intersection = intersectionArea(a, b)
        val minArea = minOf(area(a), area(b)).coerceAtLeast(1L)
        if (intersection.toFloat() / minArea.toFloat() >= 0.62f) return true

        val distance = hypot(centerX(a) - centerX(b), centerY(a) - centerY(b))
        val scale = minOf(
            hypot(a.width().toFloat(), a.height().toFloat()),
            hypot(b.width().toFloat(), b.height().toFloat())
        ).coerceAtLeast(1f)
        val areaA = area(a).coerceAtLeast(1L)
        val areaB = area(b).coerceAtLeast(1L)
        val areaRatio = maxOf(areaA, areaB).toFloat() / minOf(areaA, areaB).toFloat()
        return distance <= scale * 0.16f && areaRatio <= 1.85f
    }

    private fun fullFramePenalty(rect: Rect, w: Int, h: Int): Int {
        if (w <= 0 || h <= 0) return 0
        val ratio = area(rect).toFloat() / (w.toLong() * h.toLong()).coerceAtLeast(1L).toFloat()
        return if (ratio > 0.82f) 1 else 0
    }

    private fun iou(a: Rect, b: Rect): Float {
        val intersection = intersectionArea(a, b)
        val unionArea = area(a) + area(b) - intersection
        return if (unionArea <= 0L) 0f else intersection.toFloat() / unionArea.toFloat()
    }

    private fun intersectionArea(a: Rect, b: Rect): Long {
        val left = maxOf(a.left, b.left)
        val top = maxOf(a.top, b.top)
        val right = minOf(a.right, b.right)
        val bottom = minOf(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0L
        return (right - left).toLong() * (bottom - top).toLong()
    }

    private fun expandAndClamp(rect: Rect, width: Int, height: Int): Rect {
        val padX = max(8, (rect.width() * 0.08f).toInt())
        val padY = max(8, (rect.height() * 0.08f).toInt())
        return Rect(
            max(0, rect.left - padX),
            max(0, rect.top - padY),
            min(width, rect.right + padX),
            min(height, rect.bottom + padY)
        )
    }

    private fun union(a: Rect, b: Rect): Rect = Rect(
        min(a.left, b.left),
        min(a.top, b.top),
        max(a.right, b.right),
        max(a.bottom, b.bottom)
    )

    private fun rectKey(r: Rect): String = "${r.left}:${r.top}:${r.right}:${r.bottom}"
    private fun area(r: Rect): Long = r.width().coerceAtLeast(0).toLong() * r.height().coerceAtLeast(0).toLong()
    private fun centerX(r: Rect): Float = (r.left + r.right) / 2f
    private fun centerY(r: Rect): Float = (r.top + r.bottom) / 2f
    private fun isVertical(r: Rect): Boolean = r.height() >= r.width() * 1.45f
    private fun isHorizontal(r: Rect): Boolean = r.width() >= r.height() * 1.45f
    private fun isLongRect(r: Rect): Boolean {
        val short = min(r.width(), r.height()).coerceAtLeast(1)
        val long = max(r.width(), r.height())
        return long.toFloat() / short.toFloat() >= LONG_ASPECT
    }
    private fun sameOrientation(a: Rect, b: Rect): Boolean =
        (isVertical(a) && isVertical(b)) || (isHorizontal(a) && isHorizontal(b))
    private fun orientationOf(r: Rect): String = when {
        isVertical(r) -> "VERTICAL"
        isHorizontal(r) -> "HORIZONTAL"
        else -> "COMPACT"
    }
    private fun orientationFamily(value: String): String = when {
        value.startsWith("VERTICAL") -> "VERTICAL"
        value.startsWith("HORIZONTAL") -> "HORIZONTAL"
        else -> value
    }
    private fun shortAxisSize(r: Rect): Int = if (isVertical(r)) r.width() else r.height()
    private fun longAxisLength(r: Rect): Int = if (isVertical(r)) r.height() else r.width()
    private fun longAxisOverlapRatio(a: Rect, b: Rect): Float {
        if (!sameOrientation(a, b)) return 0f
        val overlap = if (isVertical(a)) {
            axisOverlap(a.top, a.bottom, b.top, b.bottom)
        } else {
            axisOverlap(a.left, a.right, b.left, b.right)
        }
        val minimum = min(longAxisLength(a), longAxisLength(b)).coerceAtLeast(1)
        return overlap.toFloat() / minimum.toFloat()
    }
    private fun axisOverlap(a0: Int, a1: Int, b0: Int, b1: Int): Int =
        (min(a1, b1) - max(a0, b0)).coerceAtLeast(0)

    private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T =
        suspendCancellableCoroutine { continuation ->
            addOnSuccessListener { value -> if (continuation.isActive) continuation.resume(value) }
            addOnFailureListener { error -> if (continuation.isActive) continuation.resumeWithException(error) }
            addOnCanceledListener { continuation.cancel() }
        }
}
