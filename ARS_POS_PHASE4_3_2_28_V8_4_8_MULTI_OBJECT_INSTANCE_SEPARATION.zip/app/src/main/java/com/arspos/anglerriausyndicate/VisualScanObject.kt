package com.arspos.anglerriausyndicate

import android.graphics.Rect
import com.arspos.anglerriausyndicate.data.RecognitionCandidate

/** Hasil deteksi + pengenalan satu objek pada Phase 4.3.2.28 V8.4.8. */
data class VisualScanObject(
    val index: Int,
    val bounds: Rect,
    val match: VisualProductMatch?,
    val bestScore: Int = match?.score ?: 0,
    val visualScore: Int = bestScore,
    val textScore: Int = 0,
    val finalScore: Int = bestScore,
    val ocrText: String = "",
    val barcode: String = "",
    val reason: String = "",
    val candidates: List<RecognitionCandidate> = emptyList(),
    val proposalId: String = "",
    val proposalSource: String = "UNKNOWN",
    val proposalType: String = ScanProposal.TYPE_NORMAL,
    val proposalRotation: Int = 0,
    val lineageId: String = "",
    val physicalInstanceHint: String = "",
    val quantityEligible: Boolean = true,
    val bridgeSuppressed: Boolean = false,
    val originalBounds: Rect = Rect(bounds),
    val normalizedBounds: Rect = Rect(bounds)
)
