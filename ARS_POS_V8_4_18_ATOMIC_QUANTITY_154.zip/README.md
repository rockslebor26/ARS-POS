# ARS POS 1.5.4 (154) / Phase 4.3.2.38 / V8.4.18

Current candidate: **Atomic Quantity Commit + Physical Evidence Consistency**.

This source continues directly from V8.4.17 WorkSync 1.5.3 (153). It retains interactive object review, visual evidence, physical-track truth, Rescue Gate V2, typed NORMAL/LONG lanes, rod authenticity/anchor identity and all recognition thresholds.

V8.4.18 changes the cashier boundary only where needed: quantity drafts are derived only from eligible non-bridge, non-rescue physical objects; initial requested quantity is clamped against remaining stock after the current cart; the review requires a live scan session; UI double-tap is blocked; ViewModel duplicate-session and atomic stock validation remain authoritative.

Release identity: `com.arspos.anglerriausyndicate`, Room DB v5, versionName `1.5.4`, versionCode `154`. Official signer continuity is mandatory. Install in-place; do not uninstall the existing official app.
