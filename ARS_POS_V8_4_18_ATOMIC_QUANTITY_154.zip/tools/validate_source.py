#!/usr/bin/env python3
"""Static release invariants only. This is not Kotlin compilation/device QA."""
import argparse
import json
import re
import sys
from pathlib import Path
from kotlin_sanity import check_tree

EXPECTED_THRESHOLDS = {
    "ACCEPT_EXACT_BARCODE": 90, "ACCEPT_STRONG_IDENTITY": 82,
    "ACCEPT_IDENTITY_WITH_VISUAL": 68, "ACCEPT_CANONICAL_TEXT": 78,
    "ACCEPT_PROFILE_IDENTITY": 78, "ACCEPT_VISUAL_ONLY": 80,
    "ACCEPT_LONG_VISUAL_ONLY": 72, "MIN_VISUAL_SUPPORT": 34,
    "MIN_MARGIN": 10, "MIN_VISUAL_MARGIN": 15, "MIN_LONG_VISUAL_MARGIN": 14,
    "MIN_TEXT_GATE": 58, "MIN_LONG_ANCHOR_SCORE": 55, "MIN_LONG_ANCHOR_MARGIN": 8,
}

def validate(root):
    root = Path(root)
    pkg = root / "app/src/main/java/com/arspos/anglerriausyndicate"
    checks = []
    def check(ok, label):
        if not ok:
            raise ValueError(label)
        checks.append(label)
    gradle = (root / "app/build.gradle.kts").read_text()
    check('applicationId = "com.arspos.anglerriausyndicate"' in gradle, "package unchanged")
    check('versionCode = 154' in gradle and 'versionName = "1.5.4"' in gradle, "release 1.5.4/154")
    check('signingConfig = signingConfigs.getByName("arsOfficialRelease")' in gradle, "official signer configuration")
    check('getByName("debug")' not in gradle, "no debug release signer")
    database = (pkg / "data/db/ArsDatabase.kt").read_text()
    check(bool(re.search(r"version\s*=\s*5\b", database)), "Room DB remains v5")
    check("fallbackToDestructiveMigration" not in database, "no destructive migration")
    engine = (pkg / "data/SmartRecognitionEngine.kt").read_text()
    thresholds = {k:int(v) for k,v in re.findall(r"private const val (\w+) = (\d+)", engine)}
    check(thresholds == EXPECTED_THRESHOLDS, "all 14 recognition thresholds unchanged")
    for rule in ["REJECT_NORMAL_REQUIRES_IDENTITY", "REJECT_IDENTITY_MARGIN", "REJECT_ROD_ANCHOR_MARGIN",
                 "REJECT_BARCODE_MISMATCH", "REJECT_BARCODE_AMBIGUOUS"]:
        check(rule in engine, rule)
    recorder = (pkg / "ArsVisualEvidenceRecorder.kt").read_text()
    for literal in ['snapshotBitmap(scene, mutable = true)', 'PRE_IDENTITY_ANCHORS',
                    'GEOMETRIC_HYPOTHESIS_NOT_IDENTITY', 'evidenceFailures', 'check(flushPending(4_000L))']:
        check(literal in recorder, literal)
    scanner = (pkg / "SmartVisualScanner.kt").read_text()
    check('if (created === bitmap) bitmap.copy(Bitmap.Config.ARGB_8888, false)' in scanner, "owned full-frame crop")
    firewall = (pkg / "CrossCategorySceneFirewall.kt").read_text()
    check('it.rodAuthenticityState == ScanProposal.AUTH_TRUSTED' in firewall, "trusted-only ownership")
    resolver = (pkg / "RodPhysicalTrackResolver.kt").read_text()
    check('ANALYZER_TRACK_WITHOUT_ML_SUPPORT' not in resolver, "ML absence does not prune pixel evaluation")
    check('if (score <= 0) return 0' in resolver, "complete-link merge guard")
    vm = (pkg / "PosViewModel.kt").read_text()
    for literal in ['ScanCommitPolicy.rejection', 'reviewProducts.getValue', 'committedScanSessions.contains(session)']:
        check(literal in vm, literal)
    ui = (pkg / "MainActivity.kt").read_text()
    for literal in ['InteractiveScanPreview', 'TINJAU JUMLAH & TAMBAH', 'DETAIL DIAGNOSTIK', 'LAPORKAN HASIL SCAN BERGAMBAR', 'quantityCommitInProgress', 'SCAN_REVIEW_OPEN', 'SCAN_CART_COMMIT_OK']:
        check(literal in ui, literal)
    repository = (pkg / "data/ProductionRepository.kt").read_text()
    rescue = repository[repository.index('proposalId = "RESCUE-'):]
    check('quantityEligible = false' in rescue[:1600], "rescue cannot create quantity")
    for path in [root / "app/src/test/java/com/arspos/anglerriausyndicate/WorkSyncSafetyTest.kt",
                 root / "app/src/test/java/com/arspos/anglerriausyndicate/data/RecognitionSafetyTest.kt"]:
        check(path.is_file(), path.name)
    kotlin_files = check_tree(root / "app/src")
    return {"static_invariants": "PASS", "checks": len(checks), "details": checks,
            "kotlin_files_lexically_checked": kotlin_files,
            "kotlin_compilation": "NOT_RUN_BY_THIS_SCRIPT", "device_tests": "NOT_RUN_BY_THIS_SCRIPT"}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    try:
        print(json.dumps(validate(args.root), indent=2))
    except (ValueError, OSError) as exc:
        sys.exit(f"SOURCE VALIDATION FAILED: {exc}")
