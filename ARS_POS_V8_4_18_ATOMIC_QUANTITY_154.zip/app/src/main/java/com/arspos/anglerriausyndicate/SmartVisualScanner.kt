package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.38 V8.4.18 scanner frontend: evidence integrity + physical-track truth + Rescue Gate V2.
 *
 * V8.4.13 keeps NORMAL/LONG lanes typed but treats LONG detector lines as axis
 * hypotheses first. PhysicalObject Truth resolution consolidates compatible
 * hypotheses, RodAuthenticityEvaluator then labels each physical object as
 * NON_ROD / ROD_UNCERTAIN / TRUSTED_ROD, and only trusted rods may own
 * cashier quantity or participate in the NORMAL cross-category firewall.
 */
object SmartVisualScanner {
    private const val MAX_OBJECTS = 6
    private const val MIN_OBJECT_AREA_RATIO = 0.012f
    private const val MAX_BOX_IOU = 0.32f
    private const val LONG_ASPECT = 2.15f
    private const val MIN_ANALYZER_ROD_STRUCTURE = 34
    private const val STRONG_NORMAL_OWNERSHIP = 0.55f

    private val options = ObjectDetectorOptions.Builder()
        .setDetectorMode(ObjectDetectorOptions.SINGLE_IMAGE_MODE)
        .enableMultipleObjects()
        .build()

    private val detector by lazy { ObjectDetection.getClient(options) }

    suspend fun detectProposals(bitmap: Bitmap): List<ScanProposal> {
        val rects = detectObjectRects(bitmap)
        return rects.mapIndexed { index, rect ->
            val normalized = ScanCoordinateNormalizer.normalize(rect, 0, bitmap.width, bitmap.height)
            val longLike = isLongRect(normalized)
            ScanProposal(
                proposalId = "ML-${index + 1}",
                source = ScanProposal.SOURCE_MLKIT,
                proposalType = if (longLike) ScanProposal.TYPE_LONG else ScanProposal.TYPE_NORMAL,
                originalBounds = Rect(rect),
                normalizedBounds = normalized,
                rotationDegrees = 0,
                lineageId = if (longLike) longLineage(normalized, bitmap.width, bitmap.height) else "ML-${index + 1}",
                physicalInstanceHint = if (longLike) "" else "NORMAL-ML-${index + 1}",
                quantityEligible = true,
                orientation = orientationOf(normalized),
                strength = 70
            )
        }
    }

    /** Backward-compatible helper for older callers. */
    suspend fun detectObjects(bitmap: Bitmap): List<Rect> =
        detectProposals(bitmap).map { Rect(it.normalizedBounds) }

    private suspend fun detectObjectRects(bitmap: Bitmap): List<Rect> {
        val imageW = bitmap.width
        val imageH = bitmap.height
        val imageArea = imageW.toLong() * imageH.toLong()
        val regions = listOf(
            Rect(0, 0, imageW, imageH),
            tile(imageW, imageH, 0, 0),
            tile(imageW, imageH, 1, 0),
            tile(imageW, imageH, 0, 1),
            tile(imageW, imageH, 1, 1)
        )

        val all = ArrayList<Rect>()
        for (region in regions.distinctBy { "${it.left}:${it.top}:${it.right}:${it.bottom}" }) {
            val crop = runCatching {
                Bitmap.createBitmap(bitmap, region.left, region.top, region.width(), region.height())
            }.getOrNull() ?: continue
            val detected = runCatching {
                detector.process(InputImage.fromBitmap(crop, 0)).await()
            }.getOrElse { emptyList() }
            detected.forEach { obj ->
                val b = obj.boundingBox
                val mapped = Rect(
                    region.left + b.left,
                    region.top + b.top,
                    region.left + b.right,
                    region.top + b.bottom
                )
                val safe = expandAndClamp(mapped, imageW, imageH)
                val proposalArea = safe.width().toLong() * safe.height().toLong()
                if (
                    safe.width() >= 24 &&
                    safe.height() >= 24 &&
                    proposalArea.toDouble() / imageArea.toDouble() >= MIN_OBJECT_AREA_RATIO
                ) {
                    all += safe
                }
            }
            if (crop !== bitmap && !crop.isRecycled) crop.recycle()
        }

        val selected = ArrayList<Rect>()
        all.sortedByDescending { it.width().toLong() * it.height().toLong() }.forEach { candidate ->
            if (selected.none { samePhysicalProposal(it, candidate) }) selected += candidate
        }

        return selected.sortedWith(
            compareBy<Rect> { fullFramePenalty(it, imageW, imageH) }
                .thenByDescending { it.width().toLong() * it.height().toLong() }
        ).take(MAX_OBJECTS)
    }

    data class ProposalMergeResult(
        val proposals: List<ScanProposal>,
        val rawLongHypotheses: Int,
        val physicalObjectsBeforeResolve: Int,
        val physicalObjectsAfterResolve: Int,
        val hypothesesMerged: Int,
        val duplicatePhysicalObjectsPrevented: Int,
        val trustedRodTracks: Int,
        val uncertainRodTracks: Int,
        val nonRodTracks: Int,
        val crossingTracksPreserved: Int,
        val crossLaneSuppressed: Int,
        val geometryBridgeSuppressed: Int = 0,
        val authenticityRejected: Int = 0,
        val backgroundLineSuppressed: Int = 0
    )

    /**
     * V8.4.14 Rod Claim Ownership + intersection-aware authenticity pipeline.
     *
     * Order is intentional: typed lanes -> NORMAL-owned pre-gate -> physical
     * object resolution -> authenticity -> cross-category firewall. The firewall
     * therefore never treats a raw line hypothesis, branch, beam or grout line
     * as a trusted rod merely because it has a high line/structure score.
     */
    fun mergeProposalMetadataDetailed(
        base: List<ScanProposal>,
        extra: List<ScanProposal>,
        bitmap: Bitmap,
        maxObjects: Int = MAX_OBJECTS,
        diagnosticSession: String = ""
    ): ProposalMergeResult {
        val imageWidth = bitmap.width
        val imageHeight = bitmap.height
        val normal = ArrayList<ScanProposal>()
        val long = ArrayList<ScanProposal>()

        (base + extra).forEach { candidate ->
            when (candidate.proposalType) {
                ScanProposal.TYPE_LONG -> long += candidate
                ScanProposal.TYPE_RESCUE, ScanProposal.TYPE_AMBIGUOUS_CONTAINER -> Unit
                else -> {
                    val existingIndex = normal.indexOfFirst {
                        samePhysicalProposal(it.normalizedBounds, candidate.normalizedBounds)
                    }
                    if (existingIndex >= 0) normal[existingIndex] = mergeMetadata(normal[existingIndex], candidate)
                    else normal += candidate
                }
            }
        }

        val normalSelected = normal
            .mapIndexed { index, item ->
                item.copy(physicalInstanceHint = item.physicalInstanceHint.ifBlank { "NORMAL-${index + 1}" })
            }
            .sortedByDescending { area(it.normalizedBounds) }
            .take(4)

        val sceneGatedLong = applyCrossLaneSceneGate(long, normalSelected)
        val resolved = RodPhysicalTrackResolver.resolve(sceneGatedLong)

        val authenticated = resolved.proposals.map { proposal ->
            if (proposal.proposalType == ScanProposal.TYPE_LONG && !proposal.bridgeSuppressed) {
                RodAuthenticityEvaluator.apply(bitmap, proposal)
            } else proposal
        }.map { proposal ->
            // Rejected geometry remains evidence, never NORMAL ownership.
            // ROD_UNCERTAIN may be scored but cannot create cashier quantity.
            if (proposal.proposalType == ScanProposal.TYPE_LONG &&
                proposal.rodAuthenticityState == ScanProposal.AUTH_NON_ROD
            ) {
                proposal.copy(
                    proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                    source = ScanProposal.SOURCE_AUTHENTICITY,
                    quantityEligible = false,
                    bridgeSuppressed = true,
                    physicalMergeReason = listOf(
                        proposal.physicalMergeReason,
                        "AUTHENTICITY_NON_ROD"
                    ).filter { it.isNotBlank() }.joinToString("+")
                )
            } else proposal
        }

        authenticated.forEach { track ->
            ArsFlightRecorder.event("SCAN_TRACK_AUDIT", "Track before display pruning", mapOf(
                "session" to diagnosticSession, "proposalId" to track.proposalId, "physicalObjectId" to track.physicalObjectId,
                "bounds" to "${track.normalizedBounds.left},${track.normalizedBounds.top},${track.normalizedBounds.right},${track.normalizedBounds.bottom}",
                "axisStart" to "${track.axisStartX},${track.axisStartY}",
                "axisEnd" to "${track.axisEndX},${track.axisEndY}",
                "axisConfidence" to track.axisConfidence,
                "rodClaim" to track.rodClaim, "rodClaimScore" to track.rodClaimScore,
                "rodAuthenticityState" to track.rodAuthenticityState,
                "rodAuthenticityScore" to track.rodAuthenticityScore,
                "branchPenalty" to track.branchPenalty,
                "widthVariance" to track.widthVariance, "curvatureScore" to track.curvatureScore,
                "segmentSupport" to track.segmentSupport,
                "shaftVariation" to track.shaftVariation,
                "shaftContinuity" to track.shaftContinuity,
                "measuredWidthMedianPx" to track.measuredWidthMedianPx,
                "crossThroughHeuristicRuns" to track.crossThroughIntersections,
                "branchHeuristicRuns" to track.trueBranchIntersections,
                "mergeReason" to track.physicalMergeReason,
                "quantityEligible" to track.quantityEligible
            ))
            ArsVisualEvidenceRecorder.captureTrackAudit(diagnosticSession, bitmap, track)
        }

        val realLong = authenticated
            .filter { it.proposalType == ScanProposal.TYPE_LONG && !it.bridgeSuppressed }
            .sortedWith(
                compareByDescending<ScanProposal> { it.trustedRod }
                    .thenByDescending { it.rodAuthenticityScore }
                    .thenByDescending { it.rodStructureScore }
                    .thenByDescending { it.axisConfidence }
                    .thenByDescending { it.strength }
            )
            .take(4)

        val evidenceOnly = authenticated.filter {
            it.bridgeSuppressed || it.proposalType == ScanProposal.TYPE_AMBIGUOUS_CONTAINER
        }

        val firewall = CrossCategorySceneFirewall.apply(
            normalInput = normalSelected,
            resolvedLongInput = authenticated,
            imageWidth = imageWidth,
            imageHeight = imageHeight
        )
        val safeNormals = firewall.normals

        val combined = ArrayList<ScanProposal>()
        combined += safeNormals.take(min(2, safeNormals.size))
        combined += realLong
        safeNormals.drop(min(2, safeNormals.size)).forEach { combined += it }

        // Keep one evidence-only object for ARS DEV CENTER diagnosis. It never
        // enters recognition quantity.
        if (combined.size < maxObjects && evidenceOnly.isNotEmpty()) {
            combined += evidenceOnly.maxWithOrNull(
                compareBy<ScanProposal> { it.rodAuthenticityScore }
                    .thenBy { area(it.normalizedBounds) }
            )!!
        }

        val output = combined
            .distinctBy { it.proposalId + ":" + it.physicalInstanceHint + ":" + rectKey(it.normalizedBounds) }
            .take(maxObjects.coerceIn(1, MAX_OBJECTS))

        val trusted = authenticated.count {
            it.proposalType == ScanProposal.TYPE_LONG && !it.bridgeSuppressed && it.trustedRod
        }
        val uncertain = authenticated.count {
            it.proposalType == ScanProposal.TYPE_LONG && !it.bridgeSuppressed &&
                it.rodAuthenticityState == ScanProposal.AUTH_UNCERTAIN
        }
        val nonRod = authenticated.count {
            it.rodAuthenticityState == ScanProposal.AUTH_NON_ROD
        }

        return ProposalMergeResult(
            proposals = output,
            rawLongHypotheses = resolved.rawAxisHypotheses,
            physicalObjectsBeforeResolve = resolved.physicalObjectsBeforeResolve,
            physicalObjectsAfterResolve = resolved.physicalObjectsAfterResolve,
            hypothesesMerged = resolved.hypothesesMerged,
            duplicatePhysicalObjectsPrevented = resolved.duplicatePhysicalObjectsPrevented,
            trustedRodTracks = trusted,
            uncertainRodTracks = uncertain,
            nonRodTracks = nonRod,
            crossingTracksPreserved = resolved.crossingPairsPreserved,
            crossLaneSuppressed = resolved.crossLaneSuppressed,
            geometryBridgeSuppressed = authenticated.count { it.source == ScanProposal.SOURCE_BRIDGE },
            authenticityRejected = authenticated.count { it.source == ScanProposal.SOURCE_AUTHENTICITY },
            backgroundLineSuppressed = authenticated.count { it.source == ScanProposal.SOURCE_BACKGROUND }
        )
    }

    /** Backward-compatible wrapper for non-diagnostic callers. */
    fun mergeProposalMetadata(
        base: List<ScanProposal>,
        extra: List<ScanProposal>,
        bitmap: Bitmap,
        maxObjects: Int = MAX_OBJECTS
    ): List<ScanProposal> = mergeProposalMetadataDetailed(base, extra, bitmap, maxObjects).proposals

    fun crossingTrackPairs(proposals: List<ScanProposal>): Int =
        RodPhysicalTrackResolver.crossingPairs(proposals)

    /** Legacy V8.4.5 API retained for compatibility. */
    fun mergeProposals(base: List<Rect>, extra: List<Rect>, maxObjects: Int = MAX_OBJECTS): List<Rect> {
        val selected = ArrayList<Rect>()
        (base + extra)
            .sortedByDescending { it.width().toLong() * it.height().toLong() }
            .forEach { candidate ->
                if (selected.none { samePhysicalProposal(it, candidate) }) selected += candidate
            }
        return selected.take(maxObjects.coerceIn(1, MAX_OBJECTS))
    }

    fun crop(bitmap: Bitmap, bounds: Rect): Bitmap? {
        val safe = expandAndClamp(bounds, bitmap.width, bitmap.height)
        if (safe.width() < 24 || safe.height() < 24) return null
        return runCatching {
            val created = Bitmap.createBitmap(bitmap, safe.left, safe.top, safe.width(), safe.height())
            // createBitmap may alias an immutable full-frame source. Callers
            // own/recycle the returned crop, never the analysis source.
            if (created === bitmap) bitmap.copy(Bitmap.Config.ARGB_8888, false) else created
        }.getOrNull()
    }

    /**
     * V8.4.13 oriented LONG crop. The physical axis is warped into a narrow
     * left-to-right strip before recognition. This removes most floor/wall
     * background that previously entered a diagonal rod's axis-aligned box.
     */
    fun crop(bitmap: Bitmap, proposal: ScanProposal): Bitmap? {
        if (proposal.proposalType != ScanProposal.TYPE_LONG || !proposal.hasResolvedAxis) {
            return crop(bitmap, proposal.normalizedBounds)
        }
        return orientedLongCrop(bitmap, proposal) ?: crop(bitmap, proposal.normalizedBounds)
    }

    private fun orientedLongCrop(bitmap: Bitmap, proposal: ScanProposal): Bitmap? {
        val sx = proposal.axisStartX.toFloat()
        val sy = proposal.axisStartY.toFloat()
        val ex = proposal.axisEndX.toFloat()
        val ey = proposal.axisEndY.toFloat()
        val dx = ex - sx
        val dy = ey - sy
        val length = hypot(dx, dy)
        if (length < 48f) return null
        val ux = dx / length
        val uy = dy / length
        val nx = -uy
        val ny = ux
        val measured = proposal.measuredWidthMedianPx.takeIf { it > 0 }?.toFloat()
        val detectorHalf = proposal.axisWidthPx.coerceAtLeast(24) * 0.72f
        val halfWidth = if (measured != null) {
            min(detectorHalf, max(14f, measured * 2.60f))
        } else {
            max(24f, detectorHalf)
        }

        val src = floatArrayOf(
            sx - nx * halfWidth, sy - ny * halfWidth,
            ex - nx * halfWidth, ey - ny * halfWidth,
            ex + nx * halfWidth, ey + ny * halfWidth,
            sx + nx * halfWidth, sy + ny * halfWidth
        )
        val outW = length.toInt().coerceIn(96, 1400)
        val outH = (halfWidth * 2f).toInt().coerceIn(48, 260)
        val dst = floatArrayOf(
            0f, 0f,
            outW.toFloat(), 0f,
            outW.toFloat(), outH.toFloat(),
            0f, outH.toFloat()
        )
        return runCatching {
            val matrix = Matrix()
            if (!matrix.setPolyToPoly(src, 0, dst, 0, 4)) return@runCatching null
            val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
            try {
                val canvas = Canvas(out)
                canvas.drawBitmap(bitmap, matrix, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                out
            } catch (failure: Throwable) {
                if (!out.isRecycled) out.recycle()
                throw failure
            }
        }.getOrNull()
    }

    fun acceptBest(candidates: List<VisualProductMatch>): VisualProductMatch? {
        if (candidates.isEmpty()) return null
        val ranked = candidates.sortedByDescending { it.score }
        val best = ranked.first()
        val second = ranked.getOrNull(1)
        if (best.score < 82) return null
        if (second != null && best.score - second.score < 8) return null
        return best
    }


    /**
     * V8.4.13 NORMAL-owned region pre-gate.
     *
     * NORMAL ML Kit detections are treated as owned compact-product regions.
     * A pure long-analyzer strip cannot claim those same pixels as a rod unless
     * it also carries independent ML long evidence and adequate rod structure.
     * This prevents boxes/packages, grout lines and broad scene bands from
     * becoming phantom LONG instances.
     */
    private fun applyCrossLaneSceneGate(
        longInput: List<ScanProposal>,
        normalInput: List<ScanProposal>
    ): List<ScanProposal> {
        if (longInput.isEmpty()) return emptyList()

        return longInput.map { candidate ->
            if (candidate.bridgeSuppressed) return@map candidate

            val isPureAnalyzer = candidate.source == ScanProposal.SOURCE_LONG &&
                !candidate.proposalId.contains("ML-")
            val ownedNormals = normalInput.filter { normal ->
                val intersection = intersectionArea(candidate.normalizedBounds, normal.normalizedBounds)
                if (intersection <= 0L) return@filter false
                val normalArea = area(normal.normalizedBounds).coerceAtLeast(1L)
                intersection.toFloat() / normalArea.toFloat() >= STRONG_NORMAL_OWNERSHIP
            }

            val spansMultipleNormals = ownedNormals.size >= 2
            val weakRodStructure = isPureAnalyzer &&
                candidate.rodStructureScore in 0 until MIN_ANALYZER_ROD_STRUCTURE

            when {
                spansMultipleNormals -> candidate.copy(
                    proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                    source = ScanProposal.SOURCE_CROSS_LANE,
                    physicalInstanceHint = "CROSS-LANE-${candidate.proposalId}",
                    quantityEligible = false,
                    bridgeSuppressed = true,
                    normalOwnershipConflict = true
                )

                weakRodStructure -> candidate.copy(
                    proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                    source = ScanProposal.SOURCE_BACKGROUND,
                    physicalInstanceHint = "BACKGROUND-${candidate.proposalId}",
                    quantityEligible = false,
                    bridgeSuppressed = true,
                    normalOwnershipConflict = ownedNormals.isNotEmpty()
                )

                isPureAnalyzer && ownedNormals.isNotEmpty() &&
                    candidate.rodStructureScore < (MIN_ANALYZER_ROD_STRUCTURE + 10) -> candidate.copy(
                    proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                    source = ScanProposal.SOURCE_CROSS_LANE,
                    physicalInstanceHint = "CROSS-LANE-${candidate.proposalId}",
                    quantityEligible = false,
                    bridgeSuppressed = true,
                    normalOwnershipConflict = true
                )

                else -> candidate.copy(
                    normalOwnershipConflict = ownedNormals.isNotEmpty()
                )
            }
        }
    }

    private fun assignPhysicalHintsAndSuppressBridges(input: List<ScanProposal>): List<ScanProposal> {
        if (input.isEmpty()) return emptyList()

        // First suppress broad same-axis containers that cover two narrower,
        // physically separated candidates. This breaks the V8.4.7 bridge chain.
        val sameAxisClassified = input.map { candidate ->
            if (isParallelContainer(candidate, input)) {
                candidate.copy(
                    proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                    source = ScanProposal.SOURCE_BRIDGE,
                    physicalInstanceHint = "BRIDGE-${candidate.proposalId}",
                    quantityEligible = false,
                    bridgeSuppressed = true
                )
            } else candidate
        }

        val usable = sameAxisClassified.filterNot { it.bridgeSuppressed }
        val vertical = usable.filter { isVertical(it.normalizedBounds) }
        val horizontal = usable.filter { isHorizontal(it.normalizedBounds) }

        val verticalHints = clusterSameAxis(vertical, "PHYS-V")
        val horizontalHints = clusterSameAxis(horizontal, "PHYS-H")
        val assigned = sameAxisClassified.map { proposal ->
            if (proposal.bridgeSuppressed) return@map proposal
            val hint = verticalHints[proposal.proposalId]
                ?: horizontalHints[proposal.proposalId]
                ?: "PHYS-${proposal.proposalId}"
            proposal.copy(physicalInstanceHint = hint)
        }.toMutableList()

        // Choose one orientation as the physical anchor. The orientation with
        // more distinct axis clusters wins; ties prefer the family with the
        // longer average axis. This prevents a single crossing floor/tile band
        // from rewriting two real rod instance IDs into one bridge lineage.
        val verticalCount = verticalHints.values.distinct().size
        val horizontalCount = horizontalHints.values.distinct().size
        val verticalAvgLength = vertical.map { longAxisLength(it.normalizedBounds) }.average().takeIf { !it.isNaN() } ?: 0.0
        val horizontalAvgLength = horizontal.map { longAxisLength(it.normalizedBounds) }.average().takeIf { !it.isNaN() } ?: 0.0
        val anchorVertical = when {
            verticalCount > horizontalCount -> true
            horizontalCount > verticalCount -> false
            else -> verticalAvgLength >= horizontalAvgLength
        }

        // Only non-anchor proposals may inherit an anchor physical ID. If a
        // non-anchor band touches two or more anchor instances it is a bridge.
        for (i in assigned.indices) {
            val candidate = assigned[i]
            if (candidate.bridgeSuppressed) continue
            val candidateVertical = isVertical(candidate.normalizedBounds)
            val candidateHorizontal = isHorizontal(candidate.normalizedBounds)
            if (!candidateVertical && !candidateHorizontal) continue

            val isAnchorFamily = (anchorVertical && candidateVertical) || (!anchorVertical && candidateHorizontal)
            if (isAnchorFamily) continue

            val anchors = assigned.filter { other ->
                other !== candidate && !other.bridgeSuppressed &&
                    ((anchorVertical && isVertical(other.normalizedBounds)) ||
                        (!anchorVertical && isHorizontal(other.normalizedBounds)))
            }
            val hits = anchors
                .filter { crossAxisSupportsSameRegion(candidate.normalizedBounds, it.normalizedBounds) }
                .map { it.physicalInstanceHint }
                .filter { it.isNotBlank() }
                .distinct()

            if (hits.size >= 2) {
                assigned[i] = candidate.copy(
                    proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                    source = ScanProposal.SOURCE_BRIDGE,
                    physicalInstanceHint = "BRIDGE-${candidate.proposalId}",
                    quantityEligible = false,
                    bridgeSuppressed = true
                )
            } else if (hits.size == 1) {
                assigned[i] = candidate.copy(physicalInstanceHint = hits.first())
            }
        }

        return assigned
    }

    private fun clusterSameAxis(items: List<ScanProposal>, prefix: String): Map<String, String> {
        if (items.isEmpty()) return emptyMap()
        val vertical = prefix.endsWith("V")
        val sorted = items.sortedBy { if (vertical) centerX(it.normalizedBounds) else centerY(it.normalizedBounds) }
        val groups = mutableListOf<MutableList<ScanProposal>>()

        sorted.forEach { candidate ->
            val group = groups.firstOrNull { existing ->
                existing.all { current -> samePhysicalAxis(current.normalizedBounds, candidate.normalizedBounds) }
            }
            if (group != null) group += candidate else groups += mutableListOf(candidate)
        }

        val result = HashMap<String, String>()
        groups.forEachIndexed { index, group ->
            val id = "$prefix-${index + 1}"
            group.forEach { result[it.proposalId] = id }
        }
        return result
    }

    private fun isParallelContainer(candidate: ScanProposal, all: List<ScanProposal>): Boolean {
        val r = candidate.normalizedBounds
        if (!isVertical(r) && !isHorizontal(r)) return false
        val sameOrientationPeers = all.filter { other ->
            other !== candidate && sameOrientation(r, other.normalizedBounds)
        }
        if (sameOrientationPeers.size < 2) return false

        val candidateShort = shortAxisSize(r).coerceAtLeast(1)
        val contained = sameOrientationPeers.filter { peer ->
            val pr = peer.normalizedBounds
            val peerShort = shortAxisSize(pr).coerceAtLeast(1)
            val longOverlap = longAxisOverlapRatio(r, pr)
            val centerInside = if (isVertical(r)) {
                centerX(pr) in r.left.toFloat()..r.right.toFloat()
            } else {
                centerY(pr) in r.top.toFloat()..r.bottom.toFloat()
            }
            candidateShort >= peerShort * 1.55f && centerInside && longOverlap >= 0.45f
        }
        if (contained.size < 2) return false

        val centers = contained.map { if (isVertical(r)) centerX(it.normalizedBounds) else centerY(it.normalizedBounds) }.sorted()
        val widestGap = centers.zipWithNext { a, b -> abs(b - a) }.maxOrNull() ?: 0f
        val peerShort = contained.map { shortAxisSize(it.normalizedBounds).toFloat() }.minOrNull() ?: candidateShort.toFloat()
        return widestGap >= max(28f, peerShort * 0.75f)
    }

    private fun samePhysicalAxis(a: Rect, b: Rect): Boolean {
        if (!sameOrientation(a, b)) return false
        val shortA = shortAxisSize(a).coerceAtLeast(1)
        val shortB = shortAxisSize(b).coerceAtLeast(1)
        val shortRatio = max(shortA, shortB).toFloat() / min(shortA, shortB).toFloat()
        if (shortRatio > 1.75f) return false

        val centerGap = if (isVertical(a)) abs(centerX(a) - centerX(b)) else abs(centerY(a) - centerY(b))
        val gapLimit = min(shortA, shortB) * 0.72f + 14f
        return centerGap <= gapLimit && longAxisOverlapRatio(a, b) >= 0.40f
    }

    private fun crossAxisSupportsSameRegion(a: Rect, b: Rect): Boolean {
        val intersection = intersectionArea(a, b)
        if (intersection <= 0L) return false
        val smaller = min(area(a), area(b)).coerceAtLeast(1L)
        return intersection.toFloat() / smaller.toFloat() >= 0.10f
    }

    private fun mergeMetadata(a: ScanProposal, b: ScanProposal): ScanProposal {
        val preferred = if (a.strength >= b.strength) a else b
        val mergedBounds = union(a.normalizedBounds, b.normalizedBounds)
        return preferred.copy(
            proposalId = "${preferred.proposalId}+${if (preferred === a) b.proposalId else a.proposalId}",
            source = if (a.source == b.source) a.source else ScanProposal.SOURCE_MERGED,
            proposalType = if (a.proposalType == ScanProposal.TYPE_LONG || b.proposalType == ScanProposal.TYPE_LONG) ScanProposal.TYPE_LONG else preferred.proposalType,
            originalBounds = union(a.originalBounds, b.originalBounds),
            normalizedBounds = mergedBounds,
            lineageId = if (a.lineageId == b.lineageId) a.lineageId else preferred.lineageId,
            physicalInstanceHint = if (a.physicalInstanceHint == b.physicalInstanceHint) a.physicalInstanceHint else preferred.physicalInstanceHint,
            normalOwnershipConflict = a.normalOwnershipConflict || b.normalOwnershipConflict,
            rodStructureScore = max(a.rodStructureScore, b.rodStructureScore),
            orientation = if (preferred.orientation != "UNKNOWN") preferred.orientation else orientationOf(mergedBounds),
            strength = max(a.strength, b.strength)
        )
    }

    private fun sameTypedLongProposal(a: ScanProposal, b: ScanProposal): Boolean {
        if (orientationFamily(a.orientation) != orientationFamily(b.orientation)) return false
        // Do not merge merely because V8.4.7 bucket lineage matches. Physical
        // separation now wins over old H/V bucket lineage.
        return samePhysicalAxis(a.normalizedBounds, b.normalizedBounds)
    }

    private fun longLineage(rect: Rect, width: Int, height: Int): String {
        val vertical = isVertical(rect)
        val axisSize = if (vertical) width else height
        val center = if (vertical) centerX(rect) else centerY(rect)
        val bucketSize = (axisSize * 0.18f).coerceAtLeast(24f)
        val bucket = (center / bucketSize).toInt()
        return "LONG-${if (vertical) "V" else "H"}-$bucket"
    }

    private fun tile(w: Int, h: Int, col: Int, row: Int): Rect {
        val tw = (w * 0.62f).toInt().coerceAtLeast(64).coerceAtMost(w)
        val th = (h * 0.62f).toInt().coerceAtLeast(64).coerceAtMost(h)
        val left = if (col == 0) 0 else w - tw
        val top = if (row == 0) 0 else h - th
        return Rect(left, top, min(w, left + tw), min(h, top + th))
    }

    private fun samePhysicalProposal(a: Rect, b: Rect): Boolean {
        val overlap = iou(a, b)
        if (overlap >= MAX_BOX_IOU) return true

        val intersection = intersectionArea(a, b)
        val minArea = minOf(area(a), area(b)).coerceAtLeast(1L)
        if (intersection.toFloat() / minArea.toFloat() >= 0.62f) return true

        val distance = hypot(centerX(a) - centerX(b), centerY(a) - centerY(b))
        val scale = minOf(
            hypot(a.width().toFloat(), a.height().toFloat()),
            hypot(b.width().toFloat(), b.height().toFloat())
        ).coerceAtLeast(1f)
        val areaA = area(a).coerceAtLeast(1L)
        val areaB = area(b).coerceAtLeast(1L)
        val areaRatio = maxOf(areaA, areaB).toFloat() / minOf(areaA, areaB).toFloat()
        return distance <= scale * 0.16f && areaRatio <= 1.85f
    }

    private fun fullFramePenalty(rect: Rect, w: Int, h: Int): Int {
        if (w <= 0 || h <= 0) return 0
        val ratio = area(rect).toFloat() / (w.toLong() * h.toLong()).coerceAtLeast(1L).toFloat()
        return if (ratio > 0.82f) 1 else 0
    }

    private fun iou(a: Rect, b: Rect): Float {
        val intersection = intersectionArea(a, b)
        val unionArea = area(a) + area(b) - intersection
        return if (unionArea <= 0L) 0f else intersection.toFloat() / unionArea.toFloat()
    }

    private fun intersectionArea(a: Rect, b: Rect): Long {
        val left = maxOf(a.left, b.left)
        val top = maxOf(a.top, b.top)
        val right = minOf(a.right, b.right)
        val bottom = minOf(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0L
        return (right - left).toLong() * (bottom - top).toLong()
    }

    private fun expandAndClamp(rect: Rect, width: Int, height: Int): Rect {
        val padX = max(8, (rect.width() * 0.08f).toInt())
        val padY = max(8, (rect.height() * 0.08f).toInt())
        return Rect(
            max(0, rect.left - padX),
            max(0, rect.top - padY),
            min(width, rect.right + padX),
            min(height, rect.bottom + padY)
        )
    }

    private fun union(a: Rect, b: Rect): Rect = Rect(
        min(a.left, b.left),
        min(a.top, b.top),
        max(a.right, b.right),
        max(a.bottom, b.bottom)
    )

    private fun rectKey(r: Rect): String = "${r.left}:${r.top}:${r.right}:${r.bottom}"
    private fun area(r: Rect): Long = r.width().coerceAtLeast(0).toLong() * r.height().coerceAtLeast(0).toLong()
    private fun centerX(r: Rect): Float = (r.left + r.right) / 2f
    private fun centerY(r: Rect): Float = (r.top + r.bottom) / 2f
    private fun isVertical(r: Rect): Boolean = r.height() >= r.width() * 1.45f
    private fun isHorizontal(r: Rect): Boolean = r.width() >= r.height() * 1.45f
    private fun isLongRect(r: Rect): Boolean {
        val short = min(r.width(), r.height()).coerceAtLeast(1)
        val long = max(r.width(), r.height())
        return long.toFloat() / short.toFloat() >= LONG_ASPECT
    }
    private fun sameOrientation(a: Rect, b: Rect): Boolean =
        (isVertical(a) && isVertical(b)) || (isHorizontal(a) && isHorizontal(b))
    private fun orientationOf(r: Rect): String = when {
        isVertical(r) -> "VERTICAL"
        isHorizontal(r) -> "HORIZONTAL"
        else -> "COMPACT"
    }
    private fun orientationFamily(value: String): String = when {
        value.startsWith("VERTICAL") -> "VERTICAL"
        value.startsWith("HORIZONTAL") -> "HORIZONTAL"
        else -> value
    }
    private fun shortAxisSize(r: Rect): Int = if (isVertical(r)) r.width() else r.height()
    private fun longAxisLength(r: Rect): Int = if (isVertical(r)) r.height() else r.width()
    private fun longAxisOverlapRatio(a: Rect, b: Rect): Float {
        if (!sameOrientation(a, b)) return 0f
        val overlap = if (isVertical(a)) {
            axisOverlap(a.top, a.bottom, b.top, b.bottom)
        } else {
            axisOverlap(a.left, a.right, b.left, b.right)
        }
        val minimum = min(longAxisLength(a), longAxisLength(b)).coerceAtLeast(1)
        return overlap.toFloat() / minimum.toFloat()
    }
    private fun axisOverlap(a0: Int, a1: Int, b0: Int, b1: Int): Int =
        (min(a1, b1) - max(a0, b0)).coerceAtLeast(0)

    private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T =
        suspendCancellableCoroutine { continuation ->
            addOnSuccessListener { value -> if (continuation.isActive) continuation.resume(value) }
            addOnFailureListener { error -> if (continuation.isActive) continuation.resumeWithException(error) }
            addOnCanceledListener { continuation.cancel() }
        }
}
