package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max

/**
 * V8.4.14 live HANDLE + MID-SHAFT + TIP anchor extractor.
 *
 * The oriented LONG crop is canonicalized left-to-right, but camera framing can
 * reverse which physical endpoint lands on the left. V8.4.12 therefore exposes
 * BOTH endpoint crops. ProductVisualMatcher can compare both HANDLE/TIP role
 * hypotheses against master anchors and choose one deterministic global role
 * assignment instead of trusting endpoint texture alone.
 */
object RodAnchorExtractor {
    data class Anchors(
        val leftEnd: Bitmap,
        val side: Bitmap,
        val rightEnd: Bitmap,
        val handleOnLeft: Boolean
    ) {
        val handle: Bitmap
            get() = if (handleOnLeft) leftEnd else rightEnd
        val tip: Bitmap
            get() = if (handleOnLeft) rightEnd else leftEnd

        fun recycle() {
            listOf(leftEnd, side, rightEnd).distinct().forEach { if (!it.isRecycled) it.recycle() }
        }
    }

    fun extract(orientedRod: Bitmap): Anchors? {
        if (orientedRod.width < 72 || orientedRod.height < 24) return null
        val endpointFraction = 0.34f
        val handleOnLeft = endpointEnergy(orientedRod, true) >= endpointEnergy(orientedRod, false)

        val endpointW = max(36, (orientedRod.width * endpointFraction).toInt()).coerceAtMost(orientedRod.width)
        val sideW = max(48, (orientedRod.width * 0.52f).toInt()).coerceAtMost(orientedRod.width)
        val sideLeft = ((orientedRod.width - sideW) / 2).coerceAtLeast(0)

        val allocated = ArrayList<Bitmap>(3)
        return try {
            fun own(x: Int, width: Int): Bitmap =
                Bitmap.createBitmap(orientedRod, x, 0, width, orientedRod.height).also { allocated += it }
            Anchors(own(0, endpointW), own(sideLeft, sideW), own(orientedRod.width - endpointW, endpointW), handleOnLeft)
        } catch (_: Throwable) {
            allocated.filter { it !== orientedRod }.distinct().forEach { if (!it.isRecycled) it.recycle() }
            null
        }
    }

    private fun endpointEnergy(bitmap: Bitmap, left: Boolean): Float {
        val w = max(24, (bitmap.width * 0.30f).toInt()).coerceAtMost(bitmap.width)
        val startX = if (left) 0 else bitmap.width - w
        val stepX = max(1, w / 36)
        val stepY = max(1, bitmap.height / 24)
        var texture = 0f
        var darkMass = 0f
        var samples = 0

        var y = 0
        while (y < bitmap.height) {
            var x = startX
            while (x < startX + w) {
                val current = luminance(bitmap.getPixel(x, y))
                val x2 = (x + stepX).coerceAtMost(startX + w - 1)
                val y2 = (y + stepY).coerceAtMost(bitmap.height - 1)
                texture += abs(current - luminance(bitmap.getPixel(x2, y)))
                texture += abs(current - luminance(bitmap.getPixel(x, y2)))
                darkMass += (1f - current).coerceIn(0f, 1f)
                samples++
                x += stepX
            }
            y += stepY
        }
        if (samples == 0) return 0f
        return texture / samples.toFloat() * 0.62f + darkMass / samples.toFloat() * 0.38f
    }

    private fun luminance(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
}
