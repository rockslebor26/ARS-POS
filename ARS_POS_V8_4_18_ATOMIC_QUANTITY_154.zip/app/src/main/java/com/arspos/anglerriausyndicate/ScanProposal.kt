package com.arspos.anglerriausyndicate

import android.graphics.Rect

/**
 * Phase 4.3.2.34 V8.4.14 — rod-claim ownership metadata.
 *
 * A detected LONG line is only an AXIS_HYPOTHESIS. It becomes a TRACK-* after
 * global physical-object resolution, and only a TRUSTED_ROD track may own
 * cashier quantity or block a NORMAL visual-only identity. This separates
 * geometry evidence from physical truth and prevents one long object from
 * becoming several sellable objects.
 */
data class ScanProposal(
    val proposalId: String,
    val source: String,
    val proposalType: String,
    val originalBounds: Rect,
    val normalizedBounds: Rect,
    val rotationDegrees: Int = 0,
    val lineageId: String,
    val physicalInstanceHint: String = "",
    val quantityEligible: Boolean = true,
    val bridgeSuppressed: Boolean = false,
    val normalOwnershipConflict: Boolean = false,
    val rodStructureScore: Int = 0,
    val orientation: String = "UNKNOWN",
    val strength: Int = 0,
    val axisAngleDeg: Float = 0f,
    val axisStartX: Int = 0,
    val axisStartY: Int = 0,
    val axisEndX: Int = 0,
    val axisEndY: Int = 0,
    // In V8.4.13 this is explicitly the detector corridor width, not the
    // measured physical-object width. Real width telemetry is stored below.
    val axisWidthPx: Int = 0,
    val axisConfidence: Int = 0,

    // V8.4.13 physical-object truth / rod-authenticity telemetry.
    val physicalObjectId: String = "",
    val hypothesesMerged: Int = 1,
    val physicalMergeReason: String = "",
    val measuredWidthMedianPx: Int = 0,
    val measuredWidthP10Px: Int = 0,
    val measuredWidthP90Px: Int = 0,
    val widthVariance: Float = 0f,
    val taperRatio: Float = 0f,
    val curvatureScore: Int = 0,
    val rodPositiveEvidence: Int = 0,
    val branchPenalty: Int = 0,
    val beamPenalty: Int = 0,
    val floorLinePenalty: Int = 0,
    val shadowPenalty: Int = 0,
    val rodAuthenticityScore: Int = 0,
    val rodAuthenticityState: String = AUTH_UNKNOWN,
    val trustedRod: Boolean = false,

    // Raw geometric claim is diagnostic only. It grants neither ownership nor
    // quantity; trusted authenticity and product identity remain independent.
    val rodClaim: Boolean = false,
    val rodClaimScore: Int = 0,
    val crossThroughIntersections: Int = 0,
    val trueBranchIntersections: Int = 0,

    // Cross-category firewall metadata. Barcode/strong OCR remain independent
    // evidence and these flags never lower any recognition threshold.
    val crossCategoryConflict: Boolean = false,
    val crossCategoryConflictScore: Int = 0,
    val rodTrackHits: Int = 0,
    val visualOnlyBlocked: Boolean = false,
    val crossCategoryReason: String = "",
    val segmentSupport: Boolean = false,
    val shaftVariation: Float = 0f,
    val shaftContinuity: Float = 0f
) {
    val hasResolvedAxis: Boolean
        get() = axisConfidence > 0 &&
            (axisStartX != axisEndX || axisStartY != axisEndY)

    companion object {
        const val TYPE_NORMAL = "NORMAL_OBJECT"
        const val TYPE_LONG = "LONG_OBJECT"
        const val TYPE_RESCUE = "FULL_FRAME_RESCUE"
        const val TYPE_AMBIGUOUS_CONTAINER = "AMBIGUOUS_CONTAINER"

        const val SOURCE_MLKIT = "MLKIT"
        const val SOURCE_LONG = "LONG_ANALYZER"
        const val SOURCE_MERGED = "MERGED"
        const val SOURCE_RESCUE = "FULL_FRAME_RESCUE"
        const val SOURCE_SCENE_BARCODE = "SCENE_BARCODE"
        const val SOURCE_BRIDGE = "BRIDGE_SUPPRESSED"
        const val SOURCE_CROSS_LANE = "CROSS_LANE_SUPPRESSED"
        const val SOURCE_BACKGROUND = "BACKGROUND_REJECTED"
        const val SOURCE_TRACK = "PHYSICAL_TRACK"
        const val SOURCE_AUTHENTICITY = "ROD_AUTHENTICITY_REJECTED"

        const val AUTH_UNKNOWN = "AUTH_UNKNOWN"
        const val AUTH_NON_ROD = "NON_ROD"
        const val AUTH_UNCERTAIN = "ROD_UNCERTAIN"
        const val AUTH_TRUSTED = "TRUSTED_ROD"
        const val OWNERSHIP_ROD_CLAIM = "ROD_CLAIM"
    }
}
