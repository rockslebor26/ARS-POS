package com.arspos.anglerriausyndicate

/**
 * Persistent development target lock shown in ARS Dev Center.
 * This is documentation/diagnostics only and is never used as recognition logic.
 */
object ArsProjectCharter {
    val ultimateGoal = """
        CAMERA → PHYSICAL OBJECT → STABLE OBJECT LOCK → IDENTITY → PRODUCT → SAFE QUANTITY

        Satu benda fisik harus dipertahankan sebagai satu objek yang sama sampai identitasnya diputuskan atau evidence dinyatakan belum cukup. Smart Scan harus cepat dan konsisten pada single-object maupun multi-object tanpa membuat quantity palsu.
    """.trimIndent()

    val nonNegotiableRules = """
        • Recognition threshold/margin tidak boleh diturunkan agar terlihat berhasil.
        • Identity accepted tidak otomatis berarti quantity accepted.
        • Cloud/AI tidak boleh membuat quantity, mengubah stok/pembayaran, signer, atau memasang APK.
        • Canonical physical truth, Safety Kernel, Decision Ledger, Ground Truth, Replay, Rod Authenticity, Package Edge Firewall, dan update in-place tetap dilindungi.
        • Package resmi tetap com.arspos.anglerriausyndicate; versionCode wajib meningkat; signer resmi wajib sama.
    """.trimIndent()

    val currentMission = """
        V8.8.9 CURRENT MISSION

        Smart Scan harus mengenali semua canonical physical object yang sudah LOCKED tanpa serialisasi satu identity owner. Setiap pass dapat memproses sampai 4 object untuk visual retrieval; selected track hanya prioritas. OCR dan high-resolution hanya eskalasi untuk object ambigu dan tidak boleh menahan object lain. Finalization harus mempertahankan semua proposal multi-object dan memakai live canonical evidence tanpa rediscovery lintas-object. Threshold recognition tidak berubah.
    """.trimIndent()

    val baseline = """
        BASELINE V8.8.7 — real-device diagnostic 2026-09-28
        • Scan sessions: 12/12 complete; crash/ANR/native crash/evidence error: 0.
        • Average completed scan: 1826 ms; object end-to-end: 1147 ms; crop OCR: 816 ms.
        • Latest first candidate: 4789 ms; another observed first candidate: 8019 ms; live MATCHED: 0.
        • Live/final comparable: 9; consistent: 5; mismatch: 4.
        • Verified failure: 2 NORMAL proposals sharing coarse foreground were merged into 1 canonical MERGED_FRAGMENT.
        • Ground-truth annotations: 0. PSS high-water: 323 MB; native high-water: 179 MB.
    """.trimIndent()

    val regressionGuard = """
        PHASE GATE
        IMPLEMENTED → TESTING → EVIDENCE VERIFIED → TARGET PASSED → CLOSED

        Target engineering V8.8.9: first candidate single-object P95 ≤1.5 s; seluruh 2–4 stable object mendapat identity candidate ≤2 s P95; locked track tanpa identity attempt <10%; PHYSICAL_STATE_BEFORE_IDENTITY setelah lock <5%; tidak ada canonical track >2 s tanpa identity attempt; live/final consistency ≥95% pada comparable object; selected-track collapse = 0 dalam MULTI mode; false/duplicate automatic quantity = 0; threshold relaxation = 0; ground truth wajib terisi pada regression run.
    """.trimIndent()

}
