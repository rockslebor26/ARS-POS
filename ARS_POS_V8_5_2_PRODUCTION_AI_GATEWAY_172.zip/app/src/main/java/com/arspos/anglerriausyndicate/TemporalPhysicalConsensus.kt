package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.3.2 / V8.5.2.
 *
 * Temporal evidence may seed missing LONG geometry, but it never identifies an
 * SKU and never bypasses RodAuthenticityEvaluator. A seeded proposal must still
 * pass the same pixel-authenticity, package-edge, cross-lane, anchor and final
 * identity gates as every other LONG proposal.
 */
object TemporalPhysicalConsensus {
    private const val MIN_SEED_ASPECT = 4.0f
    private const val MIN_SEED_OBSERVATIONS = 2

    fun seedMissingLongGeometry(
        proposals: List<ScanProposal>,
        liveLock: LiveSceneLockSnapshot?,
        finalWidth: Int,
        finalHeight: Int
    ): List<ScanProposal> {
        if (liveLock == null || liveLock.tracks.isEmpty() || finalWidth <= 0 || finalHeight <= 0) return proposals
        val liveLong = liveLock.tracks.filter {
            it.proposalType == ScanProposal.TYPE_LONG &&
                it.state != LiveSceneTrack.STATE_OCCLUDED &&
                it.observationCount >= MIN_SEED_OBSERVATIONS &&
                it.temporalPhysicalState != "TEMPORAL_UNPROVEN"
        }
        if (liveLong.isEmpty()) return proposals

        return proposals.map { proposal ->
            if (proposal.proposalType != ScanProposal.TYPE_LONG || proposal.hasResolvedAxis) return@map proposal
            val r = proposal.normalizedBounds
            val longSide = max(r.width(), r.height()).coerceAtLeast(1)
            val shortSide = min(r.width(), r.height()).coerceAtLeast(1)
            val aspect = longSide.toFloat() / shortSide.toFloat()
            if (aspect < MIN_SEED_ASPECT) return@map proposal

            val best = liveLong.map { track -> track to normalizedIou(track, liveLock, r, finalWidth, finalHeight) }
                .filter { it.second >= 0.14f }
                .maxByOrNull { it.second }
                ?: return@map proposal
            val track = best.first

            val insetX = (r.width() * 0.08f).toInt().coerceAtLeast(2)
            val insetY = (r.height() * 0.08f).toInt().coerceAtLeast(2)
            val vertical = r.height() >= r.width()
            val sx: Int
            val sy: Int
            val ex: Int
            val ey: Int
            if (vertical) {
                sx = (r.left + r.right) / 2
                ex = sx
                sy = r.top + insetY
                ey = r.bottom - insetY
            } else {
                sy = (r.top + r.bottom) / 2
                ey = sy
                sx = r.left + insetX
                ex = r.right - insetX
            }
            val temporalConfidence = (42 + track.trustedPhysicalHits * 6 + track.uncertainPhysicalHits * 3 +
                min(track.observationCount, 5) * 2).coerceIn(42, 68)
            val seededStructure = max(
                proposal.rodStructureScore,
                track.maxRodStructureScore.coerceIn(34, 82)
            )
            proposal.copy(
                source = ScanProposal.SOURCE_TEMPORAL_SEED,
                lineageId = "${proposal.lineageId}+${track.trackId}",
                axisStartX = sx,
                axisStartY = sy,
                axisEndX = ex,
                axisEndY = ey,
                axisAngleDeg = if (vertical) 90f else 0f,
                axisWidthPx = shortSide,
                axisConfidence = temporalConfidence,
                rodStructureScore = seededStructure,
                physicalMergeReason = listOf(proposal.physicalMergeReason, "TEMPORAL_ML_SEED:${track.trackId}")
                    .filter { it.isNotBlank() }.joinToString("+")
            )
        }
    }

    /**
     * A strong temporal history may keep a bad final frame as evidence-only
     * ROD_UNCERTAIN. It never becomes quantity eligible through this method.
     */
    fun stabilizeFinalAuthenticity(
        proposal: ScanProposal,
        track: LiveSceneTrack?
    ): ScanProposal {
        if (track == null || proposal.proposalType != ScanProposal.TYPE_LONG) return proposal
        if (proposal.rodAuthenticityState != ScanProposal.AUTH_NON_ROD) return proposal
        val temporalStrong = track.temporalPhysicalState == "TEMPORAL_TRUSTED_ROD" &&
            track.trustedPhysicalHits >= 2 && track.foregroundSupportHits >= 2 &&
            track.maxRodAuthenticityScore >= 80
        val finalGeometryStillPlausible = proposal.axisConfidence >= 50 &&
            proposal.rodStructureScore >= 75 && proposal.branchPenalty <= 10
        if (!temporalStrong || !finalGeometryStillPlausible) return proposal
        return proposal.copy(
            rodAuthenticityState = ScanProposal.AUTH_UNCERTAIN,
            trustedRod = false,
            quantityEligible = false,
            bridgeSuppressed = false,
            physicalMergeReason = listOf(proposal.physicalMergeReason, "TEMPORAL_BAD_FRAME_RECOVERY:${track.trackId}")
                .filter { it.isNotBlank() }.joinToString("+")
        )
    }

    private fun normalizedIou(track: LiveSceneTrack, snapshot: LiveSceneLockSnapshot, b: Rect, bw: Int, bh: Int): Float {
        if (snapshot.frameWidth <= 0 || snapshot.frameHeight <= 0 || bw <= 0 || bh <= 0) return 0f
        val a = track.bounds
        val al = a.left.toFloat() / snapshot.frameWidth
        val at = a.top.toFloat() / snapshot.frameHeight
        val ar = a.right.toFloat() / snapshot.frameWidth
        val ab = a.bottom.toFloat() / snapshot.frameHeight
        val bl = b.left.toFloat() / bw
        val bt = b.top.toFloat() / bh
        val br = b.right.toFloat() / bw
        val bb = b.bottom.toFloat() / bh
        val l=max(al,bl); val t=max(at,bt); val r=min(ar,br); val bottom=min(ab,bb)
        if (r <= l || bottom <= t) return 0f
        val inter=(r-l)*(bottom-t)
        val areaA=(ar-al).coerceAtLeast(0f)*(ab-at).coerceAtLeast(0f)
        val areaB=(br-bl).coerceAtLeast(0f)*(bb-bt).coerceAtLeast(0f)
        val union=areaA+areaB-inter
        return if (union <= 0f) 0f else inter/union
    }
}
