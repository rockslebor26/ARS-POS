package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Rect

/**
 * V8.5.2 second-chance physical recovery for ML long-object proposals.
 *
 * Global line analysis can be dominated by floor/wall structure. This pass runs
 * the same physical axis detector inside the ML-owned ROI, then maps the best
 * local axis back to scene coordinates. It does not grant TRUSTED_ROD or
 * quantity; RodAuthenticityEvaluator remains mandatory afterwards.
 */
object MlGuidedLocalRodRecovery {
    data class Result(val proposals: List<ScanProposal>, val attempted: Int, val recovered: Int)

    fun recover(bitmap: Bitmap, input: List<ScanProposal>): Result {
        if (!ArsV850Config.FEATURE_ML_GUIDED_LOCAL_RECOVERY || input.isEmpty()) {
            return Result(input, 0, 0)
        }
        var attempted = 0
        var recovered = 0
        val out = input.map { proposal ->
            val eligible = proposal.proposalType == ScanProposal.TYPE_LONG &&
                !proposal.bridgeSuppressed && !proposal.hasResolvedAxis &&
                (proposal.source == ScanProposal.SOURCE_MLKIT || proposal.source == ScanProposal.SOURCE_TEMPORAL_SEED)
            if (!eligible) return@map proposal
            attempted++
            val bounds = clamp(proposal.normalizedBounds, bitmap.width, bitmap.height)
            if (bounds.width() < 80 || bounds.height() < 80) return@map proposal
            val roi = runCatching { Bitmap.createBitmap(bitmap, bounds.left, bounds.top, bounds.width(), bounds.height()) }
                .getOrNull() ?: return@map proposal
            try {
                val candidates = LongObjectAnalyzer.proposals(roi)
                val best = candidates.map { it to LongObjectAnalyzer.rodStructureScore(roi, it) }
                    .filter { (axis, structure) -> axis.axisConfidence >= 46 && structure >= 48 }
                    .maxWithOrNull(compareBy<Pair<LongObjectAnalyzer.Proposal, Int>> { it.second }
                        .thenBy { it.first.axisConfidence }
                        .thenBy { it.first.strength })
                    ?: return@map proposal
                val axis = best.first
                val structure = best.second
                recovered++
                proposal.copy(
                    source = ScanProposal.SOURCE_LOCAL_RECOVERY,
                    axisAngleDeg = axis.axisAngleDeg,
                    axisStartX = bounds.left + axis.axisStartX,
                    axisStartY = bounds.top + axis.axisStartY,
                    axisEndX = bounds.left + axis.axisEndX,
                    axisEndY = bounds.top + axis.axisEndY,
                    axisWidthPx = axis.estimatedWidthPx,
                    axisConfidence = axis.axisConfidence,
                    rodStructureScore = maxOf(proposal.rodStructureScore, structure),
                    orientation = axis.orientation,
                    strength = maxOf(proposal.strength, axis.strength),
                    quantityEligible = proposal.quantityEligible,
                    physicalMergeReason = listOf(proposal.physicalMergeReason, "ML_GUIDED_LOCAL_RECOVERY")
                        .filter { it.isNotBlank() }.joinToString("+")
                )
            } finally {
                if (!roi.isRecycled) roi.recycle()
            }
        }
        return Result(out, attempted, recovered)
    }

    private fun clamp(r: Rect, w: Int, h: Int): Rect = Rect(
        r.left.coerceIn(0, w - 1),
        r.top.coerceIn(0, h - 1),
        r.right.coerceIn(1, w),
        r.bottom.coerceIn(1, h)
    ).also {
        if (it.right <= it.left) it.right = (it.left + 1).coerceAtMost(w)
        if (it.bottom <= it.top) it.bottom = (it.top + 1).coerceAtMost(h)
    }
}
