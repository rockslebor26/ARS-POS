package com.arspos.anglerriausyndicate.data

import com.arspos.anglerriausyndicate.SmartProductInput
import com.arspos.anglerriausyndicate.ProductVisualMatcher
import com.arspos.anglerriausyndicate.VisualProductMatch
import androidx.room.withTransaction
import kotlinx.coroutines.flow.first
import com.arspos.anglerriausyndicate.data.db.*
import java.text.SimpleDateFormat
import java.util.*

data class ProfitSummary(val revenue:Long,val cost:Long,val grossProfit:Long)
data class LoginResult(val userId:Long,val role:String,val displayName:String)

class ProductionRepository(private val db:ArsDatabase){
    private val dao=db.dao()

    // V8.4.13 rolling in-process memory telemetry. This is diagnostic state
    // only; it never changes recognition decisions.
    private var scannerNativeBaselineMb: Long? = null
    private var scannerNativeHighWaterMb: Long = 0
    private var scannerPssHighWaterMb: Long = 0
    private var scannerScanCount: Int = 0
    private var scannerWarmNativeBaselineMb: Long? = null

    fun products()=dao.products()
    fun search(q:String)=if(q.isBlank())products() else dao.search(q)
    fun sales()=dao.sales()
    fun customers()=dao.customers()
    suspend fun saleItems(id:Long)=dao.saleItems(id)
    fun revenue(start:Long)=dao.revenue(start)
    fun transactionCount(start:Long)=dao.transactionCount(start)
    fun cashBalance()=dao.cashBalance()

    suspend fun login(username:String,pin:String):Result<LoginResult> = runCatching{
        val user=dao.user(username.trim()) ?: error("Username tidak ditemukan")
        require(PinHasher.matches(user.pinHash,pin)){"PIN salah"}
        if (!user.pinHash.startsWith("sha256\$")) dao.updateUser(user.copy(pinHash=PinHasher.hash(pin)))
        LoginResult(user.id,user.role,user.displayName)
    }

    suspend fun seed(){
        if(dao.countProducts()==0){
            listOf(
                ProductEntity(sku="JRG001",barcode="899000000001",name="Joran BC Elito Sidat 180",category="JORAN",brand="Elito",costPrice=95000,sellPrice=150000,wholesalePrice=135000,stock=15,minimumStock=5),
                ProductEntity(sku="REL001",barcode="899000000002",name="Reel Shimano FX 2500",category="REEL",brand="Shimano",costPrice=210000,sellPrice=275000,stock=8,minimumStock=3),
                ProductEntity(sku="SNR001",barcode="899000000003",name="PE Jabrik X9 2.0",category="SENAR",brand="Jabrik",costPrice=55000,sellPrice=85000,stock=12,minimumStock=4),
                ProductEntity(sku="LDR001",barcode="899000000004",name="Leader Relix 40lb",category="LEADER",brand="Relix",costPrice=28000,sellPrice=45000,stock=9,minimumStock=4),
                ProductEntity(sku="KIL001",barcode="899000000005",name="Kail BKK 1/0",category="KAIL",brand="BKK",costPrice=11000,sellPrice=18000,stock=20,minimumStock=5)
            ).forEach{dao.insertProduct(it)}
        }
        dao.insertUser(UserEntity(username="admin",displayName="Administrator",role="ADMIN",pinHash=PinHasher.hash("0000")))
        dao.setSetting(SettingEntity("store_name","ANGLER RIAU SYNDICATE"))
        dao.setSetting(SettingEntity("store_tagline","FISHING STORE"))
    }

    suspend fun addProduct(name:String,sku:String,barcode:String?,category:String,cost:Long,price:Long,stock:Int,brand:String?=null,variant:String?=null)=db.withTransaction{
        require(name.isNotBlank()) { "Nama produk wajib diisi" }
        val normalizedSku = sku.trim().ifBlank { SmartProductInput.generateSku(brand.orEmpty(), name, variant.orEmpty()) }
        val productId = dao.insertProduct(ProductEntity(
            sku=normalizedSku,
            barcode=barcode?.trim()?.ifBlank { null },
            name=name.trim(),
            category=category.trim().ifBlank { "LAINNYA" },
            brand=brand?.trim()?.ifBlank { null },
            variant=variant?.trim()?.ifBlank { null },
            costPrice=cost,
            sellPrice=price,
            stock=stock
        ))
        mergeProductIdentityProfile(
            productId = productId,
            brand = brand.orEmpty(),
            name = name,
            variant = variant.orEmpty(),
            barcode = barcode.orEmpty()
        )
        productId
    }

    fun productPhotos(productId:Long)=dao.productPhotos(productId)

    suspend fun visualProductMatches(bitmap: android.graphics.Bitmap):List<com.arspos.anglerriausyndicate.VisualProductMatch> {
        val photos=dao.allProductPhotos()
        if(photos.isEmpty()) return emptyList()
        val products=HashMap<Long,ProductEntity?>()
        val bestByProduct=HashMap<Long,com.arspos.anglerriausyndicate.VisualProductMatch>()
        for(photo in photos){
            val product=if(products.containsKey(photo.productId)) products[photo.productId] else dao.product(photo.productId).also{products[photo.productId]=it}
            if(product==null || !product.active) continue
            val score=com.arspos.anglerriausyndicate.ProductVisualMatcher.score(bitmap,photo.localPath)
            val match=com.arspos.anglerriausyndicate.VisualProductMatch(product,photo,score)
            val previous=bestByProduct[product.id]
            if(previous==null || score>previous.score) bestByProduct[product.id]=match
        }
        return bestByProduct.values.sortedByDescending { it.score }.take(8)
    }

    /**
     * Phase 4.3.3.2 / V8.5.2 — non-transactional Live Identity Fast Path preview.
     *
     * This intentionally does not open an evidence session, mutate the cart, or
     * populate the final review snapshot. It may expose a conservative database
     * candidate while the camera is moving; only smartVisualScan() can create a
     * final recognized object eligible for cashier quantity.
     */
    suspend fun liveScenePreview(bitmap: android.graphics.Bitmap): List<com.arspos.anglerriausyndicate.LiveSceneDetection> {
        val allProducts = dao.products().first().filter { it.active }
        if (allProducts.isEmpty()) return emptyList()

        val identityProfiles = loadIdentityProfiles()
        val verifiedProductIds = loadVerifiedProductIds()
        val productsById = allProducts.associateBy { it.id }
        val photos = selectRecognitionReferences(dao.allProductPhotos())
        if (photos.isEmpty()) {
            return com.arspos.anglerriausyndicate.SmartVisualScanner.detectProposals(bitmap).map { proposal ->
                com.arspos.anglerriausyndicate.LiveSceneDetection(
                    bounds = android.graphics.Rect(proposal.normalizedBounds),
                    proposalType = proposal.proposalType,
                    reason = "NO_MASTER_REFERENCES"
                )
            }
        }

        fun isLong(product: ProductEntity): Boolean =
            identityProfiles[product.id]?.isLongObject == true || isLikelyLongProduct(product)

        val longIds = allProducts.filter(::isLong).map { it.id }.toSet()
        val normalIds = allProducts.map { it.id }.filterNot { it in longIds }.toSet()
        val base = com.arspos.anglerriausyndicate.SmartVisualScanner.detectProposals(bitmap)
            .filter { it.proposalType != com.arspos.anglerriausyndicate.ScanProposal.TYPE_AMBIGUOUS_CONTAINER }
            .toMutableList()

        // ML Kit frequently sees compact packages but misses a thin rod. Add a
        // conservative LONG lane for live preview; authenticity is evaluated but
        // this path still cannot create final cashier quantity.
        if (longIds.isNotEmpty()) {
            val rawLong = com.arspos.anglerriausyndicate.LongObjectAnalyzer.proposals(bitmap)
                .take(6)
                .mapIndexed { index, proposal ->
                    val normalized = com.arspos.anglerriausyndicate.ScanCoordinateNormalizer.normalize(
                        proposal.bounds, 0, bitmap.width, bitmap.height
                    )
                    val axis = com.arspos.anglerriausyndicate.ScanCoordinateNormalizer.normalizeAxis(
                        proposal.axisStartX, proposal.axisStartY,
                        proposal.axisEndX, proposal.axisEndY,
                        0, bitmap.width, bitmap.height
                    )
                    com.arspos.anglerriausyndicate.ScanProposal(
                        proposalId = "LIVE-LONG-${index + 1}",
                        source = com.arspos.anglerriausyndicate.ScanProposal.SOURCE_LONG,
                        proposalType = com.arspos.anglerriausyndicate.ScanProposal.TYPE_LONG,
                        originalBounds = android.graphics.Rect(proposal.bounds),
                        normalizedBounds = normalized,
                        rotationDegrees = 0,
                        lineageId = "LIVE-AXIS-${index + 1}",
                        physicalInstanceHint = "",
                        quantityEligible = false,
                        rodStructureScore = com.arspos.anglerriausyndicate.LongObjectAnalyzer.rodStructureScore(bitmap, proposal),
                        orientation = proposal.orientation,
                        strength = proposal.strength,
                        axisAngleDeg = axis.angleDeg,
                        axisStartX = axis.start.x,
                        axisStartY = axis.start.y,
                        axisEndX = axis.end.x,
                        axisEndY = axis.end.y,
                        axisWidthPx = proposal.estimatedWidthPx,
                        axisConfidence = proposal.axisConfidence
                    )
                }
            val resolved = com.arspos.anglerriausyndicate.RodPhysicalTrackResolver.resolve(rawLong).proposals
                .map { proposal ->
                    if (proposal.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_LONG) {
                        com.arspos.anglerriausyndicate.RodAuthenticityEvaluator.apply(bitmap, proposal)
                    } else proposal
                }
                .filter {
                    it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_LONG &&
                        it.rodAuthenticityState != com.arspos.anglerriausyndicate.ScanProposal.AUTH_NON_ROD &&
                        it.axisConfidence >= 35
                }
                .sortedByDescending { it.rodAuthenticityScore + it.rodStructureScore }
                .take(3)
            base += resolved
        }

        // Avoid showing the same large region twice in live UI. This is preview
        // de-dup only; final physical truth still owns transaction quantity.
        val proposals = ArrayList<com.arspos.anglerriausyndicate.ScanProposal>()
        base.sortedByDescending { it.normalizedBounds.width().toLong() * it.normalizedBounds.height().toLong() }
            .forEach { candidate ->
                val duplicate = proposals.any { existing ->
                    val a = existing.normalizedBounds
                    val b = candidate.normalizedBounds
                    val left = maxOf(a.left, b.left)
                    val top = maxOf(a.top, b.top)
                    val right = minOf(a.right, b.right)
                    val bottom = minOf(a.bottom, b.bottom)
                    if (right <= left || bottom <= top) false else {
                        val inter = (right - left).toLong() * (bottom - top).toLong()
                        val areaA = a.width().toLong() * a.height().toLong()
                        val areaB = b.width().toLong() * b.height().toLong()
                        val iou = inter.toDouble() / (areaA + areaB - inter).coerceAtLeast(1L).toDouble()
                        iou >= 0.58
                    }
                }
                if (!duplicate && proposals.size < 6) proposals += candidate
            }

        val output = ArrayList<com.arspos.anglerriausyndicate.LiveSceneDetection>()
        proposals.forEach { proposal ->
            val rect = android.graphics.Rect(proposal.normalizedBounds)
            val safe = android.graphics.Rect(
                rect.left.coerceIn(0, bitmap.width - 1),
                rect.top.coerceIn(0, bitmap.height - 1),
                rect.right.coerceIn(1, bitmap.width),
                rect.bottom.coerceIn(1, bitmap.height)
            )
            if (safe.width() < 24 || safe.height() < 24) return@forEach
            val crop = runCatching { android.graphics.Bitmap.createBitmap(bitmap, safe.left, safe.top, safe.width(), safe.height()) }.getOrNull()
                ?: return@forEach
            try {
                val laneLong = proposal.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_LONG
                val laneIds = if (laneLong) longIds else normalIds
                val laneProducts = allProducts.filter { it.id in laneIds }
                val lanePhotos = photos.filter { it.productId in laneIds }
                if (laneProducts.isEmpty() || lanePhotos.isEmpty()) {
                    output += com.arspos.anglerriausyndicate.LiveSceneDetection(
                        bounds = safe,
                        proposalType = proposal.proposalType,
                        reason = if (laneLong) "NO_LONG_DATABASE" else "NO_NORMAL_DATABASE"
                    )
                    return@forEach
                }

                // Live LONG uses the cheap coarse fingerprint pass. The full
                // orientation/rod-specific matcher is intentionally reserved for
                // the locked production scan, so preview latency does not pay four
                // rotated/focused passes across every rod reference on each frame.
                val scores = if (laneLong) {
                    com.arspos.anglerriausyndicate.ProductVisualMatcher.scoreBatchCoarse(
                        crop,
                        lanePhotos.map { it.localPath }
                    )
                } else {
                    com.arspos.anglerriausyndicate.ProductVisualMatcher.scoreBatch(
                        crop,
                        lanePhotos.map { it.localPath },
                        longObject = false
                    )
                }
                val references = lanePhotos.mapNotNull { photo ->
                    val product = productsById[photo.productId] ?: return@mapNotNull null
                    com.arspos.anglerriausyndicate.VisualProductMatch(
                        product = product,
                        photo = photo,
                        score = scores[photo.localPath] ?: 0
                    )
                }
                val topByProduct = references.groupBy { it.product.id }.mapNotNull { (_, refs) -> refs.maxByOrNull { it.score } }
                    .sortedByDescending { it.score }
                val visualBest = topByProduct.firstOrNull()
                val visualSecond = topByProduct.getOrNull(1)
                val visualMargin = ((visualBest?.score ?: 0) - (visualSecond?.score ?: 0)).coerceAtLeast(0)

                // V8.5.2: surface a visual candidate immediately, but reserve
                // live OCR for a strong NORMAL shortlist. LONG preview identity
                // is advisory visual evidence only; final locked scan still owns
                // rod authenticity, anchor truth, OCR and quantity acceptance.
                // Recognition thresholds inside SmartRecognitionEngine are unchanged.
                val shouldRunIdentity = !laneLong &&
                    (visualBest?.score ?: 0) >= 72 &&
                    visualMargin >= 6
                val ocr = if (shouldRunIdentity) {
                    runCatching { SmartProductInput.analyzeLiveFast(crop) }
                        .getOrElse { SmartProductInput.Draft() }
                } else SmartProductInput.Draft()
                val recognized = if (shouldRunIdentity) {
                    SmartRecognitionEngine.recognize(
                        crop = crop,
                        products = laneProducts,
                        references = references,
                        ocr = ocr,
                        identityProfiles = identityProfiles,
                        verifiedProductIds = verifiedProductIds,
                        visualOnlyAllowed = true
                    )
                } else null

                // A LONG live identity remains a candidate until final physical
                // truth/anchor/quantity resolution. For NORMAL, strong OCR/barcode
                // may be shown as matched preview, but still cannot touch cart state.
                val liveAccepted = recognized?.match != null && !laneLong
                val candidateFloor = if (laneLong) 58 else 64
                val selectedProduct = recognized?.match?.product ?: visualBest?.takeIf { best ->
                    best.score >= candidateFloor && visualMargin >= 4
                }?.product
                output += com.arspos.anglerriausyndicate.LiveSceneDetection(
                    bounds = safe,
                    proposalType = proposal.proposalType,
                    product = selectedProduct,
                    visualScore = recognized?.visualScore ?: visualBest?.score ?: 0,
                    secondVisualScore = recognized?.secondVisualScore ?: visualSecond?.score ?: 0,
                    margin = recognized?.margin ?: visualMargin,
                    identityAccepted = liveAccepted,
                    rodStructureScore = proposal.rodStructureScore,
                    rodAuthenticityScore = proposal.rodAuthenticityScore,
                    rodAuthenticityState = proposal.rodAuthenticityState,
                    foregroundSupported = proposal.foregroundSupported,
                    axisAngleDeg = proposal.axisAngleDeg,
                    axisConfidence = proposal.axisConfidence,
                    axisWidthPx = proposal.axisWidthPx,
                    reason = when {
                        recognized?.match != null && laneLong -> "LONG_FINAL_PHYSICAL_TRUTH_REQUIRED"
                        recognized?.match != null -> recognized.ruleId
                        recognized != null -> recognized.ruleId
                        visualBest != null -> "DATABASE_CANDIDATE"
                        else -> "OBJECT_NOT_IN_DATABASE"
                    }
                )
            } finally {
                if (!crop.isRecycled) crop.recycle()
            }
        }
        return output
    }

    /** Phase 4.3.3.2 V8.5.2: adaptive hybrid physical/identity pipeline; thresholds unchanged. */
    suspend fun smartVisualScan(
        bitmap: android.graphics.Bitmap,
        diagnosticSession: String = "",
        liveLock: com.arspos.anglerriausyndicate.LiveSceneLockSnapshot? = null,
        identityBitmap: android.graphics.Bitmap? = null
    ): List<com.arspos.anglerriausyndicate.VisualScanObject> {
        val allPhotos = dao.allProductPhotos()
        val photos = selectRecognitionReferences(allPhotos)
        val allProducts = dao.products().first().filter { it.active }
        val identityProfiles = loadIdentityProfiles()
        val verifiedProductIds = loadVerifiedProductIds()
        val productsById = allProducts.associateBy { it.id }

        val nativeBeforeScanMb = android.os.Debug.getNativeHeapAllocatedSize() / 1024L / 1024L
        var temporaryCropCount = 0
        var recycledCropCount = 0
        var peakHeapMb = heapUsedMb()
        fun sampleHeap(): Long {
            val value = heapUsedMb()
            if (value > peakHeapMb) peakHeapMb = value
            return value
        }

        fun isLongProduct(product: ProductEntity): Boolean =
            identityProfiles[product.id]?.isLongObject == true || isLikelyLongProduct(product)

        val longProducts = allProducts.filter { isLongProduct(it) }
        val normalProducts = allProducts.filterNot { isLongProduct(it) }
        val longProductIds = longProducts.map { it.id }.toSet()
        val normalPhotos = photos.filter { normalProducts.any { product -> product.id == it.productId } }
        val longPhotos = photos.filter { longProductIds.contains(it.productId) }

        com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
            "SCAN_PIPELINE",
            "Recognition pipeline prepared with typed proposal lanes",
            mapOf(
                "session" to diagnosticSession,
                "bitmap" to "${bitmap.width}x${bitmap.height}",
                "allRefs" to allPhotos.size,
                "selectedRefs" to photos.size,
                "normalRefs" to normalPhotos.size,
                "longRefs" to longPhotos.size,
                "products" to allProducts.size,
                "normalProducts" to normalProducts.size,
                "longProducts" to longProducts.size,
                "heapUsedMb" to sampleHeap(),
                "heapMaxMb" to (Runtime.getRuntime().maxMemory() / 1024L / 1024L)
            )
        )
        if (allProducts.isEmpty()) return emptyList()

        var mergeAxisCount = 0
        // V8.4.21 FIX1: rescue policy is evaluated after the LONG merge block.
        // Persist only the aggregate track truth that Rescue Gate V2 needs;
        // never reference the block-local mergeDiagnostics outside its scope.
        var trustedRodTracksAfterMerge = 0
        var uncertainRodTracksAfterMerge = 0
        var proposals = com.arspos.anglerriausyndicate.SmartVisualScanner.detectProposals(bitmap)
        com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
            "SCAN_PROPOSALS",
            "Initial ML Kit proposals",
            mapOf(
                "session" to diagnosticSession,
                "count" to proposals.size,
                "normal" to proposals.count { it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_NORMAL },
                "longLike" to proposals.count { it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_LONG }
            )
        )

        val hasLongMaster = longProducts.any { product -> photos.any { it.productId == product.id } }
        if (hasLongMaster) {
            val rawLong = com.arspos.anglerriausyndicate.LongObjectAnalyzer.proposals(bitmap)
            val longProposals = rawLong.mapIndexed { index, proposal ->
                val normalized = com.arspos.anglerriausyndicate.ScanCoordinateNormalizer.normalize(
                    proposal.bounds,
                    0,
                    bitmap.width,
                    bitmap.height
                )
                val normalizedAxis = com.arspos.anglerriausyndicate.ScanCoordinateNormalizer.normalizeAxis(
                    proposal.axisStartX,
                    proposal.axisStartY,
                    proposal.axisEndX,
                    proposal.axisEndY,
                    0,
                    bitmap.width,
                    bitmap.height
                )
                com.arspos.anglerriausyndicate.ScanProposal(
                    proposalId = "LONG-${index + 1}",
                    source = com.arspos.anglerriausyndicate.ScanProposal.SOURCE_LONG,
                    proposalType = com.arspos.anglerriausyndicate.ScanProposal.TYPE_LONG,
                    originalBounds = android.graphics.Rect(proposal.bounds),
                    normalizedBounds = normalized,
                    rotationDegrees = 0,
                    lineageId = "AXIS-${proposal.axisAngleDeg.toInt()}-${index + 1}",
                    physicalInstanceHint = "",
                    quantityEligible = true,
                    rodStructureScore = com.arspos.anglerriausyndicate.LongObjectAnalyzer.rodStructureScore(bitmap, proposal),
                    orientation = proposal.orientation,
                    strength = proposal.strength,
                    axisAngleDeg = normalizedAxis.angleDeg,
                    axisStartX = normalizedAxis.start.x,
                    axisStartY = normalizedAxis.start.y,
                    axisEndX = normalizedAxis.end.x,
                    axisEndY = normalizedAxis.end.y,
                    axisWidthPx = proposal.estimatedWidthPx,
                    axisConfidence = proposal.axisConfidence
                )
            }
            val beforeMerge = proposals.size + longProposals.size
            val mergeDiagnostics = com.arspos.anglerriausyndicate.SmartVisualScanner.mergeProposalMetadataDetailed(
                proposals,
                longProposals,
                bitmap = bitmap,
                maxObjects = 6,
                diagnosticSession = diagnosticSession,
                liveLock = liveLock
            )
            mergeAxisCount = mergeDiagnostics.physicalObjectsAfterResolve
            trustedRodTracksAfterMerge = mergeDiagnostics.trustedRodTracks
            uncertainRodTracksAfterMerge = mergeDiagnostics.uncertainRodTracks
            proposals = mergeDiagnostics.proposals
            com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
                "SCAN_PROPOSAL_MERGE",
                "V8.5.2 adaptive physical truth + persistent fragment fusion applied",
                mapOf(
                    "session" to diagnosticSession,
                    "input" to beforeMerge,
                    "output" to proposals.size,
                    "longInput" to longProposals.size,
                    "rawLongHypotheses" to mergeDiagnostics.rawLongHypotheses,
                    "physicalObjectsBeforeResolve" to mergeDiagnostics.physicalObjectsBeforeResolve,
                    "physicalObjectsAfterResolve" to mergeDiagnostics.physicalObjectsAfterResolve,
                    "hypothesesMerged" to mergeDiagnostics.hypothesesMerged,
                    "duplicatePhysicalObjectsPrevented" to mergeDiagnostics.duplicatePhysicalObjectsPrevented,
                    "geometryBridgeSuppressed" to mergeDiagnostics.geometryBridgeSuppressed,
                    "authenticityRejected" to mergeDiagnostics.authenticityRejected,
                    "packageEdgeSuppressed" to mergeDiagnostics.packageEdgeSuppressed,
                    "mlGuidedRecoveryAttempted" to mergeDiagnostics.mlGuidedRecoveryAttempted,
                    "mlGuidedRecoveryRecovered" to mergeDiagnostics.mlGuidedRecoveryRecovered,
                    "persistentFragmentFusionGroups" to mergeDiagnostics.persistentFragmentFusionGroups,
                    "persistentFragmentsMerged" to mergeDiagnostics.persistentFragmentsMerged,
                    "backgroundLineSuppressed" to mergeDiagnostics.backgroundLineSuppressed,
                    "physicalDuplicateMerged" to mergeDiagnostics.hypothesesMerged,
                    "legacyBridgeCountIncludesAuthenticity" to true,
                    "trustedRodTracks" to mergeDiagnostics.trustedRodTracks,
                    "uncertainRodTracks" to mergeDiagnostics.uncertainRodTracks,
                    "nonRodTracks" to mergeDiagnostics.nonRodTracks,
                    "rodClaimTracks" to proposals.count { it.rodClaim },
                    "rodClaimNormalHits" to proposals.filter { it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_NORMAL }.sumOf { it.rodTrackHits },
                    "normalBlockedByRodClaim" to proposals.count { it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_NORMAL && it.visualOnlyBlocked },
                    "crossThroughIntersections" to proposals.sumOf { it.crossThroughIntersections },
                    "trueBranchIntersections" to proposals.sumOf { it.trueBranchIntersections },
                    "normalOutput" to proposals.count { it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_NORMAL },
                    "longOutput" to proposals.count { it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_LONG },
                    "bridgeSuppressed" to proposals.count { it.bridgeSuppressed || it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_AMBIGUOUS_CONTAINER },
                    "crossLaneSuppressed" to mergeDiagnostics.crossLaneSuppressed,
                    "backgroundSuppressed" to proposals.count { it.source == com.arspos.anglerriausyndicate.ScanProposal.SOURCE_BACKGROUND },
                    "authenticitySuppressed" to proposals.count { it.source == com.arspos.anglerriausyndicate.ScanProposal.SOURCE_AUTHENTICITY },
                    "normalOwnershipConflicts" to proposals.count { it.normalOwnershipConflict },
                    "normalPurityBlocked" to proposals.count { it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_NORMAL && !it.quantityEligible && it.normalPurityState == "REVIEW_REQUIRED" },
                    "minNormalPurityScore" to (proposals.filter { it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_NORMAL }.minOfOrNull { it.normalPurityScore } ?: 0),
                    "crossCategoryVisualOnlyBlocked" to proposals.count { it.visualOnlyBlocked },
                    "crossCategoryConflicts" to proposals.count { it.crossCategoryConflict },
                    "maxCrossCategoryConflictScore" to (proposals.maxOfOrNull { it.crossCategoryConflictScore } ?: 0),
                    "normalRodTrackHits" to proposals.filter { it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_NORMAL }.sumOf { it.rodTrackHits },
                    "rodStructureCandidates" to proposals.count { it.rodStructureScore > 0 },
                    "physicalHints" to proposals.map { it.physicalInstanceHint }.filter { it.isNotBlank() && it.startsWith("TRACK-") }.distinct().size,
                    "angleAwareTracks" to mergeDiagnostics.physicalObjectsAfterResolve,
                    "crossingTracksPreserved" to mergeDiagnostics.crossingTracksPreserved,
                    "axisCandidates" to mergeDiagnostics.rawLongHypotheses,
                    "maxAxisConfidence" to (proposals.maxOfOrNull { it.axisConfidence } ?: 0),
                    "maxRodAuthenticityScore" to (proposals.maxOfOrNull { it.rodAuthenticityScore } ?: 0)
                )
            )
        }

        val preGateBindings = com.arspos.anglerriausyndicate.PersistentPhysicalIdBinder.bindProposals(
            liveLock, proposals, bitmap.width, bitmap.height
        )
        val preGateBindingByProposal = preGateBindings.associateBy { it.proposalId }
        preGateBindings.forEach { binding ->
            com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
                "SCAN_PRE_GATE_BIND",
                "Persistent physical ID bound before identity scoring",
                mapOf(
                    "session" to diagnosticSession,
                    "proposalId" to binding.proposalId,
                    "physicalObjectId" to binding.physicalObjectId,
                    "persistentPhysicalId" to binding.persistentPhysicalId,
                    "normalizedIou" to binding.normalizedIou,
                    "bindingScore" to binding.totalScore,
                    "temporalPhysicalState" to binding.liveTrack.temporalPhysicalState,
                    "trustedPhysicalHits" to binding.liveTrack.trustedPhysicalHits,
                    "physicalSamples" to binding.liveTrack.physicalSampleCount,
                    "bestVisualScore" to binding.liveTrack.bestVisualScore,
                    "bestMargin" to binding.liveTrack.bestMargin,
                    "bestEvidenceProductId" to binding.liveTrack.bestEvidenceProductId,
                    "bestEvidenceAtMs" to binding.liveTrack.bestEvidenceAtMs
                )
            )
        }

        com.arspos.anglerriausyndicate.ArsVisualEvidenceRecorder.recordTrackOverlay(
            diagnosticSession,
            bitmap,
            proposals
        )

        // Scene barcode fallback remains quantity-eligible because exact barcode
        // is an independent SKU identity signal. Long full-frame rescue is never
        // quantity-eligible in V8.4.13.
        if (proposals.isEmpty()) {
            val sceneOcr = runCatching {
                com.arspos.anglerriausyndicate.SmartProductInput.analyzeMultiOrientation(bitmap)
            }.getOrElse { com.arspos.anglerriausyndicate.SmartProductInput.Draft() }
            if (sceneOcr.barcode.isBlank()) return emptyList()
            val full = android.graphics.Rect(0, 0, bitmap.width, bitmap.height)
            proposals = listOf(
                com.arspos.anglerriausyndicate.ScanProposal(
                    proposalId = "SCENE-BARCODE-1",
                    source = com.arspos.anglerriausyndicate.ScanProposal.SOURCE_SCENE_BARCODE,
                    proposalType = com.arspos.anglerriausyndicate.ScanProposal.TYPE_NORMAL,
                    originalBounds = android.graphics.Rect(full),
                    normalizedBounds = android.graphics.Rect(full),
                    rotationDegrees = 0,
                    lineageId = "SCENE-BARCODE",
                    physicalInstanceHint = "NORMAL-SCENE-BARCODE",
                    physicalObjectId = "NORMAL-SCENE-BARCODE",
                    quantityEligible = true,
                    orientation = "FULL_FRAME",
                    strength = 100
                )
            )
        }

        fun scaleRectForIdentity(rect: android.graphics.Rect, targetWidth: Int, targetHeight: Int): android.graphics.Rect {
            val sx = targetWidth.toFloat() / bitmap.width.coerceAtLeast(1).toFloat()
            val sy = targetHeight.toFloat() / bitmap.height.coerceAtLeast(1).toFloat()
            return android.graphics.Rect(
                (rect.left * sx).toInt().coerceIn(0, targetWidth - 1),
                (rect.top * sy).toInt().coerceIn(0, targetHeight - 1),
                (rect.right * sx).toInt().coerceIn(1, targetWidth),
                (rect.bottom * sy).toInt().coerceIn(1, targetHeight)
            )
        }

        fun scaleProposalForIdentity(proposal: com.arspos.anglerriausyndicate.ScanProposal, targetWidth: Int, targetHeight: Int): com.arspos.anglerriausyndicate.ScanProposal {
            val sx = targetWidth.toFloat() / bitmap.width.coerceAtLeast(1).toFloat()
            val sy = targetHeight.toFloat() / bitmap.height.coerceAtLeast(1).toFloat()
            val widthScale = minOf(sx, sy)
            return proposal.copy(
                originalBounds = scaleRectForIdentity(proposal.originalBounds, targetWidth, targetHeight),
                normalizedBounds = scaleRectForIdentity(proposal.normalizedBounds, targetWidth, targetHeight),
                axisStartX = (proposal.axisStartX * sx).toInt(),
                axisStartY = (proposal.axisStartY * sy).toInt(),
                axisEndX = (proposal.axisEndX * sx).toInt(),
                axisEndY = (proposal.axisEndY * sy).toInt(),
                axisWidthPx = (proposal.axisWidthPx * widthScale).toInt().coerceAtLeast(proposal.axisWidthPx)
            )
        }

        val result = ArrayList<com.arspos.anglerriausyndicate.VisualScanObject>()

        suspend fun analyze(
            proposal: com.arspos.anglerriausyndicate.ScanProposal,
            index: Int,
            allowSceneOcr: Boolean
        ): com.arspos.anglerriausyndicate.VisualScanObject? {
            if (proposal.bridgeSuppressed || proposal.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_AMBIGUOUS_CONTAINER) {
                com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
                    "SCAN_PROPOSAL_SUPPRESSED",
                    "Ambiguous bridge/container proposal excluded from recognition quantity",
                    mapOf(
                        "session" to diagnosticSession,
                        "object" to index,
                        "proposalId" to proposal.proposalId,
                        "proposalType" to proposal.proposalType,
                        "source" to proposal.source,
                        "lineageId" to proposal.lineageId,
                        "physicalInstanceHint" to proposal.physicalInstanceHint,
                        "axisAngleDeg" to proposal.axisAngleDeg,
                        "axisConfidence" to proposal.axisConfidence,
                        "rodStructureScore" to proposal.rodStructureScore,
                        "physicalObjectId" to proposal.physicalObjectId,
                        "hypothesesMerged" to proposal.hypothesesMerged,
                        "physicalMergeReason" to proposal.physicalMergeReason,
                        "rodAuthenticityState" to proposal.rodAuthenticityState,
                        "rodAuthenticityScore" to proposal.rodAuthenticityScore,
                        "branchPenalty" to proposal.branchPenalty,
                        "beamPenalty" to proposal.beamPenalty,
                        "floorLinePenalty" to proposal.floorLinePenalty,
                        "bounds" to "${proposal.normalizedBounds.left},${proposal.normalizedBounds.top},${proposal.normalizedBounds.right},${proposal.normalizedBounds.bottom}"
                    )
                )
                return null
            }
            val objectStarted = System.currentTimeMillis()
            val bounds = proposal.normalizedBounds
            val preBinding = preGateBindingByProposal[proposal.proposalId]
            val highResCandidate = identityBitmap?.takeIf { source ->
                source !== bitmap && !source.isRecycled &&
                    source.width.toFloat() >= bitmap.width.toFloat() * 1.35f && source.height.toFloat() >= bitmap.height.toFloat() * 1.35f &&
                    proposal.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_LONG &&
                    (proposal.trustedRod || proposal.rodAuthenticityState == com.arspos.anglerriausyndicate.ScanProposal.AUTH_UNCERTAIN)
            }
            val identitySource = highResCandidate ?: bitmap
            val identityProposal = if (identitySource === bitmap) proposal else {
                scaleProposalForIdentity(proposal, identitySource.width, identitySource.height)
            }
            val crop = com.arspos.anglerriausyndicate.SmartVisualScanner.crop(identitySource, identityProposal) ?: return null
            val highResolutionIdentityUsed = identitySource !== bitmap
            temporaryCropCount++
            try {
                val longLane = proposal.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_LONG ||
                    proposal.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_RESCUE

                val cropOcrStarted = System.currentTimeMillis()
                val ocr = runCatching {
                    if (longLane) {
                        com.arspos.anglerriausyndicate.SmartProductInput.analyzeLongIdentity(crop)
                    } else {
                        com.arspos.anglerriausyndicate.SmartProductInput.analyzeMultiOrientation(crop)
                    }
                }.getOrElse {
                    com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
                        "SCAN_OCR_ERROR",
                        it.message ?: it::class.java.simpleName,
                        mapOf(
                            "session" to diagnosticSession,
                            "object" to index,
                            "proposalId" to proposal.proposalId,
                            "proposalType" to proposal.proposalType
                        )
                    )
                    com.arspos.anglerriausyndicate.SmartProductInput.Draft()
                }
                val cropOcrDurationMs = System.currentTimeMillis() - cropOcrStarted

                var sceneOcrDurationMs = 0L
                val effectiveOcr = if (allowSceneOcr && ocr.barcode.isBlank()) {
                    val sceneOcrStarted = System.currentTimeMillis()
                    val value = runCatching {
                        com.arspos.anglerriausyndicate.SmartProductInput.analyzeMultiOrientation(bitmap)
                    }.getOrElse { ocr }
                    sceneOcrDurationMs = System.currentTimeMillis() - sceneOcrStarted
                    value
                } else ocr

                val laneProducts = if (longLane) longProducts else normalProducts
                val lanePhotos = (if (longLane) longPhotos else normalPhotos).filter { photo ->
                    !longLane || proposal.rodTipVisible || !photo.captureAngle.equals("LONG_TIP", ignoreCase = true)
                }
                if (laneProducts.isEmpty()) return null

                val scoringStarted = System.currentTimeMillis()

                // V8.4.21: coarse ranking orders work. A pixel-verified rod in
                // a small catalog preserves every available product identity.
                // Uncertain/rescue proposals retain a bounded two-product pass.
                var coarseDurationMs = 0L
                var coarseProducts = 0
                var shortlistedProducts = 0
                val scoringPhotos = if (longLane && lanePhotos.size > 4) {
                    val coarseStarted = System.currentTimeMillis()
                    val coarse = com.arspos.anglerriausyndicate.ProductVisualMatcher.scoreBatchCoarse(
                        crop,
                        lanePhotos.map { it.localPath }
                    )
                    coarseDurationMs = System.currentTimeMillis() - coarseStarted

                    val productRanks = lanePhotos.groupBy { it.productId }
                        .map { (productId, group) ->
                            val best = group.maxOfOrNull { coarse[it.localPath] ?: 0 } ?: 0
                            productId to best
                        }
                        .sortedByDescending { it.second }

                    coarseProducts = productRanks.size
                    // A verified physical body in a small catalog is scored against
                    // every available SKU. Coarse ranking cannot remove the correct
                    // product before its HANDLE/SIDE anchors are compared.
                    val shortlistSize = if (proposal.foregroundSupported && proposal.trustedRod && productRanks.size <= 8) 8 else 2
                    val keepProducts = productRanks.take(shortlistSize).map { it.first }.toSet()
                    shortlistedProducts = keepProducts.size
                    val anchorOrder = listOf(
                        "LONG_HANDLE", "LONG_SIDE", "LONG_TIP", "LONG_FULL_A", "LONG_FULL_B"
                    )

                    lanePhotos
                        .filter { keepProducts.contains(it.productId) }
                        .groupBy { it.productId }
                        .values
                        .flatMap { group ->
                            if (proposal.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_RESCUE) {
                                group.sortedByDescending { coarse[it.localPath] ?: 0 }.take(1)
                            } else {
                                val byAngle = group.groupBy { it.captureAngle.uppercase() }
                                val anchors = anchorOrder.mapNotNull { angle ->
                                    byAngle[angle]?.maxByOrNull { coarse[it.localPath] ?: 0 }
                                }
                                val fallback = group
                                    .filterNot { photo -> anchors.any { it.localPath == photo.localPath } }
                                    .sortedByDescending { coarse[it.localPath] ?: 0 }
                                (anchors + fallback).take(5)
                            }
                        }
                } else {
                    coarseProducts = lanePhotos.map { it.productId }.distinct().size
                    shortlistedProducts = coarseProducts
                    lanePhotos
                }

                val anchorScoring = if (longLane && proposal.proposalType != com.arspos.anglerriausyndicate.ScanProposal.TYPE_RESCUE) {
                    com.arspos.anglerriausyndicate.ProductVisualMatcher.scoreBatchRodAnchorAware(
                        crop,
                        scoringPhotos.map { photo ->
                            com.arspos.anglerriausyndicate.ProductVisualMatcher.RodAnchorReference(
                                path = photo.localPath,
                                angle = photo.captureAngle,
                                productId = photo.productId
                            )
                        },
                        tipVisible = proposal.rodTipVisible
                    )
                } else null
                val laneScores = anchorScoring?.scores ?: run {
                    com.arspos.anglerriausyndicate.ProductVisualMatcher.scoreBatch(
                        crop,
                        scoringPhotos.map { it.localPath },
                        longObject = longLane
                    )
                }
                val references = scoringPhotos.mapNotNull { photo ->
                    val product = productsById[photo.productId] ?: return@mapNotNull null
                    com.arspos.anglerriausyndicate.VisualProductMatch(
                        product,
                        photo,
                        laneScores[photo.localPath] ?: 0
                    )
                }
                val heapAfterScore = sampleHeap()

                com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
                    "SCAN_SCORING",
                    "V8.5.2 adaptive identity scoring + physical fragment evidence completed",
                    mapOf(
                        "session" to diagnosticSession,
                        "object" to index,
                        "proposalId" to proposal.proposalId,
                        "proposalType" to proposal.proposalType,
                        "source" to proposal.source,
                        "lineageId" to proposal.lineageId,
                        "physicalInstanceHint" to proposal.physicalInstanceHint,
                        "persistentPhysicalId" to (preBinding?.persistentPhysicalId ?: ""),
                        "preGateBindingScore" to (preBinding?.totalScore ?: 0f),
                        "highResolutionIdentityUsed" to highResolutionIdentityUsed,
                        "identityBitmap" to "${identitySource.width}x${identitySource.height}",
                        "rotation" to proposal.rotationDegrees,
                        "normalRefs" to if (longLane) 0 else scoringPhotos.size,
                        "longRefs" to if (longLane) scoringPhotos.size else 0,
                        "availableLongRefs" to if (longLane) lanePhotos.size else 0,
                        "availableLongRefsBeforeRoleGate" to if (longLane) longPhotos.size else 0,
                        "coarseProducts" to if (longLane) coarseProducts else 0,
                        "shortlistedProducts" to if (longLane) shortlistedProducts else 0,
                        "scoredProductIds" to scoringPhotos.map { it.productId }.distinct().joinToString(","),
                        "scoredReferenceIds" to scoringPhotos.map { it.id }.joinToString(","),
                        "referenceScores" to scoringPhotos.joinToString(";") { "${it.id}:${it.productId}:${it.captureAngle}:${laneScores[it.localPath] ?: 0}" },
                        "anchorRoleAssignments" to anchorScoring?.handleOnLeftByProduct?.entries?.joinToString(",") { "${it.key}:${if (it.value) "LEFT_HANDLE" else "RIGHT_HANDLE"}" }.orEmpty(),
                        "physicalAnchorHandleOnLeft" to anchorScoring?.physicalHandleOnLeft,
                        "anchorEndpointLeftScore" to (anchorScoring?.endpointLeftScore ?: 0),
                        "anchorEndpointRightScore" to (anchorScoring?.endpointRightScore ?: 0),
                        "anchorRoleMargin" to (anchorScoring?.roleMargin ?: 0),
                        "anchorRoleConfidence" to (anchorScoring?.roleConfidence ?: 0),
                        "anchorRoleState" to (anchorScoring?.roleState ?: "ANCHOR_ROLE_NOT_APPLICABLE"),
                        "coarseDurationMs" to if (longLane) coarseDurationMs else 0L,
                        "rodStructureScore" to proposal.rodStructureScore,
                        "axisAngleDeg" to proposal.axisAngleDeg,
                        "axisConfidence" to proposal.axisConfidence,
                        "axisWidthPx" to proposal.axisWidthPx,
                        "measuredWidthMedianPx" to proposal.measuredWidthMedianPx,
                        "measuredWidthP10Px" to proposal.measuredWidthP10Px,
                        "measuredWidthP90Px" to proposal.measuredWidthP90Px,
                        "widthVariance" to proposal.widthVariance,
                        "taperRatio" to proposal.taperRatio,
                        "curvatureScore" to proposal.curvatureScore,
                        "physicalObjectId" to proposal.physicalObjectId,
                        "hypothesesMerged" to proposal.hypothesesMerged,
                        "physicalMergeReason" to proposal.physicalMergeReason,
                        "rodPositiveEvidence" to proposal.rodPositiveEvidence,
                        "branchPenalty" to proposal.branchPenalty,
                        "beamPenalty" to proposal.beamPenalty,
                        "floorLinePenalty" to proposal.floorLinePenalty,
                        "shadowPenalty" to proposal.shadowPenalty,
                        "rodAuthenticityScore" to proposal.rodAuthenticityScore,
                        "rodAuthenticityState" to proposal.rodAuthenticityState,
                        "trustedRod" to proposal.trustedRod,
                        "foregroundSupported" to proposal.foregroundSupported,
                        "foregroundCoverage" to proposal.foregroundCoverage,
                        "foregroundBodyCoverage" to proposal.foregroundBodyCoverage,
                        "foregroundReason" to proposal.foregroundReason,
                        "rodTipVisible" to proposal.rodTipVisible,
                        "physicalOwnershipState" to proposal.physicalOwnershipState,
                        "physicalOwnershipOwnerId" to proposal.physicalOwnershipOwnerId,
                        "packageEdgeScore" to proposal.packageEdgeScore,
                        "packageEdgeBoundaryDistancePx" to proposal.packageEdgeBoundaryDistancePx,
                        "packageEdgeParallelEvidence" to proposal.packageEdgeParallelEvidence,
                        "packageEdgeRectangularScore" to proposal.packageEdgeRectangularScore,
                        "packageEdgeTrackInsideOwnerRatio" to proposal.packageEdgeTrackInsideOwnerRatio,
                        "rodClaim" to proposal.rodClaim,
                        "rodClaimScore" to proposal.rodClaimScore,
                        "crossThroughIntersections" to proposal.crossThroughIntersections,
                        "trueBranchIntersections" to proposal.trueBranchIntersections,
                        "orientedLongCrop" to (longLane && proposal.hasResolvedAxis),
                        "normalOwnershipConflict" to proposal.normalOwnershipConflict,
                        "normalPurityScore" to proposal.normalPurityScore,
                        "normalPurityState" to proposal.normalPurityState,
                        "normalPurityReason" to proposal.normalPurityReason,
                        "normalCropAreaRatio" to proposal.normalCropAreaRatio,
                        "normalOwnerAreaRatio" to proposal.normalOwnerAreaRatio,
                        "crossCategoryConflict" to proposal.crossCategoryConflict,
                        "crossCategoryConflictScore" to proposal.crossCategoryConflictScore,
                        "rodTrackHits" to proposal.rodTrackHits,
                        "visualOnlyBlocked" to proposal.visualOnlyBlocked,
                        "crossCategoryReason" to proposal.crossCategoryReason,
                        "cropOcrDurationMs" to cropOcrDurationMs,
                        "sceneOcrDurationMs" to sceneOcrDurationMs,
                        "durationMs" to (System.currentTimeMillis() - scoringStarted),
                        "heapAfterScoreMb" to heapAfterScore,
                        "peakHeapMb" to peakHeapMb
                    )
                )

                val decisionStarted = System.currentTimeMillis()
                val recognized = SmartRecognitionEngine.recognize(
                    crop = crop,
                    products = laneProducts,
                    references = references,
                    ocr = effectiveOcr,
                    identityProfiles = identityProfiles.filterKeys { id -> laneProducts.any { it.id == id } },
                    verifiedProductIds = verifiedProductIds,
                    visualOnlyAllowed = !proposal.visualOnlyBlocked
                )
                val decisionDurationMs = System.currentTimeMillis() - decisionStarted

                val recognitionMatch = recognized.match
                val safetyQuantity = com.arspos.anglerriausyndicate.ArsSafetyKernel.quantityDecision(
                    proposal = proposal,
                    recognitionAccepted = recognitionMatch != null
                )
                val quantityMatch = if (safetyQuantity.allowed) recognitionMatch else null
                val top = recognized.candidates.firstOrNull()
                val eventReason = if (!proposal.quantityEligible && recognitionMatch != null) {
                    val gate = when (proposal.proposalType) {
                        com.arspos.anglerriausyndicate.ScanProposal.TYPE_RESCUE -> "RESCUE EVIDENCE ONLY"
                        com.arspos.anglerriausyndicate.ScanProposal.TYPE_LONG -> "UNTRUSTED LONG EVIDENCE ONLY"
                        else -> "EVIDENCE ONLY"
                    }
                    "$gate — tidak boleh menambah quantity • ${recognized.reason}"
                } else recognized.reason

                com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
                    "SCAN_OBJECT",
                    eventReason,
                    mapOf(
                        "session" to diagnosticSession,
                        "object" to index,
                        "proposalId" to proposal.proposalId,
                        "source" to proposal.source,
                        "proposalType" to proposal.proposalType,
                        "rotation" to proposal.rotationDegrees,
                        "lineageId" to proposal.lineageId,
                        "physicalInstanceHint" to proposal.physicalInstanceHint,
                        "persistentPhysicalId" to (preBinding?.persistentPhysicalId ?: ""),
                        "preGateBindingScore" to (preBinding?.totalScore ?: 0f),
                        "highResolutionIdentityUsed" to highResolutionIdentityUsed,
                        "quantityEligible" to proposal.quantityEligible,
                        "bridgeSuppressed" to proposal.bridgeSuppressed,
                        "normalOwnershipConflict" to proposal.normalOwnershipConflict,
                        "normalPurityScore" to proposal.normalPurityScore,
                        "normalPurityState" to proposal.normalPurityState,
                        "normalPurityReason" to proposal.normalPurityReason,
                        "normalCropAreaRatio" to proposal.normalCropAreaRatio,
                        "normalOwnerAreaRatio" to proposal.normalOwnerAreaRatio,
                        "crossCategoryConflict" to proposal.crossCategoryConflict,
                        "crossCategoryConflictScore" to proposal.crossCategoryConflictScore,
                        "rodTrackHits" to proposal.rodTrackHits,
                        "visualOnlyBlocked" to proposal.visualOnlyBlocked,
                        "crossCategoryReason" to proposal.crossCategoryReason,
                        "rodStructureScore" to proposal.rodStructureScore,
                        "axisAngleDeg" to proposal.axisAngleDeg,
                        "axisConfidence" to proposal.axisConfidence,
                        "axisWidthPx" to proposal.axisWidthPx,
                        "measuredWidthMedianPx" to proposal.measuredWidthMedianPx,
                        "measuredWidthP10Px" to proposal.measuredWidthP10Px,
                        "measuredWidthP90Px" to proposal.measuredWidthP90Px,
                        "widthVariance" to proposal.widthVariance,
                        "taperRatio" to proposal.taperRatio,
                        "curvatureScore" to proposal.curvatureScore,
                        "physicalObjectId" to proposal.physicalObjectId,
                        "hypothesesMerged" to proposal.hypothesesMerged,
                        "physicalMergeReason" to proposal.physicalMergeReason,
                        "rodPositiveEvidence" to proposal.rodPositiveEvidence,
                        "branchPenalty" to proposal.branchPenalty,
                        "beamPenalty" to proposal.beamPenalty,
                        "floorLinePenalty" to proposal.floorLinePenalty,
                        "shadowPenalty" to proposal.shadowPenalty,
                        "rodAuthenticityScore" to proposal.rodAuthenticityScore,
                        "rodAuthenticityState" to proposal.rodAuthenticityState,
                        "trustedRod" to proposal.trustedRod,
                        "foregroundSupported" to proposal.foregroundSupported,
                        "foregroundCoverage" to proposal.foregroundCoverage,
                        "foregroundBodyCoverage" to proposal.foregroundBodyCoverage,
                        "foregroundReason" to proposal.foregroundReason,
                        "rodTipVisible" to proposal.rodTipVisible,
                        "orientedLongCrop" to (longLane && proposal.hasResolvedAxis),
                        "originalBounds" to "${proposal.originalBounds.left},${proposal.originalBounds.top},${proposal.originalBounds.right},${proposal.originalBounds.bottom}",
                        "normalizedBounds" to "${proposal.normalizedBounds.left},${proposal.normalizedBounds.top},${proposal.normalizedBounds.right},${proposal.normalizedBounds.bottom}",
                        "ocr" to recognized.ocrText.take(180),
                        "barcode" to recognized.barcode,
                        "candidate" to (top?.product?.name ?: ""),
                        "visual" to (top?.visualScore ?: 0),
                        "text" to (top?.textScore ?: 0),
                        "final" to (top?.finalScore ?: 0),
                        "secondFinal" to recognized.secondFinalScore,
                        "margin" to recognized.margin,
                        "anchor" to recognized.anchorScore,
                        "anchorMargin" to recognized.anchorMargin,
                        "candidateProductId" to top?.product?.id,
                        "anchorHandleOnLeft" to top?.product?.id?.let { anchorScoring?.handleOnLeftByProduct?.get(it) },
                        "physicalAnchorHandleOnLeft" to anchorScoring?.physicalHandleOnLeft,
                        "anchorEndpointLeftScore" to (anchorScoring?.endpointLeftScore ?: 0),
                        "anchorEndpointRightScore" to (anchorScoring?.endpointRightScore ?: 0),
                        "anchorRoleMargin" to (anchorScoring?.roleMargin ?: 0),
                        "anchorRoleConfidence" to (anchorScoring?.roleConfidence ?: 0),
                        "anchorRoleState" to (anchorScoring?.roleState ?: "ANCHOR_ROLE_NOT_APPLICABLE"),
                        "decisionRuleId" to recognized.ruleId,
                        "decisionDurationMs" to decisionDurationMs,
                        "totalObjectDurationMs" to (System.currentTimeMillis() - objectStarted),
                        "verified" to (top?.masterVerified ?: false),
                        "recognitionAccepted" to (recognitionMatch != null),
                        "quantityAccepted" to (quantityMatch != null),
                        "safetyKernelQuantityReason" to safetyQuantity.reason
                    )
                )

                com.arspos.anglerriausyndicate.ArsDecisionEvidenceLedger.record(
                    session = diagnosticSession,
                    proposal = proposal,
                    persistentPhysicalId = preBinding?.persistentPhysicalId ?: "",
                    candidateProductId = top?.product?.id,
                    topScore = top?.finalScore ?: 0,
                    secondScore = recognized.candidates.getOrNull(1)?.let { it.finalScore } ?: 0,
                    decisionRuleId = recognized.ruleId,
                    recognitionAccepted = recognitionMatch != null,
                    quantityAccepted = quantityMatch != null
                )

                preBinding?.let { binding ->
                    com.arspos.anglerriausyndicate.ArsVisualEvidenceRecorder.recordPersistentBinding(
                        session = diagnosticSession,
                        objectIndex = index,
                        physicalObjectId = proposal.physicalObjectId,
                        persistentPhysicalId = binding.persistentPhysicalId,
                        normalizedIou = binding.normalizedIou
                    )
                }

                com.arspos.anglerriausyndicate.ArsVisualEvidenceRecorder.recordDecision(
                    session = diagnosticSession,
                    objectIndex = index,
                    proposal = proposal.copy(
                        anchorHandleOnLeft = top?.product?.id?.let { anchorScoring?.handleOnLeftByProduct?.get(it) },
                        anchorEndpointLeftScore = anchorScoring?.endpointLeftScore ?: 0,
                        anchorEndpointRightScore = anchorScoring?.endpointRightScore ?: 0,
                        anchorRoleMargin = anchorScoring?.roleMargin ?: 0,
                        anchorRoleConfidence = anchorScoring?.roleConfidence ?: 0,
                        anchorRoleState = anchorScoring?.roleState ?: "ANCHOR_ROLE_NOT_APPLICABLE"
                    ),
                    crop = crop,
                    decisionRuleId = recognized.ruleId,
                    decisionReason = eventReason,
                    candidate = top?.product?.name.orEmpty(),
                    secondCandidate = recognized.candidates.getOrNull(1)?.product?.name.orEmpty(),
                    visualScore = top?.visualScore ?: 0,
                    finalScore = top?.finalScore ?: 0,
                    margin = recognized.margin,
                    anchorScore = recognized.anchorScore,
                    anchorMargin = recognized.anchorMargin,
                    recognitionAccepted = recognitionMatch != null,
                    quantityAccepted = quantityMatch != null,
                    barcode = recognized.barcode,
                    ocrText = recognized.ocrText
                )

                return com.arspos.anglerriausyndicate.VisualScanObject(
                    index = index,
                    bounds = android.graphics.Rect(bounds),
                    match = quantityMatch,
                    bestScore = recognized.finalScore,
                    visualScore = recognized.visualScore,
                    textScore = recognized.textScore,
                    finalScore = recognized.finalScore,
                    ocrText = recognized.ocrText,
                    barcode = recognized.barcode,
                    reason = eventReason,
                    candidates = recognized.candidates,
                    proposalId = proposal.proposalId,
                    proposalSource = proposal.source,
                    proposalType = proposal.proposalType,
                    proposalRotation = proposal.rotationDegrees,
                    lineageId = proposal.lineageId,
                    physicalInstanceHint = proposal.physicalInstanceHint,
                    physicalObjectId = proposal.physicalObjectId,
                    persistentPhysicalId = preBinding?.persistentPhysicalId ?: "",
                    recognitionAccepted = recognitionMatch != null,
                    quantityEligible = proposal.quantityEligible,
                    bridgeSuppressed = proposal.bridgeSuppressed,
                    originalBounds = android.graphics.Rect(proposal.originalBounds),
                    normalizedBounds = android.graphics.Rect(proposal.normalizedBounds),
                    frameWidth = bitmap.width,
                    frameHeight = bitmap.height,
                    decisionRuleId = recognized.ruleId
                )
            } finally {
                if (!crop.isRecycled) {
                    crop.recycle()
                    recycledCropCount++
                }
            }
        }

        proposals.forEachIndexed { index, proposal ->
            analyze(proposal, index + 1, allowSceneOcr = false)?.let { result += it }
        }

        // Long full-frame rescue is diagnostics/evidence only. It can never
        // create a cashier quantity. Also use identity profile isLongObject,
        // not only product-name heuristics, when deciding whether a long SKU
        // was already accepted.
        val hasVerifiedLongMaster = longProducts.any { verifiedProductIds.contains(it.id) }
        val acceptedLongAlready = result.any { item ->
            val productId = item.match?.product?.id ?: return@any false
            longProductIds.contains(productId) && verifiedProductIds.contains(productId)
        }
        val longProposalCount = proposals.count { it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_LONG }
        val resolvedAxisCount = mergeAxisCount
        // V8.4.21 Rescue Gate V2: raw/resolved geometry alone must not suppress
        // rescue. Only a TRUSTED physical rod is a hard blocker. ROD_UNCERTAIN
        // remains visible to telemetry but may still trigger the evidence-only
        // rescue pass. Rescue is quantityEligible=false, so this cannot lower a
        // recognition threshold or fabricate an inventory unit.
        val rescueBlockingTrustedRodTracks = trustedRodTracksAfterMerge
        val uncertainRodTracksForRescue = uncertainRodTracksAfterMerge
        val nonTrustedResolvedAxes = (resolvedAxisCount - rescueBlockingTrustedRodTracks).coerceAtLeast(0)
        val qualifiedUncertainTracks = proposals.count {
            it.rodAuthenticityState == com.arspos.anglerriausyndicate.ScanProposal.AUTH_UNCERTAIN &&
                it.segmentSupport && it.foregroundSupported && !it.bridgeSuppressed
        }
        val rescueSkipReason = com.arspos.anglerriausyndicate.ScanRescuePolicy.skipReason(
            hasVerifiedLongMaster, acceptedLongAlready, rescueBlockingTrustedRodTracks, qualifiedUncertainTracks
        )
        val rescueAllowed = rescueSkipReason == null
        val rescueReason = rescueSkipReason.orEmpty()
        com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
            "SCAN_RESCUE_POLICY", "Full-frame rescue eligibility V2",
            mapOf(
                "session" to diagnosticSession,
                "resolvedAxes" to resolvedAxisCount,
                "rescueBlockingTrustedRodTracks" to rescueBlockingTrustedRodTracks,
                "uncertainRodTracksForRescue" to uncertainRodTracksForRescue,
                "qualifiedUncertainTracks" to qualifiedUncertainTracks,
                "nonTrustedResolvedAxes" to nonTrustedResolvedAxes,
                "longProposalCount" to longProposalCount,
                "fullFrameRescueUsed" to rescueAllowed,
                "rescueSkippedReason" to rescueReason
            )
        )
        if (rescueAllowed) {
            // V8.4.13: one conditional full-frame evidence pass only. Multi-rod
            // scenes do not run rescue because a whole-frame score cannot prove
            // quantity or physical separation and was a major latency source.
            val rescueRects = listOf(
                android.graphics.Rect(0, 0, bitmap.width, bitmap.height)
            )
            rescueRects.forEachIndexed { offset, rect ->
                val rescue = com.arspos.anglerriausyndicate.ScanProposal(
                    proposalId = "RESCUE-${offset + 1}",
                    source = com.arspos.anglerriausyndicate.ScanProposal.SOURCE_RESCUE,
                    proposalType = com.arspos.anglerriausyndicate.ScanProposal.TYPE_RESCUE,
                    originalBounds = android.graphics.Rect(rect),
                    normalizedBounds = com.arspos.anglerriausyndicate.ScanCoordinateNormalizer.normalize(rect, 0, bitmap.width, bitmap.height),
                    rotationDegrees = 0,
                    lineageId = "RESCUE-EVIDENCE",
                    physicalInstanceHint = "RESCUE-EVIDENCE",
                    quantityEligible = false,
                    bridgeSuppressed = false,
                    orientation = "FULL_FRAME",
                    strength = 20
                )
                analyze(rescue, result.size + offset + 1, allowSceneOcr = false)
            }
        }

        val aggregation = com.arspos.anglerriausyndicate.ScanResultAggregator.aggregate(result.take(12))
        com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
            "SCAN_AGGREGATION",
            "Physical-instance aggregation + quantity safety completed",
            mapOf(
                "session" to diagnosticSession,
                "before" to aggregation.summary.before,
                "after" to aggregation.summary.after,
                "merged" to aggregation.summary.merged,
                "longGroups" to aggregation.summary.longGroups,
                "lineageMerges" to aggregation.summary.lineageMerges,
                "quantitySuppressed" to aggregation.summary.quantitySuppressed,
                "distinctLongInstances" to aggregation.summary.distinctLongInstances,
                "bridgeSuppressed" to proposals.count { it.bridgeSuppressed || it.proposalType == com.arspos.anglerriausyndicate.ScanProposal.TYPE_AMBIGUOUS_CONTAINER }
            )
        )
        if (aggregation.summary.quantitySuppressed > 0) {
            com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
                "SCAN_QUANTITY_SAFETY",
                "Duplicate long-object quantity suppressed",
                mapOf(
                    "session" to diagnosticSession,
                    "suppressed" to aggregation.summary.quantitySuppressed,
                    "finalObjects" to aggregation.summary.after
                )
            )
        }
        val nativeAfterScanMb = android.os.Debug.getNativeHeapAllocatedSize() / 1024L / 1024L
        val memoryInfo = android.os.Debug.MemoryInfo()
        android.os.Debug.getMemoryInfo(memoryInfo)
        val totalPssMb = memoryInfo.totalPss.toLong() / 1024L

        // Rolling baseline is process-local on purpose. A single scan may end
        // above or below its start because Android/native image libraries keep
        // reusable allocations. What matters for leak pressure is persistent
        // growth relative to a stable baseline/high-water across many scans.
        if (scannerNativeBaselineMb == null) scannerNativeBaselineMb = nativeBeforeScanMb
        scannerScanCount += 1
        if (scannerScanCount == 5) scannerWarmNativeBaselineMb = nativeBeforeScanMb
        scannerNativeHighWaterMb = maxOf(scannerNativeHighWaterMb, nativeAfterScanMb)
        scannerPssHighWaterMb = maxOf(scannerPssHighWaterMb, totalPssMb)
        val nativeBaselineMb = scannerNativeBaselineMb ?: nativeAfterScanMb
        val nativeGrowthFromBaselineMb = nativeAfterScanMb - nativeBaselineMb
        val systemMemory = com.arspos.anglerriausyndicate.ArsFlightRecorder.systemMemorySnapshot()
        val nativePressureWarning = systemMemory["systemLowMemory"] == true
        val nativeGrowthFromWarmMb = scannerWarmNativeBaselineMb?.let { nativeAfterScanMb - it }

        com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
            "SCAN_MEMORY",
            "V8.5.2 scanner + live-identity temporal memory snapshot",
            mapOf(
                "session" to diagnosticSession,
                "heapAfterScanMb" to sampleHeap(),
                "peakHeapMb" to peakHeapMb,
                "heapMaxMb" to (Runtime.getRuntime().maxMemory() / 1024L / 1024L),
                "nativeBeforeScanMb" to nativeBeforeScanMb,
                "nativeHeapMb" to nativeAfterScanMb,
                "nativeDeltaMb" to (nativeAfterScanMb - nativeBeforeScanMb),
                "nativeBaselineMb" to nativeBaselineMb,
                "warmNativeBaselineMb" to scannerWarmNativeBaselineMb,
                "nativeBeforeGrowthFromWarmMb" to scannerWarmNativeBaselineMb?.let { nativeBeforeScanMb - it },
                "nativeWarningBasis" to if (systemMemory["systemLowMemory"] == null) "OS_SIGNAL_UNAVAILABLE" else "ANDROID_ACTIVITY_MANAGER_LOW_MEMORY",
                "nativeGrowthFromWarmMb" to nativeGrowthFromWarmMb,
                "nativeGrowthWarning" to (scannerScanCount >= 8 && (nativeGrowthFromWarmMb ?: 0L) >= 32L),
                "nativeGrowthFromBaselineMb" to nativeGrowthFromBaselineMb,
                "nativeHighWaterMb" to scannerNativeHighWaterMb,
                "totalPssMb" to totalPssMb,
                "pssHighWaterMb" to scannerPssHighWaterMb,
                "scannerScanCount" to scannerScanCount,
                "nativePressureWarning" to nativePressureWarning,
                "temporaryCrops" to temporaryCropCount,
                "recycledCrops" to recycledCropCount
            ) + systemMemory
        )
        return aggregation.objects
    }

    private fun heapUsedMb(): Long =
        (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024L / 1024L

    /** V8.4.5: keep a diverse but bounded reference set per product.
     * Master Studio can store many video frames; scoring every full-resolution
     * frame for every proposal causes native bitmap pressure on mobile devices.
     */
    private fun selectRecognitionReferences(photos: List<com.arspos.anglerriausyndicate.data.db.ProductPhotoEntity>): List<com.arspos.anglerriausyndicate.data.db.ProductPhotoEntity> {
        return photos.groupBy { it.productId }.values.flatMap { productPhotos ->
            val selected = LinkedHashMap<Long, com.arspos.anglerriausyndicate.data.db.ProductPhotoEntity>()
            productPhotos.filter { it.isPrimary }.sortedByDescending { it.createdAt }.take(1).forEach { selected[it.id] = it }
            productPhotos
                .groupBy { it.captureAngle.ifBlank { "UNKNOWN" } }
                .values
                .forEach { group ->
                    group.sortedByDescending { it.createdAt }.take(1).forEach { selected[it.id] = it }
                }
            productPhotos.sortedByDescending { it.createdAt }.forEach {
                if (selected.size < 6) selected[it.id] = it
            }
            selected.values.take(6)
        }
    }

    private fun rectOverlap(a: android.graphics.Rect, b: android.graphics.Rect): Float {
        val left = maxOf(a.left, b.left)
        val top = maxOf(a.top, b.top)
        val right = minOf(a.right, b.right)
        val bottom = minOf(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val intersection = (right - left).toLong() * (bottom - top).toLong()
        val areaA = a.width().toLong() * a.height().toLong()
        val areaB = b.width().toLong() * b.height().toLong()
        val smaller = minOf(areaA, areaB)
        return if (smaller <= 0L) 0f else intersection.toFloat() / smaller.toFloat()
    }

    private fun centeredRect(width: Int, height: Int, fraction: Float): android.graphics.Rect {
        val f = fraction.coerceIn(0.50f, 1f)
        val w = (width * f).toInt().coerceAtLeast(24).coerceAtMost(width)
        val h = (height * f).toInt().coerceAtLeast(24).coerceAtMost(height)
        val left = (width - w) / 2
        val top = (height - h) / 2
        return android.graphics.Rect(left, top, left + w, top + h)
    }

    private fun isLikelyLongProduct(product: ProductEntity): Boolean {
        val hay = "${product.name} ${product.category} ${product.brand.orEmpty()} ${product.variant.orEmpty()}".uppercase()
        return listOf("JORAN", "ROD", "PANCING FIBER", "TELESCOPIC", "TELESCOP", "STICK ROD").any { hay.contains(it) }
    }

    suspend fun verifyProductMaster(productId: Long, bitmap: android.graphics.Bitmap): MasterVerificationResult {
        val product = dao.product(productId) ?: return MasterVerificationResult(
            productId = productId,
            productName = "",
            sku = "",
            barcode = "",
            referenceCount = 0,
            visualScore = 0,
            textScore = 0,
            finalScore = 0,
            ocrText = "",
            detectedBarcode = "",
            accepted = false,
            reason = "Produk tidak ditemukan"
        )
        val profile = ProductIdentityProfileCodec.decode(product.id, dao.setting("identity_profile_${product.id}"))
        val refs = selectRecognitionReferences(dao.allProductPhotos().filter { it.productId == productId })
            .map { photo ->
                VisualProductMatch(
                    product = product,
                    photo = photo,
                    score = ProductVisualMatcher.score(bitmap, photo.localPath, longObject = profile?.isLongObject == true)
                )
            }
        if (refs.isEmpty()) return MasterVerificationResult(
            productId = product.id, productName = product.name, sku = product.sku,
            barcode = product.barcode.orEmpty(), referenceCount = 0, visualScore = 0,
            textScore = 0, finalScore = 0, ocrText = "", detectedBarcode = "",
            accepted = false, reason = "Belum ada referensi master visual"
        )
        val ocr = runCatching { SmartProductInput.analyzeMultiOrientation(bitmap) }
            .getOrElse { SmartProductInput.Draft() }
        val recognized = SmartRecognitionEngine.recognize(
            crop = bitmap, products = listOf(product), references = refs, ocr = ocr,
            identityProfiles = profile?.let { mapOf(product.id to it) }.orEmpty()
        )
        val exactBarcode = ocr.barcode.isNotBlank() &&
            product.barcode.orEmpty().replace(Regex("\\D"), "") == ocr.barcode.replace(Regex("\\D"), "")
        val longObject = profile?.isLongObject == true || isLikelyLongProduct(product)
        val accepted = (refs.size >= (if (longObject) 5 else 3)) && when {
            exactBarcode && recognized.visualScore >= 45 -> true
            recognized.textScore >= 82 && recognized.visualScore >= 30 -> true
            recognized.textScore >= 72 && recognized.visualScore >= 40 -> true
            longObject && recognized.visualScore >= 72 -> true
            recognized.visualScore >= 82 -> true
            else -> false
        }
        val reason = when {
            refs.size < if (longObject) 5 else 3 -> "Referensi terlalu sedikit; minimal ${if (longObject) 5 else 3} frame master diperlukan"
            accepted && exactBarcode -> "Barcode cocok + visual master terverifikasi"
            accepted && recognized.textScore >= 82 -> "Identitas master + OCR + visual terverifikasi"
            accepted && recognized.textScore >= 72 -> "OCR + visual master terverifikasi"
            accepted -> "Visual master terverifikasi"
            else -> "Bukti master belum cukup kuat; tambah frame atau foto uji lebih jelas"
        }
        if (accepted) {
            dao.setSetting(SettingEntity("master_verified_${product.id}", "1"))
            dao.setSetting(SettingEntity("master_verified_score_${product.id}", recognized.finalScore.toString()))
            dao.setSetting(SettingEntity("master_verified_at_${product.id}", System.currentTimeMillis().toString()))
        }
        com.arspos.anglerriausyndicate.ArsFlightRecorder.event(
            "MASTER_VERIFY",
            reason,
            mapOf(
                "productId" to product.id,
                "product" to product.name,
                "refs" to refs.size,
                "visual" to recognized.visualScore,
                "text" to recognized.textScore,
                "final" to recognized.finalScore,
                "accepted" to accepted
            )
        )
        return MasterVerificationResult(
            productId = product.id, productName = product.name, sku = product.sku,
            barcode = product.barcode.orEmpty(), referenceCount = refs.size,
            visualScore = recognized.visualScore, textScore = recognized.textScore,
            finalScore = recognized.finalScore, ocrText = ocr.rawText,
            detectedBarcode = ocr.barcode, accepted = accepted, reason = reason
        )
    }

    private suspend fun loadVerifiedProductIds(): Set<Long> =
        dao.masterVerificationSettings().mapNotNull { setting ->
            if (setting.key.startsWith("master_verified_") && setting.value == "1") {
                setting.key.removePrefix("master_verified_").toLongOrNull()
            } else null
        }.toSet()

    private suspend fun loadIdentityProfiles(): Map<Long, ProductIdentityProfile> =
        dao.identityProfileSettings().mapNotNull { setting ->
            val id = setting.key.removePrefix("identity_profile_").toLongOrNull() ?: return@mapNotNull null
            ProductIdentityProfileCodec.decode(id, setting.value)?.let { id to it }
        }.toMap()

    suspend fun mergeProductIdentityProfile(
        productId: Long,
        rawText: String = "",
        brand: String = "",
        name: String = "",
        variant: String = "",
        modelCode: String = "",
        barcode: String = "",
        recognitionMode: String = "HYBRID",
        isLongObject: Boolean = false
    ) {
        val key = "identity_profile_$productId"
        val old = ProductIdentityProfileCodec.decode(productId, dao.setting(key))
        val mergedText = (listOf(old?.rawText.orEmpty(), rawText)
            .flatMap { it.lines() }
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.length >= 2 }
            .distinct()
            .takeLast(80)
            .joinToString("\n"))
        val mergedBrand = if (brand.isNotBlank()) brand.trim() else old?.brand.orEmpty()
        val mergedName = if (name.isNotBlank()) name.trim() else old?.name.orEmpty()
        val mergedVariant = if (variant.isNotBlank()) variant.trim() else old?.variant.orEmpty()
        val mergedModel = if (modelCode.isNotBlank()) modelCode.trim() else old?.modelCode.orEmpty()
        val mergedBarcode = if (barcode.isNotBlank()) barcode.trim() else old?.barcode.orEmpty()
        val aliasSource = buildList {
            addAll(old?.aliases.orEmpty())
            addAll(rawText.lines())
            add(mergedBrand)
            add(mergedName)
            add(mergedVariant)
            add(mergedModel)
        }
        val aliases = aliasSource
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.length >= 2 }
            .distinct()
            .takeLast(80)

        val oldLong = old?.isLongObject ?: false
        val merged = ProductIdentityProfile(
            productId = productId,
            rawText = mergedText,
            brand = mergedBrand,
            name = mergedName,
            variant = mergedVariant,
            modelCode = mergedModel,
            barcode = mergedBarcode,
            aliases = aliases,
            recognitionMode = recognitionMode.ifBlank { old?.recognitionMode ?: "HYBRID" },
            isLongObject = isLongObject || oldLong
        )
        dao.setSetting(SettingEntity(key, ProductIdentityProfileCodec.encode(merged)))
    }

    suspend fun productIdentityProfile(productId: Long): ProductIdentityProfile? =
        ProductIdentityProfileCodec.decode(productId, dao.setting("identity_profile_$productId"))

    suspend fun setProductRecognitionMode(productId: Long, mode: String, isLongObject: Boolean) {
        val old = productIdentityProfile(productId)
        val profile = (old ?: ProductIdentityProfile(productId = productId)).copy(
            recognitionMode = mode.ifBlank { "HYBRID" },
            isLongObject = isLongObject,
            updatedAt = System.currentTimeMillis()
        )
        dao.setSetting(SettingEntity("identity_profile_$productId", ProductIdentityProfileCodec.encode(profile)))
        invalidateMasterVerification(productId)
    }

    suspend fun clearProductIdentityProfile(productId: Long) {
        dao.setSetting(SettingEntity("identity_profile_$productId", ""))
    }

    suspend fun isMasterVerified(productId:Long):Boolean = dao.setting("master_verified_${productId}") == "1"
    suspend fun invalidateMasterVerification(productId:Long) { dao.setSetting(SettingEntity("master_verified_${productId}", "0")) }

    suspend fun addProductPhoto(productId:Long, localPath:String, primary:Boolean=false, captureAngle:String="UNKNOWN"):Long {
        if(primary) dao.clearPrimaryPhoto(productId)
        return dao.insertProductPhoto(ProductPhotoEntity(productId=productId, localPath=localPath, isPrimary=primary, captureAngle=captureAngle))
    }

    suspend fun clearProductPhotoAngle(productId:Long, angle:String) = dao.deleteProductPhotosForAngle(productId, angle)

    suspend fun setPrimaryProductPhoto(productId:Long, photoId:Long) {
        dao.clearPrimaryPhoto(productId)
        dao.setPrimaryPhoto(photoId)
    }

    suspend fun deleteProductPhoto(photo:ProductPhotoEntity) = dao.deleteProductPhoto(photo)

    suspend fun stockIn(productId:Long,qty:Int,cost:Long,supplier:String?,invoice:String?) {
        require(qty>0){"Jumlah harus > 0"}
        require(cost>=0){"Harga modal tidak valid"}
        db.withTransaction{
            val p=dao.product(productId) ?: error("Produk tidak ditemukan")
            val receipt=dao.insertReceipt(StockReceiptEntity(supplier=supplier,invoice=invoice,totalCost=cost*qty))
            dao.insertReceiptItems(listOf(StockReceiptItemEntity(0,receipt,productId,qty,cost)))
            dao.changeStock(productId,qty)
            dao.insertMovement(StockMovementEntity(
                productId=productId,
                type="PURCHASE",
                quantity=qty,
                stockBefore=p.stock,
                stockAfter=p.stock+qty,
                note=invoice
            ))
            dao.audit(AuditLogEntity(action="STOCK_IN",referenceId=receipt,detail="${p.name} +$qty"))
        }
    }

    suspend fun cashOut(amount:Long,category:String,description:String?) {
        require(amount>0){"Nominal harus > 0"}
        dao.insertCash(CashTransactionEntity(type="OUT",category=category,amount=amount,description=description))
        dao.audit(AuditLogEntity(action="CASH_OUT",detail="$category Rp $amount"))
    }

    suspend fun checkout(cart:List<CartLine>,paid:Long,method:String):CheckoutResult{
        require(cart.isNotEmpty()){"Keranjang kosong"}
        require(method in setOf("CASH","QRIS","TRANSFER","DEBIT")){"Metode pembayaran tidak valid"}
        val total=cart.sumOf{it.subtotal}
        require(paid>=total){"Uang pembayaran kurang"}
        if(method!="CASH") require(paid==total){"Pembayaran non-CASH harus sesuai total"}
        return db.withTransaction{
            cart.forEach{
                val p=dao.product(it.product.id)?:error("Produk tidak ditemukan")
                require(p.stock>=it.quantity){"Stok ${p.name} tidak mencukupi"}
            }
            val invoice="ARS-"+SimpleDateFormat("yyyyMMdd-HHmmssSSS",Locale.US).format(Date())
            val id=dao.insertSale(SaleEntity(invoiceNumber=invoice,subtotal=total,discount=0,grandTotal=total,
                paidAmount=paid,changeAmount=paid-total,paymentMethod=method))
            dao.insertItems(cart.map{SaleItemEntity(saleId=id,productId=it.product.id,productName=it.product.name,
                quantity=it.quantity,costPrice=it.product.costPrice,sellPrice=it.product.sellPrice,discount=0,subtotal=it.subtotal)})
            cart.forEach{
                val p=dao.product(it.product.id)!!
                dao.changeStock(p.id,-it.quantity)
                dao.insertMovement(StockMovementEntity(
                    productId=p.id,
                    type="SALE",
                    quantity=-it.quantity,
                    stockBefore=p.stock,
                    stockAfter=p.stock-it.quantity,
                    referenceId=id,
                    note=invoice
                ))
            }
            if(method=="CASH") dao.insertCash(CashTransactionEntity(type="IN",category="PENJUALAN",amount=total,referenceId=id))
            dao.audit(AuditLogEntity(action="SALE",referenceId=id,detail="$invoice | $method | Rp $total"))
            CheckoutResult(id,invoice,cart,total,paid,paid-total,method)
        }
    }

    suspend fun processReturn(saleId:Long, reason:String):Long {
        return db.withTransaction {
            val sale=dao.sale(saleId) ?: error("Transaksi tidak ditemukan")
            require(sale.status=="PAID"){"Transaksi tidak dapat diretur"}
            val existing=dao.returnsForSale(saleId).sumOf{it.total}
            require(existing < sale.grandTotal){"Transaksi sudah diretur penuh"}
            val items=dao.saleItems(saleId)
            val refund=items.sumOf{it.subtotal}
            val returnId=dao.insertReturn(ReturnEntity(saleId=saleId,reason=reason,total=refund))
            dao.insertReturnItems(items.map{ReturnItemEntity(returnId=returnId,productId=it.productId,quantity=it.quantity,amount=it.subtotal)})
            items.forEach{
                val p=dao.product(it.productId) ?: error("Produk retur tidak ditemukan")
                val before=p.stock
                dao.changeStock(p.id,it.quantity)
                dao.insertMovement(StockMovementEntity(
                    productId=p.id,
                    type="RETURN",
                    quantity=it.quantity,
                    stockBefore=before,
                    stockAfter=before+it.quantity,
                    referenceId=returnId,
                    note=sale.invoiceNumber
                ))
            }
            if(sale.paymentMethod=="CASH") dao.insertCash(CashTransactionEntity(type="OUT",category="RETUR",amount=refund,referenceId=returnId))
            dao.audit(AuditLogEntity(action="RETURN",referenceId=returnId,detail="${sale.invoiceNumber} | Rp $refund | $reason"))
            refund
        }
    }

    suspend fun profitSummary(start:Long):ProfitSummary{
        val sales=dao.sales().first()
        val relevant=sales.filter{it.status=="PAID"&&it.createdAt>=start}
        val grossSales=relevant.sumOf{it.grandTotal}
        var cost=0L
        relevant.forEach{s->cost+=dao.saleItems(s.id).sumOf{it.costPrice*it.quantity}}
        val returned=relevant.sumOf{s->dao.returnsForSale(s.id).sumOf{it.total}}
        return ProfitSummary(grossSales-returned,cost,(grossSales-returned)-cost)
    }
}
