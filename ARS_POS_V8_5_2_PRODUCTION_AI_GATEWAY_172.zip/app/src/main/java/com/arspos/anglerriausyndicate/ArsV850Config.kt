package com.arspos.anglerriausyndicate

/**
 * Phase 4.3.3.2 / V8.5.2 — Adaptive Hybrid Intelligence.
 *
 * The feature flags are intentionally conservative. Physical truth and cashier
 * safety are production-active; cloud identity and self-learning remain shadow
 * capabilities until field evidence proves them safe.
 */
object ArsV850Config {
    const val PHASE = "4.3.3.2"
    const val ENGINE = "V8.5.2"
    const val VERSION_NAME = "1.7.2"
    const val VERSION_CODE = 172

    const val FEATURE_PERSISTENT_FRAGMENT_FUSION = true
    const val FEATURE_ML_GUIDED_LOCAL_RECOVERY = true
    const val FEATURE_BEST_EVIDENCE_MEMORY = true
    const val FEATURE_DECISION_EVIDENCE_LEDGER = true
    const val FEATURE_GROUND_TRUTH_LEARNING = true
    const val FEATURE_AI_ENGINEER_UI = true
    const val FEATURE_AI_ENGINEER_VISUAL_EVIDENCE = true
    const val FEATURE_AI_GATEWAY_SIGNED_REQUESTS = true
    const val FEATURE_AI_GATEWAY_STRUCTURED_DIAGNOSTICS = true
    const val FEATURE_AI_GATEWAY_HEALTH_CHECK = true
    const val AI_ENGINEER_MAX_IMAGES = 4
    const val AI_ENGINEER_MAX_REPORT_CHARS = 120_000

    // Network/learning features are deliberately non-authoritative in the first
    // V8.5 build. They may observe/evaluate but cannot create identity/quantity.
    const val CLOUD_IDENTITY_MODE = "SHADOW"
    const val SELF_LEARNING_MODE = "SHADOW"
    const val AI_ENGINEER_MODE = "ASSIST_READ_ONLY"
}
