package com.arspos.anglerriausyndicate

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * V8.5.2 secure local configuration for the ARS AI Gateway.
 *
 * The OpenAI API key is NEVER stored in the APK. The app only stores an
 * operator-provisioned gateway token, encrypted with Android Keystore.
 */
object ArsAiGatewaySettings {
    private const val PREFS = "ars_ai_engineer_gateway"
    private const val KEY_URL = "gateway_url"
    private const val KEY_TOKEN = "gateway_token_cipher"
    private const val KEY_ALIAS = "ars_ai_gateway_token_v1"

    data class Snapshot(
        val url: String,
        val configured: Boolean,
        val hasToken: Boolean
    )

    fun snapshot(context: Context): Snapshot {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val url = prefs.getString(KEY_URL, "").orEmpty().trim()
        val token = loadToken(context)
        return Snapshot(
            url = url,
            configured = url.startsWith("https://", ignoreCase = true) && token.isNotBlank(),
            hasToken = token.isNotBlank()
        )
    }

    fun save(context: Context, url: String, tokenIfChanged: String? = null) {
        val cleanUrl = url.trim().removeSuffix("/")
        require(cleanUrl.isBlank() || cleanUrl.startsWith("https://", ignoreCase = true)) {
            "ARS AI Gateway wajib menggunakan HTTPS."
        }
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_URL, cleanUrl).apply()
        if (tokenIfChanged != null && tokenIfChanged.isNotBlank()) {
            prefs.edit().putString(KEY_TOKEN, encrypt(tokenIfChanged.trim())).apply()
        }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_URL)
            .remove(KEY_TOKEN)
            .apply()
    }

    fun gatewayUrl(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_URL, "")
            .orEmpty()
            .trim()
            .removeSuffix("/")

    fun loadToken(context: Context): String {
        val encoded = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TOKEN, "")
            .orEmpty()
        if (encoded.isBlank()) return ""
        return runCatching { decrypt(encoded) }.getOrDefault("")
    }

    private fun secretKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        val body = Base64.encodeToString(cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        return "$iv:$body"
    }

    private fun decrypt(value: String): String {
        val parts = value.split(':', limit = 2)
        require(parts.size == 2) { "Invalid encrypted gateway token" }
        val iv = Base64.decode(parts[0], Base64.NO_WRAP)
        val body = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(body).toString(Charsets.UTF_8)
    }
}
