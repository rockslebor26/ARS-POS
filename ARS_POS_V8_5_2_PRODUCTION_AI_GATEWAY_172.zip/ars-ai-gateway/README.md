# ARS AI Gateway — V8.5.2 Production Integration

Backend HTTPS untuk **ARS AI Engineer**. OpenAI API key **tidak pernah** disimpan di APK.

## Arsitektur

`ARS POS Android -> signed HTTPS -> ARS AI Gateway -> OpenAI Responses API`

Proteksi V8.5.2:

- gateway token disimpan di Android Keystore (AES-GCM),
- request ditandatangani HMAC-SHA256,
- timestamp + nonce anti-replay,
- package + minimum version validation,
- rate limit dan request-size limit,
- structured diagnostic output dengan JSON Schema,
- `store:false` pada Responses API,
- `safety_identifier` non-PII berbasis device install ID,
- retry upstream terbatas + circuit breaker,
- local diagnostic fallback jika gateway/OpenAI gagal,
- AI Engineer tetap `ASSIST_READ_ONLY`.

## Model routing default

- Routine build health: `gpt-5.6-terra`
- Deep root cause / evidence analysis: `gpt-5.6-sol`

Keduanya dapat diganti melalui environment variables tanpa mengubah APK.

## Environment

Salin `.env.example` menjadi `.env` hanya di server/private secret store dan isi nilainya. Jangan commit `.env`.

## Verification

```bash
node --check server.mjs
node --check security.mjs
node --test
```

## Endpoints

- `GET /health` — liveness minimal; tidak menerima evidence.
- `POST /v1/ars-ai/status` — authenticated/signed gateway readiness check.
- `POST /v1/ars-ai/analyze` — authenticated/signed read-only engineering analysis.

Tidak ada endpoint mutasi untuk quantity, stock, payment, scanner threshold, signer, model promotion, atau APK release.

Lihat `DEPLOYMENT.md` untuk deployment dan acceptance checklist.
