package com.arspos.anglerriausyndicate.data

import com.arspos.anglerriausyndicate.SmartProductInput
import com.arspos.anglerriausyndicate.ProductVisualMatcher
import com.arspos.anglerriausyndicate.VisualProductMatch
import androidx.room.withTransaction
import kotlinx.coroutines.flow.first
import com.arspos.anglerriausyndicate.data.db.*
import java.text.SimpleDateFormat
import java.util.*

data class ProfitSummary(val revenue:Long,val cost:Long,val grossProfit:Long)
data class LoginResult(val userId:Long,val role:String,val displayName:String)

class ProductionRepository(private val db:ArsDatabase){
    private val dao=db.dao()

    fun products()=dao.products()
    fun search(q:String)=if(q.isBlank())products() else dao.search(q)
    fun sales()=dao.sales()
    fun customers()=dao.customers()
    suspend fun saleItems(id:Long)=dao.saleItems(id)
    fun revenue(start:Long)=dao.revenue(start)
    fun transactionCount(start:Long)=dao.transactionCount(start)
    fun cashBalance()=dao.cashBalance()

    suspend fun login(username:String,pin:String):Result<LoginResult> = runCatching{
        val user=dao.user(username.trim()) ?: error("Username tidak ditemukan")
        require(PinHasher.matches(user.pinHash,pin)){"PIN salah"}
        if (!user.pinHash.startsWith("sha256\$")) dao.updateUser(user.copy(pinHash=PinHasher.hash(pin)))
        LoginResult(user.id,user.role,user.displayName)
    }

    suspend fun seed(){
        if(dao.countProducts()==0){
            listOf(
                ProductEntity(sku="JRG001",barcode="899000000001",name="Joran BC Elito Sidat 180",category="JORAN",brand="Elito",costPrice=95000,sellPrice=150000,wholesalePrice=135000,stock=15,minimumStock=5),
                ProductEntity(sku="REL001",barcode="899000000002",name="Reel Shimano FX 2500",category="REEL",brand="Shimano",costPrice=210000,sellPrice=275000,stock=8,minimumStock=3),
                ProductEntity(sku="SNR001",barcode="899000000003",name="PE Jabrik X9 2.0",category="SENAR",brand="Jabrik",costPrice=55000,sellPrice=85000,stock=12,minimumStock=4),
                ProductEntity(sku="LDR001",barcode="899000000004",name="Leader Relix 40lb",category="LEADER",brand="Relix",costPrice=28000,sellPrice=45000,stock=9,minimumStock=4),
                ProductEntity(sku="KIL001",barcode="899000000005",name="Kail BKK 1/0",category="KAIL",brand="BKK",costPrice=11000,sellPrice=18000,stock=20,minimumStock=5)
            ).forEach{dao.insertProduct(it)}
        }
        dao.insertUser(UserEntity(username="admin",displayName="Administrator",role="ADMIN",pinHash=PinHasher.hash("0000")))
        dao.setSetting(SettingEntity("store_name","ANGLER RIAU SYNDICATE"))
        dao.setSetting(SettingEntity("store_tagline","FISHING STORE"))
    }

    suspend fun addProduct(name:String,sku:String,barcode:String?,category:String,cost:Long,price:Long,stock:Int,brand:String?=null,variant:String?=null)=
        dao.insertProduct(ProductEntity(sku=sku,barcode=barcode,name=name,category=category,brand=brand,variant=variant,costPrice=cost,sellPrice=price,stock=stock))

    fun productPhotos(productId:Long)=dao.productPhotos(productId)

    suspend fun visualProductMatches(bitmap: android.graphics.Bitmap):List<com.arspos.anglerriausyndicate.VisualProductMatch> {
        val photos=dao.allProductPhotos()
        if(photos.isEmpty()) return emptyList()
        val products=HashMap<Long,ProductEntity?>()
        val bestByProduct=HashMap<Long,com.arspos.anglerriausyndicate.VisualProductMatch>()
        for(photo in photos){
            val product=if(products.containsKey(photo.productId)) products[photo.productId] else dao.product(photo.productId).also{products[photo.productId]=it}
            if(product==null || !product.active) continue
            val score=com.arspos.anglerriausyndicate.ProductVisualMatcher.score(bitmap,photo.localPath)
            val match=com.arspos.anglerriausyndicate.VisualProductMatch(product,photo,score)
            val previous=bestByProduct[product.id]
            if(previous==null || score>previous.score) bestByProduct[product.id]=match
        }
        return bestByProduct.values.sortedByDescending { it.score }.take(8)
    }

    /** Phase 4.3.2: object crop + OCR + visual fusion with strict acceptance. */
    suspend fun smartVisualScan(bitmap: android.graphics.Bitmap): List<com.arspos.anglerriausyndicate.VisualScanObject> {
        val photos = dao.allProductPhotos()
        if (photos.isEmpty()) return emptyList()

        val objects = com.arspos.anglerriausyndicate.SmartVisualScanner.detectObjects(bitmap)
        if (objects.isEmpty()) return emptyList()

        val products = HashMap<Long, ProductEntity?>()
        val activeProducts = ArrayList<ProductEntity>()
        for (photo in photos) {
            val p = if (products.containsKey(photo.productId)) products[photo.productId]
            else dao.product(photo.productId).also { products[photo.productId] = it }
            if (p != null && p.active && activeProducts.none { it.id == p.id }) activeProducts += p
        }

        val identityProfiles = loadIdentityProfiles()
        val result = ArrayList<com.arspos.anglerriausyndicate.VisualScanObject>()

        objects.forEachIndexed { index, bounds ->
            val crop = com.arspos.anglerriausyndicate.SmartVisualScanner.crop(bitmap, bounds)
            if (crop == null) {
                result += com.arspos.anglerriausyndicate.VisualScanObject(index + 1, bounds, null)
                return@forEachIndexed
            }

            val ocr = runCatching {
                com.arspos.anglerriausyndicate.SmartProductInput.analyzeMultiOrientation(crop)
            }.getOrElse { com.arspos.anglerriausyndicate.SmartProductInput.Draft() }

            val references = ArrayList<com.arspos.anglerriausyndicate.VisualProductMatch>()
            for (photo in photos) {
                val product = products[photo.productId] ?: continue
                if (!product.active) continue
                val score = com.arspos.anglerriausyndicate.ProductVisualMatcher.score(crop, photo.localPath)
                references += com.arspos.anglerriausyndicate.VisualProductMatch(product, photo, score)
            }

            val recognized = SmartRecognitionEngine.recognize(
                crop = crop,
                products = activeProducts,
                references = references,
                ocr = ocr,
                identityProfiles = identityProfiles
            )

            result += com.arspos.anglerriausyndicate.VisualScanObject(
                index = index + 1,
                bounds = bounds,
                match = recognized.match,
                bestScore = recognized.finalScore,
                visualScore = recognized.visualScore,
                textScore = recognized.textScore,
                finalScore = recognized.finalScore,
                ocrText = recognized.ocrText,
                barcode = recognized.barcode,
                reason = recognized.reason,
                candidates = recognized.candidates
            )
            crop.recycle()
        }

        return result
    }

    suspend fun verifyProductMaster(productId: Long, bitmap: android.graphics.Bitmap): MasterVerificationResult {
        val product = dao.product(productId) ?: return MasterVerificationResult(
            productId = productId,
            productName = "",
            sku = "",
            barcode = "",
            referenceCount = 0,
            visualScore = 0,
            textScore = 0,
            finalScore = 0,
            ocrText = "",
            detectedBarcode = "",
            accepted = false,
            reason = "Produk tidak ditemukan"
        )
        val refs = dao.allProductPhotos()
            .filter { it.productId == productId }
            .map { photo ->
                VisualProductMatch(
                    product = product,
                    photo = photo,
                    score = ProductVisualMatcher.score(bitmap, photo.localPath)
                )
            }
        if (refs.isEmpty()) return MasterVerificationResult(
            productId = product.id, productName = product.name, sku = product.sku,
            barcode = product.barcode.orEmpty(), referenceCount = 0, visualScore = 0,
            textScore = 0, finalScore = 0, ocrText = "", detectedBarcode = "",
            accepted = false, reason = "Belum ada referensi master visual"
        )
        val ocr = runCatching { SmartProductInput.analyzeMultiOrientation(bitmap) }
            .getOrElse { SmartProductInput.Draft() }
        val profile = ProductIdentityProfileCodec.decode(product.id, dao.setting("identity_profile_${product.id}"))
        val recognized = SmartRecognitionEngine.recognize(
            crop = bitmap, products = listOf(product), references = refs, ocr = ocr,
            identityProfiles = profile?.let { mapOf(product.id to it) }.orEmpty()
        )
        val exactBarcode = ocr.barcode.isNotBlank() &&
            product.barcode.orEmpty().replace(Regex("\\D"), "") == ocr.barcode.replace(Regex("\\D"), "")
        val accepted = refs.size >= 3 && when {
            exactBarcode && recognized.visualScore >= 45 -> true
            recognized.textScore >= 82 && recognized.visualScore >= 30 -> true
            recognized.textScore >= 72 && recognized.visualScore >= 40 -> true
            recognized.visualScore >= 82 -> true
            else -> false
        }
        val reason = when {
            refs.size < 3 -> "Referensi terlalu sedikit; minimal 3 frame master diperlukan"
            accepted && exactBarcode -> "Barcode cocok + visual master terverifikasi"
            accepted && exactBarcode -> "Barcode cocok + visual master terverifikasi"
            accepted && recognized.textScore >= 82 -> "Identitas master + OCR + visual terverifikasi"
            accepted && recognized.textScore >= 72 -> "OCR + visual master terverifikasi"
            accepted -> "Visual master terverifikasi"
            else -> "Bukti master belum cukup kuat; tambah frame atau foto uji lebih jelas"
        }
        if (accepted) {
            dao.setSetting(SettingEntity("master_verified_${product.id}", "1"))
            dao.setSetting(SettingEntity("master_verified_score_${product.id}", recognized.finalScore.toString()))
            dao.setSetting(SettingEntity("master_verified_at_${product.id}", System.currentTimeMillis().toString()))
        }
        return MasterVerificationResult(
            productId = product.id, productName = product.name, sku = product.sku,
            barcode = product.barcode.orEmpty(), referenceCount = refs.size,
            visualScore = recognized.visualScore, textScore = recognized.textScore,
            finalScore = recognized.finalScore, ocrText = ocr.rawText,
            detectedBarcode = ocr.barcode, accepted = accepted, reason = reason
        )
    }

    private suspend fun loadIdentityProfiles(): Map<Long, ProductIdentityProfile> =
        dao.identityProfileSettings().mapNotNull { setting ->
            val id = setting.key.removePrefix("identity_profile_").toLongOrNull() ?: return@mapNotNull null
            ProductIdentityProfileCodec.decode(id, setting.value)?.let { id to it }
        }.toMap()

    suspend fun mergeProductIdentityProfile(
        productId: Long,
        rawText: String = "",
        brand: String = "",
        name: String = "",
        variant: String = "",
        modelCode: String = "",
        barcode: String = ""
    ) {
        val key = "identity_profile_$productId"
        val old = ProductIdentityProfileCodec.decode(productId, dao.setting(key))
        val mergedText = (listOf(old?.rawText.orEmpty(), rawText)
            .flatMap { it.lines() }
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.length >= 2 }
            .distinct()
            .takeLast(80)
            .joinToString("\n"))
        val merged = ProductIdentityProfile(
            productId = productId,
            rawText = mergedText,
            brand = if (brand.isNotBlank()) brand else old?.brand.orEmpty(),
            name = if (name.isNotBlank()) name else old?.name.orEmpty(),
            variant = if (variant.isNotBlank()) variant else old?.variant.orEmpty(),
            modelCode = if (modelCode.isNotBlank()) modelCode else old?.modelCode.orEmpty(),
            barcode = if (barcode.isNotBlank()) barcode else old?.barcode.orEmpty()
        )
        dao.setSetting(SettingEntity(key, ProductIdentityProfileCodec.encode(merged)))
    }

    suspend fun clearProductIdentityProfile(productId: Long) {
        dao.setSetting(SettingEntity("identity_profile_$productId", ""))
    }

    suspend fun isMasterVerified(productId:Long):Boolean = dao.setting("master_verified_${productId}") == "1"
    suspend fun invalidateMasterVerification(productId:Long) { dao.setSetting(SettingEntity("master_verified_${productId}", "0")) }

    suspend fun addProductPhoto(productId:Long, localPath:String, primary:Boolean=false, captureAngle:String="UNKNOWN"):Long {
        if(primary) dao.clearPrimaryPhoto(productId)
        return dao.insertProductPhoto(ProductPhotoEntity(productId=productId, localPath=localPath, isPrimary=primary, captureAngle=captureAngle))
    }

    suspend fun clearProductPhotoAngle(productId:Long, angle:String) = dao.deleteProductPhotosForAngle(productId, angle)

    suspend fun setPrimaryProductPhoto(productId:Long, photoId:Long) {
        dao.clearPrimaryPhoto(productId)
        dao.setPrimaryPhoto(photoId)
    }

    suspend fun deleteProductPhoto(photo:ProductPhotoEntity) = dao.deleteProductPhoto(photo)

    suspend fun stockIn(productId:Long,qty:Int,cost:Long,supplier:String?,invoice:String?) {
        require(qty>0){"Jumlah harus > 0"}
        require(cost>=0){"Harga modal tidak valid"}
        db.withTransaction{
            val p=dao.product(productId) ?: error("Produk tidak ditemukan")
            val receipt=dao.insertReceipt(StockReceiptEntity(supplier=supplier,invoice=invoice,totalCost=cost*qty))
            dao.insertReceiptItems(listOf(StockReceiptItemEntity(0,receipt,productId,qty,cost)))
            dao.changeStock(productId,qty)
            dao.insertMovement(StockMovementEntity(
                productId=productId,
                type="PURCHASE",
                quantity=qty,
                stockBefore=p.stock,
                stockAfter=p.stock+qty,
                note=invoice
            ))
            dao.audit(AuditLogEntity(action="STOCK_IN",referenceId=receipt,detail="${p.name} +$qty"))
        }
    }

    suspend fun cashOut(amount:Long,category:String,description:String?) {
        require(amount>0){"Nominal harus > 0"}
        dao.insertCash(CashTransactionEntity(type="OUT",category=category,amount=amount,description=description))
        dao.audit(AuditLogEntity(action="CASH_OUT",detail="$category Rp $amount"))
    }

    suspend fun checkout(cart:List<CartLine>,paid:Long,method:String):CheckoutResult{
        require(cart.isNotEmpty()){"Keranjang kosong"}
        require(method in setOf("CASH","QRIS","TRANSFER","DEBIT")){"Metode pembayaran tidak valid"}
        val total=cart.sumOf{it.subtotal}
        require(paid>=total){"Uang pembayaran kurang"}
        if(method!="CASH") require(paid==total){"Pembayaran non-CASH harus sesuai total"}
        return db.withTransaction{
            cart.forEach{
                val p=dao.product(it.product.id)?:error("Produk tidak ditemukan")
                require(p.stock>=it.quantity){"Stok ${p.name} tidak mencukupi"}
            }
            val invoice="ARS-"+SimpleDateFormat("yyyyMMdd-HHmmssSSS",Locale.US).format(Date())
            val id=dao.insertSale(SaleEntity(invoiceNumber=invoice,subtotal=total,discount=0,grandTotal=total,
                paidAmount=paid,changeAmount=paid-total,paymentMethod=method))
            dao.insertItems(cart.map{SaleItemEntity(saleId=id,productId=it.product.id,productName=it.product.name,
                quantity=it.quantity,costPrice=it.product.costPrice,sellPrice=it.product.sellPrice,discount=0,subtotal=it.subtotal)})
            cart.forEach{
                val p=dao.product(it.product.id)!!
                dao.changeStock(p.id,-it.quantity)
                dao.insertMovement(StockMovementEntity(
                    productId=p.id,
                    type="SALE",
                    quantity=-it.quantity,
                    stockBefore=p.stock,
                    stockAfter=p.stock-it.quantity,
                    referenceId=id,
                    note=invoice
                ))
            }
            if(method=="CASH") dao.insertCash(CashTransactionEntity(type="IN",category="PENJUALAN",amount=total,referenceId=id))
            dao.audit(AuditLogEntity(action="SALE",referenceId=id,detail="$invoice | $method | Rp $total"))
            CheckoutResult(id,invoice,cart,total,paid,paid-total,method)
        }
    }

    suspend fun processReturn(saleId:Long, reason:String):Long {
        return db.withTransaction {
            val sale=dao.sale(saleId) ?: error("Transaksi tidak ditemukan")
            require(sale.status=="PAID"){"Transaksi tidak dapat diretur"}
            val existing=dao.returnsForSale(saleId).sumOf{it.total}
            require(existing < sale.grandTotal){"Transaksi sudah diretur penuh"}
            val items=dao.saleItems(saleId)
            val refund=items.sumOf{it.subtotal}
            val returnId=dao.insertReturn(ReturnEntity(saleId=saleId,reason=reason,total=refund))
            dao.insertReturnItems(items.map{ReturnItemEntity(returnId=returnId,productId=it.productId,quantity=it.quantity,amount=it.subtotal)})
            items.forEach{
                val p=dao.product(it.productId) ?: error("Produk retur tidak ditemukan")
                val before=p.stock
                dao.changeStock(p.id,it.quantity)
                dao.insertMovement(StockMovementEntity(
                    productId=p.id,
                    type="RETURN",
                    quantity=it.quantity,
                    stockBefore=before,
                    stockAfter=before+it.quantity,
                    referenceId=returnId,
                    note=sale.invoiceNumber
                ))
            }
            if(sale.paymentMethod=="CASH") dao.insertCash(CashTransactionEntity(type="OUT",category="RETUR",amount=refund,referenceId=returnId))
            dao.audit(AuditLogEntity(action="RETURN",referenceId=returnId,detail="${sale.invoiceNumber} | Rp $refund | $reason"))
            refund
        }
    }

    suspend fun profitSummary(start:Long):ProfitSummary{
        val sales=dao.sales().first()
        val relevant=sales.filter{it.status=="PAID"&&it.createdAt>=start}
        val grossSales=relevant.sumOf{it.grandTotal}
        var cost=0L
        relevant.forEach{s->cost+=dao.saleItems(s.id).sumOf{it.costPrice*it.quantity}}
        val returned=relevant.sumOf{s->dao.returnsForSale(s.id).sumOf{it.total}}
        return ProfitSummary(grossSales-returned,cost,(grossSales-returned)-cost)
    }
}
