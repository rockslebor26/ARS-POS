# ARS POS Phase 4.3.2.10 — Universal Product Identity

## Tujuan
Produk tanpa barcode tetap dapat memiliki identitas ARS dan dapat dikenali melalui OCR + visual master. Barcode menjadi penguat, bukan syarat.

## Perubahan utama
- Barcode pada input produk berstatus OPSIONAL.
- SKU internal ARS tetap wajib dan dapat dibuat otomatis.
- Master Studio menyimpan identity memory dari OCR/brand/name/variant/model/barcode ke settings lokal.
- Smart Scan memuat identity memory saat startup scan dan menggabungkannya dengan OCR multi-orientasi serta visual master.
- Exact barcode tetap memiliki prioritas tertinggi jika tersedia.
- Produk tanpa barcode tidak otomatis ditolak hanya karena barcode kosong.
- Margin kandidat tetap dipakai agar sistem memilih TIDAK DIKENALI ketika dua produk terlalu berdekatan.
- Tidak ada cloud upload; identitas disimpan lokal.

## Kompatibilitas update
- applicationId tetap `com.arspos.anglerriausyndicate`.
- release testing tetap menggunakan debug signing yang sama seperti build sebelumnya.
- versionCode dinaikkan dari 119 ke 120.
- Database tidak dinaikkan versinya untuk fitur identity memory ini karena data disimpan pada tabel settings yang sudah ada.
- APK 1.2.0 dapat dipasang sebagai update di atas 1.1.9 selama APK sebelumnya juga menggunakan sertifikat signing testing yang sama. Jangan uninstall aplikasi saat menguji update.

## Catatan
100% identity/master completeness bukan jaminan AI 100%. Sistem tetap memprioritaskan pencegahan salah jual.
