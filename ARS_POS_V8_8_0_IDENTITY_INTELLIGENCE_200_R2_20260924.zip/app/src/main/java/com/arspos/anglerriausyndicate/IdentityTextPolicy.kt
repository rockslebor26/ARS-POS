package com.arspos.anglerriausyndicate

/**
 * Phase 4.3.5.0 / V8.8.0 — separates SKU-bearing package text from generic,
 * regulatory and quantity text. This is a deterministic local policy; it does
 * not lower any recognition threshold and it does not infer a product ID.
 */
object IdentityTextPolicy {
    private val nonIdentityFragments = listOf(
        "PERINGATAN", "MEROKOK", "BERHENTI MEROKOK", "LAYANAN BERHENTI",
        "KANKER", "TENGGOROKAN", "PENYAKIT JANTUNG", "KEHAMILAN",
        "DILARANG MENJUAL", "USIA 18", "18+", "WARNING", "SMOKING",
        "TOBACCO", "NICOTINE", "SURGEON GENERAL", "HEALTH WARNING",
        "DIPRODUKSI OLEH", "DISTRIBUSI OLEH", "CUSTOMER SERVICE",
        "LAYANAN KONSUMEN", "BPOM", "P-IRT", "NETTO", "BERAT BERSIH"
    )

    private val genericTokens = setOf(
        "PERINGATAN", "MEROKOK", "KARENA", "KANKER", "TENGGOROKAN",
        "LAYANAN", "BERHENTI", "KESEHATAN", "WARNING", "SMOKING",
        "TOBACCO", "NICOTINE", "BATANG", "PCS", "PCS", "GRAM", "NETTO",
        "DIPRODUKSI", "DISTRIBUSI", "OLEH", "INDONESIA", "KONSUMEN"
    )

    private val quantityOnly = Regex(
        "^\\d{1,5}\\s*(BATANG|PCS?|PC|ML|MILLILITER|G|GR|GRAM|KG|L|LTR|LITER)$",
        RegexOption.IGNORE_CASE
    )

    fun isNonIdentityLine(line: String): Boolean {
        val normalized = line.trim().replace(Regex("\\s+"), " ").uppercase()
        if (normalized.length < 2) return true
        if (quantityOnly.matches(normalized)) return true
        return nonIdentityFragments.any { normalized.contains(it) }
    }

    fun identityLines(raw: String): List<String> = raw.lines()
        .map { it.trim().replace(Regex("\\s+"), " ") }
        .filter { it.length >= 2 }
        .filterNot(::isNonIdentityLine)
        .distinct()

    fun identityBearingText(raw: String): String = identityLines(raw).joinToString("\n")

    fun distinctiveTokens(raw: String): List<String> = identityLines(raw)
        .flatMap { line ->
            line.uppercase()
                .replace(Regex("[^A-Z0-9]+"), " ")
                .trim()
                .split(" ")
        }
        .map { it.trim() }
        .filter { it.length >= 3 && it !in genericTokens && !it.all(Char::isDigit) }
        .distinct()
        .take(48)

    fun ignoredLineCount(raw: String): Int {
        val all = raw.lines().map { it.trim() }.filter { it.length >= 2 }.distinct()
        return all.count(::isNonIdentityLine)
    }
}
