package com.arspos.anglerriausyndicate

/**
 * V8.8.0 live identity scheduling. Ambiguous visual evidence must trigger OCR
 * rather than suppress it. This controls *when* identity evidence is gathered;
 * final recognition thresholds remain owned by SmartRecognitionEngine.
 */
object LiveIdentityPolicy {
    const val MIN_VISUAL_FOR_NORMAL_IDENTITY = 72
    const val AMBIGUOUS_VISUAL_MARGIN = 6

    fun shouldRunNormalIdentity(laneLong: Boolean, visualScore: Int): Boolean =
        !laneLong && visualScore >= MIN_VISUAL_FOR_NORMAL_IDENTITY

    fun triggerReason(laneLong: Boolean, visualScore: Int, visualMargin: Int): String = when {
        laneLong -> "LONG_PREVIEW_FINAL_IDENTITY_REQUIRED"
        visualScore < MIN_VISUAL_FOR_NORMAL_IDENTITY -> "VISUAL_BELOW_LIVE_IDENTITY_TRIGGER"
        visualMargin < AMBIGUOUS_VISUAL_MARGIN -> "AMBIGUOUS_VISUAL_REQUIRES_OCR"
        else -> "NORMAL_IDENTITY_EVIDENCE_REFRESH"
    }
}
