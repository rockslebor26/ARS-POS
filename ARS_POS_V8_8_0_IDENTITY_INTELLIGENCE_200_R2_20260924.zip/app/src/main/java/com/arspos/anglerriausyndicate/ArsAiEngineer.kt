package com.arspos.anglerriausyndicate

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/**
 * V8.8.0 ARS AI Engineer console.
 *
 * The model may analyze evidence and generate an engineering/update proposal.
 * Runtime learning is limited to operator-confirmed visual references elsewhere
 * in the app. APK/code deployment, quantity, stock, payment, thresholds and
 * signing remain explicit gated operations.
 */
@Composable
fun ArsAiEngineerDialog(context: Context, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var gateway by remember { mutableStateOf(ArsAiGatewaySettings.snapshot(context)) }
    var busy by remember { mutableStateOf(false) }
    var result by remember {
        mutableStateOf(
            "ARS AI Engineer V8.8.0 siap.\n\n" +
                if (gateway.configured) {
                    "Gateway AI terkonfigurasi. Pilih analisis di bawah."
                } else {
                    "Gateway AI belum dikonfigurasi. Fitur tetap dapat membuka diagnosis lokal; konfigurasi HTTPS gateway diperlukan untuk analisis model online di dalam ARS POS."
                }
        )
    }
    var source by remember { mutableStateOf(if (gateway.configured) "READY" else "LOCAL") }
    var question by remember { mutableStateOf("") }
    var showConfig by remember { mutableStateOf(false) }
    var gatewayUrl by remember { mutableStateOf(gateway.url) }
    var gatewayToken by remember { mutableStateOf("") }
    var gatewayStatus by remember { mutableStateOf("BELUM DIUJI") }

    fun request(mode: String, prompt: String, includeEvidence: Boolean) {
        if (busy) return
        busy = true
        result = "Menganalisis…"
        scope.launch {
            val response = ArsAiEngineerClient.analyze(
                context = context,
                mode = mode,
                question = prompt,
                includeVisualEvidence = includeEvidence
            )
            result = buildString {
                append(response.analysis)
                if (response.source == "GATEWAY") {
                    appendLine()
                    appendLine()
                    append("AI source: ${response.model.ifBlank { "gateway" }}")
                    if (response.gatewayVersion.isNotBlank()) append(" • gateway ${response.gatewayVersion}")
                    if (response.requestId.isNotBlank()) append(" • request ${response.requestId.take(18)}")
                    append(" • ${response.latencyMs} ms")
                }
            }
            source = response.source
            busy = false
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = {
            Column {
                Text("ARS AI ENGINEER", fontWeight = FontWeight.Bold)
                Text(
                    "V8.8.0 • SIGNED HTTPS • ENGINEERING PROPOSAL GATE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 610.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    if (gateway.configured) "● AI GATEWAY: TERKONFIGURASI" else "○ AI GATEWAY: BELUM DIKONFIGURASI",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Text(
                    "Mode: ${ArsV850Config.AI_ENGINEER_MODE} • Cloud Identity: ${ArsV850Config.CLOUD_IDENTITY_MODE} • Self Learning: ${ArsV850Config.SELF_LEARNING_MODE}",
                    fontSize = 10.sp
                )
                Text(
                    "AI Engineer dapat menganalisis telemetry/evidence dan menyusun proposal perubahan. Pembelajaran visual terkonfirmasi dapat dilakukan di Smart Scan; quantity, stok, pembayaran, threshold, signer, dan pemasangan APK tetap dikunci oleh Safety Kernel/release gate.",
                    fontSize = 10.sp
                )
                Text(
                    "Gateway status: $gatewayStatus",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
                OutlinedButton(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy && gateway.configured,
                    onClick = {
                        busy = true
                        gatewayStatus = "MENGUJI…"
                        scope.launch {
                            val status = ArsAiEngineerClient.testGateway(context)
                            gatewayStatus = if (status.ok) {
                                "ONLINE • gateway ${status.gatewayVersion.ifBlank { "?" }} • fast ${status.fastModel.ifBlank { "?" }} • deep ${status.deepModel.ifBlank { "?" }} • ${status.latencyMs} ms"
                            } else {
                                "GAGAL • ${status.message}"
                            }
                            busy = false
                        }
                    }
                ) {
                    Text("UJI KONEKSI AI", fontSize = 11.sp)
                }

                Button(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy,
                    onClick = {
                        request(
                            mode = "BUILD_HEALTH",
                            prompt = "Analisis kesehatan build ARS POS saat ini. Prioritaskan crash/ANR, memory/native pressure, latency, regression, update in-place, serta safety scanner. Berikan blocker dan test berikutnya.",
                            includeEvidence = false
                        )
                    }
                ) {
                    Text("ANALISIS BUILD", fontSize = 11.sp)
                }

                Button(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy,
                    onClick = {
                        request(
                            mode = "LAST_SCAN_ROOT_CAUSE",
                            prompt = "Analisis scan terakhir beserta visual evidence yang terikat. Cari root cause dari physical truth, fragment fusion, ML-guided recovery, persistent ID, identity margin, false NORMAL, duplicate quantity, rod authenticity, anchor role, dan latency. Jangan menilai gambar terpisah dari telemetry.",
                            includeEvidence = true
                        )
                    }
                ) {
                    Text("ANALISIS SCAN TERAKHIR + BUKTI", fontSize = 11.sp)
                }

                OutlinedButton(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy,
                    onClick = {
                        request(
                            mode = "NEXT_ACTION",
                            prompt = "Dari report terbaru, tentukan akar masalah paling penting dan tindakan engineering berikutnya. Jangan menurunkan recognition threshold dan jangan mengubah quantity safety.",
                            includeEvidence = true
                        )
                    }
                ) {
                    Text("ROOT CAUSE + SARAN PERBAIKAN", fontSize = 11.sp)
                }

                Button(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy,
                    onClick = {
                        request(
                            mode = "DEVELOPMENT_PROPOSAL",
                            prompt = "Susun proposal update ARS POS berikutnya yang paling langsung mendorong tiga target produk: input barang dari HP, Smart Scan multi-object dengan harga/total, dan pengenalan barang tanpa kode/text/barcode. Gunakan telemetry dan visual evidence sebagai dasar. Nyatakan file/modul yang perlu diubah, risiko regresi, test acceptance, dan apakah update APK diperlukan. Jangan pernah menurunkan threshold atau melewati quantity safety.",
                            includeEvidence = true
                        )
                    }
                ) {
                    Text("RANCANG UPDATE SELANJUTNYA", fontSize = 11.sp)
                }

                HorizontalDivider()

                OutlinedTextField(
                    value = question,
                    onValueChange = { question = it.take(8_000) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Tanya ARS AI Engineer") },
                    placeholder = { Text("Contoh: kenapa joran biru tadi tidak dikenali?") },
                    minLines = 2,
                    maxLines = 5
                )
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy && question.isNotBlank(),
                    onClick = {
                        request(
                            mode = "CUSTOM_QUESTION",
                            prompt = question,
                            includeEvidence = true
                        )
                    }
                ) {
                    Text(if (busy) "MENGANALISIS…" else "TANYA AI", fontSize = 11.sp)
                }

                HorizontalDivider()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        modifier = Modifier,
                        enabled = !busy,
                        onClick = { showConfig = !showConfig }
                    ) {
                        Text("GATEWAY", fontSize = 10.sp)
                    }
                    OutlinedButton(
                        modifier = Modifier,
                        enabled = !busy,
                        onClick = {
                            result = ArsAiLocalAdvisor.analyze(ArsFlightRecorder.buildReport(context))
                            source = "LOCAL_FALLBACK"
                        }
                    ) {
                        Text("DIAGNOSIS LOKAL", fontSize = 10.sp)
                    }
                }

                if (showConfig) {
                    Text("KONFIGURASI ARS AI GATEWAY", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text(
                        "Gunakan backend HTTPS milik ARS. Jangan masukkan OpenAI API key di aplikasi; API key hanya disimpan di server gateway.",
                        fontSize = 9.sp
                    )
                    OutlinedTextField(
                        value = gatewayUrl,
                        onValueChange = { gatewayUrl = it.take(500) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Gateway HTTPS URL") },
                        placeholder = { Text("https://ai.ars.example") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = gatewayToken,
                        onValueChange = { gatewayToken = it.take(2_000) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(if (gateway.hasToken) "Token baru (kosong = pertahankan)" else "Gateway token") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            modifier = Modifier,
                            onClick = {
                                runCatching {
                                    ArsAiGatewaySettings.save(
                                        context,
                                        gatewayUrl,
                                        gatewayToken.takeIf { it.isNotBlank() }
                                    )
                                }.onSuccess {
                                    gatewayToken = ""
                                    gateway = ArsAiGatewaySettings.snapshot(context)
                                    gatewayStatus = "BELUM DIUJI"
                                    Toast.makeText(context, "ARS AI Gateway tersimpan. Jalankan UJI KONEKSI AI.", Toast.LENGTH_SHORT).show()
                                }.onFailure {
                                    Toast.makeText(context, it.message ?: "Gateway tidak valid.", Toast.LENGTH_LONG).show()
                                }
                            }
                        ) { Text("SIMPAN", fontSize = 10.sp) }

                        OutlinedButton(
                            modifier = Modifier,
                            onClick = {
                                ArsAiGatewaySettings.clear(context)
                                gatewayUrl = ""
                                gatewayToken = ""
                                gateway = ArsAiGatewaySettings.snapshot(context)
                                gatewayStatus = "BELUM DIKONFIGURASI"
                                Toast.makeText(context, "Konfigurasi AI dihapus.", Toast.LENGTH_SHORT).show()
                            }
                        ) { Text("HAPUS", fontSize = 10.sp) }
                    }
                }

                HorizontalDivider()
                Text("HASIL ANALISIS • $source", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Text(result, fontSize = 10.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = onDismiss) { Text("SELESAI") }
        }
    )
}
