# ARS POS Phase 4.3.2.26 — V8.4.6

Version: **1.4.1**  
Version Code: **141**

## Official Update Channel

V8.4.6 establishes the permanent Android update identity for ARS POS.

Rules from this version forward:

1. `applicationId` stays `com.arspos.anglerriausyndicate`.
2. Release APKs are signed only by the dedicated **ARS POS OFFICIAL RELEASE** keystore supplied through GitHub Actions secrets.
3. `versionCode` must strictly increase for every APK update.
4. The release workflow must never fall back to the Android debug keystore.
5. Do not uninstall the official-channel app when installing future versions; install the newer APK over the existing APK.
6. Room migrations must be supplied whenever the database schema changes.

## Update tracking

`ArsUpdateChannel.kt` records app-private version transitions and signing metadata. Every ARS Dev Center / ChatGPT report includes:

- current version and versionCode
- previous installed version when available
- `FRESH_INSTALL`, `IN_PLACE_UPDATE`, rollback, or other version transition
- package id
- release signing channel
- signer certificate SHA-256
- first install time
- last update time
- database version

Events added to the Flight Recorder include `APP_INSTALL`, `APP_UPDATE`, and `APP_VERSION_TRANSITION`.

## Important bootstrap note

Builds before V8.4.6 used a debug signing configuration. Android can only update an installed APK when package id and signing identity match. Therefore the first switch to the official release key may require one final uninstall/install. From the first successful V8.4.6 official installation onward, keep the same release key permanently and install future APKs as in-place updates.
