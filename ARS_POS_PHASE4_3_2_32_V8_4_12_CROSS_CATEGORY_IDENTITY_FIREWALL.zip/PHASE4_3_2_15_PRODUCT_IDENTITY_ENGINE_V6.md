# ARS POS — Phase 4.3.2.15 Product Identity Engine V6

V6 changes recognition from visual-first to identity-first.

- Exact barcode is definitive when it matches the product database.
- OCR identity must support recognition when OCR text is present.
- Visual similarity alone cannot identify an unverified product.
- Visual-only recognition is allowed only for a master explicitly verified by the user and only with a strong score and large margin.
- Close visual candidates are rejected as UNKNOWN.
- Unknown objects are never offered with a TAMBAH action.
- Existing multi-object camera flow remains offline and still-photo based.
