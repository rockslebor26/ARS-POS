# Phase 4.3.2.12 Build Fix

Build #174 failed during `:app:kaptGenerateStubsReleaseKotlin` because `PosViewModel.kt` was missing the final closing brace for the `PosViewModel` class.

The source is corrected and the release version is bumped to:
- versionCode 123
- versionName 1.2.3

Barcode remains optional; SKU is the required internal product identity.
