# ARS POS — Phase 4.3.2.17 Product Identity Engine V8

## Hybrid fishing-store identity

V8 is designed for a fishing store where many products do not have a barcode and some may have little or no printed identity. The product master captured during stock/product enrollment becomes the local identity reference.

### Recognition lanes

1. **Barcode lane** — exact barcode is the strongest proof when available.
2. **OCR/identity lane** — brand, product name, variant, model and aliases are matched when readable.
3. **Visual master lane** — a verified multi-frame master can identify products without barcode or readable text.
4. **Long-object lane** — rods/joran and other elongated products can be enrolled as LONG_OBJECT. V8 compares orientation variants and uses dedicated full-length/detail master passes. It is intended for rods up to roughly 5 meters.
5. **Unknown safety gate** — weak or ambiguous evidence remains UNKNOWN and is never silently added to the sale.

## Master enrollment

Normal products use six sides. Long objects use:

- full length A
- full length B
- handle/butt
- tip
- side detail

The completeness percentage is enrollment completeness, not AI certainty. Barcode is optional; no-barcode products can still reach a complete master when the visual enrollment and manual identity are present.

## Shopping scan

The cashier still takes **one photo**. V8 can process multiple detected regions and groups recognized products in the review panel. The cashier can add recognized items to the cart, review quantities/prices, and then use the existing payment flow. No payment is automatic.

## Important limitation

This remains a deterministic offline identity system using ML Kit object proposals, OCR/barcode and local visual descriptors. It is not a newly trained neural network. A future custom model can be added once ARS has enough labeled product images.
