# ARS POS Phase 4.3.2.32 — V8.4.12
## Cross-Category Identity Firewall + Bidirectional Rod Anchor Role Consensus

Release identity:
- applicationId: `com.arspos.anglerriausyndicate`
- versionName: `1.4.7`
- versionCode: `147`
- database version: `5` (unchanged)
- official signing channel: unchanged
- update target: install in-place over `1.4.6 (146)` Official; **do not uninstall**

## Why this phase exists
V8.4.11 field data established that stability and update continuity are healthy, while the highest-impact remaining scanner failure is cross-category false acceptance. In rod-dominated scenes, ML Kit can create a compact `NORMAL_OBJECT` from a handle, crossing region, shadow or broad crop. A verified NORMAL visual master may then score strongly enough to become a sellable SKU even though the physical scene contains rods.

The safe correction is **not** to lower LONG recognition thresholds. V8.4.12 inserts a geometry/identity firewall between proposal resolution and final NORMAL visual-only acceptance, while strengthening rod endpoint identity without relaxing any acceptance constant.

## V8.4.12 invariants
1. Package, official signer and database schema remain unchanged.
2. `versionCode` increases from 146 to 147.
3. NORMAL and LONG lanes remain typed; they never become one recognition lane.
4. LONG quantity remains based on resolved `TRACK-*` physical instances, never raw proposal count.
5. Crossing LONG axes remain independently preserved.
6. A NORMAL region geometrically owned by strong rod tracks cannot create a visual-only NORMAL SKU.
7. Exact barcode and sufficiently strong OCR remain independent identity evidence; the firewall must not destroy them.
8. A real compact NORMAL product that is physically isolated from rod corridors remains eligible for normal recognition.
9. Rod HANDLE/TIP role is selected by a deterministic two-hypothesis endpoint consensus; SIDE remains same-type matched.
10. Existing visual and anchor acceptance thresholds remain unchanged (`MIN_LONG_VISUAL_MARGIN = 14`, `MIN_LONG_ANCHOR_MARGIN = 8`).
11. Full-frame rescue remains evidence-only and cannot create cashier quantity.
12. Ambiguous bridge/background/cross-lane evidence remains quantity-ineligible.
13. All temporary crops must be recycled.
14. Rolling memory telemetry is diagnostic only and cannot change recognition decisions.

## Main changes
### CrossCategorySceneFirewall.kt
Runs after `RodPhysicalTrackResolver.resolve` so NORMAL ownership is judged against resolved rod geometry rather than raw detector boxes. Strong rod tracks require resolved axis metadata, rod-structure evidence and sufficient axis confidence. The firewall records conflict score, rod-track hits and a deterministic reason.

For visual-only NORMAL acceptance:
- multi-rod scene: NORMAL must be compact **and isolated from every rod corridor**;
- direct rod-axis intersection: blocked;
- elongated or broad NORMAL region in a rod scene: blocked;
- compact isolated NORMAL region: allowed.

The block is scoped to visual-only identity. Barcode/OCR evidence continues through the recognition engine.

### RodAnchorExtractor.kt + ProductVisualMatcher.kt
The live oriented rod crop exposes both endpoints. Each endpoint is scored against HANDLE and TIP masters. Two global hypotheses are compared:
- left = HANDLE, right = TIP
- right = HANDLE, left = TIP

One hypothesis wins deterministically for the complete object; SIDE is scored independently. Scan fingerprint banks are reused so this identity improvement does not multiply bitmap work unnecessarily.

### SmartRecognitionEngine.kt
Adds `REJECT_CROSS_CATEGORY_VISUAL_ONLY`. The rule is applied after exact barcode/strong text paths but before visual-only acceptance. This intentionally converts a dangerous false SKU into UNKNOWN.

### ArsFlightRecorder.kt / ProductionRepository.kt
Adds:
- cross-category visual-only blocked count;
- cross-category conflict count / max score;
- NORMAL rod-track hit count;
- rolling native heap baseline/growth/high-water;
- PSS high-water and scanner scan count;
- native pressure warning after repeated persistent growth;
- OCR, decision and total object timing fields.

## Required field acceptance tests
1. **One rod only** — exactly one LONG track; zero sellable NORMAL objects.
2. **Two parallel rods** — exactly two LONG tracks; no duplicate NORMAL SKU.
3. **Two crossing rods** — exactly two LONG tracks; crossing preserved; intersection never becomes a sellable NORMAL object.
4. **Rod handle close-up** — must not become a compact-product SKU by visual-only similarity.
5. **Two rods + real compact NORMAL product isolated from both** — NORMAL product remains recognizable, LONG tracks remain independent.
6. **Real NORMAL product near a rod with exact barcode** — barcode path remains valid even if visual-only is blocked.
7. **Similar rods** — remain UNKNOWN whenever visual/anchor margins are insufficient; do not lower thresholds.
8. **Repeated scan x10** — no force close, no incomplete sessions, quantity stable, every temporary crop recycled.
9. **Memory** — inspect baseline/growth/high-water; no persistent runaway native growth.
10. **Latency** — dense scenes should not gain unnecessary rescue passes; inspect object OCR/decision/total timing.
11. **Official update** — report must show `1.4.6 (146) -> 1.4.7 (147)`, `IN_PLACE_UPDATE`, identical package and signer SHA-256.

## Primary success criterion
The regression target is strict: **a rod or rod intersection must never become a sellable NORMAL SKU solely because of visual similarity.** When identity evidence is ambiguous, UNKNOWN is the correct result.
