# ARS POS Phase 4.3.2.26 V8.4.6 Official Update Channel FIX1

Build signing lifecycle fix.

Problem found after official signing secrets were configured:
- Prepare signing correctly writes only ARS_RELEASE_STORE_FILE to GITHUB_ENV.
- The following `gradle clean` configures the Android project with a non-empty store file path, while password/alias/password are step-scoped and therefore absent.
- The previous Gradle script used `!!` for those missing values and could fail during project configuration before the release build started.

FIX1:
- `releaseSigningAvailable` requires all four signing values before configuring the signing config.
- release tasks still fail early if any official signing value is missing.
- clean/non-release Gradle tasks no longer dereference partial signing state.
- workflow also passes the official signing secrets to the Clean step as defense in depth.

Version remains 1.4.1 / 141 because the previous official APK was never successfully built or released.
