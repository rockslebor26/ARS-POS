# ARS POS Phase 4.3.2.7.1 — Recognition Engine V2

Perbaikan fokus: barcode-first, OCR multi-orientasi (0/90/180/270), model-code evidence, dan SKU database-only.

- Kamera kasir tetap satu foto.
- Rotasi hanya dilakukan di memori untuk OCR/barcode.
- SKU tidak pernah dibuat dari OCR saat shopping scan.
- Kandidat selalu berasal dari katalog aktif.
- Visual master tetap menjadi bukti pendukung.
- Hasil lemah tetap ditolak.
