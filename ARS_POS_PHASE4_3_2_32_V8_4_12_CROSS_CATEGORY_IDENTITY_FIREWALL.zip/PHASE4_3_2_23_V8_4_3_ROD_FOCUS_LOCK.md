# ARS POS Phase 4.3.2.23 — V8.4.3 Rod Focus Lock

Version: 1.3.8 (versionCode 138)

## Tujuan
Membuat Master joran/rod lebih bersih dan lebih stabil dengan area Target Lock yang sempit dan memanjang, lalu mengurangi pengaruh background sebelum referensi visual disimpan atau dibandingkan.

## Perubahan utama
- Target lock joran diubah menjadi ROI vertikal sempit: 28% lebar x 92% tinggi frame.
- UI kamera Master joran menampilkan jalur target memanjang dan center-line.
- Tombol khusus `LOCK ROD` dan status `ROD FOCUS`.
- `RodFocusProcessor` mencari struktur vertikal terkuat di dalam ROI joran.
- Area di luar strip rod diganti dengan background netral sebelum menjadi Master.
- Frame video Master dan foto uji Master memakai preprocessing yang sama.
- `ProductVisualMatcher` menerapkan Rod Focus pada sisi scan untuk produk long-object, termasuk rotasi 0/90/180/270.
- Unknown safety gate tetap dipertahankan: visual kuat tidak otomatis menentukan SKU bila Master belum terverifikasi.

## Prinsip
V8.4.3 bukan semantic-segmentation AI. Ini adalah preprocessing deterministik offline yang membuat sistem lebih fokus kepada joran dan mengurangi tekstur lantai/dinding yang sebelumnya ikut mendominasi fingerprint.

## Pengujian yang disarankan
1. Rekam ulang satu Master joran memakai `LOCK ROD`.
2. Pastikan joran berada di garis tengah dan hampir memenuhi tinggi target.
3. Uji pengenalan Master sampai VERIFIED.
4. Scan satu joran saja dengan background berbeda.
5. Setelah itu uji joran + 2 produk kecil dalam satu foto.
