# ARS POS — Phase 4.3.2.6 Master Recognition Verification

## Tujuan
Phase ini menjadi quality gate sebelum produk dipakai oleh Smart Shopping Scan.
Master visual yang sudah direkam harus dapat diuji kembali menggunakan **satu foto**, bukan video.

## Alur
1. Produk memiliki minimal 3 frame master.
2. Tekan **UJI PENGENALAN MASTER**.
3. Kamera mengambil satu foto uji.
4. Sistem menjalankan OCR + barcode + visual matching terhadap referensi master produk tersebut.
5. Sistem menampilkan Visual, OCR, Final Score, barcode, jumlah referensi, dan alasan hasil.
6. Jika bukti cukup kuat, status disimpan sebagai **MASTER TERVERIFIKASI** secara offline.
7. Jika master direkam ulang, status verifikasi otomatis dibatalkan.

## Aturan penerimaan
- Minimal 3 frame referensi.
- Barcode cocok + visual >= 55%, atau
- OCR >= 72% + visual >= 55%, atau
- visual >= 82%.

Threshold ini sengaja tidak diturunkan hanya untuk membuat produk mudah dikenali; tujuan POS adalah meminimalkan false positive.

## Status
`master_verified_<productId>` disimpan pada tabel settings lokal.

## Batasan
Verifikasi ini adalah quality gate untuk master produk. Ini belum merupakan custom AI model yang dilatih dari dataset toko. Smart Shopping Scan multi-produk tetap akan menjadi fase berikutnya.
