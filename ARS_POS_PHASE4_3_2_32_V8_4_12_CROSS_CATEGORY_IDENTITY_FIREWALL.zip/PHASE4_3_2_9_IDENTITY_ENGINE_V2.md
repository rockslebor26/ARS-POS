# ARS POS Phase 4.3.2.9 — Product Identity Engine V2

- Barcode exact match has highest priority.
- OCR identity is evaluated using brand, name, variant, SKU and model/code tokens.
- OCR tolerates small recognition errors with fuzzy token matching.
- Model patterns such as DH-90 and numeric product codes are treated as high-value identity clues.
- Visual evidence is aggregated across distinct master capture angles.
- One long generic OCR phrase cannot by itself force a match.
- Candidate margin is retained to prevent ambiguous SKU selection.
- SKU, price, stock and checkout data always come from ProductEntity/database.
- Shopping scan remains a single still photo; master video only supplies reference frames.

Version: 1.1.9 / versionCode 119
