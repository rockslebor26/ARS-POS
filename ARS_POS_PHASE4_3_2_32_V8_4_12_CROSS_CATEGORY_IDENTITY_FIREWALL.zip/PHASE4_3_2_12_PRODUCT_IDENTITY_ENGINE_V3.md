# ARS POS — Phase 4.3.2.12

## Product Identity Engine V3

- Barcode is optional and never required to create a product.
- SKU ARS is the internal primary identity and is generated when left blank.
- A product can be saved when OCR/barcode returns no data; the cashier must provide the product name.
- Product identity profile is created immediately on product save and can later be enriched by Master Studio.
- Product photos remain local and can be used as visual master references.
- Existing application ID and Room database are preserved so releases remain update-compatible.
- This phase does not invent a product name from an unreadable image; it requires manual name entry when OCR is unavailable.
