# ARS POS — Phase 4.3.2.13 Product Identity Engine V4

## Tujuan
Memperkuat pengenalan produk tanpa barcode tanpa menurunkan standar anti-salah-jual.

## Perubahan
- Barcode tetap opsional.
- Profil identitas produk sekarang menyimpan aliases dari OCR, nama, merek, varian, dan model.
- Codec profil v2 membaca profil v1 sehingga update tidak menghapus identitas lama.
- OCR intake memakai empat orientasi in-memory.
- Foto intake pertama tetap disimpan sebagai master visual seed.
- UI intake menjelaskan bahwa barcode/teks bukan syarat penyimpanan.
- Mesin recognition memakai alias identity memory sebagai bukti tambahan, tetapi tetap konservatif terhadap kandidat ambigu.
- applicationId tetap `com.arspos.anglerriausyndicate`.
- versionCode naik ke 126 / versionName 1.2.6.

## Aturan update
APK baru harus dipasang di atas APK sebelumnya dengan applicationId dan signing key yang sama. Database tidak dihapus; migrasi tetap non-destructive.
