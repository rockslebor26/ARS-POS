# ARS POS — Phase 4.3.2.19 Product Identity Engine V8.2

V8.2 memperkuat pengenalan produk panjang/joran tanpa menurunkan unknown safety gate.

## Perubahan utama
- Dedicated long-object visual lane berbasis projection, aspect dan orientation signature.
- Multi-proposal rescue untuk full frame dan centered windows 90%, 78%, 64% ketika detector tidak menghasilkan identitas joran yang aman.
- Long-object matcher tetap membandingkan 0/90/180/270 derajat.
- Visual-only recognition tetap mensyaratkan master terverifikasi dan margin kandidat.
- Kelengkapan master tetap berbeda dari kekuatan identitas master.
- OCR/barcode tetap opsional untuk produk pancing tanpa barcode/nama.
- Shopping scan tetap satu foto, multi-produk, grouping SKU, review kasir, tanpa pembayaran otomatis.
- Label scanner diperbarui menjadi Phase 4.3.2.18 V8.2.

## Safety
V8.2 tidak mengubah prinsip bahwa objek yang bukti identitasnya lemah tetap UNKNOWN. Threshold long-object diturunkan secara terbatas hanya karena dedicated matcher memberikan bukti bentuk tambahan, dan margin kandidat tetap wajib.
