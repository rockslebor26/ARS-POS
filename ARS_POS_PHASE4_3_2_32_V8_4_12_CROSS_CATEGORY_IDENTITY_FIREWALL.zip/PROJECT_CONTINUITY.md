# ARS POS PROJECT CONTINUITY

Baseline pengembangan resmi berikutnya: **Phase 4.3.2.32 / V8.4.12 / 1.4.7 (147)**.

Update chain resmi:
- V8.4.6 Official: 1.4.1 (141)
- V8.4.7: 1.4.2 (142) — IN_PLACE_UPDATE terbukti berhasil
- V8.4.8: 1.4.3 (143) — multi-object physical-instance separation + scanner hardening
- V8.4.9: 1.4.4 (144) — rod anchor identity + cross-lane scene gate + cached long matcher
- V8.4.10: 1.4.5 (145) — anchor-preserving rod shortlist + deterministic identity evidence
- V8.4.11: 1.4.6 (146) — angle-aware physical tracks + LONG-vs-LONG cross-axis separation + live HANDLE/SIDE/TIP anchors
- V8.4.12: 1.4.7 (147) — cross-category identity firewall + bidirectional HANDLE/TIP role consensus + rolling memory telemetry

Aturan permanen:
- applicationId tetap `com.arspos.anglerriausyndicate`
- ARS POS OFFICIAL RELEASE signer harus tetap identik
- versionCode selalu meningkat
- jangan uninstall official app ketika menguji update berikutnya
- UNKNOWN lebih aman daripada salah SKU
- jangan menurunkan recognition threshold hanya agar produk terlihat dikenali
- NORMAL visual-only tidak boleh mengalahkan ownership geometri rod
- barcode exact / OCR kuat tetap boleh membuktikan produk NORMAL asli
- AMBIGUOUS_CONTAINER/bridge/CROSS_LANE/FULL_FRAME_RESCUE tidak boleh membuat quantity baru
- quantity LONG berasal dari resolved `TRACK-*`, bukan jumlah proposal
- same SKU + physical track berbeda boleh menjadi quantity > 1
- database tetap version 5 kecuali ada migration yang benar-benar diperlukan

Fokus validasi V8.4.12:
1. satu rod saja tidak boleh dikenali sebagai SKU NORMAL
2. dua rod sejajar tidak boleh menghasilkan `2 x` SKU NORMAL palsu
3. dua rod silang harus tetap menjadi dua LONG tracks dan intersection tidak boleh menjadi NORMAL sellable object
4. dua rod + satu produk NORMAL yang terpisah harus menghasilkan dua LONG tracks + satu NORMAL object
5. produk NORMAL yang dekat rod hanya boleh lolos visual-only jika region benar-benar terisolasi; barcode/OCR kuat tetap independen
6. satu rod -> exactly satu resolved LONG `TRACK-*`
7. repeated scan quantity LONG harus stabil
8. rod identity memakai oriented crop + bidirectional HANDLE/TIP role consensus + SIDE anchor
9. rod mirip dengan visual/anchor margin tidak cukup -> UNKNOWN; threshold tidak diturunkan
10. full-frame rescue tetap `quantityEligible=false`
11. cross-category block count/reason, rod-track hit dan conflict score tercatat
12. native baseline/growth/high-water, PSS high-water, crop recycle dan scanner latency tercatat
13. tidak ada force close / incomplete session
14. update 1.4.6 (146) -> 1.4.7 (147) harus IN_PLACE_UPDATE dengan package/signer sama

Lihat `PHASE4_3_2_32_V8_4_12_CROSS_CATEGORY_IDENTITY_FIREWALL.md`.
