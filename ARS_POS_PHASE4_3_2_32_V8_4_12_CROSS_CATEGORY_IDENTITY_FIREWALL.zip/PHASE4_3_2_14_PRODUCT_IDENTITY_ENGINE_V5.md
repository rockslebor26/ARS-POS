# ARS POS Phase 4.3.2.14 — Product Identity Engine V5

V5 focuses on real-world recognition quality for products without barcodes.

## Changes
- Canonical product name/brand/variant tokens are kept separate from historical OCR aliases.
- Strong canonical OCR matches are no longer diluted by accumulated OCR history.
- Visual matching adds center-weighted shape and gradient descriptors to reduce wood/table/background false positives.
- Object boxes use IoU de-duplication to reduce duplicate detections.
- Shopping scan remains one still camera photo and can contain multiple products.
- Barcode remains optional; exact barcode is still the strongest identity proof.
- Weak evidence remains rejected to prevent wrong sales.

This is still an offline deterministic recognition engine, not a newly trained neural network.
