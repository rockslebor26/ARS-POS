# ARS POS Phase 4.3.2.29 — V8.4.9

## Rod Anchor Identity + Cross-Lane Scene Gate + Cached Long Matcher

V8.4.9 melanjutkan fondasi V8.4.8 tanpa menurunkan threshold recognition. Fokus utama adalah mengurangi phantom LONG proposal, memisahkan kepemilikan area NORMAL/LONG, memperkuat identitas joran yang bentuk globalnya mirip, dan menurunkan latency long-object matching secara aman.

## Temuan yang ditangani

- Dua produk NORMAL dapat dideteksi benar oleh ML Kit, tetapi LongObjectAnalyzer masih dapat membuat proposal LONG tambahan dari area yang sama atau background.
- Dua joran fisik sudah mulai terpisah oleh physical-instance hint, tetapi background panjang seperti garis lantai/dinding masih dapat menjadi phantom instance.
- Joran berbeda dapat mempunyai silhouette global sangat mirip; identitas tidak boleh hanya bergantung pada bentuk keseluruhan.
- V8.4.8 long-object scoring menjadi bottleneck saat jumlah reference bertambah.
- Diagnostic log dapat dibersihkan, tetapi metadata update resmi harus tetap dapat dilaporkan dari update-channel state yang persisten.

## Safety invariants

1. Recognition threshold tidak diturunkan untuk memaksa produk terlihat dikenali.
2. NORMAL-owned region mendapat prioritas terhadap proposal LONG yang lemah/ambigu.
3. Proposal LONG yang terlihat seperti background/garis tipis tidak boleh menambah quantity.
4. AMBIGUOUS_CONTAINER / bridge tetap quantity-ineligible.
5. FULL_FRAME_RESCUE tetap evidence-only dan tidak boleh membuat physical quantity baru.
6. Dua physicalInstanceHint berbeda tetap dapat menjadi dua barang walaupun SKU sama.
7. Duplicate crop dari physical instance yang sama boleh digabung.
8. UNKNOWN tetap lebih aman daripada salah SKU.
9. Package dan official signer tidak boleh berubah pada update in-place.

## Cross-Lane Scene Gate

Pipeline V8.4.9 memberi kepemilikan awal pada proposal NORMAL yang kompak. Proposal LONG kemudian diperiksa terhadap NORMAL-owned regions:

- LONG yang mencakup beberapa NORMAL regions dapat ditandai sebagai ambiguous container;
- LONG analyzer yang terlalu banyak overlap dengan NORMAL-owned region dan tidak mempunyai struktur joran yang cukup akan disuppress;
- keputusan suppression dicatat pada telemetry sebagai cross-lane/background suppression, bukan dipaksa menjadi SKU.

Ini adalah gate deterministik berbasis proposal geometry/structure, bukan semantic segmentation AI.

## Rod Structure Gate

`LongObjectAnalyzer.rodStructureScore()` menilai ciri geometris/foreground sederhana pada candidate crop, termasuk kontinuitas jalur panjang, variasi massa, area anchor/handle, dan aspect ratio. Tujuannya menolak background linear seperti garis keramik/dinding sebelum candidate ikut recognition/quantity.

## Rod Anchor Identity

Untuk produk LONG, V8.4.9 menambahkan anchor score dari reference master yang sudah ada, dengan penekanan lebih besar pada bagian identitas seperti handle/reel-seat/side dibanding silhouette full-body saja. Long visual-only acceptance tetap membutuhkan master terverifikasi, visual/margin safety yang sudah ada, serta anchor score dan anchor margin minimum.

Report menyimpan deterministic `decisionRuleId`, margin, anchor score, dan anchor margin agar alasan ACCEPT/UNKNOWN dapat diaudit.

## Cached Long Matcher

V8.4.9 memindahkan long matching ke batch path yang meng-cache fingerprint reference dan mengekstrak scan descriptors sekali per orientasi. ProductionRepository memakai coarse per-product shortlist lalu fine matching hanya pada kandidat teratas. Tujuannya mengurangi repeated rotate/isolate/fingerprint work tanpa mengubah safety threshold.

## Memory telemetry

Flight Recorder mencatat:

- Java heap after/peak/max;
- native heap before/after/delta;
- total PSS;
- temporary crop count dan recycled crop count.

Telemetry dipakai untuk diagnosis. `System.gc()` tidak dijadikan solusi normal.

## Update channel

V8.4.9 adalah update resmi dari V8.4.8:

- Previous: 1.4.3 (143)
- Current: 1.4.4 (144)
- Package: `com.arspos.anglerriausyndicate`
- Signing channel: `ARS POS OFFICIAL RELEASE`
- Signer SHA-256 harus identik dengan official release sebelumnya.

Install APK V8.4.9 langsung di atas V8.4.8. **Jangan uninstall**.

Report sesudah update diharapkan menunjukkan `IN_PLACE_UPDATE`, database preserved, previous/current version benar, package sama, dan signer SHA-256 sama.

## Test matrix setelah build

1. 1 LIGHTS — hanya NORMAL lane yang relevan.
2. 2 LIGHTS — dua physical NORMAL instances; tidak ada phantom LONG quantity.
3. 1 joran — Qty 1 dan tidak ada duplicate long quantity.
4. 2 joran sama — dua physical instances jika benar-benar terpisah.
5. 2 joran berbeda — masing-masing dipisahkan; jika identitas masih ambigu, tetap UNKNOWN.
6. joran + LIGHTS — NORMAL dan LONG tidak saling mengambil area.
7. background tanpa produk — linear background harus ditolak.
8. joran horizontal/diagonal/portrait — verifikasi coordinate normalization dan anchor behavior.
9. ulang scan beberapa kali — pantau native heap delta/PSS dan latency.
