# ARS POS Phase 4.3.2.21 — V8.4.1 FIX1 Fullscreen Target Camera

Version: 1.3.5 (versionCode 135)

## Fokus
V8.4 memperbaiki pengalaman pengambilan foto uji dan video master dengan kamera fullscreen.

### Fitur kamera master
- Preview kamera memakai hampir seluruh layar.
- Target frame di tengah layar.
- LOCK TARGET sebelum capture/record.
- Status TARGET TERKUNCI.
- Mode objek panjang untuk joran/rod.
- Flash/torch toggle.
- Flip kamera depan/belakang.
- Foto uji master menggunakan CameraX ImageCapture.
- Video master menggunakan CameraX VideoCapture.
- Video dibatasi otomatis sampai 4 detik dan dapat dihentikan manual.
- Setelah capture, pipeline lama tetap dipakai: pilih frame terbaik, OCR/barcode, identity memory, dan penyimpanan master.

## Catatan penting
LOCK TARGET pada V8.4 adalah framing/interaction lock: kasir mengunci objek yang sedang dibingkai sebelum capture. Ini mencegah capture dilakukan sebelum target ditempatkan dengan benar.

Object tracking/segmentation otomatis penuh tetap menjadi tahap lanjutan; V8.4 tidak mengklaim bahwa kotak target sudah merupakan segmentasi AI sempurna.

## Tidak berubah
- POS offline.
- Database produk/master.
- OCR/barcode.
- Smart Shopping Scan satu foto banyak objek.
- Keranjang dan pembayaran manual.
- Safety gate UNKNOWN.
- Branding ARS POS.


V8.4.1 FIX1 BUILD FIX: DialogProperties berasal dari androidx.compose.ui.window, bukan androidx.compose.material3. Import diperbaiki agar compileReleaseKotlin tidak gagal.
