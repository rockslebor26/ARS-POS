# ARS POS Phase 4.3.2.31 — V8.4.11
## Angle-Aware Physical Track + Live Rod Anchor Identity

Release identity:
- applicationId: `com.arspos.anglerriausyndicate`
- versionName: `1.4.6`
- versionCode: `146`
- database version: `5` (unchanged)
- official signing channel: unchanged; install in-place over 1.4.5 (145), do not uninstall.

## Why this phase exists
V8.4.10 proved update safety, crash stability, typed NORMAL/LONG lanes, anti-bridge safety and memory telemetry. Field tests with two rods showed the remaining error was geometric rather than threshold-related:
- two physical rods could become 3–4 LONG instances;
- two rods could also collapse into one instance;
- vertical/horizontal scene bands could absorb tile grout/background;
- crossing rods were not represented as independent arbitrary-angle axes;
- full LONG crop was compared to HANDLE/SIDE/TIP master references, reducing identity margin.

V8.4.11 fixes those causes without lowering recognition thresholds.

## V8.4.11 invariants
1. NORMAL and LONG lanes remain typed and never merge into one lane.
2. Long-object identity is based on a canonical geometric axis, not only a bounding rectangle.
3. Physical quantity is based on resolved `TRACK-*` identities, not proposal count.
4. Crossing axes remain distinct even when rectangles intersect.
5. ML boxes support an existing physical axis; once angle-aware tracks exist they do not independently create extra LONG quantity.
6. A long proposal spanning multiple tracks is evidence-only (`CROSS_LANE_SUPPRESSED`).
7. Unsupported analyzer axes in an ML-supported multi-object scene are background evidence only.
8. Rod-structure background rejection V2 uses the actual axis path and penalizes broad/uniform scene bands.
9. LONG recognition uses an oriented narrow crop along the physical axis.
10. Live HANDLE/SIDE/TIP crops are compared only with the corresponding master anchor type.
11. Existing recognition acceptance thresholds are not lowered.
12. Full-frame rescue remains evidence-only and cannot create cashier quantity.
13. Database schema remains version 5.
14. Package and signer must remain unchanged for in-place update safety.

## New / revised components
- `LongObjectAnalyzer.kt`: multi-angle contrast-path proposal engine + axis-aware rod-structure V2.
- `RodPhysicalTrackResolver.kt`: global deterministic `TRACK-*` resolution and LONG-vs-LONG cross-axis separation.
- `RodAnchorExtractor.kt`: live HANDLE/SIDE/TIP extraction from oriented rod crops.
- `ScanProposal.kt`: canonical axis metadata (angle, endpoints, width, confidence).
- `SmartVisualScanner.kt`: oriented LONG crop and global track resolver integration.
- `ProductVisualMatcher.kt`: anchor-to-anchor scoring path.
- `ProductionRepository.kt`: track telemetry, oriented scoring and anchor-aware matcher.
- `SmartRecognitionEngine.kt`: stronger anchor weighting while keeping all acceptance thresholds unchanged.
- `ArsFlightRecorder.kt`: V8.4.11 track/axis telemetry.

## Required acceptance tests
- One rod: exactly one LONG `TRACK-*`.
- Two parallel rods: exactly two LONG tracks.
- Two crossing rods: exactly two LONG tracks; crossing pair preserved.
- Two rods + compact NORMAL product: two LONG tracks plus one NORMAL object.
- Tile grout/background without rod: no sellable LONG quantity.
- Five repeated scans of one rod: stable quantity 1.
- Similar rods remain UNKNOWN when identity margin is insufficient; never lower thresholds to force recognition.
- No force close, no incomplete sessions, all temporary crops recycled.
- Official update must report 1.4.5 (145) -> 1.4.6 (146), IN_PLACE_UPDATE, same package and same signer SHA-256.
