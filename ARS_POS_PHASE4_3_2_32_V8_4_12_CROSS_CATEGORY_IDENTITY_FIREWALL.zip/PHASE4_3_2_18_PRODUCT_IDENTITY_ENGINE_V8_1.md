# ARS POS — Phase 4.3.2.18 Product Identity Engine V8.1

V8.1 memperkuat jalur visual tanpa mengorbankan unknown safety gate.

## Perubahan
- Multi-scale center windows: 90%, 82%, 68%.
- Edge projection descriptor untuk membantu membedakan bentuk produk.
- Long-object matching 0/90/180/270 derajat.
- Auto-detect kategori produk panjang seperti JORAN/ROD/PANCING FIBER untuk jalur visual.
- Full-frame long-object lane sebagai rescue ketika detector memotong joran terlalu ketat.
- Master Identity Strength 0–100% di Product Master Studio.
- Master verification long-object dapat menerima bukti visual mulai 72% setelah minimal 5 referensi.
- Shopping scan tetap menggunakan satu foto dan tidak melakukan pembayaran otomatis.
- Produk UNKNOWN tetap tidak dimasukkan ke keranjang.

## Prinsip
Kelengkapan master bukan confidence AI. Verifikasi pemilik tetap menjadi gate untuk visual-only recognition.
