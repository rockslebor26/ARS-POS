# ARS POS Phase 4.3.2.27 — V8.4.7

## Physical Instance Tracking + Long Object Coordinate Normalization

Version: **1.4.2**  
versionCode: **142**  
Package: **com.arspos.anglerriausyndicate**  
Signing: **ARS POS OFFICIAL RELEASE** (same official key as V8.4.6)

### Tujuan
Mencegah satu joran fisik dihitung sebagai beberapa produk hanya karena scanner menghasilkan beberapa crop/band untuk objek yang sama.

### Perubahan utama
- Proposal scanner sekarang memiliki `proposalId`, `source`, `proposalType`, `rotation`, `lineageId`, `originalBounds`, `normalizedBounds`, dan `quantityEligible`.
- Semua proposal memakai canonical original-image coordinate space sebelum aggregation.
- NORMAL lane hanya menilai master produk normal.
- LONG lane hanya menilai master produk `isLongObject`/joran.
- Full-frame long rescue adalah **evidence only** dan tidak boleh menambah quantity.
- Detection rescue sekarang menghormati `identity_profile.isLongObject`, bukan hanya heuristik nama produk.
- Long-object quantity safety: beberapa proposal untuk SKU joran yang sama digabung kecuali dua instance paralel benar-benar dapat dibuktikan terpisah.
- Flight Recorder menulis lineage, source/type proposal, normalized bounds, lineage merges, dan quantity suppressed.
- Threshold recognition tidak diturunkan.

### Update in-place
V8.4.7 harus dipasang langsung di atas V8.4.6 Official tanpa uninstall. Report yang benar diharapkan menunjukkan:
- `Last Install Transition: IN_PLACE_UPDATE`
- Previous: `1.4.1 (141)`
- Current: `1.4.2 (142)`
- package sama
- signer SHA-256 sama
