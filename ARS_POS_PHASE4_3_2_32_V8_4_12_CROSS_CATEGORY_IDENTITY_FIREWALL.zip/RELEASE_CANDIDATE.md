# ARS POS 1.0.0 — Release Candidate

Brand: ANGLER RIAU SYNDICATE
Application ID: com.arspos.anglerriausyndicate
Version: 1.0.0 (versionCode 100)

## Hardened in this candidate
- Offline Room/SQLite data layer.
- Historical cost/sell values are stored in sale items.
- Transactional checkout and stock decrement.
- Stock-in transaction and movement history.
- Transactional return flow with stock restoration and cash refund for CASH sales.
- Net revenue subtracts recorded returns.
- Gross profit uses historical cost and subtracts returns.
- SHA-256 PIN storage with transparent upgrade from the old demo plaintext PIN.
- Bluetooth Classic SPP ESC/POS printing.
- Selected printer address persistence.
- Automatic print after successful checkout when a printer is configured.
- Reprint from recent transactions.
- Product creation and stock-in UI.
- ARS master logo bundled into Android resources.
- Cleartext HTTP disabled.
- Destructive Room migration removed; schema remains compatible with Phase 6 because no Room columns were changed in this candidate.

## Demo account
username: admin
PIN: 0000

Change the demo PIN before store deployment.

## Important build note
The build environment used to prepare this package does not contain Gradle/Android build tooling and has no outbound DNS/network access, so a signed APK cannot honestly be marked as built or tested here. This package is therefore a RELEASE CANDIDATE source package, not a falsely claimed final APK.

Before production deployment, run a clean Android Release build and test on the actual thermal printer and Android device.


## Phase 4.3.2.6
Master Recognition Verification: one-photo verification against the product master, with offline verified status.
