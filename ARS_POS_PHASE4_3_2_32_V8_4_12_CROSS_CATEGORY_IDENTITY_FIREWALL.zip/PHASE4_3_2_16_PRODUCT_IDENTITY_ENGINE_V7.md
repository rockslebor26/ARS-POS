# ARS POS — Phase 4.3.2.16 Product Identity Engine V7

V7 strengthens the offline identity engine without weakening the UNKNOWN safety gate.

## Main improvements

- Master-to-scan visual comparison now evaluates three windows: full object, center 82%, and center 68%.
- Center-window agreement adds a small stability bonus, reducing background/table influence when the shopping-scan crop and master frame contain different amounts of background.
- Visual descriptors remain deterministic and offline: grayscale structure, color histogram, difference hash, shape descriptor, and gradient descriptor.
- OCR/barcode remain identity evidence; visual evidence remains supporting evidence.
- Visual-only recognition still requires an explicitly verified master and a strong dominant visual match.
- Unknown objects remain UNKNOWN and are never offered as a sellable candidate.
- Existing master frames remain usable; no mandatory re-enrollment is required for this V7 matcher improvement.

## Target

Version `1.2.9` / `versionCode 129`.

The next stage after V7 is Smart Shopping Scan quantity grouping: one still photo containing multiple products -> identify SKU -> group identical SKU -> build a reviewable cart -> cashier confirms before payment.
