# ARS POS — ANGLER RIAU SYNDICATE

Current development release candidate:

- Phase **4.3.2.32**
- Engine **V8.4.12 — Cross-Category Identity Firewall + Bidirectional Rod Anchor Role Consensus**
- Version **1.4.7**
- versionCode **147**
- Database **5 (unchanged)**
- Package **com.arspos.anglerriausyndicate**
- Signing channel **ARS POS OFFICIAL RELEASE**

## V8.4.12 focus
Field diagnostics from V8.4.11 proved the next highest-risk defect is not a force close and not a low recognition threshold. The dangerous failure is a LONG rod scene producing a sellable NORMAL visual-only SKU such as a compact package. V8.4.12 therefore adds:

- cross-category NORMAL/LONG identity firewall after angle-aware rod tracks are resolved;
- NORMAL visual-only rejection when its region intersects/is owned by strong rod tracks;
- barcode and sufficiently strong OCR remain independent identity evidence for a genuine NORMAL product near rods;
- bidirectional HANDLE/TIP endpoint-role consensus instead of trusting endpoint orientation alone;
- same-type HANDLE/SIDE/TIP master matching with cached scan fingerprint reuse;
- preserved LONG-vs-LONG crossing-track separation and deterministic TRACK quantity;
- full-frame rescue remains evidence-only and quantity-ineligible;
- rolling native-heap/PSS baseline and high-water telemetry;
- per-object OCR/decision/total latency telemetry;
- all conservative recognition thresholds remain unchanged.

Install V8.4.12 directly over V8.4.11 Official. Do **not** uninstall the official app. The package and official signer must remain identical.

See `PHASE4_3_2_32_V8_4_12_CROSS_CATEGORY_IDENTITY_FIREWALL.md`.
