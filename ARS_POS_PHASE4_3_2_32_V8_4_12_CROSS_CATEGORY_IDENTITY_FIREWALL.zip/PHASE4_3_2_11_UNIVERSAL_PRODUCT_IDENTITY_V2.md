# ARS POS — Phase 4.3.2.11
## Universal Product Identity V2

Phase 4.3.2.11 memperbaiki hubungan antara foto scan, OCR, identitas produk, dan seluruh frame master.

### Perubahan utama
- Barcode tetap menjadi sinyal identitas terkuat jika tersedia.
- Barcode tidak wajib untuk mengenali produk.
- Nama produk, brand, variant/model, SKU, dan identity profile master dipakai sebagai sinyal terpisah.
- Token produk yang sebelumnya dianggap kata umum seperti LIGHTS/AMERICAN/BLEND tidak lagi dibuang secara global.
- Kecocokan nama produk dihitung sebagai kumpulan token identitas, bukan kecocokan satu kata.
- Seluruh referensi master dipakai untuk mencari bukti visual terbaik.
- Margin antar kandidat tetap digunakan untuk menolak hasil ambigu.
- Master verification lebih toleran terhadap perubahan sudut/pencahayaan ketika identitas OCR/master kuat.
- Tidak membuat SKU atau harga dari OCR saat shopping scan; SKU, harga, dan stok selalu berasal dari ProductEntity.
- Tetap offline.
- Tidak menghapus database, master frame, transaksi, atau data POS saat APK diperbarui.

### Contoh tanpa barcode
Foto produk dapat dikenali jika OCR membaca kombinasi identitas seperti brand + nama/model meskipun barcode kosong. Visual tetap digunakan sebagai bukti pendukung.

### Kompatibilitas update
Application ID tetap `com.arspos.anglerriausyndicate`. Version code dinaikkan ke `121` dan version name menjadi `1.2.1`. APK release pengujian tetap menggunakan signing key debug yang sama dengan versi pengembangan sebelumnya, sehingga APK dapat dipasang sebagai update selama perangkat memiliki APK dari jalur signing yang sama.
