# ARS POS — One-time Official Release Signing Setup

The project intentionally does **not** contain the private release keystore.
Keep that key outside the repository and back it up securely.

The GitHub Actions release workflow requires these repository secrets:

- `ARS_RELEASE_KEYSTORE_BASE64`
- `ARS_RELEASE_STORE_PASSWORD`
- `ARS_RELEASE_KEY_ALIAS`
- `ARS_RELEASE_KEY_PASSWORD`

Optional continuity guard after the first official build:

- `ARS_RELEASE_CERT_SHA256`

`ARS_RELEASE_CERT_SHA256` is the certificate fingerprint printed by the workflow. If configured, every future build compares the APK signer against it and fails if the signer changes.

## Generate the keystore once

On a trusted computer with Java installed:

```bash
keytool -genkeypair \
  -v \
  -keystore ars-pos-official-release.jks \
  -alias ars_pos_release \
  -keyalg RSA \
  -keysize 4096 \
  -validity 10000 \
  -dname "CN=ARS POS, OU=ANGLER RIAU SYNDICATE, O=ANGLER RIAU SYNDICATE, C=ID"
```

Choose and securely save the store/key passwords.

Convert the keystore to a single-line Base64 value before putting it in GitHub Secrets. On Linux/macOS:

```bash
base64 < ars-pos-official-release.jks | tr -d '\n'
```

Never commit the `.jks`, passwords, or Base64 keystore to the repository.

## Permanent rule

Losing or changing the official private signing key can prevent future APKs from updating existing official ARS POS installations. Back up the keystore in at least two secure offline locations.
