# ARS POS Phase 4.3.2.8 — Recognition Engine V3

Perbaikan fokus pada kualitas keputusan identitas produk, bukan sekadar menurunkan threshold.

- Barcode exact match menjadi bukti identitas terkuat.
- OCR dinormalisasi dan dinilai memakai identity tokens yang lebih khas.
- Visual menggunakan agregasi beberapa master frame; satu frame yang kebetulan mirip tidak boleh mendominasi.
- Final score adalah identity-confidence, bukan raw OCR score.
- Top candidate harus unggul dari kandidat kedua dengan margin minimum.
- Produk yang bukti identitasnya lemah tetap ditolak untuk mencegah salah SKU/harga.
- SKU, harga, stok, dan transaksi tetap berasal dari database ARS POS.
- Shopping scan tetap menggunakan satu foto; master video hanya menjadi sumber frame referensi.

Version: 1.1.8 / versionCode 118
