# ARS POS Phase 4.3.2.25 — V8.4.5
## Long Object Aggregation + Recognition Pipeline Stabilization

Version: **1.4.0**  
versionCode: **140**

V8.4.5 continues from V8.4.4 Crash Shield + Flight Recorder. The goal is to make Smart Shopping Scan safer, faster, and less likely to count multiple proposals from one physical product as separate shopping items.

### Main changes

1. **Physical-object aggregation**
   - New `ScanResultAggregator` merges overlapping/contained proposals.
   - Long-object proposals may also be merged when they agree on the same product and their long axes overlap.
   - Aggregation never promotes UNKNOWN into a recognized SKU; the strict recognition safety gate remains authoritative.

2. **Pre-scoring proposal merge**
   - ML Kit and `LongObjectAnalyzer` proposals are merged before OCR/reference scoring.
   - Maximum expensive proposals is reduced to 6 per scan session.

3. **Reference scoring stabilization**
   - Maximum recognition references per product reduced to 6, while preserving primary and capture-angle diversity.
   - Normal-product reference scoring uses `ProductVisualMatcher.scoreBatch()` so the scan fingerprint is calculated once per crop instead of once per reference image.
   - Rod/long-object scoring keeps the dedicated Rod Focus pipeline.

4. **Flight Recorder V8.4.5**
   - Adds `SCAN_PROPOSAL_MERGE`, `SCAN_SCORING`, and `SCAN_AGGREGATION` events.
   - Diagnostic report includes average completed scan duration, average object scoring duration, latest proposal merge, and latest physical-object aggregation.

5. **Crash safety remains active**
   - Scan bitmap downscaling, reference downsampling, bitmap recycling, `OutOfMemoryError` shield, and exception logging remain from V8.4.4.

### Safety policy

- Barcode exact match remains strongest.
- OCR/identity evidence is combined with verified master evidence.
- High visual similarity alone does not bypass master verification/margin gates.
- Duplicate aggregation cannot manufacture a recognized match.
- Weak or ambiguous products remain `UNKNOWN`.

### Expected test

1. Scan one rod only and confirm duplicate rod proposals collapse to one physical result.
2. Scan rod + one small packaged product and confirm both remain separate.
3. Scan two identical physical products side by side and confirm they are not merged unless their boxes truly overlap.
4. Open ARS DEV CENTER and compare `SCAN_PROPOSAL_MERGE`, `SCAN_AGGREGATION`, and scan duration.
