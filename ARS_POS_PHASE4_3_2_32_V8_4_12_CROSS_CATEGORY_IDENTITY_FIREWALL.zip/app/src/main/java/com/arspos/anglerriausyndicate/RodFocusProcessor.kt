package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.23 V8.4.3 — Rod Focus processor.
 *
 * Product Master already crops to the locked target ROI. This processor performs
 * a second, rod-specific isolation pass inside that ROI. It searches for the
 * strongest long vertical structure near the center, keeps a conservative strip
 * around it, and replaces the remaining background with a neutral tone.
 *
 * The goal is not semantic segmentation. It is deterministic preprocessing that
 * prevents floor/wall texture from dominating the visual master for rods.
 */
object RodFocusProcessor {
    private const val GRID_W = 96
    private const val GRID_H = 160
    private const val SEARCH_LEFT = 0.18f
    private const val SEARCH_RIGHT = 0.82f
    private const val MIN_KEEP_RATIO = 0.34f
    private const val MAX_KEEP_RATIO = 0.58f
    private const val PADDING_RATIO = 0.10f

    data class Result(
        val bitmap: Bitmap,
        val focusStrength: Int,
        val centerXRatio: Float,
        val keptWidthRatio: Float
    )

    fun isolate(source: Bitmap): Result {
        if (source.width < 40 || source.height < 80) {
            return Result(source.copy(Bitmap.Config.ARGB_8888, false), 0, 0.5f, 1f)
        }

        val small = Bitmap.createScaledBitmap(source, GRID_W, GRID_H, true)
        try {
            val gray = FloatArray(GRID_W * GRID_H)
            for (y in 0 until GRID_H) {
                for (x in 0 until GRID_W) {
                    gray[y * GRID_W + x] = luminance(small.getPixel(x, y))
                }
            }

            val scores = FloatArray(GRID_W)
            val startX = (GRID_W * SEARCH_LEFT).toInt().coerceIn(4, GRID_W - 5)
            val endX = (GRID_W * SEARCH_RIGHT).toInt().coerceIn(startX + 1, GRID_W - 4)

            for (x in startX until endX) {
                var contrast = 0f
                var continuity = 0
                var edgeEnergy = 0f
                var samples = 0

                for (y in 3 until GRID_H - 3) {
                    val center = gray[y * GRID_W + x]
                    val left = gray[y * GRID_W + (x - 3).coerceAtLeast(0)]
                    val right = gray[y * GRID_W + (x + 3).coerceAtMost(GRID_W - 1)]
                    val side = (left + right) * 0.5f
                    val localContrast = abs(center - side)
                    contrast += localContrast
                    if (localContrast >= 0.040f) continuity++

                    val dx = abs(
                        gray[y * GRID_W + (x + 1).coerceAtMost(GRID_W - 1)] -
                            gray[y * GRID_W + (x - 1).coerceAtLeast(0)]
                    )
                    edgeEnergy += dx
                    samples++
                }

                val n = samples.coerceAtLeast(1)
                val continuityRatio = continuity.toFloat() / n.toFloat()
                val contrastMean = contrast / n.toFloat()
                val edgeMean = edgeEnergy / n.toFloat()
                val centerBias = 1f - (abs(x - GRID_W / 2f) / (GRID_W / 2f)).coerceIn(0f, 1f)

                scores[x] =
                    continuityRatio * 0.46f +
                    contrastMean * 2.4f * 0.28f +
                    edgeMean * 2.2f * 0.18f +
                    centerBias * 0.08f
            }

            val bestX = (startX until endX).maxByOrNull { scores[it] } ?: GRID_W / 2
            val best = scores[bestX].coerceAtLeast(0f)
            val threshold = best * 0.46f

            var leftX = bestX
            var rightX = bestX
            while (leftX > startX && scores[leftX - 1] >= threshold) leftX--
            while (rightX < endX - 1 && scores[rightX + 1] >= threshold) rightX++

            val rawWidthRatio = ((rightX - leftX + 1).toFloat() / GRID_W.toFloat()) + PADDING_RATIO
            val keepRatio = rawWidthRatio.coerceIn(MIN_KEEP_RATIO, MAX_KEEP_RATIO)
            val centerRatio = (bestX.toFloat() / GRID_W.toFloat()).coerceIn(0.22f, 0.78f)

            val keepWidth = (source.width * keepRatio).toInt().coerceIn(24, source.width)
            val centerPx = (source.width * centerRatio).toInt().coerceIn(0, source.width - 1)
            val leftPx = (centerPx - keepWidth / 2).coerceIn(0, source.width - keepWidth)
            val rightPx = leftPx + keepWidth

            val out = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
            val neutral = neutralBackground(source)
            val row = IntArray(source.width)

            for (y in 0 until source.height) {
                source.getPixels(row, 0, source.width, 0, y, source.width, 1)
                for (x in 0 until source.width) {
                    if (x < leftPx || x >= rightPx) row[x] = neutral
                }
                out.setPixels(row, 0, source.width, 0, y, source.width, 1)
            }

            val strength = (best * 150f).toInt().coerceIn(0, 100)
            return Result(out, strength, centerRatio, keepRatio)
        } finally {
            if (small !== source) small.recycle()
        }
    }

    private fun neutralBackground(source: Bitmap): Int {
        val sampleRows = intArrayOf(
            (source.height * 0.18f).toInt(),
            (source.height * 0.50f).toInt(),
            (source.height * 0.82f).toInt()
        )
        val sampleCols = intArrayOf(
            (source.width * 0.06f).toInt(),
            (source.width * 0.94f).toInt()
        )

        var sr = 0L
        var sg = 0L
        var sb = 0L
        var count = 0
        for (y in sampleRows) {
            for (x in sampleCols) {
                val px = source.getPixel(
                    x.coerceIn(0, source.width - 1),
                    y.coerceIn(0, source.height - 1)
                )
                sr += Color.red(px)
                sg += Color.green(px)
                sb += Color.blue(px)
                count++
            }
        }
        if (count == 0) return Color.rgb(128, 128, 128)
        val r = (sr / count).toInt().coerceIn(0, 255)
        val g = (sg / count).toInt().coerceIn(0, 255)
        val b = (sb / count).toInt().coerceIn(0, 255)
        val gray = ((r + g + b) / 3).coerceIn(72, 196)
        return Color.rgb(gray, gray, gray)
    }

    private fun luminance(color: Int): Float =
        (0.299f * Color.red(color) + 0.587f * Color.green(color) + 0.114f * Color.blue(color)) / 255f
}
