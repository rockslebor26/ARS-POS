package com.arspos.anglerriausyndicate.data

data class MasterVerificationResult(
    val productId: Long,
    val productName: String,
    val sku: String,
    val barcode: String,
    val referenceCount: Int,
    val visualScore: Int,
    val textScore: Int,
    val finalScore: Int,
    val ocrText: String,
    val detectedBarcode: String,
    val accepted: Boolean,
    val reason: String
)
