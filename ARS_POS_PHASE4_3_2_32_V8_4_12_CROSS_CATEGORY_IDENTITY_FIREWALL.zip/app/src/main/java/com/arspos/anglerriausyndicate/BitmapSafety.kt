package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import kotlin.math.max

/** Memory guard for scanner/native image pipelines. */
object BitmapSafety {
    const val SCAN_MAX_DIMENSION = 1024
    const val MATCH_MAX_DIMENSION = 720

    fun scaledForScan(source: Bitmap, maxDimension: Int = SCAN_MAX_DIMENSION): Bitmap {
        val longest = max(source.width, source.height)
        if (longest <= maxDimension) return source.copy(Bitmap.Config.ARGB_8888, false)
        val scale = maxDimension.toFloat() / longest.toFloat()
        val w = (source.width * scale).toInt().coerceAtLeast(1)
        val h = (source.height * scale).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, w, h, true)
    }
}
