package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min

/**
 * V8.4.12 canonical coordinate conversion.
 *
 * Rectangles and LONG physical axes are normalized exactly once into the
 * original customer-photo coordinate system. Every downstream stage (track
 * resolution, cross-lane gate, aggregation and anchor extraction) therefore
 * uses the same space.
 */
object ScanCoordinateNormalizer {
    data class Point(val x: Int, val y: Int)
    data class Axis(
        val start: Point,
        val end: Point,
        val angleDeg: Float
    )

    fun normalize(
        rect: Rect,
        rotationDegrees: Int,
        originalWidth: Int,
        originalHeight: Int
    ): Rect {
        val rotation = canonicalRotation(rotationDegrees)
        val mapped = when (rotation) {
            90 -> Rect(
                rect.top,
                originalHeight - rect.right,
                rect.bottom,
                originalHeight - rect.left
            )
            180 -> Rect(
                originalWidth - rect.right,
                originalHeight - rect.bottom,
                originalWidth - rect.left,
                originalHeight - rect.top
            )
            270 -> Rect(
                originalWidth - rect.bottom,
                rect.left,
                originalWidth - rect.top,
                rect.right
            )
            else -> Rect(rect)
        }
        return clamp(mapped, originalWidth, originalHeight)
    }

    fun normalizeAxis(
        startX: Int,
        startY: Int,
        endX: Int,
        endY: Int,
        rotationDegrees: Int,
        originalWidth: Int,
        originalHeight: Int
    ): Axis {
        val start = normalizePoint(startX, startY, rotationDegrees, originalWidth, originalHeight)
        val end = normalizePoint(endX, endY, rotationDegrees, originalWidth, originalHeight)
        val angle = normalizedAngle(
            Math.toDegrees(
                atan2(
                    (end.y - start.y).toDouble(),
                    (end.x - start.x).toDouble()
                )
            ).toFloat()
        )
        return Axis(start, end, angle)
    }

    fun normalizePoint(
        x: Int,
        y: Int,
        rotationDegrees: Int,
        originalWidth: Int,
        originalHeight: Int
    ): Point {
        val rotation = canonicalRotation(rotationDegrees)
        val mapped = when (rotation) {
            90 -> Point(y, originalHeight - x)
            180 -> Point(originalWidth - x, originalHeight - y)
            270 -> Point(originalWidth - y, x)
            else -> Point(x, y)
        }
        return Point(
            mapped.x.coerceIn(0, originalWidth.coerceAtLeast(1) - 1),
            mapped.y.coerceIn(0, originalHeight.coerceAtLeast(1) - 1)
        )
    }

    fun clamp(rect: Rect, width: Int, height: Int): Rect {
        val left = min(max(0, rect.left), width)
        val top = min(max(0, rect.top), height)
        val right = min(max(left, rect.right), width)
        val bottom = min(max(top, rect.bottom), height)
        return Rect(left, top, right, bottom)
    }

    private fun canonicalRotation(rotationDegrees: Int): Int =
        ((rotationDegrees % 360) + 360) % 360

    private fun normalizedAngle(angle: Float): Float {
        var a = angle
        while (a > 90f) a -= 180f
        while (a <= -90f) a += 180f
        return a
    }
}
