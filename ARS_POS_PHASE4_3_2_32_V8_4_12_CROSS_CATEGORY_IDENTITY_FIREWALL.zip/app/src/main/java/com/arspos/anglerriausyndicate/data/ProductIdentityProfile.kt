package com.arspos.anglerriausyndicate.data

/** Persistent product identity profile for ARS hybrid recognition. */
data class ProductIdentityProfile(
    val productId: Long,
    val rawText: String = "",
    val brand: String = "",
    val name: String = "",
    val variant: String = "",
    val modelCode: String = "",
    val barcode: String = "",
    val aliases: List<String> = emptyList(),
    val recognitionMode: String = "HYBRID",
    val isLongObject: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)
