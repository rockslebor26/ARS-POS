package com.arspos.anglerriausyndicate.data

import android.util.Base64

/** V3 codec; V1/V2 profiles remain readable on existing installations. */
object ProductIdentityProfileCodec {
    private const val VERSION_1 = "1"
    private const val VERSION_2 = "2"
    private const val VERSION_3 = "3"

    fun encode(p: ProductIdentityProfile): String {
        val aliasText = p.aliases.map { it.trim() }.filter { it.isNotBlank() }
            .distinct().take(80).joinToString("\n")
        return listOf(
            VERSION_3, p.rawText, p.brand, p.name, p.variant, p.modelCode, p.barcode,
            aliasText, p.recognitionMode, p.isLongObject.toString()
        ).joinToString("\n") { Base64.encodeToString(it.toByteArray(Charsets.UTF_8), Base64.NO_WRAP) }
    }

    fun decode(productId: Long, value: String?): ProductIdentityProfile? {
        if (value.isNullOrBlank()) return null
        val parts = value.split('\n').mapNotNull {
            runCatching { String(Base64.decode(it, Base64.DEFAULT), Charsets.UTF_8) }.getOrNull()
        }
        if (parts.isEmpty()) return null
        return when (parts[0]) {
            VERSION_3 -> if (parts.size >= 10) ProductIdentityProfile(
                productId = productId, rawText = parts[1], brand = parts[2], name = parts[3],
                variant = parts[4], modelCode = parts[5], barcode = parts[6],
                aliases = parts[7].lines().map { it.trim() }.filter { it.isNotBlank() }.distinct().take(80),
                recognitionMode = parts[8].ifBlank { "HYBRID" },
                isLongObject = parts[9].equals("true", true)
            ) else null
            VERSION_2 -> if (parts.size >= 8) ProductIdentityProfile(
                productId = productId, rawText = parts[1], brand = parts[2], name = parts[3],
                variant = parts[4], modelCode = parts[5], barcode = parts[6],
                aliases = parts[7].lines().map { it.trim() }.filter { it.isNotBlank() }.distinct().take(80)
            ) else null
            VERSION_1 -> if (parts.size >= 7) ProductIdentityProfile(
                productId = productId, rawText = parts[1], brand = parts[2], name = parts[3],
                variant = parts[4], modelCode = parts[5], barcode = parts[6]
            ) else null
            else -> null
        }
    }
}
