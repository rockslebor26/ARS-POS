package com.arspos.anglerriausyndicate

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import com.arspos.anglerriausyndicate.data.MasterVerificationResult
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executor
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val StudioGold = Color(0xFFE1BC68)
private val StudioPanel = Color(0xFF151515)
private val StudioBlack = Color(0xFF080808)
private val StudioMuted = Color(0xFF9A9A9A)

private data class MasterAngle(val key: String, val label: String)

private val MASTER_ANGLES = listOf(
    MasterAngle("FRONT", "Depan"),
    MasterAngle("RIGHT", "Kanan"),
    MasterAngle("BACK", "Belakang"),
    MasterAngle("LEFT", "Kiri"),
    MasterAngle("TOP", "Atas"),
    MasterAngle("BOTTOM", "Bawah")
)

private fun isLikelyLongStudioProduct(product: com.arspos.anglerriausyndicate.data.db.ProductEntity): Boolean {
    val hay = "${product.name} ${product.category} ${product.brand.orEmpty()} ${product.variant.orEmpty()}".uppercase()
    return listOf("JORAN", "ROD", "PANCING FIBER", "TELESCOPIC", "TELESCOP", "STICK ROD").any { hay.contains(it) }
}

private val LONG_MASTER_ANGLES = listOf(
    MasterAngle("LONG_FULL_A", "Panjang A"),
    MasterAngle("LONG_FULL_B", "Panjang B"),
    MasterAngle("LONG_HANDLE", "Handle/Butt"),
    MasterAngle("LONG_TIP", "Ujung/Tip"),
    MasterAngle("LONG_SIDE", "Sisi Detail")
)

private class MasterCameraController(private val context: Context) {
    var videoCapture: VideoCapture<Recorder>? = null
        private set
    private var recording: Recording? = null
    private var cameraProvider: ProcessCameraProvider? = null

    fun bind(previewView: PreviewView, owner: LifecycleOwner) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            runCatching {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(
                            Quality.HD,
                            FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
                        )
                    )
                    .build()
                val capture = VideoCapture.withOutput(recorder)
                videoCapture = capture
                provider.unbindAll()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun start(file: File, executor: Executor, onEvent: (VideoRecordEvent) -> Unit): Boolean {
        val capture = videoCapture ?: return false
        if (recording != null) return false
        val output = FileOutputOptions.Builder(file).build()
        return runCatching {
            recording = capture.output.prepareRecording(context, output)
                .start(executor) { event -> onEvent(event) }
            true
        }.getOrDefault(false)
    }

    fun stop() {
        recording?.stop()
        recording = null
    }

    fun release() {
        recording?.stop()
        recording = null
        cameraProvider?.unbindAll()
        videoCapture = null
    }
}

private data class FrameCandidate(val bitmap: Bitmap, val score: Double, val timeUs: Long)

private fun frameQuality(source: Bitmap): Double {
    val w = min(160, source.width)
    val h = max(1, (source.height.toFloat() * w / source.width).toInt())
    val small = Bitmap.createScaledBitmap(source, w, h, true)
    var sum = 0.0
    var sumSq = 0.0
    var count = 0
    var prev = 0
    for (y in 1 until h step 2) {
        for (x in 1 until w step 2) {
            val c = small.getPixel(x, y)
            val gray = (0.299 * android.graphics.Color.red(c) + 0.587 * android.graphics.Color.green(c) + 0.114 * android.graphics.Color.blue(c)).toInt()
            val left = small.getPixel(x - 1, y)
            val up = small.getPixel(x, y - 1)
            val gx = abs(gray - ((0.299 * android.graphics.Color.red(left) + 0.587 * android.graphics.Color.green(left) + 0.114 * android.graphics.Color.blue(left)).toInt()))
            val gy = abs(gray - ((0.299 * android.graphics.Color.red(up) + 0.587 * android.graphics.Color.green(up) + 0.114 * android.graphics.Color.blue(up)).toInt()))
            val edge = gx + gy
            sum += edge
            sumSq += edge * edge
            count++
            prev = gray
        }
    }
    val mean = if (count == 0) 0.0 else sum / count
    val variance = if (count == 0) 0.0 else max(0.0, sumSq / count - mean * mean)
    if (small !== source) small.recycle()
    return variance + mean * 0.4 + prev * 0.0
}

private fun extractBestFrames(video: File, maxFrames: Int = 3): List<Bitmap> {
    val retriever = MediaMetadataRetriever()
    val candidates = mutableListOf<FrameCandidate>()
    return try {
        retriever.setDataSource(video.absolutePath)
        val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        if (durationMs <= 0L) return emptyList()
        val samples = 7
        for (i in 0 until samples) {
            val timeUs = ((durationMs * 1000L) * (i + 1) / (samples + 1)).coerceAtLeast(0L)
            val bitmap = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST) ?: continue
            candidates += FrameCandidate(bitmap, frameQuality(bitmap), timeUs)
        }
        val selected = mutableListOf<Bitmap>()
        candidates.sortedByDescending { it.score }.forEach { candidate ->
            if (selected.size >= maxFrames) return@forEach
            val distinct = selected.none { other ->
                val w = min(24, min(candidate.bitmap.width, other.width))
                val h = min(24, min(candidate.bitmap.height, other.height))
                if (w <= 0 || h <= 0) false else {
                    val a = Bitmap.createScaledBitmap(candidate.bitmap, w, h, true)
                    val b = Bitmap.createScaledBitmap(other, w, h, true)
                    var diff = 0.0
                    for (y in 0 until h step 3) for (x in 0 until w step 3) {
                        val ca = a.getPixel(x, y)
                        val cb = b.getPixel(x, y)
                        diff += abs(android.graphics.Color.red(ca) - android.graphics.Color.red(cb)) +
                                abs(android.graphics.Color.green(ca) - android.graphics.Color.green(cb)) +
                                abs(android.graphics.Color.blue(ca) - android.graphics.Color.blue(cb))
                    }
                    a.recycle(); b.recycle()
                    diff / ((w * h + 1) * 3) < 0.035
                }
            }
            if (distinct) selected += candidate.bitmap
        }
        candidates.map { it.bitmap }.filter { it !in selected }.forEach { it.recycle() }
        selected
    } finally {
        retriever.release()
    }
}


private fun cropToTargetLock(source: Bitmap, spec: TargetLockSpec): Bitmap {
    val left = (source.width * spec.left).roundToInt().coerceIn(0, source.width - 1)
    val top = (source.height * spec.top).roundToInt().coerceIn(0, source.height - 1)
    val right = (source.width * (spec.left + spec.width)).roundToInt().coerceIn(left + 1, source.width)
    val bottom = (source.height * (spec.top + spec.height)).roundToInt().coerceIn(top + 1, source.height)
    return Bitmap.createBitmap(source, left, top, right - left, bottom - top)
}

private fun processTargetLock(source: Bitmap, spec: TargetLockSpec): Bitmap {
    val cropped = cropToTargetLock(source, spec)
    if (!spec.longObject) return cropped

    val focused = RodFocusProcessor.isolate(cropped).bitmap
    if (focused !== cropped) cropped.recycle()
    return focused
}

private fun applyTargetLockToFrames(frames: List<Bitmap>, spec: TargetLockSpec): List<Bitmap> {
    return frames.map { source ->
        val focused = processTargetLock(source, spec)
        if (focused !== source) source.recycle()
        focused
    }
}

private fun saveMasterFrame(context: Context, productId: Long, angle: String, bitmap: Bitmap, index: Int): String {
    val dir = File(context.filesDir, "product_photos/master/$productId/$angle").apply { mkdirs() }
    val file = File(dir, "${angle}_${System.currentTimeMillis()}_$index.jpg")
    FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    return file.absolutePath
}


private fun decodeStudioCameraBitmap(file: File, maxDimension: Int = 1600): Bitmap? {
    if (!file.exists() || file.length() <= 0L) return null
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) sample *= 2
    return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.ARGB_8888
    })
}

@Composable
fun ProductMasterStudio(
    vm: PosViewModel,
    product: com.arspos.anglerriausyndicate.data.db.ProductEntity,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val photos by vm.productPhotos(product.id).collectAsState(initial = emptyList())
    var angleIndex by remember { mutableIntStateOf(0) }
    var recording by remember { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Kamera Master fullscreen + Lock Target siap. Rekam 2–4 detik per sudut.") }
    var detectedText by remember { mutableStateOf("") }
    var detectedBarcode by remember { mutableStateOf("") }
    var seconds by remember { mutableIntStateOf(0) }
    var showFullscreenCamera by remember { mutableStateOf(false) }
    var fullscreenMode by remember { mutableStateOf("VIDEO") }
    var fullscreenOutputFile by remember { mutableStateOf<File?>(null) }
    var tickJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    var verification by remember { mutableStateOf<MasterVerificationResult?>(null) }
    var verifiedPreviously by remember { mutableStateOf(false) }
    var isLongObject by remember { mutableStateOf(false) }
    LaunchedEffect(product.id) {
        verifiedPreviously = runCatching { vm.isMasterVerified(product.id) }.getOrDefault(false)
        isLongObject = runCatching {
            val profile = vm.productIdentityProfile(product.id)
            profile?.isLongObject ?: isLikelyLongStudioProduct(product)
        }.getOrDefault(isLikelyLongStudioProduct(product))
    }
    val masterAngles = if (isLongObject) LONG_MASTER_ANGLES else MASTER_ANGLES
    var verifying by remember { mutableStateOf(false) }
    fun openFullscreenPhoto() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            message = "Izin kamera diperlukan. Izinkan kamera lalu buka Master Studio lagi."
            return
        }
        val dir = File(context.cacheDir, "camera_capture").apply { mkdirs() }
        val file = File.createTempFile("master_verify_", ".jpg", dir)
        fullscreenMode = "PHOTO"
        fullscreenOutputFile = file
        showFullscreenCamera = true
    }

    DisposableEffect(Unit) {
        onDispose {
            tickJob?.cancel()
        }
    }

    if (angleIndex >= masterAngles.size) angleIndex = 0
    val currentAngle = masterAngles[angleIndex]
    val completedAngles = masterAngles.count { a -> photos.any { it.captureAngle == a.key } }
    val sharpFrames = photos.count { it.captureAngle in masterAngles.map(MasterAngle::key) }
    val ocrReady = detectedText.isNotBlank()
    val barcodeReady = detectedBarcode.isNotBlank() || !product.barcode.isNullOrBlank()
    val manualIdentityReady = product.name.isNotBlank() || product.sku.isNotBlank()
    val angleWeight = if (isLongObject) 14 else 10
    val qualityWeight = if (isLongObject) 15 else 25
    val identityReady = barcodeReady || ocrReady || manualIdentityReady
    val completeness = (
        completedAngles * angleWeight +
        min(qualityWeight, (sharpFrames * qualityWeight) / masterAngles.size.coerceAtLeast(1)) +
        (if (identityReady) 15 else 0)
    ).coerceIn(0, 100)
    val angleCoverage = completedAngles.toFloat() / masterAngles.size.coerceAtLeast(1)
    val frameDepth = (sharpFrames.toFloat() / if (isLongObject) 10f else 12f).coerceIn(0f, 1f)
    val identityDepth = if (barcodeReady) 1f else if (ocrReady) 0.85f else if (manualIdentityReady) 0.65f else 0f
    val masterIdentityStrength = (angleCoverage * 45f + frameDepth * 25f + identityDepth * 30f).roundToInt().coerceIn(0, 100)

    AlertDialog(
        onDismissRequest = { if (!recording && !processing) onClose() },
        title = {
            Column {
                Text("ARS PRODUCT MASTER STUDIO", fontWeight = FontWeight.Bold)
                Text(product.name, color = StudioGold, fontSize = 12.sp)
            }
        },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 650.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(colors = CardDefaults.cardColors(StudioBlack), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("📷 KAMERA MASTER FULLSCREEN", color = StudioGold, fontWeight = FontWeight.Bold)
                        Text(
                            if (isLongObject) "Mode objek panjang: saat kamera aktif, seluruh layar digunakan agar joran sampai ±5 meter mudah dibingkai." else "Saat pengambilan foto/video, kamera membuka penuh layar agar produk mudah dibingkai dan dikunci.",
                            color = Color.White,
                            fontSize = 11.sp
                        )
                        Text("🔒 LOCK TARGET aktif sebelum foto atau rekam. Background tidak dijadikan target utama.", color = StudioMuted, fontSize = 10.sp)
                    }
                }

                Text("KELENGKAPAN MASTER  $completeness%", color = StudioGold, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { completeness / 100f }, modifier = Modifier.fillMaxWidth())
                Text("KEKUATAN IDENTITAS MASTER  $masterIdentityStrength%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                LinearProgressIndicator(progress = { masterIdentityStrength / 100f }, modifier = Modifier.fillMaxWidth())
                Text("Kelengkapan = cakupan enrollment. Kekuatan identitas = kedalaman sudut/frame + identitas produk.", color = StudioMuted, fontSize = 10.sp)

                Card(colors = CardDefaults.cardColors(StudioPanel), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("MODE IDENTITAS PRODUK", color = StudioGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Text(
                            if (isLongObject) "OBJEK PANJANG • joran/rod/kail panjang sampai ±5 meter" else "HYBRID NORMAL • produk kemasan, reel, lure, aksesori, dll.",
                            color = Color.White,
                            fontSize = 11.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(
                                checked = isLongObject,
                                onCheckedChange = { value ->
                                    if (!recording && !processing && !verifying) {
                                        isLongObject = value
                                        angleIndex = 0
                                        verifiedPreviously = false
                                        verification = null
                                        scope.launch { vm.setProductRecognitionMode(product.id, "HYBRID", value) }
                                    }
                                }
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Produk panjang / Joran / Rod", color = Color.White, fontSize = 11.sp)
                        }
                        Text(
                            if (isLongObject) "Master khusus objek panjang: ambil seluruh panjang, handle, ujung, dan detail sisi. Saat belanja, foto tetap 1 kali dan sistem mencari identitas visual dari master ini." else "Barcode dan nama tetap dipakai bila tersedia. Bila tidak ada barcode/nama yang terbaca, master visual terverifikasi menjadi identitas cadangan.",
                            color = StudioMuted,
                            fontSize = 10.sp
                        )
                    }
                }

                if (verifiedPreviously) {
                    Text("✓ MASTER SUDAH TERVERIFIKASI", color = StudioGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }

                if (photos.size >= 3) {
                    OutlinedButton(
                        enabled = !recording && !processing && !verifying,
                        onClick = { openFullscreenPhoto() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (verifying) "MEMVERIFIKASI MASTER..." else "🔎 UJI PENGENALAN MASTER")
                    }
                }

                verification?.let { result ->
                    Card(
                        colors = CardDefaults.cardColors(if (result.accepted) StudioPanel else Color(0xFF241818)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                if (result.accepted) "✓ MASTER TERVERIFIKASI" else "✕ MASTER BELUM TERVERIFIKASI",
                                color = if (result.accepted) StudioGold else Color(0xFFE57373),
                                fontWeight = FontWeight.Bold
                            )
                            Text("Referensi: ${result.referenceCount} frame", color = Color.White, fontSize = 11.sp)
                            Text("Visual ${result.visualScore}% • OCR ${result.textScore}% • Final ${result.finalScore}%", color = StudioGold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            if (result.barcode.isNotBlank()) Text("Barcode master: ${result.barcode}", color = Color.White, fontSize = 10.sp)
                            if (result.detectedBarcode.isNotBlank()) Text("Barcode foto uji: ${result.detectedBarcode}", color = Color.White, fontSize = 10.sp)
                            if (result.ocrText.isNotBlank()) Text("OCR: ${result.ocrText.replace("\n", " • ").take(160)}", color = StudioMuted, fontSize = 9.sp)
                            Text(result.reason, color = if (result.accepted) StudioMuted else Color.White.copy(alpha = 0.78f), fontSize = 10.sp)
                            if (result.accepted) {
                                Text("✓ Produk ini siap menjadi referensi untuk Smart Shopping Scan.", color = StudioGold, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                        }
                    }
                }

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(masterAngles) { a ->
                        val done = photos.any { it.captureAngle == a.key }
                        AssistChip(
                            onClick = { angleIndex = masterAngles.indexOf(a) },
                            label = { Text(if (done) "✓ ${a.label}" else "○ ${a.label}") },
                            colors = AssistChipDefaults.assistChipColors(
                                labelColor = if (done) StudioGold else Color.White
                            )
                        )
                    }
                }

                Card(colors = CardDefaults.cardColors(StudioPanel), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("SEKARANG: ${currentAngle.label.uppercase()}", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(
                            when (currentAngle.key) {
                                "FRONT" -> "Tampilkan bagian depan produk."
                                "RIGHT" -> "Putar ke sisi kanan."
                                "BACK" -> "Putar ke bagian belakang."
                                "LEFT" -> "Putar ke sisi kiri."
                                "TOP" -> "Arahkan kamera ke bagian atas."
                                "BOTTOM" -> "Arahkan kamera ke bagian bawah dengan aman."
                                "LONG_FULL_A" -> "Bentangkan seluruh joran/rod dari handle sampai tip. Pastikan seluruh panjang masuk frame."
                                "LONG_FULL_B" -> "Ambil seluruh panjang dari sudut/arah berbeda untuk menangkap siluet dan warna."
                                "LONG_HANDLE" -> "Dekatkan ke handle/butt dan ambil detail sambungan, reel seat, dan grip."
                                "LONG_TIP" -> "Ambil detail ujung/tip dan sambungan ruas terakhir."
                                else -> "Ambil sisi detail sepanjang produk dengan cahaya merata."
                            },
                            color = StudioMuted,
                            fontSize = 12.sp
                        )
                        Text(if (isLongObject) "Untuk joran panjang: kamera boleh lebih jauh agar seluruh produk masuk frame. Jangan tekuk joran; gunakan lantai/dinding sebagai latar yang kontras." else "Putar produk perlahan • jangan terlalu dekat • pastikan tulisan terlihat jelas.", color = StudioMuted, fontSize = 11.sp)
                    }
                }

                if (processing) {
                    Text("MEMPROSES VIDEO → MEMILIH FRAME TERBAIK...", color = StudioGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                if (message.isNotBlank()) Text(message, color = StudioMuted, fontSize = 11.sp)
                if (detectedText.isNotBlank()) Text("OCR: $detectedText", color = Color.White, fontSize = 11.sp)
                if (detectedBarcode.isNotBlank()) Text("Barcode: $detectedBarcode", color = StudioGold, fontSize = 11.sp)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        enabled = !recording && !processing,
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                message = "Izin kamera diperlukan. Izinkan kamera lalu buka Master Studio lagi."
                                return@Button
                            }
                            verifiedPreviously = false
                            verification = null
                            scope.launch { vm.invalidateMasterVerification(product.id) }
                            val file = File(context.cacheDir, "master_video_${product.id}_${currentAngle.key}_${System.currentTimeMillis()}.mp4")
                            fullscreenMode = "VIDEO"
                            fullscreenOutputFile = file
                            showFullscreenCamera = true
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = StudioGold)
                    ) { Text(if (recording) "MEREKAM..." else "REKAM ${currentAngle.label.uppercase()}", color = Color.Black) }
                }

                if (photos.isNotEmpty()) {
                    Text("REFERENSI MASTER TERSIMPAN: ${photos.size} FRAME", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    if (completedAngles == masterAngles.size) {
                        Text(if (isLongObject) "✓ MASTER OBJEK PANJANG LENGKAP" else "✓ MASTER 6 SISI LENGKAP", color = StudioGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Master siap menjadi referensi visual offline untuk Smart Shopping Scan.", color = StudioMuted, fontSize = 11.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !recording && !processing, onClick = onClose) { Text("SELESAI") }
        },
        dismissButton = {
            TextButton(enabled = !recording && !processing, onClick = {
                angleIndex = 0
                message = "Mulai lagi dari sisi depan."
            }) { Text("ULANG DARI DEPAN") }
        }
    )

    if (showFullscreenCamera) {
        val file = fullscreenOutputFile
        if (file != null) {
            FullscreenMasterCamera(
                title = if (fullscreenMode == "PHOTO") "MASTER • FOTO UJI" else "MASTER • VIDEO",
                subtitle = if (isLongObject) "OBJEK PANJANG • ${currentAngle.label.uppercase()}" else currentAngle.label.uppercase(),
                mode = fullscreenMode,
                isLongObject = isLongObject,
                outputFile = file,
                onCaptured = { captured, targetLock ->
                    showFullscreenCamera = false
                    fullscreenOutputFile = null
                    if (fullscreenMode == "PHOTO") {
                        val decoded = runCatching { decodeStudioCameraBitmap(captured) }.getOrNull()
                        captured.delete()
                        val bitmap = decoded?.let { source ->
                            val focused = runCatching { processTargetLock(source, targetLock) }.getOrNull()
                            if (focused != null && focused !== source) source.recycle()
                            focused
                        }
                        if (bitmap != null) {
                            verifying = true
                            verification = null
                            scope.launch {
                                verification = runCatching {
                                    withContext(Dispatchers.Default) { vm.verifyProductMaster(product.id, bitmap) }
                                }.getOrElse {
                                    MasterVerificationResult(
                                        productId = product.id, productName = product.name, sku = product.sku,
                                        barcode = product.barcode.orEmpty(), referenceCount = photos.size,
                                        visualScore = 0, textScore = 0, finalScore = 0, ocrText = "",
                                        detectedBarcode = "", accepted = false,
                                        reason = "Uji master gagal: ${it.message ?: "kesalahan tidak diketahui"}"
                                    )
                                }
                                if (verification?.accepted == true) verifiedPreviously = true
                                bitmap.recycle()
                                verifying = false
                            }
                        } else message = "Foto uji tidak dapat dibaca. Silakan coba lagi."
                    } else {
                        processing = true
                        recording = false
                        tickJob?.cancel()
                        scope.launch {
                            val angle = currentAngle
                            val frames = withContext(Dispatchers.Default) {
                                applyTargetLockToFrames(extractBestFrames(captured, 3), targetLock)
                            }
                            if (frames.isEmpty()) {
                                message = "Frame tidak berhasil diambil. Ulangi rekaman dengan cahaya lebih baik."
                                captured.delete()
                                processing = false
                                return@launch
                            }
                            photos.filter { it.captureAngle == angle.key }.forEach { old -> runCatching { File(old.localPath).delete() } }
                            vm.clearProductPhotoAngle(product.id, angle.key)
                            var saved = 0
                            for ((i, frame) in frames.withIndex()) {
                                val path = saveMasterFrame(context, product.id, angle.key, frame, i + 1)
                                vm.addProductPhoto(product.id, path, photos.isEmpty() && saved == 0, angle.key)
                                runCatching {
                                    val draft = withContext(Dispatchers.Default) { SmartProductInput.analyze(frame) }
                                    if (draft.rawText.isNotBlank()) detectedText = draft.rawText.take(220)
                                    if (draft.barcode.isNotBlank()) detectedBarcode = draft.barcode
                                    vm.mergeProductIdentityProfile(
                                        product.id, draft.rawText, draft.brand, draft.name, draft.variant,
                                        draft.modelCode, draft.barcode, "HYBRID", isLongObject
                                    )
                                }
                                frame.recycle()
                                saved++
                            }
                            captured.delete()
                            message = if (isLongObject) "$saved frame ROD-FOCUS disimpan untuk ${angle.label}; ROI sempit dan background diabaikan." else "$saved frame TARGET-LOCK disimpan untuk ${angle.label}; background luar target dibuang."
                            processing = false
                            if (angleIndex < masterAngles.lastIndex) angleIndex++
                        }
                    }
                },
                onCancel = {
                    showFullscreenCamera = false
                    fullscreenOutputFile?.delete()
                    fullscreenOutputFile = null
                }
            )
        }
    }

}
