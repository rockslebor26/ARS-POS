# Phase 4.3.2.12 CLEAN FIX3

Build repair for the Product Identity Engine V3 release candidate.

Primary fix:
- Added the missing PosViewModel.clearProductPhotoAngle() API wrapper used by ProductMasterStudio.
- Kept ProductionRepository.clearProductPhotoAngle() unchanged.
- Bumped versionCode to 125 and versionName to 1.2.5 so the APK remains an in-place update.
- Build workflow now validates the missing API before Gradle compilation.

No applicationId change. Existing app data/database is intended to remain on update.
