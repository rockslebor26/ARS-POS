# ARS POS Phase 4.3.2.30 — V8.4.10

Version 1.4.5 (145).

V8.4.10 is a conservative scanner correction built from V8.4.9. It does not lower recognition thresholds.

## Primary correction
V8.4.9 coarse LONG shortlisting could retain only one or two highest-scoring reference frames per product. This could remove identity-bearing LONG_HANDLE, LONG_SIDE, or LONG_TIP references before Rod Anchor Identity made its decision. V8.4.10 shortlists the two strongest LONG product identities and preserves one best reference per anchor angle (HANDLE, SIDE, TIP, FULL_A, FULL_B), capped at five references per product.

## Safety retained
- typed NORMAL/LONG lanes
- cross-lane scene gate and NORMAL-owned regions
- rod-structure background rejection
- anti-bridge suppression
- physical-instance quantity aggregation
- verified-master requirement
- visual score and margin gates unchanged
- rod anchor score and anchor-margin gates unchanged
- full-frame rescue remains evidence-only
- temporary crop recycling and memory telemetry retained

## Update channel
Install directly over official 1.4.4 (144). Package must remain com.arspos.anglerriausyndicate, signer must remain identical, and versionCode must be 145. Do not uninstall.
