# ARS POS — Phase 4.3.2.7 Product Recognition Engine

Phase 4.3.2.7 memperbaiki fondasi pengenalan produk ARS POS.

## Perubahan utama
- Kandidat sekarang berasal dari seluruh katalog produk aktif, bukan hanya produk yang memiliki foto master.
- Barcode tetap menjadi sinyal identitas terkuat.
- OCR dicocokkan per bidang brand, nama, variant, SKU, dan barcode.
- Produk dengan master visual memakai beberapa referensi terbaik untuk skor visual.
- Produk tanpa master masih dapat menjadi kandidat berbasis OCR/barcode, tetapi tidak boleh lolos hanya karena kemiripan visual lemah.
- Hasil yang ditolak tetap menyimpan top-5 kandidat untuk diagnostik.
- UI SCAN CERDAS sekarang menampilkan Visual/OCR/Final, barcode, OCR, alasan, dan top-3 kandidat untuk objek yang ditolak.

## Tujuan fase
Membedakan masalah data master dari masalah OCR/visual sebelum Smart Shopping Scan penuh dibuat.

## Prinsip keselamatan POS
Sistem tidak otomatis menambahkan produk yang bukti identitasnya belum cukup. Kasir tetap menekan TAMBAH setelah memeriksa hasil.
