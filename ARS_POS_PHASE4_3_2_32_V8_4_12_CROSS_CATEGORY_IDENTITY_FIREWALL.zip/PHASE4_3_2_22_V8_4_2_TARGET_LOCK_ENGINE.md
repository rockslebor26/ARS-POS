# ARS POS Phase 4.3.2.22 — V8.4.2 Target Lock Engine

Version 1.3.7 / versionCode 137.

V8.4.2 turns the fullscreen Master camera's LOCK TARGET from a visual-only control into an actual ROI pipeline. The normalized locked target region is returned with each capture and applied consistently to still-photo verification and every extracted video-master frame. Pixels outside the target region are discarded before OCR, barcode analysis, identity-memory merge, visual-master storage, and verification.

Normal products use a central target ROI. Long products use a taller ROI intended for rods and other elongated fishing products. The existing safety gate remains unchanged: unknown objects remain UNKNOWN and visual-only recognition still requires a sufficiently strong verified master.

The shopping scanner also receives stricter multi-pass proposal de-duplication. Overlapping tile detections are merged using IoU, intersection-over-smaller-area, and a conservative center/size check so one physical product is less likely to appear as many objects.

This phase intentionally does not claim full automatic AI object tracking. V8.4.2 establishes a reliable target-centric reference pipeline first; automatic live tracking can be layered on top after this ROI pipeline is validated on real store products.
