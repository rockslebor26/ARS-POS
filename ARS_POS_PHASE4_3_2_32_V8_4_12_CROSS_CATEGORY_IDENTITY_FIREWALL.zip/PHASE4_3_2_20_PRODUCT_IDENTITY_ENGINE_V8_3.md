# ARS POS — Phase 4.3.2.20 / V8.3

## Tujuan
V8.3 merombak jalur pengenalan objek panjang agar joran/rod tidak bergantung pada proposal ML Kit.

## Arsitektur
- ML Kit object detection tetap menjadi proposal untuk produk kecil.
- LongObjectAnalyzer mencari proposal pita panjang vertikal/horizontal dari seluruh foto.
- Proposal long-object dibandingkan terhadap master visual menggunakan orientation, projection, shape, gradient, dan narrow full-length strip.
- Barcode/OCR tetap menjadi bukti identitas terkuat bila tersedia.
- Produk tanpa barcode/OCR hanya dapat diterima bila master visual sudah diverifikasi.
- Unknown tetap UNKNOWN.

## Master
Master tetap menggunakan Product Master Studio. Mode joran/objek panjang harus diaktifkan untuk hasil terbaik dan merekam seluruh panjang + handle + tip + sisi detail.

## Shopping Scan
Input tetap satu foto. Sistem dapat menggabungkan proposal ML Kit dan proposal long-object. Hasil yang diterima dikelompokkan berdasarkan SKU sebelum masuk keranjang.

## Catatan
V8.3 masih merupakan deterministic offline reference matcher, bukan model AI yang dilatih khusus toko. Threshold tidak digunakan untuk memaksa produk lemah menjadi cocok.
