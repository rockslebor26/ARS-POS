# ARS POS Phase 4.3.2.28 — V8.4.8

## Multi-Object Physical Instance Separation + Scanner Performance Hardening

Target V8.4.8 adalah memperbaiki temuan V8.4.7 saat multi-object scan:

- satu rod sudah dapat menjadi Qty 1, tetapi dua rod terpisah masih dapat tergabung menjadi satu physical instance;
- proposal lebar dapat menjadi bridge yang menghubungkan dua rod berbeda;
- NORMAL dan LONG lane harus tetap terpisah sampai aggregation;
- full-frame rescue harus tetap evidence-only;
- long-object scoring terlalu lambat ketika jumlah reference bertambah;
- Flight Recorder perlu current-build summary dan memory telemetry yang lebih akurat.

## Safety invariants

1. NORMAL_OBJECT tidak boleh merge dengan LONG_OBJECT.
2. AMBIGUOUS_CONTAINER / bridge proposal quantityEligible=false.
3. FULL_FRAME_RESCUE quantityEligible=false.
4. Dua physicalInstanceHint PHYS-* yang berbeda dipertahankan sebagai dua barang fisik.
5. Duplicate crop dari physicalInstanceHint yang sama boleh digabung.
6. UNKNOWN tetap lebih aman daripada memilih SKU yang salah.
7. Recognition threshold tidak diturunkan untuk memaksa hasil dikenali.

## Pipeline V8.4.8

- ML Kit proposal + LongObjectAnalyzer proposal
- coordinate normalization ke original-image space
- strict same-axis proposal merge
- anti-bridge/container classification
- physical-instance hint assignment
- typed NORMAL/LONG scoring lane
- coarse shortlist untuk reference rod
- fine rod matcher maksimal 3 reference per SKU
- conditional single full-frame rescue only when <=1 long proposal
- lane-aware complete-linkage physical aggregation
- current-build telemetry + Java/native heap snapshot

## Update channel

V8.4.8 adalah update resmi dari V8.4.7:

- Previous: 1.4.2 (142)
- Current: 1.4.3 (143)
- package tetap: com.arspos.anglerriausyndicate
- signer harus identik dengan ARS POS OFFICIAL RELEASE
- install langsung di atas V8.4.7; jangan uninstall.

Report yang benar sesudah instalasi diharapkan menunjukkan:

- Last Install Transition: IN_PLACE_UPDATE
- Previous Installed Version: 1.4.2 (142)
- Current Installed Version: 1.4.3 (143)
- signer SHA-256 sama
- database preserved
