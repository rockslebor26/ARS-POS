# ARS POS Phase 4.3.2.24 — V8.4.4 Crash Shield + Flight Recorder

Version: 1.3.9 (versionCode 139)

## Tujuan
Menstabilkan Smart Shopping Scan yang force close dan menambahkan diagnostic recorder lokal agar setiap pengujian menghasilkan report teknis yang dapat dikirim ke ChatGPT/OpenAI.

## Perubahan utama
- Smart Scan analysis bitmap dibatasi maksimal 1024 px pada sisi terpanjang.
- Reference photo decode dibatasi maksimal 720 px dan bitmap referensi direcycle setelah fingerprint dibuat.
- Maksimal 8 reference frame yang beragam per produk dipakai saat recognition.
- Proposal objek dibatasi sehingga long-object rescue tidak membanjiri memori.
- Semua crop scanner direcycle melalui try/finally.
- OutOfMemoryError dan exception scanner ditahan oleh Crash Shield agar aplikasi tidak langsung force close dari pipeline Kotlin.
- ARS Flight Recorder menyimpan event scan, proposal, kandidat, skor, master verification, durasi, error dan uncaught crash secara offline.
- ARS DEV CENTER di Dashboard menampilkan report dan tombol CHATGPT REPORT.
- Tombol CHATGPT REPORT memakai Android share intent ke aplikasi ChatGPT jika tersedia. Tidak ada OpenAI API key yang ditanam di APK.
- Data transaksi, PIN dan data pelanggan tidak dimasukkan ke diagnostic report.

## Catatan keamanan OpenAI
Integrasi API langsung tidak menggunakan secret key di APK. Jika nanti dibutuhkan analisis OpenAI sepenuhnya di dalam aplikasi, request harus melewati backend ARS yang menyimpan API key secara aman.
