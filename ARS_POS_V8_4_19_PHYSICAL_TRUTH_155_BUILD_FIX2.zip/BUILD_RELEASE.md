# Build resmi versi 155

Ikuti README.md dan gunakan file pendamping ARS_POS_V8_4_19_PHYSICAL_TRUTH_155.yml sebagai .github/workflows/build-apk.yml.

Source ZIP: ARS_POS_V8_4_19_PHYSICAL_TRUTH_155.zip. AGP8.7.3 / Gradle8.9 / Kotlin2.0.21 / Java17 / compileSdk35. Release hanya dengan signer resmi yang telah terpasang pada aplikasi versi154. Semua pemeriksaan package, versionCode155, versionName1.5.5, signer SHA-256, alignment, kompilasi, dan unit test wajib lulus sebelum upload artifact APK.

Kompilasi Android lengkap dan APK bertanda tangan belum dihasilkan di lingkungan penyusunan; GitHub Actions menjadi gerbang build. Tidak ada keystore dalam arsip ini, dan tidak perlu membuat keystore baru.
