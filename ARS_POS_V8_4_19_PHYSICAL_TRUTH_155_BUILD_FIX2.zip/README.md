# ARS POS 1.5.5 (155) — V8.4.19 Physical Truth

Phase 4.3.2.39. Kelanjutan source resmi 1.5.4 (154), bukan aplikasi baru.
Package: com.arspos.anglerriausyndicate. Database Room tetap v5.

Perbaikan berangkat dari ZIP diagnostik tanggal 15 September 2026: nat lantai sempat mendapat TRUSTED_ROD, badan joran kehilangan kepercayaan, dan satu kemasan menghasilkan dua proposal. Versi ini memperbaiki pembacaan piksel dan kepemilikan objek, mengikat anchor dengan kandidat yang benar, dan memperketat jalur quantity. Seluruh 14 threshold pengenalan SKU dan implementasi keputusan identitas tetap sama (hanya komentar versi berubah).

## Build melalui GitHub

1. Unggah **ARS_POS_V8_4_19_PHYSICAL_TRUTH_155.zip** ke root repository dengan nama persis itu. Jangan mengompres ulang karena workflow memeriksa SHA-256.
2. Salin seluruh isi file pendamping **ARS_POS_V8_4_19_PHYSICAL_TRUTH_155.yml** ke **.github/workflows/build-apk.yml**. Workflow pendamping berada di luar ZIP agar checksum arsip tidak mereferensikan dirinya sendiri.
3. Gunakan lima repository secrets resmi yang sudah dipakai: ARS_RELEASE_KEYSTORE_BASE64, ARS_RELEASE_STORE_PASSWORD, ARS_RELEASE_KEY_ALIAS, ARS_RELEASE_KEY_PASSWORD, ARS_RELEASE_CERT_SHA256.
4. Jalankan Actions → ARS POS V8.4.19 Physical Truth 155 → Run workflow. Push pada main untuk ZIP/YML tersebut juga memicu build.
5. Ambil artifact **ARS-POS-V8.4.19-PHYSICAL-TRUTH-155-OFFICIAL**, ekstrak APK, dan pasang sebagai update in-place pada versi 154.

Signer wajib: AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB.
Workflow berhenti apabila package/versi/signer berbeda, kompilasi gagal, atau uji gagal. Tidak ada fallback signer debug. Keystore tidak disertakan dalam source. Pasang update langsung; uninstall akan menghapus data lokal.

## Status verifikasi

- 85 uji JUnit lulus pada komponen Kotlin menggunakan compiler JVM 1.9.24, JDK 17, dan adapter API Android lokal. Adapter hanya dipakai untuk pemeriksaan lokal dan tidak masuk aplikasi.
- 47 kasus piksel dari 18 scene asli: 9 badan joran yang ditandai manual dan 38 track lain sesuai label. Ini uji regresi dataset pengembangan, bukan ukuran akurasi umum SKU.
- 32 replay pemeriksa authenticity dengan axisConfidence dan rodStructureScore yang benar-benar tersedia dalam event lulus. Lima badan joran positif. Lima belas track tanpa rodStructureScore tidak diberi skor buatan dan tidak masuk replay ini.
- 6 uji utilitas Python lulus. Pemeriksaan statis memastikan package, DB, threshold dan binding evidence.
- Kompilasi Android penuh belum berhasil dijalankan di lingkungan penyusunan karena artifact AGP 8.7.3 dari repository eksternal tidak dapat diunduh. Belum ada APK resmi yang dibangun/diuji pada realme. Workflow wajib menjalankan kompilasi Kotlin 2.0.21, seluruh unit test, dan assembleRelease sebelum artifact APK dapat diterbitkan.

Detail perubahan dan uji perangkat: RELEASE_155.md. Dokumen phase lama di source merupakan arsip; petunjuk rilis ini yang berlaku.
