package com.arspos.anglerriausyndicate

import android.graphics.Bitmap

internal object NormalPhysicalResolver {
    fun resolve(input: List<ScanProposal>, bitmap: Bitmap, session: String): List<ScanProposal> {
        if(input.isEmpty())return emptyList()
        val result=NormalPixelOwnership.resolve(bitmap.width,bitmap.height,input.map {
            val b=it.normalizedBounds;NormalPixelOwnership.Box(b.left,b.top,b.right,b.bottom)
        }) { x,y->bitmap.getPixel(x,y) }
        return result.groups.mapIndexed { index,group ->
            val representative=group.maxWithOrNull(compareBy<Int>{ input[it].normalizedBounds.width().toLong()*input[it].normalizedBounds.height() }
                .thenBy { result.owners[it].coverage })!!
            val p=input[representative]
            val ambiguous=group.any { it in result.ambiguous }
            val id="NORMAL-${index+1}"
            val reason=when { ambiguous->"NORMAL_OVERLAP_REQUIRES_REVIEW";group.size>1->"NORMAL_SHARED_FOREGROUND_COMPONENT";else->"NORMAL_SINGLE_PROPOSAL" }
            ArsFlightRecorder.event("SCAN_NORMAL_OWNERSHIP",reason,mapOf(
                "session" to session,"physicalObjectId" to id,"proposalIds" to group.map { input[it].proposalId },
                "foregroundComponent" to result.owners[representative].component,
                "foregroundCoverage" to result.owners[representative].coverage,
                "mergedProposals" to group.size,"quantityEligible" to (!ambiguous && p.quantityEligible)))
            p.copy(proposalId=group.joinToString("+"){input[it].proposalId},physicalObjectId=id,
                physicalInstanceHint=id,lineageId="NORMAL-LINEAGE-$id",hypothesesMerged=group.size,
                physicalMergeReason=reason,quantityEligible=p.quantityEligible && !ambiguous)
        }
    }
}
