# ARS POS Project Continuity

Current source candidate: **1.5.4 (154) / Phase 4.3.2.38 / V8.4.18**.

Direct predecessor: 1.5.3 (153) / Phase 4.3.2.37 / V8.4.17 WorkSync. Database remains v5; package and official signer must remain unchanged. Recognition thresholds remain unchanged.
