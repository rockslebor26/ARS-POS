# ARS POS Project Continuity

Current engineering baseline: **1.5.1 (151) / Phase 4.3.2.36 / V8.4.16**.

V8.4.16 continues directly from V8.4.15 Identity Safety. It adds bounded session-bound visual diagnostic evidence and an ARS Dev Center ZIP export so future ChatGPT analysis can correlate telemetry with the exact scene/crop/track/anchor that produced a decision.

Recognition thresholds are not lowered. Package remains `com.arspos.anglerriausyndicate`, Room database remains v5, and official signer continuity is mandatory for in-place update.
