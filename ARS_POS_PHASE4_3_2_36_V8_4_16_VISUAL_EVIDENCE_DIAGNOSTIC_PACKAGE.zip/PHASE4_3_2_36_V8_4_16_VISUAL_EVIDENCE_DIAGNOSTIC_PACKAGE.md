# ARS POS 1.5.1 (151) / Phase 4.3.2.36 / V8.4.16

## Visual Evidence Recorder + Diagnostic Scan Package

V8.4.16 continues directly from V8.4.15 Identity Safety. It adds diagnostic visual evidence to make ARS Dev Center reports reproducible without changing the recognition policy.

## Implemented
- Visual evidence is captured from the same scanner analysis bitmap/crop used by the recognition pipeline.
- Every scan session stores `scene/analysis_scene.jpg` bound to the scanner `sessionId` / `scanId`.
- Every authenticated physical track is recorded before display pruning. The evidence manifest carries proposal/physical object id, bounds, axis, axis confidence, width, width variance, curvature, rod claim, authenticity, merge reason and quantity eligibility.
- Track crops are stored in `tracks/` and one `overlay/physical_track_overlay.jpg` renders audited bounds and physical axes on the analysis scene.
- Every scored recognition decision stores an object crop in `objects/`, bound to the exact `decisionRuleId`, candidate, visual/final score, identity margin, anchor score/margin and quantity result.
- LONG decisions additionally store diagnostic `HANDLE`, `SIDE`, and `TIP` crops in `anchors/` when extraction succeeds.
- `evidence_manifest.jsonl`, `session.json`, and `completion.json` bind files to scanner telemetry instead of leaving anonymous JPG files.
- ARS Dev Center adds `CHATGPT + EVIDENCE ZIP`. Export contains `report.txt`, `flight_recorder.jsonl`, package metadata, and retained evidence sessions.
- Image disk writes are offloaded to a bounded single-worker queue. Evidence may be dropped when the queue is full; scanner recognition is never blocked to preserve diagnostics.
- Retention is bounded to maximum 20 sessions and approximately 35 MB. JPEG quality is 82 and evidence snapshots are limited to a 1280-pixel longest edge.
- Clearing ARS Dev Center logs also clears retained visual evidence.

## Identity-safety invariants retained from V8.4.15
- NORMAL visual-only identity remains blocked without independent barcode/strong OCR evidence.
- Cross-category rod/NORMAL firewall remains active.
- Full-frame rescue remains evidence-only and quantity-ineligible.
- Typed NORMAL/LONG lanes, physical-track resolution, rod claim/authenticity and anchor-aware LONG matching remain active.
- `MIN_LONG_VISUAL_MARGIN = 14` and `MIN_LONG_ANCHOR_MARGIN = 8` remain unchanged.
- Diagnostic capture does not modify candidate ranking, recognition thresholds, physical quantity, cart state, transaction state or Room database contents.

## Release identity
- `applicationId`: `com.arspos.anglerriausyndicate`
- `versionName`: `1.5.1`
- `versionCode`: `151`
- database version: `5` (unchanged)
- update target: official `1.5.0 (150)` / V8.4.15, in-place; do not uninstall
- signing channel: existing ARS Official Release certificate only

## Device validation priority
1. Confirm `1.5.0 (150) -> 1.5.1 (151)` is recorded as `IN_PLACE_UPDATE` with the same package and signer SHA-256.
2. Scan one rod, two parallel rods, two crossing rods, rod + compact NORMAL product, compact NORMAL-only product, and background-only scenes.
3. Confirm scene, track crop/overlay, object crop and LONG anchor crops all use the same session identity as `SCAN_TRACK_AUDIT` / `SCAN_OBJECT`.
4. Force representative rejects such as `REJECT_VISUAL_MARGIN`, `REJECT_ANCHOR_MARGIN`, and `REJECT_NORMAL_REQUIRES_IDENTITY`; verify the exact `decisionRuleId` has a matching object crop.
5. Export `CHATGPT + EVIDENCE ZIP`; verify `report.txt`, `flight_recorder.jsonl`, `package_info.json`, `evidence_manifest.jsonl`, scene/track/object/anchor images are readable.
6. Repeat at least ten scans and compare scanner latency, Java heap, native heap, total PSS, evidence queue drops, and retained evidence size.
7. Confirm old evidence is automatically removed at the 20-session / 35 MB retention limit.
8. No threshold relaxation is permitted to improve apparent recognition rate.

## Known scope boundary
This release improves observability, not recognition accuracy by itself. The captured visual evidence is intended to make the next recognition/geometry change evidence-driven. Shaft intersection topology and physical-object geometry should only be changed after V8.4.16 device reports demonstrate a repeatable failure mode.
