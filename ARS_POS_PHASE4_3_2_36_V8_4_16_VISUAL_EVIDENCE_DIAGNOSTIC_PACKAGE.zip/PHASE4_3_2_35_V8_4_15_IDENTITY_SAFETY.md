# ARS POS 1.5.0 (150) / Phase 4.3.2.35 / V8.4.15

Test build: Identity Safety + Crop-Scoped OCR + Track Audit.

## Implemented
- NORMAL visual-only candidates remain UNKNOWN even when no rod claim exists. Barcode or existing strong OCR rules are required for automatic recognition; use manual product search for products without that evidence. This is temporary containment, not improved visual recognition.
- Object OCR cannot be replaced with whole-frame OCR. Existing scene barcode fallback only operates when no proposal exists.
- Rejection message is selected from the exact decisionRuleId.
- Full-frame rescue is skipped when any resolved physical axis exists, including rejected axes. It remains quantity-ineligible when used.
- SCAN_TRACK_AUDIT records all authenticated tracks before display pruning with session, bounds, axis, width variance, curvature, claim, authenticity, merge reason and quantity eligibility.
- Added warm baseline at the fifth completed scan; cold baseline and existing warning retained. Neither is an OS memory-pressure signal.
- Six Kotlin unit tests in CI cover visual-only blocking, exact barcode, strong OCR, weak OCR, accepted rod anchors and ambiguous rod rejection.

## Deliberately not claimed as completed
- Shaft measurement/intersection topology has NOT been rewritten. Existing CROSS_THROUGH labels are heuristic run counts, not proven geometric intersections.
- Multi-object merging and multi-anchor retrieval are inherited; their accuracy is not validated by this release.
- No scanner latency, memory leak or device recognition improvement is claimed before device tests.

## Compatibility
Package com.arspos.anglerriausyndicate; database v5 unchanged.
Install over official 1.4.9 (149); preserve existing signing secrets and signer fingerprint.
No recognition thresholds are lowered. Do not uninstall the old app.

## Validation and device checklist
Local: source checks, YAML parsing and Kotlin delimiter checks only. Full compilation and unit tests must run in GitHub Actions; no local Android SDK/Gradle is available.
1. Rod-only false LIGHTS photo: no automatic LIGHTS acceptance, even with high visual score.
2. Actual LIGHTS with readable OCR or barcode: correct accepted identity.
3. Actual LIGHTS with visual evidence only: UNKNOWN is expected in this temporary containment release; use manual search.
4. Two rods: export report and inspect all SCAN_TRACK_AUDIT entries; two displayed objects do not establish correct physical separation.
5. Report rescue skipped reason and cold/warm memory baselines. Export report immediately after each failure.
