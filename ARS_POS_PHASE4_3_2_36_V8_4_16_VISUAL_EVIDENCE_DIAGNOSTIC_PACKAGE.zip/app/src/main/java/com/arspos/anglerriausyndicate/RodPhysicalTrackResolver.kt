package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.33 V8.4.13 — Physical Object Truth resolver V2.
 *
 * LONG detector output is treated as axis hypotheses, not as inventory units.
 * Compatible hypotheses are consolidated before TRACK-* IDs are assigned.
 * Interior cross-axis intersections remain separate; endpoint continuation can
 * join adjacent pieces of the same slightly curved physical object.
 */
object RodPhysicalTrackResolver {
    private const val MIN_AXIS_CONFIDENCE = 30
    private const val MIN_TRACK_STRUCTURE = 30
    private const val PARALLEL_MERGE_ANGLE = 18f
    private const val CONTAINED_DUPLICATE_ANGLE = 23f
    private const val ENDPOINT_CONTINUATION_ANGLE = 38f
    private const val CROSSING_ANGLE = 20f

    data class Result(
        val proposals: List<ScanProposal>,
        val trackCount: Int,
        val crossingPairsPreserved: Int,
        val crossLaneSuppressed: Int,
        val rawAxisHypotheses: Int = 0,
        val physicalObjectsBeforeResolve: Int = 0,
        val physicalObjectsAfterResolve: Int = 0,
        val hypothesesMerged: Int = 0,
        val duplicatePhysicalObjectsPrevented: Int = 0
    )

    fun resolve(input: List<ScanProposal>): Result {
        if (input.isEmpty()) return Result(emptyList(), 0, 0, 0)

        val suppressed = input
            .filter { it.bridgeSuppressed || it.proposalType == ScanProposal.TYPE_AMBIGUOUS_CONTAINER }
            .toMutableList()
        val usable = input.filterNot { it.bridgeSuppressed || it.proposalType == ScanProposal.TYPE_AMBIGUOUS_CONTAINER }
        val axisCandidates = usable.filter {
            it.hasResolvedAxis && it.axisConfidence >= MIN_AXIS_CONFIDENCE && it.rodStructureScore >= MIN_TRACK_STRUCTURE
        }
        val fallback = usable.filterNot { axisCandidates.contains(it) }

        val groups = mutableListOf<MutableList<ScanProposal>>()
        axisCandidates.sortedWith(
            compareByDescending<ScanProposal> { it.rodStructureScore }
                .thenByDescending { it.axisConfidence }
                .thenByDescending { it.strength }
                .thenBy { it.proposalId }
        ).forEach { candidate ->
            val compatible = groups.withIndex()
                .mapNotNull { indexed ->
                    val score = groupCompatibility(indexed.value, candidate)
                    if (score > 0) indexed.index to score else null
                }
                .maxWithOrNull(compareBy<Pair<Int, Int>> { it.second }.thenBy { -it.first })

            if (compatible == null) {
                groups += mutableListOf(candidate)
            } else {
                groups[compatible.first] += candidate
            }
        }

        // Conservative fallback when the angle analyzer has no reliable axis.
        if (groups.isEmpty()) {
            val fallbackGroups = mutableListOf<MutableList<ScanProposal>>()
            fallback.sortedByDescending { it.strength }.forEach { candidate ->
                val group = fallbackGroups.firstOrNull { current ->
                    current.all { rectFallbackSameTrack(it.normalizedBounds, candidate.normalizedBounds) }
                }
                if (group == null) fallbackGroups += mutableListOf(candidate) else group += candidate
            }
            val tracks = fallbackGroups.take(3).mapIndexed { index, group ->
                mergeTrack(group, "TRACK-${index + 1}", "RECT_FALLBACK")
            }
            return Result(
                proposals = tracks + suppressed,
                trackCount = tracks.size,
                crossingPairsPreserved = 0,
                crossLaneSuppressed = suppressed.count { it.source == ScanProposal.SOURCE_CROSS_LANE },
                rawAxisHypotheses = 0,
                physicalObjectsBeforeResolve = fallback.size,
                physicalObjectsAfterResolve = tracks.size,
                hypothesesMerged = (fallback.size - tracks.size).coerceAtLeast(0),
                duplicatePhysicalObjectsPrevented = (fallback.size - tracks.size).coerceAtLeast(0)
            )
        }

        var tracks = groups.mapIndexed { index, group ->
            val reason = if (group.size > 1) "AXIS_HYPOTHESES_CONSOLIDATED" else "SINGLE_AXIS_HYPOTHESIS"
            mergeTrack(group, "TRACK-${index + 1}", reason)
        }.toMutableList()
        val mlSupport = IntArray(tracks.size)

        // ML proposals support existing physical objects but do not independently
        // create a second LONG quantity once geometric tracks exist.
        fallback.forEach { candidate ->
            val hits = tracks.withIndex().filter { (_, track) -> supportsTrack(candidate, track) }
            when (hits.size) {
                1 -> {
                    val i = hits.first().index
                    if (candidate.source == ScanProposal.SOURCE_MLKIT) mlSupport[i]++
                    tracks[i] = mergeTrack(
                        listOf(tracks[i], candidate),
                        tracks[i].physicalInstanceHint,
                        "ML_SUPPORT_FOR_PHYSICAL_OBJECT"
                    )
                }
                0 -> {
                    suppressed += candidate.copy(
                        proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                        source = ScanProposal.SOURCE_BACKGROUND,
                        physicalInstanceHint = "UNRESOLVED-${candidate.proposalId}",
                        physicalObjectId = "",
                        quantityEligible = false,
                        bridgeSuppressed = true,
                        physicalMergeReason = "NO_PHYSICAL_TRACK_SUPPORT"
                    )
                }
                else -> {
                    suppressed += candidate.copy(
                        proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                        source = ScanProposal.SOURCE_CROSS_LANE,
                        physicalInstanceHint = "CROSS-LANE-${candidate.proposalId}",
                        physicalObjectId = "",
                        quantityEligible = false,
                        bridgeSuppressed = true,
                        physicalMergeReason = "ML_SPANS_MULTIPLE_PHYSICAL_OBJECTS"
                    )
                }
            }
        }

        // If ML explicitly supports one or more resolved physical objects, pure
        // analyzer objects with no ML support are downgraded to evidence-only.
        // This preserves the V8.4.12 background-safety behavior.
        if (mlSupport.any { it > 0 }) {
            val retained = ArrayList<ScanProposal>()
            tracks.forEachIndexed { index, track ->
                if (mlSupport[index] > 0) {
                    retained += track
                } else {
                    suppressed += track.copy(
                        proposalType = ScanProposal.TYPE_AMBIGUOUS_CONTAINER,
                        source = ScanProposal.SOURCE_BACKGROUND,
                        physicalInstanceHint = "UNSUPPORTED-${track.physicalInstanceHint}",
                        quantityEligible = false,
                        bridgeSuppressed = true,
                        physicalMergeReason = "ANALYZER_TRACK_WITHOUT_ML_SUPPORT"
                    )
                }
            }
            tracks = retained.mapIndexed { index, track ->
                val id = "TRACK-${index + 1}"
                track.copy(
                    physicalInstanceHint = id,
                    physicalObjectId = id,
                    lineageId = "TRACK-LINEAGE-$id"
                )
            }.toMutableList()
        }

        var crossingPairs = 0
        for (i in tracks.indices) for (j in i + 1 until tracks.size) {
            val a = tracks[i]
            val b = tracks[j]
            if (a.hasResolvedAxis && b.hasResolvedAxis &&
                angleDifference(a.axisAngleDeg, b.axisAngleDeg) >= CROSSING_ANGLE &&
                interiorCrossOrNear(a, b)
            ) crossingPairs++
        }

        val merged = (axisCandidates.size - groups.size).coerceAtLeast(0)
        return Result(
            proposals = tracks + suppressed,
            trackCount = tracks.size,
            crossingPairsPreserved = crossingPairs,
            crossLaneSuppressed = suppressed.count { it.source == ScanProposal.SOURCE_CROSS_LANE },
            rawAxisHypotheses = axisCandidates.size,
            physicalObjectsBeforeResolve = axisCandidates.size,
            physicalObjectsAfterResolve = tracks.size,
            hypothesesMerged = merged,
            duplicatePhysicalObjectsPrevented = merged
        )
    }

    fun crossingPairs(proposals: List<ScanProposal>): Int {
        val tracks = proposals.filter {
            it.proposalType == ScanProposal.TYPE_LONG &&
                !it.bridgeSuppressed &&
                it.physicalInstanceHint.startsWith("TRACK-")
        }
        var count = 0
        for (i in tracks.indices) for (j in i + 1 until tracks.size) {
            if (angleDifference(tracks[i].axisAngleDeg, tracks[j].axisAngleDeg) >= CROSSING_ANGLE &&
                interiorCrossOrNear(tracks[i], tracks[j])
            ) count++
        }
        return count
    }

    /** Positive score means candidate can join the physical-object group. */
    private fun groupCompatibility(group: List<ScanProposal>, candidate: ScanProposal): Int {
        var best = 0
        for (current in group) {
            val score = hypothesisCompatibility(current, candidate)
            if (score > best) best = score
        }
        if (best <= 0) return 0

        // Anti-bridge guard: a candidate may not join a group when it forms a
        // strong interior cross with any existing member. This prevents a
        // crossing rod from being swallowed by a curved-object chain.
        val conflicts = group.any { current ->
            angleDifference(current.axisAngleDeg, candidate.axisAngleDeg) >= CROSSING_ANGLE &&
                segmentsIntersectInterior(current, candidate)
        }
        return if (conflicts) 0 else best
    }

    private fun hypothesisCompatibility(a: ScanProposal, b: ScanProposal): Int {
        if (!a.hasResolvedAxis || !b.hasResolvedAxis) return 0
        val angle = angleDifference(a.axisAngleDeg, b.axisAngleDeg)
        if (angle >= CROSSING_ANGLE && segmentsIntersectInterior(a, b)) return 0

        val corridor = effectiveCorridor(a, b)
        val lineDistance = symmetricLineDistance(a, b)
        val projection = max(axisProjectionOverlap(a, b), axisProjectionOverlap(b, a))
        val overlap = intersectionOverSmaller(a.normalizedBounds, b.normalizedBounds)
        val endpointDistance = nearestEndpointDistance(a, b)

        // Same underlying straight/slightly angled support.
        if (angle <= PARALLEL_MERGE_ANGLE &&
            lineDistance <= corridor * 0.58f + 8f &&
            projection >= 0.32f
        ) {
            return 100 + (projection * 30f).toInt() - angle.toInt()
        }

        // Duplicate detector hypotheses often have almost the same occupied box
        // but quantized angles differ by one detector bin.
        if (angle <= CONTAINED_DUPLICATE_ANGLE &&
            overlap >= 0.74f &&
            segmentDistance(a, b) <= corridor * 0.45f + 6f
        ) {
            return 88 + (overlap * 20f).toInt() - angle.toInt()
        }

        // Curved physical objects can be represented by adjoining line pieces.
        // Join only at endpoints; interior intersections are explicitly rejected.
        if (angle <= ENDPOINT_CONTINUATION_ANGLE &&
            endpointDistance <= corridor * 1.05f + 12f &&
            !segmentsIntersectInterior(a, b) &&
            (projection >= 0.12f || overlap >= 0.22f)
        ) {
            return 62 + (overlap * 20f).toInt() - (angle * 0.5f).toInt()
        }

        return 0
    }

    private fun supportsTrack(candidate: ScanProposal, track: ScanProposal): Boolean {
        if (!track.hasResolvedAxis) return false
        val cx = (candidate.normalizedBounds.left + candidate.normalizedBounds.right) * 0.5f
        val cy = (candidate.normalizedBounds.top + candidate.normalizedBounds.bottom) * 0.5f
        val distance = pointToSegmentDistance(
            cx, cy,
            track.axisStartX.toFloat(), track.axisStartY.toFloat(),
            track.axisEndX.toFloat(), track.axisEndY.toFloat()
        )
        val shortAxis = min(candidate.normalizedBounds.width(), candidate.normalizedBounds.height()).coerceAtLeast(1)
        val limit = max(effectiveCorridor(track, track) * 1.15f, shortAxis * 0.70f) + 8f
        if (distance > limit) return false
        val overlap = intersectionOverSmaller(candidate.normalizedBounds, track.normalizedBounds)
        return overlap >= 0.14f || centerProjectionInside(candidate, track)
    }

    private fun centerProjectionInside(candidate: ScanProposal, track: ScanProposal): Boolean {
        val px = (candidate.normalizedBounds.left + candidate.normalizedBounds.right) * 0.5f
        val py = (candidate.normalizedBounds.top + candidate.normalizedBounds.bottom) * 0.5f
        val ax = track.axisStartX.toFloat()
        val ay = track.axisStartY.toFloat()
        val bx = track.axisEndX.toFloat()
        val by = track.axisEndY.toFloat()
        val vx = bx - ax
        val vy = by - ay
        val len2 = vx * vx + vy * vy
        if (len2 <= 1f) return false
        val t = ((px - ax) * vx + (py - ay) * vy) / len2
        return t in -0.08f..1.08f
    }

    private fun mergeTrack(group: List<ScanProposal>, trackId: String, reason: String): ScanProposal {
        val axisSource = group.filter { it.hasResolvedAxis }.maxWithOrNull(
            compareBy<ScanProposal> { it.rodStructureScore }
                .thenBy { it.axisConfidence }
                .thenBy { it.strength }
        )
        val representative = axisSource ?: group.maxByOrNull { it.strength } ?: group.first()
        val ids = group.flatMap { it.proposalId.split('+') }.filter { it.isNotBlank() }.distinct().joinToString("+")
        val sources = group.map { it.source }.distinct()

        // Keep the best axis corridor rather than unioning every hypothesis box.
        // A union of 4-5 axes recreates the V8.4.12 broad-container problem.
        val mergedBounds = if (axisSource != null) Rect(axisSource.normalizedBounds) else union(group.map { it.normalizedBounds })
        val originalBounds = if (axisSource != null) Rect(axisSource.originalBounds) else union(group.map { it.originalBounds })
        val mergedHypotheses = group.sumOf { it.hypothesesMerged.coerceAtLeast(1) }

        return representative.copy(
            proposalId = ids.ifBlank { representative.proposalId },
            source = if (sources.size == 1) sources.first() else ScanProposal.SOURCE_MERGED,
            proposalType = ScanProposal.TYPE_LONG,
            originalBounds = originalBounds,
            normalizedBounds = mergedBounds,
            lineageId = "TRACK-LINEAGE-$trackId",
            physicalInstanceHint = trackId,
            physicalObjectId = trackId,
            hypothesesMerged = mergedHypotheses,
            physicalMergeReason = reason,
            quantityEligible = true,
            bridgeSuppressed = false,
            rodStructureScore = group.maxOfOrNull { it.rodStructureScore } ?: representative.rodStructureScore,
            strength = group.maxOfOrNull { it.strength } ?: representative.strength,
            axisAngleDeg = axisSource?.axisAngleDeg ?: representative.axisAngleDeg,
            axisStartX = axisSource?.axisStartX ?: representative.axisStartX,
            axisStartY = axisSource?.axisStartY ?: representative.axisStartY,
            axisEndX = axisSource?.axisEndX ?: representative.axisEndX,
            axisEndY = axisSource?.axisEndY ?: representative.axisEndY,
            axisWidthPx = axisSource?.axisWidthPx ?: representative.axisWidthPx,
            axisConfidence = axisSource?.axisConfidence ?: representative.axisConfidence,
            orientation = axisSource?.orientation ?: representative.orientation
        )
    }

    private fun effectiveCorridor(a: ScanProposal, b: ScanProposal): Float {
        // V8.4.12 axisWidthPx was a detector corridor (~73 px on 768-wide
        // frames), not true object width. Cap it for physical-identity matching.
        val raw = min(
            a.axisWidthPx.coerceAtLeast(18),
            b.axisWidthPx.coerceAtLeast(18)
        ).toFloat()
        return raw.coerceIn(18f, 42f)
    }

    private fun interiorCrossOrNear(a: ScanProposal, b: ScanProposal): Boolean =
        segmentsIntersectInterior(a, b) || segmentDistance(a, b) <= effectiveCorridor(a, b) * 1.15f

    private fun segmentsIntersectInterior(a: ScanProposal, b: ScanProposal): Boolean {
        val result = intersectionParameters(
            a.axisStartX.toFloat(), a.axisStartY.toFloat(), a.axisEndX.toFloat(), a.axisEndY.toFloat(),
            b.axisStartX.toFloat(), b.axisStartY.toFloat(), b.axisEndX.toFloat(), b.axisEndY.toFloat()
        ) ?: return false
        return result.first in 0.12f..0.88f && result.second in 0.12f..0.88f
    }

    private fun intersectionParameters(
        ax: Float, ay: Float, bx: Float, by: Float,
        cx: Float, cy: Float, dx: Float, dy: Float
    ): Pair<Float, Float>? {
        val rX = bx - ax
        val rY = by - ay
        val sX = dx - cx
        val sY = dy - cy
        val denominator = rX * sY - rY * sX
        if (abs(denominator) < 1e-5f) return null
        val qpx = cx - ax
        val qpy = cy - ay
        val t = (qpx * sY - qpy * sX) / denominator
        val u = (qpx * rY - qpy * rX) / denominator
        return if (t in 0f..1f && u in 0f..1f) t to u else null
    }

    private fun nearestEndpointDistance(a: ScanProposal, b: ScanProposal): Float = minOf(
        hypot((a.axisStartX - b.axisStartX).toFloat(), (a.axisStartY - b.axisStartY).toFloat()),
        hypot((a.axisStartX - b.axisEndX).toFloat(), (a.axisStartY - b.axisEndY).toFloat()),
        hypot((a.axisEndX - b.axisStartX).toFloat(), (a.axisEndY - b.axisStartY).toFloat()),
        hypot((a.axisEndX - b.axisEndX).toFloat(), (a.axisEndY - b.axisEndY).toFloat())
    )

    private fun segmentDistance(a: ScanProposal, b: ScanProposal): Float = segmentDistance(
        a.axisStartX.toFloat(), a.axisStartY.toFloat(), a.axisEndX.toFloat(), a.axisEndY.toFloat(),
        b.axisStartX.toFloat(), b.axisStartY.toFloat(), b.axisEndX.toFloat(), b.axisEndY.toFloat()
    )

    private fun symmetricLineDistance(a: ScanProposal, b: ScanProposal): Float {
        val aMidX = (a.axisStartX + a.axisEndX) * 0.5f
        val aMidY = (a.axisStartY + a.axisEndY) * 0.5f
        val bMidX = (b.axisStartX + b.axisEndX) * 0.5f
        val bMidY = (b.axisStartY + b.axisEndY) * 0.5f
        val d1 = pointToSegmentDistance(aMidX, aMidY, b.axisStartX.toFloat(), b.axisStartY.toFloat(), b.axisEndX.toFloat(), b.axisEndY.toFloat())
        val d2 = pointToSegmentDistance(bMidX, bMidY, a.axisStartX.toFloat(), a.axisStartY.toFloat(), a.axisEndX.toFloat(), a.axisEndY.toFloat())
        return (d1 + d2) * 0.5f
    }

    private fun axisProjectionOverlap(a: ScanProposal, b: ScanProposal): Float {
        val ax = a.axisStartX.toFloat()
        val ay = a.axisStartY.toFloat()
        val bx = a.axisEndX.toFloat()
        val by = a.axisEndY.toFloat()
        val vx = bx - ax
        val vy = by - ay
        val length = hypot(vx, vy).coerceAtLeast(1f)
        val ux = vx / length
        val uy = vy / length
        fun projection(x: Float, y: Float): Float = (x - ax) * ux + (y - ay) * uy
        val b0 = projection(b.axisStartX.toFloat(), b.axisStartY.toFloat())
        val b1 = projection(b.axisEndX.toFloat(), b.axisEndY.toFloat())
        val bMin = min(b0, b1)
        val bMax = max(b0, b1)
        val overlap = (min(length, bMax) - max(0f, bMin)).coerceAtLeast(0f)
        val bLength = abs(bMax - bMin).coerceAtLeast(1f)
        return overlap / min(length, bLength).coerceAtLeast(1f)
    }

    private fun rectFallbackSameTrack(a: Rect, b: Rect): Boolean {
        val inter = intersectionOverSmaller(a, b)
        if (inter >= 0.72f) return true
        val caX = (a.left + a.right) * 0.5f
        val caY = (a.top + a.bottom) * 0.5f
        val cbX = (b.left + b.right) * 0.5f
        val cbY = (b.top + b.bottom) * 0.5f
        val dist = hypot(caX - cbX, caY - cbY)
        val scale = min(
            hypot(a.width().toFloat(), a.height().toFloat()),
            hypot(b.width().toFloat(), b.height().toFloat())
        ).coerceAtLeast(1f)
        return dist <= scale * 0.14f
    }

    private fun segmentDistance(
        ax: Float, ay: Float, bx: Float, by: Float,
        cx: Float, cy: Float, dx: Float, dy: Float
    ): Float {
        if (segmentsIntersect(ax, ay, bx, by, cx, cy, dx, dy)) return 0f
        return minOf(
            pointToSegmentDistance(ax, ay, cx, cy, dx, dy),
            pointToSegmentDistance(bx, by, cx, cy, dx, dy),
            pointToSegmentDistance(cx, cy, ax, ay, bx, by),
            pointToSegmentDistance(dx, dy, ax, ay, bx, by)
        )
    }

    private fun segmentsIntersect(ax: Float, ay: Float, bx: Float, by: Float, cx: Float, cy: Float, dx: Float, dy: Float): Boolean {
        fun cross(px: Float, py: Float, qx: Float, qy: Float, rx: Float, ry: Float): Float =
            (qx - px) * (ry - py) - (qy - py) * (rx - px)
        val c1 = cross(ax, ay, bx, by, cx, cy)
        val c2 = cross(ax, ay, bx, by, dx, dy)
        val c3 = cross(cx, cy, dx, dy, ax, ay)
        val c4 = cross(cx, cy, dx, dy, bx, by)
        return (c1 == 0f || c2 == 0f || c1 * c2 <= 0f) && (c3 == 0f || c4 == 0f || c3 * c4 <= 0f)
    }

    private fun pointToSegmentDistance(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val vx = bx - ax
        val vy = by - ay
        val len2 = vx * vx + vy * vy
        if (len2 <= 1e-5f) return hypot(px - ax, py - ay)
        val t = (((px - ax) * vx + (py - ay) * vy) / len2).coerceIn(0f, 1f)
        val qx = ax + vx * t
        val qy = ay + vy * t
        return hypot(px - qx, py - qy)
    }

    private fun intersectionOverSmaller(a: Rect, b: Rect): Float {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val inter = (right - left).toLong() * (bottom - top).toLong()
        val smaller = min(
            a.width().toLong() * a.height().toLong(),
            b.width().toLong() * b.height().toLong()
        ).coerceAtLeast(1L)
        return inter.toFloat() / smaller.toFloat()
    }

    private fun union(rects: List<Rect>): Rect {
        if (rects.isEmpty()) return Rect()
        return Rect(
            rects.minOf { it.left }, rects.minOf { it.top },
            rects.maxOf { it.right }, rects.maxOf { it.bottom }
        )
    }

    private fun normalizedAngle(angle: Float): Float {
        var a = angle
        while (a > 90f) a -= 180f
        while (a <= -90f) a += 180f
        return a
    }

    private fun angleDifference(a: Float, b: Float): Float {
        var d = abs(normalizedAngle(a) - normalizedAngle(b))
        if (d > 90f) d = 180f - d
        return d
    }
}
