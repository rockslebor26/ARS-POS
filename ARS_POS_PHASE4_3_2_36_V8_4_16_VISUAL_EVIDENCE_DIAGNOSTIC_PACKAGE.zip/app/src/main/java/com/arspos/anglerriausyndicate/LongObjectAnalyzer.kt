package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Phase 4.3.2.33 V8.4.13 — angle-aware LONG proposal engine.
 *
 * V8.4.10 searched only vertical/horizontal scene bands. That was safe for
 * simple poses but it could turn a diagonal/crossing rod scene into broad
 * rectangles containing floor grout and multiple rods. V8.4.11 instead scores
 * narrow contrast paths over several angles and publishes a canonical physical
 * axis for each proposal. Identity thresholds are intentionally unchanged.
 */
object LongObjectAnalyzer {
    private const val GRID_LONG_SIDE = 128
    private const val MIN_GRID_SIDE = 72
    private const val ANGLE_STEP = 15
    private const val OFFSET_STEP = 3f
    private const val SIDE_SAMPLE = 3.2f
    private const val ACTIVE_CONTRAST = 0.050f
    private const val MIN_CONTINUITY = 0.17f
    private const val MAX_PROPOSALS = 6

    data class Proposal(
        val bounds: Rect,
        val orientation: String,
        val strength: Int,
        val axisAngleDeg: Float,
        val axisStartX: Int,
        val axisStartY: Int,
        val axisEndX: Int,
        val axisEndY: Int,
        val estimatedWidthPx: Int,
        val axisConfidence: Int
    )

    private data class GridCandidate(
        val angle: Float,
        val offset: Float,
        val score: Float,
        val continuity: Float,
        val longestRun: Float,
        val contrast: Float,
        val startT: Float,
        val endT: Float
    )

    fun proposals(bitmap: Bitmap): List<Proposal> {
        if (bitmap.width < 80 || bitmap.height < 80) return emptyList()

        val scale = GRID_LONG_SIDE.toFloat() / max(bitmap.width, bitmap.height).toFloat()
        val gridW = max(MIN_GRID_SIDE, (bitmap.width * scale).roundToInt()).coerceAtMost(GRID_LONG_SIDE)
        val gridH = max(MIN_GRID_SIDE, (bitmap.height * scale).roundToInt()).coerceAtMost(GRID_LONG_SIDE)
        val small = Bitmap.createScaledBitmap(bitmap, gridW, gridH, true)

        return try {
            val gray = FloatArray(gridW * gridH)
            for (y in 0 until gridH) {
                for (x in 0 until gridW) {
                    gray[y * gridW + x] = luminance(small.getPixel(x, y))
                }
            }

            val raw = ArrayList<GridCandidate>()
            val angles = buildList {
                var angle = -75
                while (angle <= 90) {
                    add(angle.toFloat())
                    angle += ANGLE_STEP
                }
            }

            for (angle in angles) {
                val radians = Math.toRadians(angle.toDouble())
                val dx = cos(radians).toFloat()
                val dy = sin(radians).toFloat()
                val nx = -dy
                val ny = dx
                val maxOffset = abs(nx) * gridW * 0.55f + abs(ny) * gridH * 0.55f
                var offset = -maxOffset
                val perAngle = ArrayList<GridCandidate>()
                while (offset <= maxOffset) {
                    scoreLine(gray, gridW, gridH, dx, dy, nx, ny, offset)?.let { scored ->
                        if (scored.continuity >= MIN_CONTINUITY) perAngle += scored.copy(angle = angle, offset = offset)
                    }
                    offset += OFFSET_STEP
                }
                raw += perAngle.sortedByDescending { it.score }.take(3)
            }

            val selected = ArrayList<GridCandidate>()
            raw.sortedByDescending { it.score }.forEach { candidate ->
                val duplicate = selected.any { other ->
                    angleDifference(candidate.angle, other.angle) <= 10f &&
                        abs(candidate.offset - other.offset) <= 7f
                }
                if (!duplicate) selected += candidate
            }

            val widthPx = max(34, (min(bitmap.width, bitmap.height) * 0.095f).roundToInt())
            selected.take(MAX_PROPOSALS).mapNotNull { candidate ->
                val endpoints = activeLineEndpoints(gridW, gridH, candidate)
                    ?: return@mapNotNull null
                val sx = (endpoints[0] * bitmap.width / gridW.toFloat()).roundToInt().coerceIn(0, bitmap.width - 1)
                val sy = (endpoints[1] * bitmap.height / gridH.toFloat()).roundToInt().coerceIn(0, bitmap.height - 1)
                val ex = (endpoints[2] * bitmap.width / gridW.toFloat()).roundToInt().coerceIn(0, bitmap.width - 1)
                val ey = (endpoints[3] * bitmap.height / gridH.toFloat()).roundToInt().coerceIn(0, bitmap.height - 1)
                val length = hypot((ex - sx).toFloat(), (ey - sy).toFloat())
                if (length < min(bitmap.width, bitmap.height) * 0.38f) return@mapNotNull null

                val margin = max(18, widthPx / 2)
                val bounds = Rect(
                    (min(sx, ex) - margin).coerceAtLeast(0),
                    (min(sy, ey) - margin).coerceAtLeast(0),
                    (max(sx, ex) + margin).coerceAtMost(bitmap.width),
                    (max(sy, ey) + margin).coerceAtMost(bitmap.height)
                )
                if (bounds.width() < 24 || bounds.height() < 24) return@mapNotNull null

                val confidence = (
                    candidate.continuity * 55f +
                        candidate.longestRun * 30f +
                        (candidate.contrast / 0.16f).coerceIn(0f, 1f) * 15f
                    ).roundToInt().coerceIn(0, 100)
                val strength = (candidate.score * 170f).roundToInt().coerceIn(0, 100)
                val trueAngle = normalizedAngle(
                    Math.toDegrees(atan2((ey - sy).toDouble(), (ex - sx).toDouble())).toFloat()
                )

                Proposal(
                    bounds = bounds,
                    orientation = orientationName(trueAngle),
                    strength = strength,
                    axisAngleDeg = trueAngle,
                    axisStartX = sx,
                    axisStartY = sy,
                    axisEndX = ex,
                    axisEndY = ey,
                    estimatedWidthPx = widthPx,
                    axisConfidence = confidence
                )
            }
        } finally {
            if (!small.isRecycled) small.recycle()
        }
    }

    /**
     * V8.4.11 rod-structure background rejection.
     *
     * Samples across the actual detected axis instead of a broad rectangular
     * band. A tile seam may be continuous, but it normally has no sustained
     * handle/reel-seat mass. Isolated transverse crossings are penalized rather
     * than rewarded.
     */
    fun rodStructureScore(bitmap: Bitmap, proposal: Proposal): Int {
        val sx = proposal.axisStartX.toFloat()
        val sy = proposal.axisStartY.toFloat()
        val ex = proposal.axisEndX.toFloat()
        val ey = proposal.axisEndY.toFloat()
        val dx0 = ex - sx
        val dy0 = ey - sy
        val length = hypot(dx0, dy0)
        if (length < 40f) return 0

        val dx = dx0 / length
        val dy = dy0 / length
        val nx = -dy
        val ny = dx
        val majorSamples = 96
        val minorSamples = 28
        val halfWidth = max(16f, proposal.estimatedWidthPx * 0.65f)
        val occupancies = FloatArray(majorSamples)
        val centroids = FloatArray(majorSamples) { Float.NaN }

        for (m in 0 until majorSamples) {
            val t = if (majorSamples == 1) 0f else m.toFloat() / (majorSamples - 1).toFloat()
            val cx = sx + dx0 * t
            val cy = sy + dy0 * t
            val samples = FloatArray(minorSamples)
            for (s in 0 until minorSamples) {
                val u = if (minorSamples == 1) 0f else s.toFloat() / (minorSamples - 1).toFloat()
                val offset = (u - 0.5f) * 2f * halfWidth
                samples[s] = sampleLuminance(bitmap, cx + nx * offset, cy + ny * offset)
            }

            val edge = max(2, minorSamples / 8)
            var background = 0f
            var edgeCount = 0
            for (s in 0 until edge) {
                background += samples[s] + samples[minorSamples - 1 - s]
                edgeCount += 2
            }
            background /= edgeCount.coerceAtLeast(1)

            var active = 0
            var weighted = 0f
            var weight = 0f
            for (s in samples.indices) {
                val delta = abs(samples[s] - background)
                if (delta >= 0.095f) {
                    active++
                    weighted += s * delta
                    weight += delta
                }
            }
            occupancies[m] = active.toFloat() / minorSamples.toFloat()
            if (weight > 0f) centroids[m] = weighted / weight / (minorSamples - 1).coerceAtLeast(1).toFloat()
        }

        val continuity = occupancies.count { it >= 0.035f }.toFloat() / majorSamples.toFloat()
        val strongMask = occupancies.map { it >= 0.13f }
        val longestStrongRun = longestRun(strongMask).toFloat() / majorSamples.toFloat()
        val averageMass = occupancies.average().toFloat().coerceIn(0f, 1f)
        val peakMass = occupancies.maxOrNull() ?: 0f
        val variation = (peakMass - averageMass).coerceAtLeast(0f)

        val validCentroids = centroids.filter { !it.isNaN() }
        val centroidStability = if (validCentroids.size < 8) 0f else {
            val mean = validCentroids.average().toFloat()
            val variance = validCentroids.map { (it - mean) * (it - mean) }.average().toFloat()
            (1f - sqrt(variance).div(0.24f)).coerceIn(0f, 1f)
        }

        var score = 0f
        score += (continuity / 0.72f).coerceIn(0f, 1f) * 25f
        score += (longestStrongRun / 0.18f).coerceIn(0f, 1f) * 30f
        score += (averageMass / 0.18f).coerceIn(0f, 1f) * 15f
        score += (variation / 0.28f).coerceIn(0f, 1f) * 10f
        score += centroidStability * 20f

        // Uniform floor/wall seams: long and stable, but no sustained local mass.
        if (continuity >= 0.55f && longestStrongRun < 0.045f) score -= 28f
        if (averageMass < 0.055f) score -= 14f
        if (peakMass < 0.12f) score -= 14f
        // Broad lighting/tile bands can make almost the entire cross-section
        // look "active". A real rod should occupy only a bounded portion of the
        // oriented strip and should change width around handle/reel-seat areas.
        if (averageMass > 0.48f) score -= 34f
        if (continuity > 0.72f && variation < 0.055f) score -= 30f
        if (proposal.axisConfidence < 35) score -= 8f

        return score.roundToInt().coerceIn(0, 100)
    }

    /** Compatibility overload for legacy callers. */
    fun rodStructureScore(bitmap: Bitmap, bounds: Rect, orientation: String = "UNKNOWN"): Int {
        val vertical = orientation.startsWith("VERTICAL") || bounds.height() >= bounds.width()
        val sx: Int
        val sy: Int
        val ex: Int
        val ey: Int
        if (vertical) {
            sx = (bounds.left + bounds.right) / 2
            ex = sx
            sy = bounds.top
            ey = bounds.bottom
        } else {
            sy = (bounds.top + bounds.bottom) / 2
            ey = sy
            sx = bounds.left
            ex = bounds.right
        }
        val angle = if (vertical) 90f else 0f
        return rodStructureScore(
            bitmap,
            Proposal(
                bounds = Rect(bounds),
                orientation = orientation,
                strength = 50,
                axisAngleDeg = angle,
                axisStartX = sx,
                axisStartY = sy,
                axisEndX = ex,
                axisEndY = ey,
                estimatedWidthPx = max(24, min(bounds.width(), bounds.height())),
                axisConfidence = 40
            )
        )
    }

    private fun scoreLine(
        gray: FloatArray,
        width: Int,
        height: Int,
        dx: Float,
        dy: Float,
        nx: Float,
        ny: Float,
        offset: Float
    ): GridCandidate? {
        val cx = (width - 1) / 2f + nx * offset
        val cy = (height - 1) / 2f + ny * offset
        val diagonal = hypot(width.toFloat(), height.toFloat())
        val half = diagonal * 0.60f
        var t = -half
        var valid = 0
        var active = 0
        var run = 0
        var bestRun = 0
        var contrastSum = 0f
        val activeTs = ArrayList<Float>()

        while (t <= half) {
            val x = cx + dx * t
            val y = cy + dy * t
            if (x >= 4f && y >= 4f && x < width - 4f && y < height - 4f) {
                val center = sample(gray, width, height, x, y)
                val sideA = sample(gray, width, height, x + nx * SIDE_SAMPLE, y + ny * SIDE_SAMPLE)
                val sideB = sample(gray, width, height, x - nx * SIDE_SAMPLE, y - ny * SIDE_SAMPLE)
                val contrast = abs(center - (sideA + sideB) * 0.5f)
                contrastSum += contrast
                valid++
                if (contrast >= ACTIVE_CONTRAST) {
                    active++
                    activeTs += t
                    run++
                    if (run > bestRun) bestRun = run
                } else {
                    run = 0
                }
            }
            t += 1.35f
        }

        if (valid < 24) return null
        val continuity = active.toFloat() / valid.toFloat()
        val longestRun = bestRun.toFloat() / valid.toFloat()
        val contrast = contrastSum / valid.toFloat()
        if (activeTs.size < 10) return null
        val startIndex = (activeTs.size * 0.05f).toInt().coerceIn(0, activeTs.lastIndex)
        val endIndex = (activeTs.size * 0.95f).toInt().coerceIn(startIndex, activeTs.lastIndex)
        val score = contrast * 0.45f + continuity * 0.35f + longestRun * 0.20f
        return GridCandidate(0f, 0f, score, continuity, longestRun, contrast, activeTs[startIndex], activeTs[endIndex])
    }

    private fun activeLineEndpoints(width: Int, height: Int, candidate: GridCandidate): FloatArray? {
        val radians = Math.toRadians(candidate.angle.toDouble())
        val dx = cos(radians).toFloat()
        val dy = sin(radians).toFloat()
        val nx = -dy
        val ny = dx
        val cx = (width - 1) / 2f + nx * candidate.offset
        val cy = (height - 1) / 2f + ny * candidate.offset
        val pad = max(2.5f, (candidate.endT - candidate.startT) * 0.035f)
        val t0 = candidate.startT - pad
        val t1 = candidate.endT + pad
        val sx = cx + dx * t0
        val sy = cy + dy * t0
        val ex = cx + dx * t1
        val ey = cy + dy * t1
        if (sx !in -1f..width.toFloat() || ex !in -1f..width.toFloat() ||
            sy !in -1f..height.toFloat() || ey !in -1f..height.toFloat()) {
            return clippedLineEndpoints(width, height, candidate.angle, candidate.offset)
        }
        return floatArrayOf(
            sx.coerceIn(0f, width - 1f), sy.coerceIn(0f, height - 1f),
            ex.coerceIn(0f, width - 1f), ey.coerceIn(0f, height - 1f)
        )
    }

    private fun clippedLineEndpoints(width: Int, height: Int, angleDeg: Float, offset: Float): FloatArray? {
        val radians = Math.toRadians(angleDeg.toDouble())
        val dx = cos(radians).toFloat()
        val dy = sin(radians).toFloat()
        val nx = -dy
        val ny = dx
        val cx = (width - 1) / 2f + nx * offset
        val cy = (height - 1) / 2f + ny * offset
        val points = ArrayList<Pair<Float, Float>>()

        fun addIfInside(x: Float, y: Float) {
            if (x >= -0.5f && x <= width - 0.5f && y >= -0.5f && y <= height - 0.5f) {
                points += x.coerceIn(0f, width - 1f) to y.coerceIn(0f, height - 1f)
            }
        }

        if (abs(dx) > 1e-4f) {
            var t = (0f - cx) / dx
            addIfInside(0f, cy + dy * t)
            t = ((width - 1).toFloat() - cx) / dx
            addIfInside((width - 1).toFloat(), cy + dy * t)
        }
        if (abs(dy) > 1e-4f) {
            var t = (0f - cy) / dy
            addIfInside(cx + dx * t, 0f)
            t = ((height - 1).toFloat() - cy) / dy
            addIfInside(cx + dx * t, (height - 1).toFloat())
        }

        val unique = points.distinctBy { "${it.first.roundToInt()}:${it.second.roundToInt()}" }
        if (unique.size < 2) return null
        var bestA = unique[0]
        var bestB = unique[1]
        var bestDistance = -1f
        for (i in unique.indices) for (j in i + 1 until unique.size) {
            val distance = hypot(unique[j].first - unique[i].first, unique[j].second - unique[i].second)
            if (distance > bestDistance) {
                bestDistance = distance
                bestA = unique[i]
                bestB = unique[j]
            }
        }
        return floatArrayOf(bestA.first, bestA.second, bestB.first, bestB.second)
    }

    private fun sample(gray: FloatArray, width: Int, height: Int, x: Float, y: Float): Float {
        val ix = x.roundToInt().coerceIn(0, width - 1)
        val iy = y.roundToInt().coerceIn(0, height - 1)
        return gray[iy * width + ix]
    }

    private fun sampleLuminance(bitmap: Bitmap, x: Float, y: Float): Float {
        val ix = x.roundToInt().coerceIn(0, bitmap.width - 1)
        val iy = y.roundToInt().coerceIn(0, bitmap.height - 1)
        return luminance(bitmap.getPixel(ix, iy))
    }

    private fun longestRun(values: List<Boolean>): Int {
        var best = 0
        var current = 0
        values.forEach { active ->
            if (active) {
                current++
                if (current > best) best = current
            } else current = 0
        }
        return best
    }

    private fun orientationName(angle: Float): String {
        val a = normalizedAngle(angle)
        return when {
            abs(a) <= 12f -> "HORIZONTAL"
            abs(abs(a) - 90f) <= 12f -> "VERTICAL"
            else -> "ANGLE_${a.roundToInt()}"
        }
    }

    private fun normalizedAngle(angle: Float): Float {
        var a = angle
        while (a > 90f) a -= 180f
        while (a <= -90f) a += 180f
        return a
    }

    private fun angleDifference(a: Float, b: Float): Float {
        var d = abs(normalizedAngle(a) - normalizedAngle(b))
        if (d > 90f) d = 180f - d
        return d
    }

    private fun luminance(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
}
