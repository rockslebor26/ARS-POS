# ARS POS Phase 4.3.2.34 / Engine V8.4.14

Release: 1.4.9 (149)
Package: com.arspos.anglerriausyndicate
Database: v5 (unchanged)

## Scope

- Create `ROD_CLAIM` from resolved axis, structure, continuity, beam and floor evidence before final authenticity.
- A claim blocks NORMAL visual-only identity inside the rod corridor, but never creates quantity.
- `TRUSTED_ROD` remains the only LONG state eligible for cashier quantity.
- Classify short isolated secondary-line runs as background `CROSS_THROUGH`; sustained runs remain true-branch evidence.
- Preserve HANDLE, MID-SHAFT/SIDE, TIP and full oriented rod evidence for local Top-K retrieval.
- Preserve exact barcode and strong OCR as independent identity evidence.
- Preserve deterministic thresholds, duplicate prevention, typed lanes, full-frame rescue quantity safety, and memory telemetry.

## New telemetry

- rodClaim, rodClaimScore, rodClaimTracks
- rodClaimNormalHits, normalBlockedByRodClaim
- crossThroughIntersections, trueBranchIntersections
- existing anchor, retrieval, quantity, latency and memory fields remain enabled

## Safety invariants

- No threshold relaxation.
- `ROD_CLAIM` and `ROD_UNCERTAIN` are quantity-ineligible.
- Full-frame rescue remains evidence-only and quantity-ineligible.
- Database schema remains v5; no migration is introduced.
- Official signer continuity is enforced by the workflow.
