# ARS POS 1.5.1 (151) / Phase 4.3.2.36 / V8.4.16

Current prototype: **Visual Evidence Recorder + Diagnostic Scan Package**.

See `PHASE4_3_2_36_V8_4_16_VISUAL_EVIDENCE_DIAGNOSTIC_PACKAGE.md` for scope, safety invariants and the device validation plan.

This is an in-place update over official **1.5.0 (150) / V8.4.15**. Package remains `com.arspos.anglerriausyndicate`, Room database remains v5, and official signer continuity is mandatory. **Do not uninstall the existing official app before testing.**
