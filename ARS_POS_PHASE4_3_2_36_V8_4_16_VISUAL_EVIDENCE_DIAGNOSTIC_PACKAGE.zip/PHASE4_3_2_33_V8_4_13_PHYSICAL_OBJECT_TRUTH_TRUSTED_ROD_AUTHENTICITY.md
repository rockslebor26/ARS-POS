# ARS POS Phase 4.3.2.33 — V8.4.13
## Physical Object Truth + Trusted Rod Authenticity + Deterministic Track Quantity

Release identity:
- applicationId: `com.arspos.anglerriausyndicate`
- versionName: `1.4.8`
- versionCode: `148`
- database version: `5` (unchanged)
- official signing channel: unchanged
- update target: install in-place over `1.4.7 (147)` Official; **do not uninstall**

## Why this phase exists
V8.4.12 field data proved update continuity, crash safety and rolling memory behavior are healthy, but it also exposed a structural scanner problem: one physical elongated object can create several angle hypotheses (`TRACK-1..TRACK-4`). Those hypotheses can then be mistaken for several rods and can incorrectly influence the cross-category NORMAL firewall.

V8.4.13 changes the semantic model. A detected LONG line is an `AXIS_HYPOTHESIS`, not an inventory object. Hypotheses are first consolidated into physical objects; each physical object is then evaluated for rod authenticity. Only `TRUSTED_ROD` tracks may own LONG cashier quantity or block NORMAL visual-only identity.

## Non-negotiable invariants
1. Package, official signer and database schema remain unchanged.
2. `versionCode` increases from 147 to 148.
3. NORMAL and LONG lanes remain typed.
4. Recognition thresholds are not lowered (`MIN_LONG_VISUAL_MARGIN = 14`, `MIN_LONG_ANCHOR_MARGIN = 8`).
5. Axis hypotheses never directly create quantity.
6. Quantity for LONG items requires a final physical object with `TRUSTED_ROD` authenticity plus accepted identity.
7. `NON_ROD` is removed from LONG recognition/quantity.
8. `ROD_UNCERTAIN` may produce diagnostic identity evidence but is quantity-ineligible and cannot own NORMAL regions.
9. Cross-category firewall uses only trusted resolved rod tracks.
10. Barcode exact / sufficiently strong OCR remain independent identity evidence.
11. Crossing physical rods remain separate; an interior cross-axis intersection is not a merge signal.
12. Adjacent axis pieces may merge only through deterministic near-parallel / containment / endpoint-continuation evidence.
13. Full-frame rescue stays evidence-only (`quantityEligible=false`).
14. Temporary crops must be recycled and memory telemetry remains diagnostic-only.

## Core changes
### Physical Object Truth Resolver V2
`RodPhysicalTrackResolver` now groups compatible axis hypotheses before assigning `TRACK-*`. It uses:
- angle compatibility;
- symmetric centerline distance;
- projected overlap;
- high-containment duplicate evidence;
- endpoint continuation for slightly curved objects;
- explicit interior-crossing rejection to preserve two crossed rods.

The best axis corridor is retained instead of unioning all hypothesis rectangles. This prevents a broad merged box from recreating the old bridge/background problem.

### Rod Authenticity Evaluator
`RodAuthenticityEvaluator` measures actual image support around the resolved axis and records:
- measured width median/P10/P90;
- width coefficient of variation;
- endpoint taper ratio;
- centerline curvature/instability;
- multiple-cluster support;
- positive rod evidence;
- branch, beam, floor-line and shadow penalties.

The final state is one of:
- `NON_ROD`
- `ROD_UNCERTAIN`
- `TRUSTED_ROD`

This is not SKU recognition. It is a physical-category safety gate before identity/quantity.

### Cross-Category Identity Firewall V2
A NORMAL visual-only region is blocked only by `TRUSTED_ROD` tracks. Raw LONG hypotheses, `NON_ROD`, and `ROD_UNCERTAIN` tracks cannot claim NORMAL ownership. This specifically protects the field case where a branch/beam plus a genuine compact product previously caused the compact product to be blocked by phantom rod tracks.

### Adaptive oriented crop
The oriented LONG crop now uses measured physical width when available. `axisWidthPx` remains a detector corridor telemetry field, while `measuredWidthMedianPx` represents image-measured physical width. This should reduce floor/background contamination without lowering recognition thresholds.

## Required field acceptance tests
1. One real rod -> one final physical object; ideally one `TRUSTED_ROD`.
2. Two parallel rods -> exactly two final physical objects; no duplicate quantity.
3. Two crossed rods -> exactly two physical objects; crossing preserved.
4. One branch/stick -> `NON_ROD` or `ROD_UNCERTAIN`; zero LONG quantity.
5. Beam/plank -> not `TRUSTED_ROD`.
6. Tile/grout line -> not `TRUSTED_ROD`.
7. Branch + real NORMAL compact product -> branch must not block NORMAL visual-only identity.
8. Rod + genuine isolated NORMAL product -> one trusted rod plus one independent NORMAL object.
9. False compact NORMAL crop on a trusted rod -> firewall blocks visual-only path.
10. Similar rod identities -> UNKNOWN when visual/anchor margins are insufficient.
11. Repeated scan x10 -> stable physical-object count; no FC/incomplete session; 100% temporary crop recycle.
12. Full-frame rescue -> remains quantity-ineligible.
13. Memory -> no persistent native/PSS runaway growth.
14. Official update -> `1.4.7 (147) -> 1.4.8 (148)`, `IN_PLACE_UPDATE`, package and signer unchanged.

## New diagnostic fields
`SCAN_PROPOSAL_MERGE` adds:
- `rawLongHypotheses`
- `physicalObjectsBeforeResolve`
- `physicalObjectsAfterResolve`
- `hypothesesMerged`
- `duplicatePhysicalObjectsPrevented`
- `trustedRodTracks`
- `uncertainRodTracks`
- `nonRodTracks`
- `authenticitySuppressed`
- `maxRodAuthenticityScore`

Per LONG object/suppression adds:
- `physicalObjectId`
- `hypothesesMerged`
- `physicalMergeReason`
- `measuredWidthMedianPx/P10/P90`
- `widthVariance`
- `taperRatio`
- `curvatureScore`
- `rodPositiveEvidence`
- `branchPenalty`
- `beamPenalty`
- `floorLinePenalty`
- `shadowPenalty`
- `rodAuthenticityScore`
- `rodAuthenticityState`
- `trustedRod`

## Primary success criterion
A visual line is never treated as a product merely because it is long. Physical truth must be established first, rod authenticity second, identity third, and cashier quantity last.
