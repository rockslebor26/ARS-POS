# ARS QRIS Voice — Phase V1 CORE

Aplikasi Android independen untuk membacakan notifikasi pembayaran QRIS yang masuk melalui aplikasi GoPay Merchant.

## Identitas build

- Application ID: `com.ars.qrisvoice`
- Version: `1.0.0` (`versionCode 1`)
- Engine: `QRIS_NOTIFICATION_VOICE_CORE_V1`
- Target utama: Xiaomi 15 / HyperOS
- Source whitelist: `com.gojek.gopaymerchant`
- Mode: local-only
- Tidak memiliki permission INTERNET

## Voice template

`Pembayaran masuk, {nominal dalam bahasa Indonesia} rupiah. [jeda 350 ms] Terima kasih.`

TTS menggunakan locale Indonesia, speech rate 0.94, pitch 1.07, dan memilih voice Indonesia offline bila tersedia. Android TTS tidak menyediakan metadata gender/umur yang konsisten, jadi karakter “wanita muda” harus divalidasi pada engine TTS di Xiaomi 15.

## Safety / privacy

Aplikasi hanya memproses notifikasi dari package GoPay Merchant. Notifikasi aplikasi lain segera diabaikan. Aplikasi tidak mengakses PIN, OTP, password, Accessibility Service, rekening, atau API GoPay.

## Payment acceptance V1

Parser sengaja `STRICT_V1`: sebuah event baru dianggap pembayaran bila memenuhi semuanya:

1. berasal dari `com.gojek.gopaymerchant`;
2. memiliki nominal dengan format `Rp...`;
3. memiliki konteks pembayaran (`pembayaran`, `qris`, `transaksi`, atau `bayar`);
4. memiliki sinyal sukses (`berhasil`, `diterima`, `menerima`, `masuk`, atau `terbayar`);
5. tidak mengandung sinyal negatif seperti gagal, pending, refund, promo, atau pinjaman.

Format notifikasi GoPay yang sebenarnya pada akun/perangkat toko belum tersedia. Karena itu V1 menyertakan Diagnostic Mode untuk merekam struktur notifikasi GoPay. Setelah satu atau beberapa transaksi asli diuji, vocabulary parser harus dikalibrasi berdasarkan evidence tersebut sebelum dianggap final-production.

## Xiaomi 15 / HyperOS

Setelah instalasi:

1. Buka ARS QRIS Voice.
2. Tekan **AKTIFKAN AKSES NOTIFIKASI** dan izinkan ARS QRIS Voice.
3. Tekan **SETEL BACKGROUND XIAOMI / BATERAI**.
4. Di HyperOS, aktifkan **Background autostart** untuk ARS QRIS Voice.
5. Atur battery saver ke **No restrictions** bila opsi tersebut tersedia.
6. Kembali ke aplikasi dan pastikan status listener siap.
7. Tekan **TEST SUARA**.
8. Aktifkan **Diagnostic Mode** saat transaksi uji pertama.
9. Setelah transaksi, tekan **SALIN DIAGNOSTIC GOPAY** dan kirim hasilnya ke chat untuk mengunci format parser terhadap notifikasi GoPay Merchant yang nyata.

## Background behavior

Mesin utama menggunakan `NotificationListenerService`, bukan polling. Saat layar mati, Android dapat tetap memanggil listener ketika GoPay Merchant mem-posting notifikasi. Saat pembayaran diterima, aplikasi mengambil partial wake lock ber-timeout 15 detik untuk membantu menyelesaikan parsing dan TTS, kemudian timeout otomatis melepaskannya.

Catatan: Android/HyperOS dapat menghentikan layanan jika pengguna melakukan Force Stop. Setelah Force Stop, buka aplikasi kembali.

## Build

Project memakai Android Gradle Plugin 9.4.0, Gradle 9.6, JDK 17, `compileSdk 36`, dan `targetSdk 36`.

GitHub Actions tersedia di `.github/workflows/build-apk.yml`. Jalankan **Build ARS QRIS Voice APK** melalui Actions untuk menghasilkan debug APK.
