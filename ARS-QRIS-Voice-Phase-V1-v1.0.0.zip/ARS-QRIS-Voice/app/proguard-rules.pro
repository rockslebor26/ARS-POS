# ARS QRIS Voice V1 - no custom shrinking rules yet.
