package com.ars.qrisvoice

object AppConfig {
    const val APP_VERSION = "1.0.0"
    const val ENGINE = "QRIS_NOTIFICATION_VOICE_CORE_V1"
    const val GOPAY_PACKAGE = "com.gojek.gopaymerchant"
    const val ACTION_PAYMENT_ACCEPTED = "com.ars.qrisvoice.PAYMENT_ACCEPTED"
    const val DEDUP_WINDOW_MS = 30_000L
    const val WAKELOCK_TIMEOUT_MS = 15_000L
}
