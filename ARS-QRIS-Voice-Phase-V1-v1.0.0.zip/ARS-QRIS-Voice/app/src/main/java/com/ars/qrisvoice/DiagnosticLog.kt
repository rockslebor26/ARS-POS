package com.ars.qrisvoice

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DiagnosticLog {
    private const val PREFS = "ars_settings"
    private const val KEY_ENABLED = "diagnostic_enabled"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    @Synchronized
    fun append(context: Context, lines: Map<String, Any?>) {
        if (!isEnabled(context)) return
        val file = File(context.filesDir, "gopay_diagnostic.log")
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
        val body = buildString {
            append("[$ts]\n")
            lines.forEach { (key, value) -> append(key).append('=').append(value ?: "").append('\n') }
            append("---\n")
        }
        file.appendText(body)
        if (file.length() > 1_000_000) {
            val tail = file.readText().takeLast(600_000)
            file.writeText(tail)
        }
    }

    fun path(context: Context): String = File(context.filesDir, "gopay_diagnostic.log").absolutePath
}
