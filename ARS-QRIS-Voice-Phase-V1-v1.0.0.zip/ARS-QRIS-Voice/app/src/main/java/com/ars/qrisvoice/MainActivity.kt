package com.ars.qrisvoice

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var store: PaymentStore
    private lateinit var statusText: TextView
    private lateinit var latestAmountText: TextView
    private lateinit var latestTimeText: TextView
    private lateinit var todayText: TextView
    private lateinit var diagnosticSwitch: Switch

    private val paymentReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = refreshDashboard()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = PaymentStore(this)
        VoiceEngine.get(this)
        setContentView(buildUi())
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(AppConfig.ACTION_PAYMENT_ACCEPTED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(paymentReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(paymentReceiver, filter)
        }
    }

    override fun onStop() {
        runCatching { unregisterReceiver(paymentReceiver) }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        refreshDashboard()
        if (hasNotificationAccess()) {
            NotificationListenerService.requestRebind(
                ComponentName(this, GopayNotificationListenerService::class.java)
            )
        }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(30))
            setBackgroundColor(Color.rgb(17, 24, 39))
        }

        root.addView(text("ARS QRIS VOICE", 27f, true, Color.WHITE, Gravity.CENTER_HORIZONTAL))
        root.addView(text("ANGLER RIAU SYNDICATE", 13f, false, Color.LTGRAY, Gravity.CENTER_HORIZONTAL).marginBottom(26))

        statusText = text("Memeriksa...", 18f, true, Color.WHITE, Gravity.CENTER_HORIZONTAL)
        root.addView(statusText.marginBottom(24))

        root.addView(text("PEMBAYARAN TERAKHIR", 12f, true, Color.LTGRAY, Gravity.CENTER_HORIZONTAL))
        latestAmountText = text("Rp0", 38f, true, Color.WHITE, Gravity.CENTER_HORIZONTAL)
        root.addView(latestAmountText.marginTop(8))
        latestTimeText = text("Belum ada transaksi", 14f, false, Color.LTGRAY, Gravity.CENTER_HORIZONTAL)
        root.addView(latestTimeText.marginBottom(24))

        todayText = text("Hari ini: 0 transaksi • Rp0", 17f, true, Color.WHITE, Gravity.CENTER_HORIZONTAL)
        root.addView(todayText.marginBottom(22))

        root.addView(button("AKTIFKAN AKSES NOTIFIKASI") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        root.addView(button("SETEL BACKGROUND XIAOMI / BATERAI") { openBackgroundSettings() })

        root.addView(button("TEST SUARA") {
            VoiceEngine.get(this).test()
            Toast.makeText(this, "Test: Pembayaran masuk, lima puluh ribu rupiah. Terima kasih.", Toast.LENGTH_LONG).show()
        })

        root.addView(button("RIWAYAT TRANSAKSI") {
            startActivity(Intent(this, HistoryActivity::class.java))
        })

        root.addView(button("SALIN DIAGNOSTIC GOPAY") {
            val file = java.io.File(filesDir, "gopay_diagnostic.log")
            if (!file.exists() || file.length() == 0L) {
                Toast.makeText(this, "Belum ada diagnostic. Aktifkan Diagnostic Mode lalu lakukan transaksi uji.", Toast.LENGTH_LONG).show()
            } else {
                val content = file.readText().takeLast(80_000)
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("ARS QRIS Voice Diagnostic", content))
                Toast.makeText(this, "Diagnostic GoPay disalin. Tempelkan ke chat untuk kalibrasi parser.", Toast.LENGTH_LONG).show()
            }
        })

        diagnosticSwitch = Switch(this).apply {
            text = "Diagnostic Mode"
            setTextColor(Color.WHITE)
            textSize = 16f
            isChecked = DiagnosticLog.isEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                DiagnosticLog.setEnabled(this@MainActivity, checked)
                Toast.makeText(
                    this@MainActivity,
                    if (checked) "Diagnostic aktif: ${DiagnosticLog.path(this@MainActivity)}" else "Diagnostic dimatikan",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        root.addView(diagnosticSwitch.marginTop(12))

        root.addView(text(
            "V1 • ${AppConfig.ENGINE}\nLOCAL ONLY • GoPay Merchant only\nTidak menggunakan PIN, OTP, password, Accessibility Service, atau internet.",
            12f, false, Color.GRAY, Gravity.CENTER_HORIZONTAL
        ).marginTop(28))

        return ScrollView(this).apply { addView(root) }
    }

    private fun refreshDashboard() {
        val listener = hasNotificationAccess()
        val gopay = isPackageInstalled(AppConfig.GOPAY_PACKAGE)
        val connected = getSharedPreferences("ars_runtime", MODE_PRIVATE)
            .getBoolean("listener_connected", false)

        statusText.text = when {
            !gopay -> "● GOPAY MERCHANT TIDAK DITEMUKAN"
            !listener -> "● AKSES NOTIFIKASI BELUM AKTIF"
            connected -> "● SIAP • GOPAY MERCHANT"
            else -> "● AKSES AKTIF • MENUNGGU LISTENER"
        }
        statusText.setTextColor(
            if (gopay && listener) Color.rgb(74, 222, 128) else Color.rgb(248, 113, 113)
        )

        val latest = store.latest()
        latestAmountText.text = latest?.let { Formatters.rupiah(it.amount) } ?: "Rp0"
        latestTimeText.text = latest?.let { Formatters.dateTime(it.receivedAt) } ?: "Belum ada transaksi"

        val stats = store.todayStats()
        todayText.text = "Hari ini: ${stats.count} transaksi • ${Formatters.rupiah(stats.totalAmount)}"
    }

    private fun hasNotificationAccess(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.split(':')
            .mapNotNull(ComponentName::unflattenFromString)
            .any { it.packageName == packageName }
    }

    private fun isPackageInstalled(pkg: String): Boolean = runCatching {
        packageManager.getPackageInfo(pkg, 0)
        true
    }.getOrDefault(false)

    private fun openBackgroundSettings() {
        val miuiIntent = Intent("miui.intent.action.OP_AUTO_START").apply {
            addCategory(Intent.CATEGORY_DEFAULT)
        }
        val started = runCatching {
            startActivity(miuiIntent)
            true
        }.getOrDefault(false)

        if (!started) {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        }
        Toast.makeText(
            this,
            "Xiaomi/HyperOS: aktifkan Background autostart dan pilih Battery saver: No restrictions bila tersedia.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun text(value: String, size: Float, bold: Boolean, color: Int, gravity: Int): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            this.gravity = gravity
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
        setPadding(dp(12), dp(8), dp(12), dp(8))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        }
    }

    private fun View.marginTop(value: Int): View = apply {
        layoutParams = (layoutParams as? LinearLayout.LayoutParams ?: LinearLayout.LayoutParams(-1, -2)).apply { topMargin = dp(value) }
    }

    private fun View.marginBottom(value: Int): View = apply {
        layoutParams = (layoutParams as? LinearLayout.LayoutParams ?: LinearLayout.LayoutParams(-1, -2)).apply { bottomMargin = dp(value) }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
