package com.ars.qrisvoice

import java.util.Locale

object PaymentParser {
    private val amountRegex = Regex(
        pattern = "(?i)\\bRp\\s*([0-9][0-9.,\\s]*)"
    )


    private val paymentContext = listOf(
        "pembayaran", "qris", "transaksi", "bayar"
    )

    private val positiveSignals = listOf(
        "berhasil", "diterima", "menerima", "masuk", "terbayar"
    )

    private val rejectSignals = listOf(
        "gagal", "dibatalkan", "batal", "pending", "menunggu", "kedaluwarsa",
        "refund", "pengembalian", "promo", "diskon", "pinjaman"
    )

    fun parse(rawParts: List<String?>): ParsedPayment {
        val normalized = rawParts
            .filterNotNull()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .joinToString(" | ")
            .replace(Regex("\\s+"), " ")
            .trim()

        if (normalized.isBlank()) {
            return ParsedPayment(false, null, normalized, "REJECT_EMPTY_NOTIFICATION")
        }

        val lower = normalized.lowercase(Locale.forLanguageTag("id-ID"))

        if (rejectSignals.any { lower.contains(it) }) {
            return ParsedPayment(false, extractAmount(normalized), normalized, "REJECT_NEGATIVE_SIGNAL")
        }

        val amount = extractAmount(normalized)
            ?: return ParsedPayment(false, null, normalized, "REJECT_NO_RUPIAH_AMOUNT")

        val hasContext = paymentContext.any { lower.contains(it) }
        val hasPositive = positiveSignals.any { lower.contains(it) }

        if (!hasContext) {
            return ParsedPayment(false, amount, normalized, "REJECT_NO_PAYMENT_CONTEXT")
        }

        if (!hasPositive) {
            return ParsedPayment(false, amount, normalized, "REJECT_NO_SUCCESS_SIGNAL")
        }

        if (amount <= 0L) {
            return ParsedPayment(false, amount, normalized, "REJECT_INVALID_AMOUNT")
        }

        return ParsedPayment(true, amount, normalized, "PAYMENT_CONFIRMED_STRICT_V1")
    }

    fun extractAmount(text: String): Long? {
        val match = amountRegex.find(text) ?: return null
        var numeric = match.groupValues[1]
            .trim()
            .trimEnd('.', ',', ';', ':')
            .replace(" ", "")

        if (numeric.isBlank()) return null

        val lastDot = numeric.lastIndexOf('.')
        val lastComma = numeric.lastIndexOf(',')

        numeric = when {
            lastDot >= 0 && lastComma >= 0 -> {
                // Indonesian common form: 1.250.000,00. If comma has 1-2 trailing digits,
                // treat it as decimals; otherwise both separators are grouping marks.
                val commaTail = numeric.length - lastComma - 1
                if (lastComma > lastDot && commaTail in 1..2) {
                    numeric.substring(0, lastComma).replace(".", "").replace(",", "")
                } else {
                    numeric.replace(".", "").replace(",", "")
                }
            }
            lastComma >= 0 -> normalizeSingleSeparator(numeric, ',')
            lastDot >= 0 -> normalizeSingleSeparator(numeric, '.')
            else -> numeric
        }

        return numeric.toLongOrNull()
    }

    private fun normalizeSingleSeparator(value: String, separator: Char): String {
        val parts = value.split(separator)
        if (parts.size <= 1) return value
        val trailing = parts.last().length
        return when {
            parts.size > 2 -> parts.joinToString("")
            trailing == 3 -> parts.joinToString("") // Rp10,000 or Rp10.000
            trailing in 1..2 -> parts.first()        // decimal fraction, e.g. Rp10.000,00 handled above
            else -> parts.joinToString("")
        }
    }
}
