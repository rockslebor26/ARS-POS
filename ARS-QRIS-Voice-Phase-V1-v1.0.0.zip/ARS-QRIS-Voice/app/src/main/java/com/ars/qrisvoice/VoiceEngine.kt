package com.ars.qrisvoice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.ArrayDeque
import java.util.Locale

class VoiceEngine private constructor(private val appContext: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = ArrayDeque<Long>()

    init {
        tts = TextToSpeech(appContext, this)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val engine = tts ?: return
        engine.language = Locale.forLanguageTag("id-ID")
        engine.setSpeechRate(0.94f)
        engine.setPitch(1.07f)
        selectBestOfflineIndonesianVoice(engine)?.let { engine.voice = it }
        ready = true
        while (pending.isNotEmpty()) speakPaymentNow(pending.removeFirst())
    }

    @Synchronized
    fun speakPayment(amount: Long) {
        if (!ready) {
            pending.addLast(amount)
            return
        }
        speakPaymentNow(amount)
    }

    @Synchronized
    fun test() = speakPayment(50_000)

    fun isReady(): Boolean = ready

    private fun speakPaymentNow(amount: Long) {
        val engine = tts ?: return
        val amountWords = RupiahWords.spell(amount)
        val first = "Pembayaran masuk, $amountWords rupiah."
        engine.speak(first, TextToSpeech.QUEUE_ADD, null, "ars-payment-${System.nanoTime()}")
        engine.playSilentUtterance(350L, TextToSpeech.QUEUE_ADD, "ars-pause-${System.nanoTime()}")
        engine.speak("Terima kasih.", TextToSpeech.QUEUE_ADD, null, "ars-thanks-${System.nanoTime()}")
    }

    private fun selectBestOfflineIndonesianVoice(engine: TextToSpeech): Voice? {
        return engine.voices
            ?.filter { voice ->
                voice.locale.language.equals("id", ignoreCase = true) && !voice.isNetworkConnectionRequired
            }
            ?.sortedWith(compareBy<Voice> { it.name.contains("male", ignoreCase = true) }
                .thenBy { it.name })
            ?.firstOrNull()
    }

    companion object {
        @Volatile private var instance: VoiceEngine? = null

        fun get(context: Context): VoiceEngine = instance ?: synchronized(this) {
            instance ?: VoiceEngine(context.applicationContext).also { instance = it }
        }
    }
}
