package com.ars.qrisvoice

data class ParsedPayment(
    val accepted: Boolean,
    val amount: Long?,
    val normalizedText: String,
    val reason: String
)

data class PaymentRecord(
    val id: Long,
    val amount: Long,
    val receivedAt: Long,
    val fingerprint: String,
    val sourcePackage: String,
    val decisionReason: String
)

data class DailyStats(
    val count: Int,
    val totalAmount: Long
)
