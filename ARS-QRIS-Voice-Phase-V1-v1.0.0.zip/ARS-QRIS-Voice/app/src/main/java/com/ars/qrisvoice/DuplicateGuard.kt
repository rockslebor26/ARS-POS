package com.ars.qrisvoice

import android.content.Context
import java.security.MessageDigest

class DuplicateGuard(context: Context) {
    private val prefs = context.getSharedPreferences("dedup_guard", Context.MODE_PRIVATE)

    fun fingerprint(notificationKey: String, amount: Long, normalizedText: String): String {
        val canonical = "$notificationKey|$amount|${normalizedText.lowercase()}"
        val bytes = MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun isDuplicateAndRemember(fingerprint: String, now: Long): Boolean {
        val previous = prefs.getLong(fingerprint, 0L)
        val duplicate = previous > 0L && now - previous in 0..AppConfig.DEDUP_WINDOW_MS
        prefs.edit().putLong(fingerprint, now).apply()
        prune(now)
        return duplicate
    }

    private fun prune(now: Long) {
        if (prefs.all.size < 128) return
        val editor = prefs.edit()
        prefs.all.forEach { (key, value) ->
            val time = value as? Long ?: 0L
            if (now - time > 10 * 60_000L) editor.remove(key)
        }
        editor.apply()
    }
}
