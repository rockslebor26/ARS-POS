package com.ars.qrisvoice

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Calendar

class PaymentStore(context: Context) : SQLiteOpenHelper(context, "ars_qris_voice.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amount INTEGER NOT NULL,
                received_at INTEGER NOT NULL,
                fingerprint TEXT NOT NULL,
                source_package TEXT NOT NULL,
                decision_reason TEXT NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_payments_received_at ON payments(received_at)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun insert(amount: Long, receivedAt: Long, fingerprint: String, sourcePackage: String, reason: String): Long {
        val values = ContentValues().apply {
            put("amount", amount)
            put("received_at", receivedAt)
            put("fingerprint", fingerprint)
            put("source_package", sourcePackage)
            put("decision_reason", reason)
        }
        return writableDatabase.insertOrThrow("payments", null, values)
    }

    fun latest(): PaymentRecord? {
        readableDatabase.rawQuery(
            "SELECT id, amount, received_at, fingerprint, source_package, decision_reason FROM payments ORDER BY received_at DESC LIMIT 1",
            null
        ).use { c ->
            if (!c.moveToFirst()) return null
            return PaymentRecord(
                id = c.getLong(0),
                amount = c.getLong(1),
                receivedAt = c.getLong(2),
                fingerprint = c.getString(3),
                sourcePackage = c.getString(4),
                decisionReason = c.getString(5)
            )
        }
    }

    fun todayStats(now: Long = System.currentTimeMillis()): DailyStats {
        val start = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        readableDatabase.rawQuery(
            "SELECT COUNT(*), COALESCE(SUM(amount), 0) FROM payments WHERE received_at >= ?",
            arrayOf(start.toString())
        ).use { c ->
            c.moveToFirst()
            return DailyStats(c.getInt(0), c.getLong(1))
        }
    }

    fun recent(limit: Int = 100): List<PaymentRecord> {
        val out = mutableListOf<PaymentRecord>()
        readableDatabase.rawQuery(
            "SELECT id, amount, received_at, fingerprint, source_package, decision_reason FROM payments ORDER BY received_at DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out += PaymentRecord(
                    id = c.getLong(0),
                    amount = c.getLong(1),
                    receivedAt = c.getLong(2),
                    fingerprint = c.getString(3),
                    sourcePackage = c.getString(4),
                    decisionReason = c.getString(5)
                )
            }
        }
        return out
    }
}
