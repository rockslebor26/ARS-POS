package com.ars.qrisvoice

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class GopayNotificationListenerService : NotificationListenerService() {
    private lateinit var store: PaymentStore
    private lateinit var duplicateGuard: DuplicateGuard

    override fun onCreate() {
        super.onCreate()
        store = PaymentStore(applicationContext)
        duplicateGuard = DuplicateGuard(applicationContext)
        VoiceEngine.get(applicationContext)
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        getSharedPreferences("ars_runtime", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("listener_connected", true)
            .putLong("listener_connected_at", System.currentTimeMillis())
            .apply()
    }

    override fun onListenerDisconnected() {
        getSharedPreferences("ars_runtime", Context.MODE_PRIVATE)
            .edit().putBoolean("listener_connected", false).apply()
        requestRebind(componentName)
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != AppConfig.GOPAY_PACKAGE) return

        val extras = sbn.notification.extras
        val rawParts = listOf(
            extras.getCharSequence(Notification.EXTRA_TITLE)?.toString(),
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT)?.toString(),
            extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.joinToString(" | ")
        )

        val parsed = PaymentParser.parse(rawParts)
        val now = System.currentTimeMillis()

        DiagnosticLog.append(
            applicationContext,
            mapOf(
                "package" to sbn.packageName,
                "notificationKey" to sbn.key,
                "notificationId" to sbn.id,
                "postTime" to sbn.postTime,
                "title" to rawParts.getOrNull(0),
                "text" to rawParts.getOrNull(1),
                "bigText" to rawParts.getOrNull(2),
                "subText" to rawParts.getOrNull(3),
                "amount" to parsed.amount,
                "accepted" to parsed.accepted,
                "reason" to parsed.reason
            )
        )

        if (!parsed.accepted || parsed.amount == null) return

        val fingerprint = duplicateGuard.fingerprint(sbn.key, parsed.amount, parsed.normalizedText)
        if (duplicateGuard.isDuplicateAndRemember(fingerprint, now)) {
            DiagnosticLog.append(applicationContext, mapOf("decision" to "DUPLICATE_SUPPRESSED", "fingerprint" to fingerprint))
            return
        }

        val wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ARSQRISVoice:PaymentSpeech")
        wakeLock.acquire(AppConfig.WAKELOCK_TIMEOUT_MS)

        store.insert(
            amount = parsed.amount,
            receivedAt = now,
            fingerprint = fingerprint,
            sourcePackage = sbn.packageName,
            reason = parsed.reason
        )

        VoiceEngine.get(applicationContext).speakPayment(parsed.amount)

        sendBroadcast(
            Intent(AppConfig.ACTION_PAYMENT_ACCEPTED)
                .setPackage(packageName)
                .putExtra("amount", parsed.amount)
                .putExtra("receivedAt", now)
        )
    }

    private val componentName by lazy {
        android.content.ComponentName(this, GopayNotificationListenerService::class.java)
    }
}
