package com.ars.qrisvoice

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Formatters {
    private val idLocale = Locale.forLanguageTag("id-ID")

    fun rupiah(amount: Long): String = NumberFormat.getCurrencyInstance(idLocale).apply {
        maximumFractionDigits = 0
    }.format(amount)

    fun time(epochMs: Long): String = SimpleDateFormat("HH:mm:ss", idLocale).format(Date(epochMs))

    fun dateTime(epochMs: Long): String = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", idLocale).format(Date(epochMs))
}
