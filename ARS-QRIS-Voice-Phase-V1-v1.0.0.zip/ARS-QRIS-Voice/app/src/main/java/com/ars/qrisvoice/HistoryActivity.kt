package com.ars.qrisvoice

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class HistoryActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = PaymentStore(this)
        val records = store.recent(100)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(30))
            setBackgroundColor(Color.rgb(17, 24, 39))
        }

        root.addView(TextView(this).apply {
            text = "RIWAYAT PEMBAYARAN"
            textSize = 24f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_HORIZONTAL
        })

        if (records.isEmpty()) {
            root.addView(row("Belum ada pembayaran yang diterima."))
        } else {
            records.forEach { record ->
                root.addView(row("${Formatters.rupiah(record.amount)}\n${Formatters.dateTime(record.receivedAt)}"))
            }
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun row(value: String): TextView = TextView(this).apply {
        text = value
        textSize = 17f
        setTextColor(Color.WHITE)
        setPadding(dp(10), dp(14), dp(10), dp(14))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
