package com.ars.qrisvoice

object RupiahWords {
    fun spell(value: Long): String {
        require(value >= 0) { "Nominal tidak boleh negatif" }
        if (value == 0L) return "nol"
        return spellPositive(value).replace(Regex("\\s+"), " ").trim()
    }

    private fun spellPositive(n: Long): String = when {
        n < 12 -> SMALL[n.toInt()]
        n < 20 -> spellPositive(n - 10) + " belas"
        n < 100 -> spellPositive(n / 10) + " puluh" + remainder(n % 10)
        n < 200 -> "seratus" + remainder(n - 100)
        n < 1_000 -> spellPositive(n / 100) + " ratus" + remainder(n % 100)
        n < 2_000 -> "seribu" + remainder(n - 1_000)
        n < 1_000_000 -> spellPositive(n / 1_000) + " ribu" + remainder(n % 1_000)
        n < 1_000_000_000 -> spellPositive(n / 1_000_000) + " juta" + remainder(n % 1_000_000)
        n < 1_000_000_000_000 -> spellPositive(n / 1_000_000_000) + " miliar" + remainder(n % 1_000_000_000)
        n < 1_000_000_000_000_000 -> spellPositive(n / 1_000_000_000_000) + " triliun" + remainder(n % 1_000_000_000_000)
        else -> n.toString()
    }

    private fun remainder(n: Long): String = if (n == 0L) "" else " ${spellPositive(n)}"

    private val SMALL = listOf(
        "nol", "satu", "dua", "tiga", "empat", "lima",
        "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas"
    )
}
