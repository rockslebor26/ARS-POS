package com.ars.qrisvoice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PaymentParserTest {
    @Test
    fun parsesSuccessfulPayment() {
        val p = PaymentParser.parse(listOf("Pembayaran QRIS berhasil", "Kamu menerima Rp75.000"))
        assertTrue(p.accepted)
        assertEquals(75_000L, p.amount)
    }

    @Test
    fun rejectsPromo() {
        val p = PaymentParser.parse(listOf("Promo QRIS", "Diskon pembayaran Rp50.000"))
        assertFalse(p.accepted)
    }

    @Test
    fun rejectsFailedPayment() {
        val p = PaymentParser.parse(listOf("Pembayaran gagal", "QRIS Rp25.000"))
        assertFalse(p.accepted)
    }

    @Test
    fun rupiahWords() {
        assertEquals("seratus dua puluh lima ribu", RupiahWords.spell(125_000))
        assertEquals("satu juta dua ratus lima puluh ribu", RupiahWords.spell(1_250_000))
    }
}
