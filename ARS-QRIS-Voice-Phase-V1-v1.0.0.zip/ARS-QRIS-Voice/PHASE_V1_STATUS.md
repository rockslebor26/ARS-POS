# Phase V1 Status

## Implemented

- [x] GoPay Merchant package whitelist
- [x] NotificationListenerService
- [x] Screen-off/event-driven architecture
- [x] Partial wakelock timeout for payment processing
- [x] Strict payment classifier
- [x] Rupiah parser
- [x] Indonesian number-to-words
- [x] TTS queue + 350 ms pause + “Terima kasih.”
- [x] Anti-duplicate window
- [x] Local SQLite history
- [x] Daily count and total
- [x] Diagnostic log toggle + copy-to-clipboard handoff
- [x] Notification Access shortcut
- [x] Xiaomi/HyperOS background-settings shortcut with fallback
- [x] GoPay installation check
- [x] GitHub Actions APK build workflow
- [x] Unit tests for parser / number words

## Requires real Xiaomi 15 evidence before production lock

- [ ] Capture actual GoPay Merchant payment notification title/text/bigText
- [ ] Verify payment-success vocabulary
- [ ] Verify duplicate behavior for real GoPay notification updates
- [ ] Verify TTS voice choice on Xiaomi 15 sounds sufficiently young/female/natural
- [ ] Verify screen-off payment speech for repeated transactions
- [ ] Verify HyperOS background autostart / battery settings on exact OS version
- [ ] Run 20+ real/safe test payment events without false-positive or duplicate speech
