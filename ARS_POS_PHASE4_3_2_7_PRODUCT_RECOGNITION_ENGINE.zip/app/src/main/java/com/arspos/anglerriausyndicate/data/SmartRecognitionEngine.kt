package com.arspos.anglerriausyndicate.data

import android.graphics.Bitmap
import com.arspos.anglerriausyndicate.SmartProductInput
import com.arspos.anglerriausyndicate.VisualProductMatch
import com.arspos.anglerriausyndicate.data.db.ProductEntity

/**
 * Phase 4.3.2.7: ARS Product Recognition Engine.
 *
 * Prinsip utama:
 * - Kandidat selalu berasal dari katalog produk aktif, bukan hanya dari foto master.
 * - Barcode adalah identitas terkuat.
 * - OCR dicocokkan per bidang (brand/nama/variant/SKU/barcode), bukan sekadar jumlah token.
 * - Visual menggunakan referensi terbaik dari master, bila tersedia.
 * - Hasil diagnostik tetap menyimpan kandidat walau akhirnya ditolak, agar operator
 *   dapat melihat alasan kegagalan tanpa mengubah sistem menjadi "tebak saja".
 */
object SmartRecognitionEngine {
    data class Result(
        val match: VisualProductMatch?,
        val visualScore: Int,
        val textScore: Int,
        val finalScore: Int,
        val ocrText: String,
        val barcode: String = "",
        val reason: String,
        val candidates: List<RecognitionCandidate> = emptyList()
    )

    private const val ACCEPT_BARCODE = 92
    private const val ACCEPT_TEXT_WITH_VISUAL = 72
    private const val ACCEPT_VISUAL = 86
    private const val MIN_VISUAL_SUPPORT = 50

    suspend fun recognize(
        crop: Bitmap,
        products: List<ProductEntity>,
        references: List<VisualProductMatch>,
        ocr: SmartProductInput.Draft
    ): Result {
        if (products.isEmpty()) return Result(null, 0, 0, 0, ocr.rawText, ocr.barcode, "Katalog kosong")

        val normalizedOcr = normalize(ocr.rawText)
        val barcode = normalizeCode(ocr.barcode)
        val model = normalizeCode(ocr.modelCode)

        val refsByProduct = references.groupBy { it.product.id }
        val candidates = products.map { product ->
            val refs = refsByProduct[product.id].orEmpty().sortedByDescending { it.score }
            val visual = aggregateVisual(refs)
            val text = textScore(product, normalizedOcr, barcode, model)
            val final = fuse(visual, text, barcode, model, product)
            RecognitionCandidate(
                product = product,
                visualScore = visual,
                textScore = text,
                finalScore = final,
                evidence = evidence(product, visual, text, barcode, model, refs.isNotEmpty()),
                hasMaster = refs.isNotEmpty()
            )
        }.sortedWith(compareByDescending<RecognitionCandidate> { it.finalScore }.thenByDescending { it.textScore })
            .take(5)

        val best = candidates.firstOrNull()
        val accepted = best != null && accept(best, barcode, model)
        val bestReference = best?.let { refsByProduct[it.product.id].orEmpty().maxByOrNull { ref -> ref.score } }

        return Result(
            match = if (accepted) bestReference else null,
            visualScore = best?.visualScore ?: 0,
            textScore = best?.textScore ?: 0,
            finalScore = best?.finalScore ?: 0,
            ocrText = ocr.rawText,
            barcode = ocr.barcode,
            reason = if (best == null) "Tidak ada kandidat katalog" else if (accepted) best.evidence else rejectionReason(best, barcode, model),
            candidates = candidates
        )
    }

    fun textScore(product: ProductEntity, ocrText: String, barcode: String = "", model: String = ""): Int {
        val productBarcode = normalizeCode(product.barcode.orEmpty())
        if (barcode.isNotBlank() && productBarcode.isNotBlank() && barcode == productBarcode) return 100

        val normalized = normalize(ocrText)
        if (normalized.isBlank()) return 0

        val brand = normalize(product.brand.orEmpty())
        val name = normalize(product.name)
        val variant = normalize(product.variant.orEmpty())
        val sku = normalize(product.sku)

        var score = 0
        if (brand.isNotBlank() && containsPhrase(normalized, brand)) score += 30
        score += fieldTokenScore(normalized, name, 45)
        score += fieldTokenScore(normalized, variant, 15)
        if (sku.isNotBlank() && containsPhrase(normalized, sku)) score += 10
        if (productBarcode.isNotBlank() && containsPhrase(normalized, productBarcode)) score += 20

        return score.coerceIn(0, 100)
    }

    private fun aggregateVisual(refs: List<VisualProductMatch>): Int {
        if (refs.isEmpty()) return 0
        val top = refs.take(3).map { it.score }
        val best = top.first()
        val support = top.drop(1).average().takeIf { top.size > 1 } ?: best.toDouble()
        return (best * 0.78 + support * 0.22).toInt().coerceIn(0, 100)
    }

    private fun fuse(visual: Int, text: Int, barcode: String, model: String, product: ProductEntity): Int {
        if (barcode.isNotBlank() && normalizeCode(product.barcode.orEmpty()) == barcode) return 100
        if (model.isNotBlank() && text >= 90) return maxOf(text, visual)
        return when {
            text >= 80 -> (visual * 0.35f + text * 0.65f).toInt()
            text > 0 -> (visual * 0.45f + text * 0.55f).toInt()
            else -> visual
        }.coerceIn(0, 100)
    }

    private fun accept(c: RecognitionCandidate, barcode: String, model: String): Boolean {
        if (barcode.isNotBlank() && c.textScore >= ACCEPT_BARCODE) return true
        if (model.isNotBlank() && c.textScore >= 90 && c.visualScore >= MIN_VISUAL_SUPPORT) return true
        if (c.textScore >= ACCEPT_TEXT_WITH_VISUAL && c.visualScore >= MIN_VISUAL_SUPPORT) return true
        return c.visualScore >= ACCEPT_VISUAL && c.hasMaster
    }

    private fun evidence(
        product: ProductEntity,
        visual: Int,
        text: Int,
        barcode: String,
        model: String,
        hasMaster: Boolean
    ): String = when {
        barcode.isNotBlank() && normalizeCode(product.barcode.orEmpty()) == barcode -> "BARCODE COCOK + OCR + visual"
        model.isNotBlank() && text >= 90 -> "MODEL/OCR + visual"
        text >= 72 && visual >= 50 -> "OCR + visual"
        text >= 72 && !hasMaster -> "OCR kuat • master belum ada"
        visual >= 86 && hasMaster -> "Visual master kuat"
        text > 0 && visual > 0 -> "OCR + visual lemah"
        text > 0 -> "OCR sebagian • master ${if (hasMaster) "tersedia" else "belum ada"}"
        hasMaster -> "Visual saja • OCR tidak cukup"
        else -> "Belum ada bukti master/OCR yang cukup"
    }

    private fun rejectionReason(c: RecognitionCandidate, barcode: String, model: String): String = when {
        !c.hasMaster && c.textScore < ACCEPT_TEXT_WITH_VISUAL -> "Produk punya data katalog, tetapi master visual belum dibuat dan OCR belum cukup kuat"
        barcode.isNotBlank() && c.textScore < ACCEPT_BARCODE -> "Barcode terdeteksi tetapi belum cocok kuat dengan kandidat"
        c.textScore < ACCEPT_TEXT_WITH_VISUAL && c.visualScore < ACCEPT_VISUAL -> "Skor OCR dan visual belum melewati standar pengenalan"
        c.visualScore < MIN_VISUAL_SUPPORT && c.textScore < ACCEPT_TEXT_WITH_VISUAL -> "Bukti visual terlalu lemah dan OCR belum cukup"
        else -> "Bukti identitas belum cukup kuat"
    }

    private fun fieldTokenScore(ocr: String, field: String, weight: Int): Int {
        if (field.isBlank()) return 0
        if (containsPhrase(ocr, field)) return weight
        val tokens = tokenize(field).filter { it.length >= 3 && !STOP_WORDS.contains(it) }
        if (tokens.isEmpty()) return 0
        val hits = tokens.count { token -> tokenize(ocr).any { it == token || (token.length >= 5 && (it.contains(token) || token.contains(it))) } }
        return ((hits.toFloat() / tokens.size) * weight).toInt().coerceIn(0, weight)
    }

    private fun containsPhrase(text: String, phrase: String): Boolean =
        phrase.isNotBlank() && text.contains(phrase)

    private fun normalize(value: String): String = value
        .uppercase()
        .replace(Regex("[^A-Z0-9]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private fun normalizeCode(value: String): String = normalize(value).replace(" ", "")
    private fun tokenize(value: String): List<String> = value.split(" ").filter { it.isNotBlank() }

    private val STOP_WORDS = setOf(
        "SIZE", "MODEL", "VARIAN", "VARIANT", "KOREA", "KOREAN", "TECHNOLOGY",
        "QUALITY", "PREMIUM", "BEST", "THE", "AND", "FOR", "GO", "PCS", "PC",
        "MADE", "IN", "CARBON", "HOOK"
    )
}
