package com.arspos.anglerriausyndicate

import android.graphics.Rect
import com.arspos.anglerriausyndicate.data.RecognitionCandidate
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.29 V8.4.9 — lane-aware physical-instance aggregation.
 *
 * Safety invariants:
 * 1) NORMAL and LONG lanes never merge.
 * 2) evidence-only bridge/full-frame proposals never create quantity.
 * 3) two different PHYS-* long-instance hints are preserved as two products.
 * 4) duplicate crops from the same physical hint may merge.
 * 5) UNKNOWN is never promoted into an accepted SKU.
 */
object ScanResultAggregator {
    data class Summary(
        val before: Int,
        val after: Int,
        val merged: Int,
        val longGroups: Int,
        val lineageMerges: Int = 0,
        val quantitySuppressed: Int = 0,
        val distinctLongInstances: Int = 0
    )

    data class Aggregated(
        val objects: List<VisualScanObject>,
        val summary: Summary
    )

    fun aggregate(input: List<VisualScanObject>): Aggregated {
        val eligible = input.filter {
            it.quantityEligible &&
                !it.bridgeSuppressed &&
                it.proposalType != ScanProposal.TYPE_AMBIGUOUS_CONTAINER &&
                it.proposalType != ScanProposal.TYPE_RESCUE
        }
        if (eligible.size <= 1) {
            val longCount = eligible.count { isLong(it) }
            return Aggregated(
                eligible,
                Summary(
                    before = eligible.size,
                    after = eligible.size,
                    merged = 0,
                    longGroups = longCount,
                    distinctLongInstances = longCount
                )
            )
        }

        var lineageMerges = 0
        val groups = mutableListOf<MutableList<VisualScanObject>>()
        eligible.sortedBy { it.index }.forEach { candidate ->
            // Complete-linkage prevents A↔bridge↔B transitive collapse.
            val group = groups.firstOrNull { existing ->
                existing.isNotEmpty() && existing.all { current -> samePhysicalObject(current, candidate) }
            }
            if (group != null) {
                if (group.any { current ->
                        current.physicalInstanceHint.isNotBlank() &&
                            current.physicalInstanceHint == candidate.physicalInstanceHint
                    }) {
                    lineageMerges++
                }
                group += candidate
            } else {
                groups += mutableListOf(candidate)
            }
        }

        var longGroups = 0
        var firstPass = groups.map { group ->
            if (group.any { isLong(it) }) longGroups++
            mergeGroup(group)
        }.sortedBy { it.index }

        // Second-pass suppression is intentionally conservative in V8.4.9.
        // Different PHYS-* hints are treated as distinct real products even if
        // they resolve to the same SKU.
        var quantitySuppressed = 0
        val safe = mutableListOf<VisualScanObject>()
        firstPass.forEach { candidate ->
            val acceptedProductId = candidate.match?.product?.id
            if (acceptedProductId == null || !isLong(candidate)) {
                safe += candidate
                return@forEach
            }

            val existingIndex = safe.indexOfFirst { existing ->
                existing.match?.product?.id == acceptedProductId &&
                    isLong(existing) &&
                    shouldSuppressDuplicateLong(existing, candidate)
            }
            if (existingIndex >= 0) {
                val merged = mergeGroup(listOf(safe[existingIndex], candidate)).copy(
                    reason = mergeReason(
                        safe[existingIndex].reason,
                        candidate.reason,
                        "QUANTITY-SAFETY SAME PHYSICAL INSTANCE"
                    )
                )
                safe[existingIndex] = merged
                quantitySuppressed++
            } else {
                safe += candidate
            }
        }

        firstPass = safe.sortedBy { it.index }
            .mapIndexed { index, item -> item.copy(index = index + 1) }

        return Aggregated(
            objects = firstPass,
            summary = Summary(
                before = eligible.size,
                after = firstPass.size,
                merged = (eligible.size - firstPass.size).coerceAtLeast(0),
                longGroups = longGroups,
                lineageMerges = lineageMerges,
                quantitySuppressed = quantitySuppressed,
                distinctLongInstances = firstPass.filter { isLong(it) }
                    .map { it.physicalInstanceHint.ifBlank { it.proposalId } }
                    .distinct().size
            )
        )
    }

    private fun mergeGroup(group: List<VisualScanObject>): VisualScanObject {
        if (group.size == 1) return group.first()

        val representative = group.sortedWith(
            compareByDescending<VisualScanObject> { it.match != null }
                .thenByDescending { it.finalScore }
                .thenByDescending { it.visualScore }
        ).first()

        val bounds = union(group.map { it.normalizedBounds })
        val original = union(group.map { it.originalBounds })
        val candidates = mergeCandidates(group)
        val proposalIds = group.map { it.proposalId }.filter { it.isNotBlank() }.distinct().joinToString("+")
        val lineages = group.map { it.lineageId }.filter { it.isNotBlank() }.distinct()
        val physicalHints = group.map { it.physicalInstanceHint }.filter { it.isNotBlank() }.distinct()
        val sources = group.map { it.proposalSource }.filter { it.isNotBlank() }.distinct().joinToString("+")

        return representative.copy(
            index = group.minOf { it.index },
            bounds = bounds,
            originalBounds = original,
            normalizedBounds = bounds,
            proposalId = proposalIds.ifBlank { representative.proposalId },
            proposalSource = sources.ifBlank { representative.proposalSource },
            lineageId = if (lineages.size == 1) lineages.first() else representative.lineageId,
            physicalInstanceHint = if (physicalHints.size == 1) physicalHints.first() else representative.physicalInstanceHint,
            reason = mergeReason(representative.reason, "", "AGGREGATED ${group.size} proposal"),
            candidates = candidates
        )
    }

    private fun mergeReason(first: String, second: String, suffix: String): String {
        val base = listOf(first, second).map { it.trim() }.filter { it.isNotBlank() }.distinct().joinToString(" • ")
        return if (base.contains(suffix)) base else listOf(base, suffix).filter { it.isNotBlank() }.joinToString(" • ")
    }

    private fun mergeCandidates(group: List<VisualScanObject>): List<RecognitionCandidate> {
        val all = group.flatMap { it.candidates }
        if (all.isEmpty()) return emptyList()

        return all.groupBy { it.product.id }
            .values
            .map { sameProduct ->
                val best = sameProduct.maxWithOrNull(
                    compareBy<RecognitionCandidate> { it.finalScore }
                        .thenBy { it.textScore }
                        .thenBy { it.visualScore }
                ) ?: sameProduct.first()
                val support = sameProduct.size
                best.copy(
                    evidence = if (support > 1) "${best.evidence} • support=$support" else best.evidence
                )
            }
            .sortedWith(
                compareByDescending<RecognitionCandidate> { it.finalScore }
                    .thenByDescending { it.textScore }
                    .thenByDescending { it.visualScore }
            )
            .take(5)
    }

    private fun samePhysicalObject(a: VisualScanObject, b: VisualScanObject): Boolean {
        if (laneFamily(a) != laneFamily(b)) return false

        if (isLong(a) || isLong(b)) {
            val ah = a.physicalInstanceHint
            val bh = b.physicalInstanceHint
            if (ah.isNotBlank() && bh.isNotBlank()) {
                if (ah == bh) return true
                if (ah.startsWith("PHYS-") && bh.startsWith("PHYS-")) return false
            }
        }

        if (
            a.lineageId.isNotBlank() &&
            a.lineageId == b.lineageId &&
            (isLong(a) || isLong(b))
        ) return true

        val ra = a.normalizedBounds
        val rb = b.normalizedBounds
        if (iou(ra, rb) >= 0.42f) return true
        if (intersectionOverSmaller(ra, rb) >= 0.72f) return true

        val areaA = area(ra)
        val areaB = area(rb)
        val minArea = min(areaA, areaB).coerceAtLeast(1L)
        val maxArea = max(areaA, areaB).coerceAtLeast(1L)
        val areaRatio = maxArea.toFloat() / minArea.toFloat()

        val distance = centerDistance(ra, rb)
        val minDiag = min(diagonal(ra), diagonal(rb)).coerceAtLeast(1f)
        if (distance <= minDiag * 0.11f && areaRatio <= 1.85f) return true

        val topA = topCandidate(a)
        val topB = topCandidate(b)
        val sameProduct = topA != null && topB != null && topA.product.id == topB.product.id
        val longObject = isLong(a) || isLong(b) || topA?.isLongObject == true || topB?.isLongObject == true

        if (sameProduct && longObject) {
            if (confirmedDistinctParallel(a, b)) return false
            return longAligned(ra, rb)
        }

        return false
    }

    private fun shouldSuppressDuplicateLong(a: VisualScanObject, b: VisualScanObject): Boolean {
        val ah = a.physicalInstanceHint
        val bh = b.physicalInstanceHint
        if (ah.isNotBlank() && bh.isNotBlank()) {
            if (ah == bh) return true
            if (ah.startsWith("PHYS-") && bh.startsWith("PHYS-")) return false
        }
        if (confirmedDistinctParallel(a, b)) return false
        return iou(a.normalizedBounds, b.normalizedBounds) >= 0.45f ||
            intersectionOverSmaller(a.normalizedBounds, b.normalizedBounds) >= 0.78f
    }

    /** Proves two long proposals are separate parallel physical instances. */
    private fun confirmedDistinctParallel(a: VisualScanObject, b: VisualScanObject): Boolean {
        val ra = a.normalizedBounds
        val rb = b.normalizedBounds

        if (isVertical(ra) && isVertical(rb)) {
            val longOverlap = axisOverlap(ra.top, ra.bottom, rb.top, rb.bottom)
            val minLength = min(ra.height(), rb.height()).coerceAtLeast(1)
            val shortGap = abs(centerX(ra) - centerX(rb))
            val shortScale = min(ra.width(), rb.width()).coerceAtLeast(1)
            return longOverlap.toFloat() / minLength >= 0.50f && shortGap >= shortScale * 0.90f + 18f
        }

        if (isHorizontal(ra) && isHorizontal(rb)) {
            val longOverlap = axisOverlap(ra.left, ra.right, rb.left, rb.right)
            val minLength = min(ra.width(), rb.width()).coerceAtLeast(1)
            val shortGap = abs(centerY(ra) - centerY(rb))
            val shortScale = min(ra.height(), rb.height()).coerceAtLeast(1)
            return longOverlap.toFloat() / minLength >= 0.50f && shortGap >= shortScale * 0.90f + 18f
        }

        return false
    }

    private fun longAligned(a: Rect, b: Rect): Boolean {
        if (isVertical(a) && isVertical(b)) {
            val overlap = axisOverlap(a.top, a.bottom, b.top, b.bottom)
            val minLength = min(a.height(), b.height()).coerceAtLeast(1)
            val centerDx = abs(centerX(a) - centerX(b))
            val widthScale = min(a.width(), b.width()).coerceAtLeast(1)
            return overlap.toFloat() / minLength >= 0.40f && centerDx <= widthScale * 0.72f + 14f
        }

        if (isHorizontal(a) && isHorizontal(b)) {
            val overlap = axisOverlap(a.left, a.right, b.left, b.right)
            val minLength = min(a.width(), b.width()).coerceAtLeast(1)
            val centerDy = abs(centerY(a) - centerY(b))
            val heightScale = min(a.height(), b.height()).coerceAtLeast(1)
            return overlap.toFloat() / minLength >= 0.40f && centerDy <= heightScale * 0.72f + 14f
        }

        return false
    }

    private fun laneFamily(item: VisualScanObject): String = when (item.proposalType) {
        ScanProposal.TYPE_LONG -> "LONG"
        ScanProposal.TYPE_NORMAL -> "NORMAL"
        else -> item.proposalType
    }

    private fun isLong(item: VisualScanObject): Boolean =
        item.proposalType == ScanProposal.TYPE_LONG ||
            item.candidates.firstOrNull()?.isLongObject == true ||
            item.match?.let { match -> item.candidates.firstOrNull { it.product.id == match.product.id }?.isLongObject } == true

    private fun topCandidate(item: VisualScanObject): RecognitionCandidate? = item.candidates.firstOrNull()

    private fun union(rects: List<Rect>): Rect = Rect(
        rects.minOf { it.left },
        rects.minOf { it.top },
        rects.maxOf { it.right },
        rects.maxOf { it.bottom }
    )

    private fun area(r: Rect): Long =
        r.width().coerceAtLeast(0).toLong() * r.height().coerceAtLeast(0).toLong()

    private fun iou(a: Rect, b: Rect): Float {
        val intersection = intersectionArea(a, b)
        if (intersection <= 0L) return 0f
        val unionArea = area(a) + area(b) - intersection
        return if (unionArea <= 0L) 0f else intersection.toFloat() / unionArea.toFloat()
    }

    private fun intersectionOverSmaller(a: Rect, b: Rect): Float {
        val intersection = intersectionArea(a, b)
        val smaller = min(area(a), area(b)).coerceAtLeast(1L)
        return intersection.toFloat() / smaller.toFloat()
    }

    private fun intersectionArea(a: Rect, b: Rect): Long {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0L
        return (right - left).toLong() * (bottom - top).toLong()
    }

    private fun centerDistance(a: Rect, b: Rect): Float = hypot(centerX(a) - centerX(b), centerY(a) - centerY(b))
    private fun centerX(r: Rect): Float = (r.left + r.right) / 2f
    private fun centerY(r: Rect): Float = (r.top + r.bottom) / 2f
    private fun diagonal(r: Rect): Float = hypot(r.width().toFloat(), r.height().toFloat())
    private fun isVertical(r: Rect): Boolean = r.height() >= r.width() * 1.45f
    private fun isHorizontal(r: Rect): Boolean = r.width() >= r.height() * 1.45f
    private fun axisOverlap(a0: Int, a1: Int, b0: Int, b1: Int): Int =
        (min(a1, b1) - max(a0, b0)).coerceAtLeast(0)
}
