package com.arspos.anglerriausyndicate

import android.graphics.Rect

/**
 * Phase 4.3.2.29 V8.4.9 — canonical scanner proposal metadata.
 *
 * Every detector proposal is converted into original-image coordinates before
 * recognition. `physicalInstanceHint` is a conservative geometry hint used to
 * keep two real products separate while still collapsing duplicate crops of one
 * physical product. Ambiguous bridge/container proposals are evidence-only and
 * never allowed to create cashier quantity.
 */
data class ScanProposal(
    val proposalId: String,
    val source: String,
    val proposalType: String,
    val originalBounds: Rect,
    val normalizedBounds: Rect,
    val rotationDegrees: Int = 0,
    val lineageId: String,
    val physicalInstanceHint: String = "",
    val quantityEligible: Boolean = true,
    val bridgeSuppressed: Boolean = false,
    val normalOwnershipConflict: Boolean = false,
    val rodStructureScore: Int = 0,
    val orientation: String = "UNKNOWN",
    val strength: Int = 0
) {
    companion object {
        const val TYPE_NORMAL = "NORMAL_OBJECT"
        const val TYPE_LONG = "LONG_OBJECT"
        const val TYPE_RESCUE = "FULL_FRAME_RESCUE"
        const val TYPE_AMBIGUOUS_CONTAINER = "AMBIGUOUS_CONTAINER"

        const val SOURCE_MLKIT = "MLKIT"
        const val SOURCE_LONG = "LONG_ANALYZER"
        const val SOURCE_MERGED = "MERGED"
        const val SOURCE_RESCUE = "FULL_FRAME_RESCUE"
        const val SOURCE_SCENE_BARCODE = "SCENE_BARCODE"
        const val SOURCE_BRIDGE = "BRIDGE_SUPPRESSED"
        const val SOURCE_CROSS_LANE = "CROSS_LANE_SUPPRESSED"
        const val SOURCE_BACKGROUND = "BACKGROUND_REJECTED"
    }
}
