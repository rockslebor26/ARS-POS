package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.29 V8.4.9: deterministic long-object proposal engine + rod-structure gate.
 *
 * It is deliberately independent from ML Kit object proposals. Thin products
 * such as rods can disappear from a generic detector, so this analyzer searches
 * the whole photo for long, continuous contrast structures and returns several
 * safe bands. Identity is still decided by the master/identity engine.
 */
object LongObjectAnalyzer {
    private const val GRID_W = 96
    private const val GRID_H = 96
    private const val BAND_FRACTION = 0.22f
    private const val FULL_FRACTION = 0.94f
    private const val MIN_CONTINUITY = 0.18f

    data class Proposal(val bounds: Rect, val orientation: String, val strength: Int)

    fun proposals(bitmap: Bitmap): List<Proposal> {
        if (bitmap.width < 40 || bitmap.height < 40) return emptyList()
        val small = Bitmap.createScaledBitmap(bitmap, GRID_W, GRID_H, true)
        return try {
            val gray = FloatArray(GRID_W * GRID_H)
            for (y in 0 until GRID_H) for (x in 0 until GRID_W) {
                gray[y * GRID_W + x] = luminance(small.getPixel(x, y))
            }

            val vertical = rankVertical(gray)
            val horizontal = rankHorizontal(gray)
            val out = ArrayList<Proposal>()

            vertical.take(4).forEach { (center, score) ->
                val band = bandRect(bitmap.width, bitmap.height, center / GRID_W.toFloat(), true)
                if (score >= MIN_CONTINUITY) out += Proposal(band, "VERTICAL", (score * 100f).toInt().coerceIn(0, 100))
            }
            horizontal.take(4).forEach { (center, score) ->
                val band = bandRect(bitmap.width, bitmap.height, center / GRID_H.toFloat(), false)
                if (score >= MIN_CONTINUITY) out += Proposal(band, "HORIZONTAL", (score * 100f).toInt().coerceIn(0, 100))
            }

            // Center strips are useful when the rod is deliberately placed in
            // the middle of the customer's photo, even if edge contrast is weak.
            out += Proposal(centerStrip(bitmap.width, bitmap.height, true), "VERTICAL_CENTER", 45)
            out += Proposal(centerStrip(bitmap.width, bitmap.height, false), "HORIZONTAL_CENTER", 45)

            out.distinctBy { "${it.bounds.left}:${it.bounds.top}:${it.bounds.right}:${it.bounds.bottom}" }
                .sortedByDescending { it.strength }
                .take(8)
        } finally {
            small.recycle()
        }
    }

    private fun rankVertical(gray: FloatArray): List<Pair<Int, Float>> {
        val scores = FloatArray(GRID_W)
        for (x in 3 until GRID_W - 3) {
            var contrast = 0f
            var continuity = 0
            for (y in 4 until GRID_H - 4) {
                val center = gray[y * GRID_W + x]
                val side = (gray[y * GRID_W + x - 3] + gray[y * GRID_W + x + 3]) / 2f
                val c = abs(center - side)
                contrast += c
                if (c > 0.045f) continuity++
            }
            val cont = continuity.toFloat() / (GRID_H - 8).coerceAtLeast(1)
            scores[x] = (contrast / (GRID_H - 8).coerceAtLeast(1)) * 0.55f + cont * 0.45f
        }
        return nonMaximum(scores, 7)
    }

    private fun rankHorizontal(gray: FloatArray): List<Pair<Int, Float>> {
        val scores = FloatArray(GRID_H)
        for (y in 3 until GRID_H - 3) {
            var contrast = 0f
            var continuity = 0
            for (x in 4 until GRID_W - 4) {
                val center = gray[y * GRID_W + x]
                val side = (gray[(y - 3) * GRID_W + x] + gray[(y + 3) * GRID_W + x]) / 2f
                val c = abs(center - side)
                contrast += c
                if (c > 0.045f) continuity++
            }
            val cont = continuity.toFloat() / (GRID_W - 8).coerceAtLeast(1)
            scores[y] = (contrast / (GRID_W - 8).coerceAtLeast(1)) * 0.55f + cont * 0.45f
        }
        return nonMaximum(scores, 7)
    }

    private fun nonMaximum(values: FloatArray, radius: Int): List<Pair<Int, Float>> {
        val candidates = values.indices
            .filter { i -> i >= 3 && i < values.lastIndex - 3 }
            .sortedByDescending { values[it] }
        val selected = ArrayList<Pair<Int, Float>>()
        for (i in candidates) {
            if (selected.none { abs(it.first - i) <= radius }) selected += i to values[i]
            if (selected.size >= 6) break
        }
        return selected
    }

    private fun bandRect(width: Int, height: Int, normalizedCenter: Float, vertical: Boolean): Rect {
        return if (vertical) {
            val bw = (width * BAND_FRACTION).toInt().coerceAtLeast(36).coerceAtMost(width)
            val bh = (height * FULL_FRACTION).toInt().coerceAtLeast(36).coerceAtMost(height)
            val cx = (width * normalizedCenter).toInt().coerceIn(0, width - 1)
            val left = (cx - bw / 2).coerceIn(0, width - bw)
            val top = (height - bh) / 2
            Rect(left, top, left + bw, top + bh)
        } else {
            val bw = (width * FULL_FRACTION).toInt().coerceAtLeast(36).coerceAtMost(width)
            val bh = (height * BAND_FRACTION).toInt().coerceAtLeast(36).coerceAtMost(height)
            val cy = (height * normalizedCenter).toInt().coerceIn(0, height - 1)
            val top = (cy - bh / 2).coerceIn(0, height - bh)
            val left = (width - bw) / 2
            Rect(left, top, left + bw, top + bh)
        }
    }

    private fun centerStrip(width: Int, height: Int, vertical: Boolean): Rect =
        bandRect(width, height, 0.5f, vertical)


    /**
     * V8.4.9 background-rejection gate.
     *
     * A long rectangle is not automatically a rod. Tile grout, wall edges and
     * table seams can be long and high-contrast too. This scorer looks for a
     * narrow continuous foreground path PLUS local width/mass variation that is
     * typical of a rod handle/reel-seat/blank combination. It is only a proposal
     * quality signal; it never lowers SKU recognition thresholds.
     */
    fun rodStructureScore(bitmap: Bitmap, bounds: Rect, orientation: String = "UNKNOWN"): Int {
        if (bitmap.width < 24 || bitmap.height < 24) return 0
        val safe = Rect(
            bounds.left.coerceIn(0, bitmap.width - 1),
            bounds.top.coerceIn(0, bitmap.height - 1),
            bounds.right.coerceIn(1, bitmap.width),
            bounds.bottom.coerceIn(1, bitmap.height)
        )
        if (safe.right <= safe.left || safe.bottom <= safe.top) return 0

        val crop = runCatching {
            Bitmap.createBitmap(bitmap, safe.left, safe.top, safe.width(), safe.height())
        }.getOrNull() ?: return 0

        val sourceW = crop.width
        val sourceH = crop.height
        val vertical = orientation.startsWith("VERTICAL") || sourceH >= sourceW
        val targetW = if (vertical) 48 else 128
        val targetH = if (vertical) 128 else 48
        val small = Bitmap.createScaledBitmap(crop, targetW, targetH, true)
        if (small !== crop && !crop.isRecycled) crop.recycle()

        return try {
            val major = if (vertical) targetH else targetW
            val minor = if (vertical) targetW else targetH
            val occupancies = FloatArray(major)

            for (m in 0 until major) {
                val edgeBand = max(2, minor / 8)
                var edgeSum = 0f
                var edgeCount = 0
                for (s in 0 until edgeBand) {
                    val c1 = if (vertical) small.getPixel(s, m) else small.getPixel(m, s)
                    val c2 = if (vertical) small.getPixel(minor - 1 - s, m) else small.getPixel(m, minor - 1 - s)
                    edgeSum += luminance(c1) + luminance(c2)
                    edgeCount += 2
                }
                val background = edgeSum / edgeCount.coerceAtLeast(1)

                var active = 0
                for (s in 0 until minor) {
                    val c = if (vertical) small.getPixel(s, m) else small.getPixel(m, s)
                    if (abs(luminance(c) - background) >= 0.11f) active++
                }
                occupancies[m] = active.toFloat() / minor.toFloat()
            }

            val continuity = occupancies.count { it >= 0.025f }.toFloat() / major.toFloat()
            val anchorMass = occupancies.count { it >= 0.12f }.toFloat() / major.toFloat()
            val averageMass = occupancies.average().toFloat().coerceIn(0f, 1f)
            val peakMass = occupancies.maxOrNull() ?: 0f
            val widthVariation = (peakMass - averageMass).coerceAtLeast(0f)

            val continuityScore = continuity * 20f
            val anchorScore = (anchorMass / 0.28f).coerceIn(0f, 1f) * 35f
            val massScore = (averageMass / 0.22f).coerceIn(0f, 1f) * 20f
            val variationScore = (widthVariation / 0.30f).coerceIn(0f, 1f) * 25f

            val aspect = max(sourceW, sourceH).toFloat() /
                min(sourceW, sourceH).coerceAtLeast(1).toFloat()
            val aspectPenalty = if (aspect < 1.8f) 14f else 0f

            (continuityScore + anchorScore + massScore + variationScore - aspectPenalty)
                .toInt()
                .coerceIn(0, 100)
        } finally {
            if (!small.isRecycled) small.recycle()
        }
    }

    private fun luminance(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
}
