# ARS POS 1.10.7 (207) — V8.8.5 Release 207

- Phase: `4.3.5.5`
- Engine: `V8.8.5`
- Revision: `CANONICAL_PHYSICAL_TARGET_FAST_IDENTITY_CONVERGENCE_R1`
- Previous official source: `1.10.6 (206)`
- Current candidate: `1.10.7 (207)`
- Package: `com.arspos.anglerriausyndicate`
- Room DB: `5`
- Update path: in-place only

## Smart Scan changes

- post-recovery canonical NORMAL resolution;
- NORMAL completeness / fragment safety gate;
- sticky identity owner scheduler;
- visual-first single-object identity path;
- bounded multi-object identity scheduling;
- OCR expected-utility routing;
- stale best-frame rejection at final lock;
- selected persistent-track finalization;
- candidate-level live/final convergence telemetry;
- canonical/completeness metadata persisted into decision evidence.

## Safety retained

- all 14 recognition thresholds unchanged;
- `Cloud Identity=SHADOW`;
- `Self Learning=ACTIVE_CONFIRMED_ONLY`;
- `ARS AI Engineer=DEV_CENTER_DIAGNOSTIC_ONLY`;
- cloud/AI cannot create quantity, change stock/payment, relax recognition thresholds, change signer, or install APK;
- Safety Kernel, Decision Evidence Ledger, Ground Truth and Replay V4 remain active.

## Verification status

Source static invariants and targeted pure-Kotlin policy compile checks must pass before packaging. Full Android debug/release compilation, unit/JVM regression tests, official signing and APK metadata verification are performed by the supplied GitHub Actions workflow. Real-device Smart Scan acceptance remains mandatory before this phase is declared finished.
