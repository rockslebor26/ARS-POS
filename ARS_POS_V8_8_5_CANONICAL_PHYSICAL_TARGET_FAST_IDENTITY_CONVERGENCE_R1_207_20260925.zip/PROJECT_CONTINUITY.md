# ARS POS Project Continuity

Current source candidate: **1.10.7 (207) / Phase 4.3.5.5 / V8.8.5 — Canonical Physical Target + Fast Identity Convergence R1**.

Direct source predecessor: **1.10.6 (206) / Phase 4.3.5.4 / V8.8.4 Sticky Physical Lock + Best-Evidence Identity Convergence R3**. Package, Room v5, official signer and all 14 recognition thresholds remain unchanged.

## Current architecture direction

Smart Scan now treats canonical physical truth as a prerequisite for identity. Base NORMAL proposals and NON_ROD-to-NORMAL rescue output are re-resolved after recovery. Purity and completeness are separate: a clean crop may still be only a fragment of a larger foreground owner and therefore may not independently own quantity.

Once a persistent physical target is selected, it becomes a sticky identity owner. Identity work does not silently round-robin to another track while the owner is in OCR/high-resolution cooldown. Single-object scenes receive a visual-first fast path; multi-object scenes retain all tracks but schedule expensive identity work selectively.

OCR is evidence escalation, not the default. A utility gate skips low-information OCR for strong visual-only/HYBRID_VISUAL candidates and escalates to better visual evidence instead. Final lock rejects stale best frames and explicitly selected tracks scope final identity while scene-wide physical safety still resolves all proposals.

Live/final convergence now compares candidate identity even when final recognition remains AMBIGUOUS, so field reports can distinguish candidate continuity from acceptance.

ARS AI Engineer remains `DEV_CENTER_DIAGNOSTIC_ONLY`; Cloud Identity remains `SHADOW`; Self Learning remains `ACTIVE_CONFIRMED_ONLY`.

## Finish criteria

Smart Scan is not declared finished by source/build success alone. Signed real-device evidence must demonstrate: one physical object resolves to one canonical transaction object, no selected-track mismatch, no identity-owner thrashing after lock, no duplicate quantity, materially faster first candidate and stable identity, bounded OCR/high-resolution work, live/final candidate continuity, safe LONG/rod authenticity, bounded memory/native pressure, and safe in-place upgrade behavior.
