# ARS POS 1.10.7 (207) — Phase 4.3.5.5 / V8.8.5

**Canonical Physical Target + Fast Identity Convergence R1**

V8.8.5 is the Smart Scan architecture correction after V8.8.4 field evidence showed that physical lock could be stable while identity ownership still rotated, rescued NORMAL fragments could remain separate transaction candidates, and low-information OCR/high-resolution work could dominate latency.

Production pipeline:

`detect → physical track → post-recovery canonical object resolve → completeness/independent-instance gate → persistent ID → sticky identity owner → visual-first Top-K → exact rerank → utility-based evidence escalation → live/final candidate convergence → Safety Kernel → quantity`.

## Release invariants

- Package: `com.arspos.anglerriausyndicate`
- versionName/versionCode: `1.10.7 / 207`
- Phase/engine: `4.3.5.5 / V8.8.5`
- Revision: `CANONICAL_PHYSICAL_TARGET_FAST_IDENTITY_CONVERGENCE_R1`
- Room database: `v5`, no destructive migration
- Cloud Identity: `SHADOW`
- Self Learning: `ACTIVE_CONFIRMED_ONLY`
- ARS AI Engineer: `DEV_CENTER_DIAGNOSTIC_ONLY`
- AI in critical Smart Scan path: disabled
- Recognition thresholds: unchanged (14/14)
- Official signer SHA-256: `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`
- Update method: in-place only; do not uninstall production data.

See `PHASE4_3_5_5_V8_8_5_CANONICAL_PHYSICAL_TARGET_FAST_IDENTITY_CONVERGENCE_R1.md` and `RELEASE_207.md`.
