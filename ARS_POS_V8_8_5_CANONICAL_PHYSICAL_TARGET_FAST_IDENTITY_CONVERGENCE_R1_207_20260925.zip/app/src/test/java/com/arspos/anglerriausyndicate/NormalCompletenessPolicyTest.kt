package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test

class NormalCompletenessPolicyTest {
    @Test fun nearWholeOwnerIsComplete() {
        val result = NormalCompletenessPolicy.evaluate(1, 1.07f, 1)
        assertEquals(NormalCompletenessPolicy.STATE_COMPLETE, result.state)
        assertTrue(result.safeForQuantity)
        assertTrue(result.score >= 90)
    }

    @Test fun partialOwnerRatioIsNotClampedAway() {
        val result = NormalCompletenessPolicy.evaluate(1, 1.90f, 1)
        assertEquals(NormalCompletenessPolicy.STATE_PARTIAL, result.state)
        assertFalse(result.safeForQuantity)
        assertTrue(result.score in 45..60)
    }

    @Test fun severeFragmentsStayPartial() {
        val fourX = NormalCompletenessPolicy.evaluate(1, 4.20f, 1)
        val nineX = NormalCompletenessPolicy.evaluate(1, 9.00f, 1)
        assertFalse(fourX.safeForQuantity)
        assertFalse(nineX.safeForQuantity)
        assertTrue(nineX.score < fourX.score)
    }

    @Test fun unmeasuredCompletenessIsNeutralNotNewFalseNegative() {
        val result = NormalCompletenessPolicy.evaluate(0, 0f, 1)
        assertEquals(NormalCompletenessPolicy.STATE_NOT_MEASURED, result.state)
        assertTrue(result.safeForQuantity)
    }
}
