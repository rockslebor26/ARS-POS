package com.arspos.anglerriausyndicate

import org.junit.Assert.assertEquals
import org.junit.Test

class LiveEvidenceEscalationPolicyTest {
    @Test fun detectorOnlyPassDoesNotPretendIdentityFailed() {
        assertEquals(
            LiveEvidenceEscalationPolicy.TRACK_ONLY,
            LiveEvidenceEscalationPolicy.stage(false, false, 0, 0, false, false, false)
        )
    }

    @Test fun repeatedEmptyOcrEscalatesToHighResolutionInsteadOfRepeatingOcr() {
        assertEquals(
            LiveEvidenceEscalationPolicy.HIGH_RES_REQUIRED,
            LiveEvidenceEscalationPolicy.stage(true, false, 84, 0, false, true, false)
        )
    }

    @Test fun unresolvedHighResolutionRequestsNewViewpoint() {
        assertEquals(
            LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED,
            LiveEvidenceEscalationPolicy.stage(true, false, 84, 0, false, false, true)
        )
    }

    @Test fun acceptedIdentityFreezesAtConfirmationStage() {
        assertEquals(
            LiveEvidenceEscalationPolicy.CONFIRMED,
            LiveEvidenceEscalationPolicy.stage(true, true, 82, 15, true, false, false)
        )
    }
    @Test fun lowUtilityOcrEscalatesDirectlyToHighResolution() {
        assertEquals(
            LiveEvidenceEscalationPolicy.HIGH_RES_REQUIRED,
            LiveEvidenceEscalationPolicy.stage(true, false, 88, 2, false, false, false, ocrUseful = false)
        )
    }

}
