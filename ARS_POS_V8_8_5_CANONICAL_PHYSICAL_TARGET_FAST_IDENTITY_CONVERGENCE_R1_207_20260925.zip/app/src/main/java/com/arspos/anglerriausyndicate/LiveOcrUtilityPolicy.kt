package com.arspos.anglerriausyndicate

import com.arspos.anglerriausyndicate.data.ProductIdentityProfile
import com.arspos.anglerriausyndicate.data.db.ProductEntity

/**
 * V8.8.5 evidence-utility gate for live OCR.
 *
 * OCR is expensive. Visual-only / HYBRID_VISUAL masters should first receive
 * visual/high-resolution evidence when the image is already strong. Products
 * with barcode/model/text identity hints keep OCR available. This changes only
 * evidence scheduling; SmartRecognitionEngine thresholds are untouched.
 */
object LiveOcrUtilityPolicy {
    data class Result(val shouldRun: Boolean, val score: Int, val reason: String)

    fun evaluate(
        product: ProductEntity?,
        profile: ProductIdentityProfile?,
        visualScore: Int,
        margin: Int,
        visualDecisionRule: String
    ): Result {
        if (product == null) return Result(false, 0, "OCR_NO_CANDIDATE")
        val mode = profile?.recognitionMode.orEmpty().uppercase()
        val visualMaster = mode == "VISUAL_ONLY" || mode == "HYBRID_VISUAL"
        val hasStrongTextHint = !product.barcode.isNullOrBlank() ||
            !profile?.barcode.isNullOrBlank() ||
            !profile?.modelCode.isNullOrBlank() ||
            profile?.rawText.orEmpty().trim().length >= 3

        if (visualMaster && visualScore >= 80 && visualDecisionRule in setOf(
                "REJECT_VISUAL_MARGIN", "REJECT_VISUAL_SECOND_MARGIN", "REJECT_IDENTITY_MARGIN",
                "REJECT_NORMAL_REQUIRES_IDENTITY", "REJECT_TEXT_TOO_WEAK"
            )
        ) {
            return Result(false, 15, "OCR_LOW_UTILITY_VISUAL_MASTER")
        }

        var score = 25
        if (hasStrongTextHint) score += 45
        if (!product.brand.isNullOrBlank()) score += 10
        if (!product.variant.isNullOrBlank()) score += 8
        if (visualScore >= 72 && margin < LiveIdentityPolicy.AMBIGUOUS_VISUAL_MARGIN) score += 12
        score = score.coerceIn(0, 100)
        return Result(score >= 55, score, if (score >= 55) "OCR_IDENTITY_HINTS_PRESENT" else "OCR_LOW_EXPECTED_INFORMATION_GAIN")
    }
}
