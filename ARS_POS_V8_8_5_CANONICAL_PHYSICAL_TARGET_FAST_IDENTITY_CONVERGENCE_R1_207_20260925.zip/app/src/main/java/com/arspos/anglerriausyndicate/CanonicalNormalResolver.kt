package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * V8.8.5 post-recovery canonical NORMAL resolver.
 *
 * NormalPhysicalResolver operates on the proposal set available at that moment.
 * V8.8.5 adds this second, authoritative pass after NON_ROD -> NORMAL rescue so
 * base NORMAL proposals and rescued fragments cannot become multiple physical
 * quantity objects merely because they entered the NORMAL lane at different
 * stages of the pipeline.
 */
object CanonicalNormalResolver {
    data class Result(
        val proposals: List<ScanProposal>,
        val before: Int,
        val after: Int,
        val fragmentsMerged: Int,
        val sharedForegroundMerges: Int,
        val independentInstancesConfirmed: Int
    )

    fun resolve(
        input: List<ScanProposal>,
        frameWidth: Int,
        frameHeight: Int,
        session: String = ""
    ): Result {
        if (input.isEmpty()) return Result(emptyList(), 0, 0, 0, 0, 0)

        val pending = input.indices.toMutableSet()
        val groups = ArrayList<List<Int>>()
        var independentConfirmed = 0

        while (pending.isNotEmpty()) {
            val seed = pending.first()
            pending.remove(seed)
            val group = mutableListOf(seed)
            var changed: Boolean
            do {
                changed = false
                val candidates = pending.toList()
                for (candidate in candidates) {
                    val merge = group.any { member -> shouldCanonicalize(input[member], input[candidate]) }
                    if (merge) {
                        group += candidate
                        pending.remove(candidate)
                        changed = true
                    } else if (group.any { member -> sameForegroundOwner(input[member], input[candidate]) } &&
                        group.all { member -> independentlyComplete(input[member], input[candidate]) }
                    ) {
                        independentConfirmed++
                    }
                }
            } while (changed)
            groups += group
        }

        var canonicalIndex = 1
        var mergedFragments = 0
        var sharedMerges = 0
        val output = groups.map { group ->
            val members = group.map { input[it] }
            if (members.size > 1) {
                mergedFragments += members.size - 1
                if (members.map { it.normalForegroundComponent }.filter { it > 0 }.distinct().size == 1) sharedMerges++
            }
            canonicalize(members, canonicalIndex++, frameWidth, frameHeight, session)
        }

        return Result(
            proposals = output,
            before = input.size,
            after = output.size,
            fragmentsMerged = mergedFragments,
            sharedForegroundMerges = sharedMerges,
            independentInstancesConfirmed = independentConfirmed
        )
    }

    private fun canonicalize(
        members: List<ScanProposal>,
        canonicalIndex: Int,
        frameWidth: Int,
        frameHeight: Int,
        session: String
    ): ScanProposal {
        val representative = members.maxWithOrNull(
            compareBy<ScanProposal> { it.normalPurityScore }
                .thenBy { it.normalForegroundCoverage }
                .thenBy { area(it.normalizedBounds) }
        ) ?: members.first()

        val unionBounds = members.map { it.normalizedBounds }.reduce(::union)
        val unionOriginal = members.map { it.originalBounds }.reduce(::union)
        val component = members.map { it.normalForegroundComponent }.filter { it > 0 }
            .groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: representative.normalForegroundComponent

        val ownerBounds = members.firstOrNull {
            it.normalForegroundComponent == component &&
                it.normalForegroundRight > it.normalForegroundLeft &&
                it.normalForegroundBottom > it.normalForegroundTop
        }?.let {
            Rect(it.normalForegroundLeft, it.normalForegroundTop, it.normalForegroundRight, it.normalForegroundBottom)
        }

        val frameArea = frameWidth.coerceAtLeast(1).toLong() * frameHeight.coerceAtLeast(1).toLong()
        val cropArea = area(unionBounds).coerceAtLeast(1L)
        val ownerArea = ownerBounds?.let(::area) ?: 0L
        val cropAreaRatio = cropArea.toFloat() / frameArea.toFloat()
        val ownerAreaRatio = if (ownerArea > 0L) ownerArea.toFloat() / cropArea.toFloat() else 0f
        val foregroundCoverage = members.maxOfOrNull { it.normalForegroundCoverage } ?: 0f
        val mergedCount = members.sumOf { it.hypothesesMerged.coerceAtLeast(1) }
        val purity = NormalProposalPurityPolicy.evaluate(
            cropAreaRatio = cropAreaRatio,
            foregroundComponent = component,
            foregroundCoverage = foregroundCoverage,
            ownerAreaRatio = ownerAreaRatio,
            ambiguousOverlap = members.any { it.normalOwnershipConflict },
            mergedProposals = mergedCount
        )
        val completeness = NormalCompletenessPolicy.evaluate(component, ownerAreaRatio, mergedCount)
        val canonicalId = "CANONICAL-NORMAL-$canonicalIndex"
        val inputMayOwnQuantity = members.any { it.quantityEligible }
        val quantityEligible = inputMayOwnQuantity && purity.safeForQuantity && completeness.safeForQuantity &&
            members.none { it.normalOwnershipConflict }
        val fragmentState = when {
            members.size > 1 -> "MERGED_FRAGMENT"
            completeness.state == NormalCompletenessPolicy.STATE_PARTIAL -> "PARTIAL"
            completeness.state == NormalCompletenessPolicy.STATE_COMPLETE -> "COMPLETE"
            else -> "UNKNOWN"
        }
        val reason = buildList {
            add(if (members.size > 1) "POST_RECOVERY_CANONICAL_MERGE" else "POST_RECOVERY_CANONICAL_SINGLE")
            if (!purity.safeForQuantity) add(purity.reason)
            if (!completeness.safeForQuantity) add(completeness.reason)
        }.joinToString("+")

        ArsFlightRecorder.event(
            "SCAN_CANONICAL_NORMAL",
            "V8.8.5 post-recovery canonical NORMAL resolution",
            mapOf(
                "session" to session,
                "canonicalPhysicalObjectId" to canonicalId,
                "proposalIds" to members.joinToString(",") { it.proposalId },
                "foregroundComponent" to component,
                "members" to members.size,
                "normalPurityScore" to purity.score,
                "normalCompletenessScore" to completeness.score,
                "normalCompletenessState" to completeness.state,
                "fragmentState" to fragmentState,
                "ownerAreaRatio" to ownerAreaRatio,
                "inputMayOwnQuantity" to inputMayOwnQuantity,
                "quantityEligible" to quantityEligible
            )
        )

        return representative.copy(
            proposalId = members.joinToString("+") { it.proposalId },
            source = if (members.map { it.source }.distinct().size == 1) representative.source else ScanProposal.SOURCE_MERGED,
            originalBounds = unionOriginal,
            normalizedBounds = unionBounds,
            lineageId = "CANONICAL-LINEAGE-$canonicalId",
            physicalInstanceHint = canonicalId,
            physicalObjectId = canonicalId,
            hypothesesMerged = mergedCount,
            physicalMergeReason = listOf(representative.physicalMergeReason, reason).filter { it.isNotBlank() }.joinToString("+"),
            quantityEligible = quantityEligible,
            normalForegroundComponent = component,
            normalForegroundCoverage = foregroundCoverage,
            normalForegroundLeft = ownerBounds?.left ?: representative.normalForegroundLeft,
            normalForegroundTop = ownerBounds?.top ?: representative.normalForegroundTop,
            normalForegroundRight = ownerBounds?.right ?: representative.normalForegroundRight,
            normalForegroundBottom = ownerBounds?.bottom ?: representative.normalForegroundBottom,
            normalPurityScore = purity.score,
            normalPurityState = if (purity.safeForQuantity) "VERIFIED" else "REVIEW_REQUIRED",
            normalPurityReason = purity.reason,
            normalCropAreaRatio = cropAreaRatio,
            normalOwnerAreaRatio = ownerAreaRatio,
            canonicalPhysicalObjectId = canonicalId,
            normalCompletenessScore = completeness.score,
            normalCompletenessState = completeness.state,
            normalCompletenessReason = completeness.reason,
            normalFragmentState = fragmentState
        )
    }

    private fun shouldCanonicalize(a: ScanProposal, b: ScanProposal): Boolean {
        if (!sameForegroundOwner(a, b)) return false
        if (independentlyComplete(a, b)) return false

        val overlap = overlapOfSmaller(a.normalizedBounds, b.normalizedBounds)
        val scoreA = preliminaryCompleteness(a)
        val scoreB = preliminaryCompleteness(b)
        val oneIsPartial = scoreA < 80 || scoreB < 80
        val center = centerDistance(a.normalizedBounds, b.normalizedBounds)
        val scale = min(diagonal(a.normalizedBounds), diagonal(b.normalizedBounds)).coerceAtLeast(1f)

        return overlap >= 0.04f || (oneIsPartial && center <= scale * 1.25f) || (scoreA < 70 && scoreB < 70)
    }

    private fun independentlyComplete(a: ScanProposal, b: ScanProposal): Boolean {
        if (!sameForegroundOwner(a, b)) return false
        val scoreA = preliminaryCompleteness(a)
        val scoreB = preliminaryCompleteness(b)
        if (scoreA < 80 || scoreB < 80) return false
        val overlap = overlapOfSmaller(a.normalizedBounds, b.normalizedBounds)
        val center = centerDistance(a.normalizedBounds, b.normalizedBounds)
        val scale = min(diagonal(a.normalizedBounds), diagonal(b.normalizedBounds)).coerceAtLeast(1f)
        return overlap < 0.04f && center > scale * 0.70f
    }

    private fun sameForegroundOwner(a: ScanProposal, b: ScanProposal): Boolean {
        if (a.normalForegroundComponent <= 0 || b.normalForegroundComponent <= 0) return false
        if (a.normalForegroundComponent != b.normalForegroundComponent) return false
        val aHas = a.normalForegroundRight > a.normalForegroundLeft && a.normalForegroundBottom > a.normalForegroundTop
        val bHas = b.normalForegroundRight > b.normalForegroundLeft && b.normalForegroundBottom > b.normalForegroundTop
        if (!aHas || !bHas) return true
        return overlapOfSmaller(
            Rect(a.normalForegroundLeft, a.normalForegroundTop, a.normalForegroundRight, a.normalForegroundBottom),
            Rect(b.normalForegroundLeft, b.normalForegroundTop, b.normalForegroundRight, b.normalForegroundBottom)
        ) >= 0.90f
    }

    private fun preliminaryCompleteness(p: ScanProposal): Int =
        NormalCompletenessPolicy.evaluate(
            p.normalForegroundComponent,
            p.normalOwnerAreaRatio,
            p.hypothesesMerged.coerceAtLeast(1)
        ).score

    private fun union(a: Rect, b: Rect): Rect = Rect(
        min(a.left, b.left), min(a.top, b.top), max(a.right, b.right), max(a.bottom, b.bottom)
    )

    private fun area(r: Rect): Long = r.width().coerceAtLeast(0).toLong() * r.height().coerceAtLeast(0).toLong()

    private fun overlapOfSmaller(a: Rect, b: Rect): Float {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val intersection = (right - left).toLong() * (bottom - top).toLong()
        return intersection.toFloat() / min(area(a), area(b)).coerceAtLeast(1L).toFloat()
    }

    private fun centerDistance(a: Rect, b: Rect): Float = hypot(
        ((a.left + a.right) - (b.left + b.right)) / 2f,
        ((a.top + a.bottom) - (b.top + b.bottom)) / 2f
    )

    private fun diagonal(r: Rect): Float = hypot(r.width().toFloat(), r.height().toFloat())
}
