package com.arspos.anglerriausyndicate

/**
 * Phase 4.3.5.5 / V8.8.5 — Canonical Physical Target + Fast Identity Convergence.
 *
 * V8.8.5 canonicalizes post-recovery NORMAL physical truth before identity,
 * preserves the strongest scene evidence into finalization, performs bounded
 * ambiguity retries, and accepts any materially higher-resolution identity
 * frame. Recognition thresholds and quantity safety remain unchanged.
 *
 * Physical tracking stays cheap and continuous. Expensive SKU identity is
 * scheduled per locked physical object, escalates evidence only when necessary,
 * and hands its bounded candidate memory to the final authoritative scanner.
 * Recognition thresholds and quantity safety are intentionally unchanged.
 */
object ArsV850Config {
    const val PHASE = "4.3.5.5"
    const val ENGINE = "V8.8.5"
    const val RELEASE_REVISION = "CANONICAL_PHYSICAL_TARGET_FAST_IDENTITY_CONVERGENCE_R1"
    const val VERSION_NAME = "1.10.7"
    const val VERSION_CODE = 207

    const val FEATURE_PERSISTENT_FRAGMENT_FUSION = true
    const val FEATURE_ML_GUIDED_LOCAL_RECOVERY = true
    const val FEATURE_BEST_EVIDENCE_MEMORY = true
    const val FEATURE_DECISION_EVIDENCE_LEDGER = true
    const val FEATURE_GROUND_TRUTH_LEARNING = true
    const val FEATURE_AI_ENGINEER_UI = true
    const val FEATURE_AI_ENGINEER_VISUAL_EVIDENCE = true
    const val FEATURE_AI_GATEWAY_SIGNED_REQUESTS = true
    const val FEATURE_AI_GATEWAY_STRUCTURED_DIAGNOSTICS = true
    const val FEATURE_AI_GATEWAY_HEALTH_CHECK = true
    const val AI_ENGINEER_MAX_IMAGES = 3
    const val AI_ENGINEER_MAX_REPORT_CHARS = 48_000

    const val CLOUD_IDENTITY_MODE = "SHADOW"
    const val SELF_LEARNING_MODE = "ACTIVE_CONFIRMED_ONLY"
    const val AI_ENGINEER_MODE = "DEV_CENTER_DIAGNOSTIC_ONLY"

    const val FEATURE_CONFIRMED_VISUAL_TEACHING = true
    const val FEATURE_NORMAL_VISUAL_ONLY_MASTER = true
    const val FEATURE_UPDATE_PROPOSAL_GATE = true

    const val FEATURE_NON_ROD_TO_NORMAL_RESCUE = true
    const val FEATURE_LIVE_ML_TALL_NORMAL_FALLBACK = true
    const val FEATURE_CATALOG_SNAPSHOT_EVIDENCE = true
    const val FEATURE_AMBIGUOUS_VISUAL_OCR = true
    const val FEATURE_REGULATORY_TEXT_FILTER = true
    const val FEATURE_WEAK_OCR_VISUAL_FALLBACK = true
    const val FEATURE_DIRECT_TEACH_CTA = true
    const val FEATURE_CONFIRMED_HYBRID_VISUAL = true

    // V8.8.2 safety foundations retained.
    const val FEATURE_FINAL_SCAN_VIEWMODEL_SCOPE = true
    const val FEATURE_LOCKED_SCENE_CONTINUITY = true
    const val FEATURE_LIVE_OCR_CACHE = true
    const val FEATURE_ADAPTIVE_ROD_AXIS_WIDTH = true
    const val FEATURE_PHYSICAL_OBJECT_STATE_MACHINE = true
    const val FEATURE_TWO_STAGE_CANDIDATE_RETRIEVAL = true
    const val FEATURE_UNIFIED_RECOVERY_COORDINATOR = true
    const val FEATURE_GUIDED_EVIDENCE_ACQUISITION = true
    const val FEATURE_AI_IN_CRITICAL_SCAN_PATH = false

    // V8.8.3 orchestration retained. These schedule evidence; they never relax recognition thresholds.
    const val FEATURE_EVENT_DRIVEN_IDENTITY = true
    const val FEATURE_OBJECT_SCOPED_RETRIEVAL = true
    const val FEATURE_CANDIDATE_MEMORY = true
    const val FEATURE_CANDIDATE_HYSTERESIS = true
    const val FEATURE_SINGLE_FLIGHT_OCR = true
    const val FEATURE_NEGATIVE_OCR_CACHE = true
    const val FEATURE_DISCRIMINATIVE_EVIDENCE = true
    const val FEATURE_HIGH_RES_NORMAL_AMBIGUITY = true
    const val FEATURE_ADAPTIVE_IDENTITY_ROI = true
    const val FEATURE_BEST_FRAME_SELECTION = true
    const val FEATURE_MULTI_OBJECT_TARGET_SELECTION = true
    const val FEATURE_IDENTITY_FREEZE_AFTER_CONFIRMATION = true
    const val FEATURE_LIVE_FINAL_DECISION_CONVERGENCE = true
    const val FEATURE_LIVE_CANDIDATE_FINAL_RECALL_SEED = true

    // V8.8.4 convergence fixes retained.
    const val FEATURE_STICKY_PHYSICAL_LOCK_UI = true
    const val FEATURE_ATOMIC_LOCK_GATE_STATE = true
    const val FEATURE_USEFUL_HIGH_RES_GAIN = true
    const val FEATURE_DISCRIMINATIVE_MICRO_OCR = true
    const val FEATURE_STATIC_AMBIGUITY_RETRY = true
    const val FEATURE_BEST_EVIDENCE_FINALIZATION = true

    // V8.8.5 canonical physical-target + fast identity convergence.
    const val FEATURE_POST_RECOVERY_CANONICAL_NORMAL = true
    const val FEATURE_NORMAL_COMPLETENESS_GATE = true
    const val FEATURE_STICKY_IDENTITY_OWNER = true
    const val FEATURE_SINGLE_OBJECT_FAST_IDENTITY = true
    const val FEATURE_MULTI_OBJECT_IDENTITY_SCHEDULER = true
    const val FEATURE_OCR_UTILITY_ROUTER = true
    const val FEATURE_FRESH_LOCK_FRAME_GATE = true
    const val FEATURE_SELECTED_TRACK_FINALIZATION = true

    const val LIVE_LOOP_DELAY_MS = 180L
    const val LIVE_STABLE_REFRESH_MS = 500L
    const val MAX_FINAL_BEST_FRAME_AGE_MS = 1_500L
}
