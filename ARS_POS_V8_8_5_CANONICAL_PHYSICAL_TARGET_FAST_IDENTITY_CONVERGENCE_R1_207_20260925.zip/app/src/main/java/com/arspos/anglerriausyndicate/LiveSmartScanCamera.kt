package com.arspos.anglerriausyndicate

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Paint
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.max

private val LiveGold = Color(0xFFE1BC68)
private val LiveGreen = Color(0xFF69D28A)
private val LiveYellow = Color(0xFFFFD166)
private val LiveGray = Color(0xFFB0B0B0)
private val LiveRed = Color(0xFFE57373)

private class LivePreviewController(private val context: Context) {
    private var provider: ProcessCameraProvider? = null

    fun bind(previewView: PreviewView, owner: androidx.lifecycle.LifecycleOwner, onReady: (Boolean) -> Unit) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            val ok = runCatching {
                val p = future.get()
                provider = p
                val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
                p.unbindAll()
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview)
            }.isSuccess
            onReady(ok)
        }, ContextCompat.getMainExecutor(context))
    }

    fun release() {
        runCatching { provider?.unbindAll() }
        provider = null
    }
}

/**
 * V8.8.5 canonical-target / sticky-identity-owner camera with fast evidence routing.
 *
 * Live boxes and database candidates are advisory. No live track can mutate the
 * cart. onLock returns one camera snapshot which must still pass the production
 * final scanner and Cashier Scan Review.
 */
@Composable
fun LiveSmartScanCamera(
    vm: PosViewModel,
    onLock: (Bitmap, LiveSceneLockSnapshot) -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val controller = remember { LivePreviewController(context) }
    val ledger = remember { LiveSceneLedger() }
    val bestFrameStore = remember { LiveBestFrameStore() }
    val physicalLockLatch = remember { LivePhysicalLockLatch() }

    var previewView by remember { mutableStateOf<PreviewView?>(null) }
    var cameraReady by remember { mutableStateOf(false) }
    var tracks by remember { mutableStateOf<List<LiveSceneTrack>>(emptyList()) }
    var frameWidth by remember { mutableStateOf(1) }
    var frameHeight by remember { mutableStateOf(1) }
    var status by remember { mutableStateOf("Menyiapkan kamera…") }
    var lastSignature by remember { mutableStateOf<IntArray?>(null) }
    var lastAnalysisAt by remember { mutableLongStateOf(0L) }
    var lastTelemetryAt by remember { mutableLongStateOf(0L) }
    var analysisBusy by remember { mutableStateOf(false) }
    var lockUiState by remember { mutableStateOf(LiveLockUiState()) }
    var selectedTrackId by remember { mutableStateOf<String?>(null) }
    var identityOwnerTrackId by remember { mutableStateOf<String?>(null) }
    var identityOwnerAcquiredAt by remember { mutableLongStateOf(0L) }
    var identityOwnerSwitchCount by remember { mutableStateOf(0) }
    var identityCursor by remember { mutableStateOf(0) }
    var objectTiles by remember { mutableStateOf<Map<String, ImageBitmap>>(emptyMap()) }
    val identityLastRunAt = remember { LinkedHashMap<String, Long>() }
    val highResLastRunAt = remember { LinkedHashMap<String, Long>() }

    DisposableEffect(Unit) {
        onDispose {
            controller.release()
            ledger.clear()
            bestFrameStore.clear()
            physicalLockLatch.clear()
            identityLastRunAt.clear()
            highResLastRunAt.clear()
        }
    }

    LaunchedEffect(cameraReady, previewView) {
        val pv = previewView ?: return@LaunchedEffect
        if (!cameraReady) return@LaunchedEffect
        status = "Arahkan produk ke kamera"
        val liveStartedAt = System.currentTimeMillis()
        var firstCandidateObservedAt = 0L
        var firstMatchedObservedAt = 0L
        while (isActive) {
            delay(ArsV850Config.LIVE_LOOP_DELAY_MS)
            if (analysisBusy) continue
            val captureStartedAt = System.currentTimeMillis()
            val raw = runCatching { pv.bitmap }.getOrNull() ?: continue
            val frameAcquireMs = System.currentTimeMillis() - captureStartedAt
            val liveFrame = scaleLiveFrame(raw, 640)
            val signature = LiveFrameDifference.signature(liveFrame)
            val sceneChange = LiveFrameDifference.score(lastSignature, signature)
            lastSignature = signature
            val now = System.currentTimeMillis()
            val analysisGapMs = if (lastAnalysisAt > 0L) now - lastAnalysisAt else 0L
            val periodicRefresh = now - lastAnalysisAt >= ArsV850Config.LIVE_STABLE_REFRESH_MS
            val changed = sceneChange >= 0.030f
            if (!changed && !periodicRefresh) {
                recycleFramePair(raw, liveFrame)
                continue
            }

            analysisBusy = true
            lastAnalysisAt = now
            try {
                val analysisStarted = System.currentTimeMillis()

                // V8.8.5 sticky identity ownership. Manual selection always wins.
                // Automatic ownership is retained while unresolved, then released
                // after MATCHED/exhausted evidence so multi-object scenes progress
                // one physical object at a time instead of round-robin thrashing.
                val manualOwner = selectedTrackId
                if (manualOwner != null && manualOwner != identityOwnerTrackId) {
                    if (identityOwnerTrackId != null) identityOwnerSwitchCount++
                    identityOwnerTrackId = manualOwner
                    identityOwnerAcquiredAt = now
                }
                if (manualOwner == null) {
                    val owner = identityOwnerTrackId?.let { id -> tracks.firstOrNull { it.trackId == id } }
                    val ownerInvalid = owner == null || owner.missingFrames > 0 ||
                        owner.physicalState != PhysicalObjectStateMachine.STATE_LOCKED
                    val ownerFinished = owner?.state == LiveSceneTrack.STATE_MATCHED ||
                        (owner?.evidenceStage == LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED &&
                            owner.identityEvaluationCount >= LiveIdentityScheduler.MAX_AMBIGUOUS_IDENTITY_EVALUATIONS)
                    if (ownerInvalid || ownerFinished) {
                        identityOwnerTrackId = null
                        identityOwnerAcquiredAt = 0L
                    }
                }

                val (selection, nextCursor) = LiveIdentityScheduler.choose(
                    tracks = tracks,
                    lastIdentityAt = identityLastRunAt,
                    lastHighResAt = highResLastRunAt,
                    nowMs = now,
                    preferredTrackId = selectedTrackId ?: identityOwnerTrackId,
                    cursor = identityCursor,
                    sceneChange = sceneChange
                )
                identityCursor = nextCursor
                if (selection != null && identityOwnerTrackId == null) {
                    identityOwnerTrackId = selection.trackId
                    identityOwnerAcquiredAt = now
                }
                val selectedTrack = selection?.let { chosen -> tracks.firstOrNull { it.trackId == chosen.trackId } }
                val identityFocus = selectedTrack?.let { listOf(android.graphics.Rect(it.bounds)) }.orEmpty()
                val detections = withContext(Dispatchers.Default) {
                    if (selection?.highResolution == true && selectedTrack != null) {
                        val physical = vm.liveScenePreview(liveFrame, identityEnabled = false)
                        val identity = vm.liveHighResolutionIdentity(
                            highResBitmap = raw,
                            liveBounds = selectedTrack.bounds,
                            liveFrameWidth = liveFrame.width,
                            liveFrameHeight = liveFrame.height,
                            proposalType = selectedTrack.proposalType,
                            preferredProductId = selectedTrack.product?.id ?: selectedTrack.bestEvidenceProductId
                        )
                        if (identity != null) mergeFocusedIdentity(physical, identity) else physical
                    } else {
                        vm.liveScenePreview(
                            bitmap = liveFrame,
                            identityEnabled = selection != null,
                            identityFocusBounds = identityFocus
                        )
                    }
                }
                if (selection != null) {
                    identityLastRunAt[selection.trackId] = now
                    if (selection.highResolution) highResLastRunAt[selection.trackId] = now
                }
                val analysisDurationMs = System.currentTimeMillis() - analysisStarted
                frameWidth = liveFrame.width
                frameHeight = liveFrame.height
                tracks = ledger.update(detections)
                lockUiState = physicalLockLatch.update(tracks, now)
                if (selectedTrackId != null && tracks.none { it.trackId == selectedTrackId }) selectedTrackId = null
                if (identityOwnerTrackId != null && tracks.none { it.trackId == identityOwnerTrackId }) {
                    identityOwnerTrackId = null
                    identityOwnerAcquiredAt = 0L
                }
                bestFrameStore.consider(raw, liveFrame, tracks, now)
                objectTiles = buildObjectTiles(liveFrame, tracks)

                val matched = tracks.count { it.state == LiveSceneTrack.STATE_MATCHED }
                val candidate = tracks.count { it.state == LiveSceneTrack.STATE_CANDIDATE }
                val unknown = tracks.count { it.state == LiveSceneTrack.STATE_UNKNOWN }
                val locked = tracks.count { it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED }
                val displayLocked = if (lockUiState.canLock) max(1, locked) else locked
                val observedNow = System.currentTimeMillis()
                if ((candidate > 0 || matched > 0) && firstCandidateObservedAt == 0L) firstCandidateObservedAt = observedNow
                if (matched > 0 && firstMatchedObservedAt == 0L) firstMatchedObservedAt = observedNow
                status = when {
                    tracks.isEmpty() -> "Belum ada objek stabil"
                    !lockUiState.canLock -> "${tracks.size} objek terdeteksi • tahan stabil sampai terkunci"
                    matched > 0 -> "$displayLocked terkunci • $matched dikenali • $candidate kandidat"
                    candidate > 0 -> "$displayLocked terkunci • $candidate kandidat • cari bukti pembeda"
                    else -> "$displayLocked objek terkunci • identitas belum ditemukan"
                }
                if (now - lastTelemetryAt >= 2_000L) {
                    lastTelemetryAt = now
                    ArsFlightRecorder.event(
                        "LIVE_SCENE_UPDATE",
                        "V8.8.5 canonical-target sticky-identity preview updated",
                        mapOf(
                            "tracks" to tracks.size,
                            "matched" to matched,
                            "candidate" to candidate,
                            "unknown" to unknown,
                            "sceneChange" to sceneChange,
                            "analysisDurationMs" to analysisDurationMs,
                            "frameAcquireMs" to frameAcquireMs,
                            "analysisGapMs" to analysisGapMs,
                            "identityTarget" to (selection?.trackId ?: ""),
                            "selectedTrack" to (selectedTrackId ?: ""),
                            "identityOwner" to (identityOwnerTrackId ?: ""),
                            "identityOwnerHoldMs" to if (identityOwnerAcquiredAt > 0L) (now - identityOwnerAcquiredAt).coerceAtLeast(0L) else 0L,
                            "identityOwnerSwitchCount" to identityOwnerSwitchCount,
                            "highResolutionTarget" to (selection?.highResolution == true),
                            "lockedTracks" to locked,
                            "uiCanLock" to lockUiState.canLock,
                            "uiCanLockReason" to lockUiState.reason,
                            "physicalLockEpochMs" to lockUiState.physicalLockEpochMs,
                            "physicalLockReleaseReason" to lockUiState.releaseReason,
                            "analysisInFlight" to analysisBusy,
                            "loopDelayMs" to ArsV850Config.LIVE_LOOP_DELAY_MS,
                            "stableRefreshMs" to ArsV850Config.LIVE_STABLE_REFRESH_MS,
                            "quantityPreview" to tracks.count { it.quantityPreviewEligible },
                            "stableTracks" to tracks.count { it.hitStreak >= 2 && it.missingFrames == 0 },
                            "firstCandidateMs" to if (firstCandidateObservedAt > 0L) firstCandidateObservedAt - liveStartedAt else 0L,
                            "firstMatchedMs" to if (firstMatchedObservedAt > 0L) firstMatchedObservedAt - liveStartedAt else 0L,
                            "longAxisTracked" to tracks.count { it.proposalType == ScanProposal.TYPE_LONG && it.axisConfidence > 0 },
                            "ocrRequested" to detections.count { it.ocrRequested },
                            "ocrSkippedLowUtility" to detections.count { it.ocrSkippedLowUtility },
                            "maxOcrUtilityScore" to (detections.maxOfOrNull { it.ocrUtilityScore } ?: 0),
                            "identityEvaluated" to detections.count { it.identityEvaluated },
                            "identityOcrPresent" to detections.count { it.identityOcrPresent },
                            "negativeOcrCacheHits" to detections.count { it.ocrGateReason.startsWith("NEGATIVE_OCR_CACHE_HIT") },
                            "evidenceStages" to tracks.map { it.evidenceStage }.distinct().joinToString(","),
                            "candidateDemotions" to tracks.sumOf { it.candidateDemotions },
                            "ocrGateReasons" to detections.map { it.ocrGateReason }.distinct().joinToString(",")
                        )
                    )
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (t: Throwable) {
                status = "Live analysis aman dihentikan sementara"
                ArsFlightRecorder.event(
                    "LIVE_SCENE_ERROR",
                    t.message ?: t::class.java.simpleName,
                    mapOf("exception" to t::class.java.name)
                )
            } finally {
                recycleFramePair(raw, liveFrame)
                analysisBusy = false
            }
        }
    }

    Dialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { ctx ->
                    PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FIT_CENTER
                        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                        previewView = this
                        controller.bind(this, owner) { ready ->
                            cameraReady = ready
                            if (!ready) status = "Kamera tidak dapat diinisialisasi"
                        }
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            Canvas(Modifier.fillMaxSize()) {
                val mapping = ScanPreviewMapping.fit(frameWidth, frameHeight, size.width, size.height)
                val labelPaint = Paint().apply {
                    isAntiAlias = true
                    textSize = 28f
                    color = android.graphics.Color.WHITE
                    style = Paint.Style.FILL
                }
                tracks.forEach { track ->
                    val left = mapping.left + track.bounds.left * mapping.scale
                    val top = mapping.top + track.bounds.top * mapping.scale
                    val right = mapping.left + track.bounds.right * mapping.scale
                    val bottom = mapping.top + track.bounds.bottom * mapping.scale
                    val color = when (track.state) {
                        LiveSceneTrack.STATE_MATCHED -> LiveGreen
                        LiveSceneTrack.STATE_CANDIDATE -> LiveYellow
                        LiveSceneTrack.STATE_UNKNOWN -> LiveRed
                        else -> LiveGray
                    }
                    drawRect(
                        color = color,
                        topLeft = androidx.compose.ui.geometry.Offset(left, top),
                        size = androidx.compose.ui.geometry.Size((right - left).coerceAtLeast(1f), (bottom - top).coerceAtLeast(1f)),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                    )
                    val label = when {
                        track.state == LiveSceneTrack.STATE_MATCHED && track.product != null -> "✓ ${track.product.name}"
                        track.state == LiveSceneTrack.STATE_CANDIDATE && track.product != null -> "◐ ${track.product.name}"
                        track.state == LiveSceneTrack.STATE_UNKNOWN -> "? OBJEK"
                        else -> track.trackId
                    }.take(34)
                    drawContext.canvas.nativeCanvas.drawText(label, left + 4f, max(top - 8f, mapping.top + 30f), labelPaint)
                }
            }

            Column(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.72f))
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Text("ARS SMART SCAN LIVE", color = LiveGold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    "V8.8.5 • Canonical Object → Sticky Identity → Fast Convergence",
                    color = Color.White.copy(alpha = 0.72f),
                    fontSize = 10.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(status, color = Color.White, fontSize = 12.sp)
            }

            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.82f))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (tracks.isNotEmpty()) {
                    val visible = tracks.take(4)
                    visible.forEach { track ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .border(
                                    1.dp,
                                    if (selectedTrackId == track.trackId) LiveGold else Color.White.copy(alpha = 0.16f),
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedTrackId = track.trackId }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            objectTiles[track.trackId]?.let { tile ->
                                Image(
                                    bitmap = tile,
                                    contentDescription = track.trackId,
                                    modifier = Modifier.size(42.dp),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(Modifier.width(8.dp))
                            }
                            Text(
                                when (track.state) {
                                    LiveSceneTrack.STATE_MATCHED -> "✓"
                                    LiveSceneTrack.STATE_CANDIDATE -> "◐"
                                    LiveSceneTrack.STATE_UNKNOWN -> "?"
                                    LiveSceneTrack.STATE_OCCLUDED -> "…"
                                    else -> "•"
                                },
                                color = when (track.state) {
                                    LiveSceneTrack.STATE_MATCHED -> LiveGreen
                                    LiveSceneTrack.STATE_CANDIDATE -> LiveYellow
                                    LiveSceneTrack.STATE_UNKNOWN -> LiveRed
                                    else -> LiveGray
                                },
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    if (track.state in setOf(LiveSceneTrack.STATE_MATCHED, LiveSceneTrack.STATE_CANDIDATE)) {
                                        track.product?.name ?: "Objek belum teridentifikasi"
                                    } else "Objek sedang dilacak",
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp,
                                    maxLines = 1
                                )
                                Text(
                                    "${track.trackId} • ${track.physicalState} • ${track.identityDecision} • ${track.evidenceStage} • visual ${track.visualScore}% • margin ${track.margin}%",
                                    color = Color.White.copy(alpha = 0.58f),
                                    fontSize = 8.sp,
                                    maxLines = 1
                                )
                                if (track.guidance.isNotBlank()) {
                                    Text(
                                        track.guidance,
                                        color = LiveYellow,
                                        fontSize = 8.sp,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }

                Text(
                    "Live preview tidak membuat quantity. Ketuk objek untuk memprioritaskan identitas; quantity final hanya setelah scene dikunci dan lolos Physical Object Truth.",
                    color = Color.White.copy(alpha = 0.60f),
                    fontSize = 9.sp
                )

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onCancel,
                        modifier = Modifier.weight(1f)
                    ) { Text("BATAL") }
                    Button(
                        onClick = {
                            val pv = previewView ?: return@Button
                            val bestInfo = bestFrameStore.info()
                            val bestAgeMs = bestInfo.ageMs()
                            val bestSnapshot = if (bestAgeMs <= ArsV850Config.MAX_FINAL_BEST_FRAME_AGE_MS) {
                                bestFrameStore.snapshot()
                            } else null
                            val snapshot = bestSnapshot ?: runCatching { pv.bitmap }.getOrNull() ?: return@Button
                            val finalLockFrameAgeMs = if (bestSnapshot != null) bestAgeMs else 0L
                            ArsFlightRecorder.event(
                                "LIVE_SCENE_LOCK",
                                "Operator locked scene for final Smart Scan",
                                mapOf(
                                    "liveTracks" to tracks.size,
                                    "liveMatched" to tracks.count { it.state == LiveSceneTrack.STATE_MATCHED },
                                    "liveCandidates" to tracks.count { it.product != null },
                                    "selectedTrack" to (selectedTrackId ?: ""),
                                    "identityOwner" to (identityOwnerTrackId ?: ""),
                                    "bestFrameUsed" to (bestSnapshot != null),
                                    "freshFrameForced" to (bestSnapshot == null && bestAgeMs > ArsV850Config.MAX_FINAL_BEST_FRAME_AGE_MS),
                                    "bestFrameQuality" to bestInfo.quality,
                                    "bestFrameAgeMs" to bestAgeMs,
                                    "uiCanLock" to lockUiState.canLock,
                                    "uiCanLockReason" to lockUiState.reason,
                                    "physicalLockEpochMs" to lockUiState.physicalLockEpochMs,
                                    "analysisInFlightAtLock" to analysisBusy,
                                    "identityEvaluations" to tracks.sumOf { it.identityEvaluationCount },
                                    "highResolutionEvidence" to tracks.sumOf { it.highResolutionEvidenceCount }
                                )
                            )
                            onLock(
                                snapshot,
                                LiveSceneLockSnapshot(
                                    frameWidth = frameWidth,
                                    frameHeight = frameHeight,
                                    lockedAtMs = System.currentTimeMillis(),
                                    sceneEpoch = lockUiState.physicalLockEpochMs.takeIf { it > 0L } ?: lastAnalysisAt,
                                    selectedTrackId = selectedTrackId ?: "",
                                    identityOwnerTrackId = identityOwnerTrackId ?: "",
                                    lockFrameAgeMs = finalLockFrameAgeMs,
                                    tracks = tracks.map { it.copy(bounds = android.graphics.Rect(it.bounds)) }
                                )
                            )
                        },
                        // V8.8.5: UI lock eligibility remains a sticky physical-state decision.
                        // OCR/HIGH_RES/analyzer activity must never make the button blink.
                        enabled = cameraReady && lockUiState.canLock,
                        modifier = Modifier.weight(1.6f),
                        colors = ButtonDefaults.buttonColors(containerColor = LiveGold)
                    ) {
                        Text("KUNCI & TINJAU HASIL", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}


private fun mergeFocusedIdentity(
    physical: List<LiveSceneDetection>,
    identity: LiveSceneDetection
): List<LiveSceneDetection> {
    val target = physical.withIndex().maxByOrNull { (_, detection) ->
        AdaptiveIdentityRoi.overlapRatio(detection.bounds, identity.bounds)
    }
    if (target == null || AdaptiveIdentityRoi.overlapRatio(target.value.bounds, identity.bounds) < 0.30f) {
        return physical
    }
    return physical.mapIndexed { index, detection ->
        if (index != target.index) detection else detection.copy(
            product = identity.product,
            visualScore = identity.visualScore,
            secondVisualScore = identity.secondVisualScore,
            margin = identity.margin,
            identityAccepted = identity.identityAccepted,
            reason = identity.reason,
            ocrRequested = identity.ocrRequested,
            identityOcrPresent = identity.identityOcrPresent,
            ocrGateReason = identity.ocrGateReason,
            identityEvaluated = true,
            evidenceStage = identity.evidenceStage,
            highResolutionIdentityUsed = identity.highResolutionIdentityUsed
        )
    }
}

private fun buildObjectTiles(bitmap: Bitmap, tracks: List<LiveSceneTrack>): Map<String, ImageBitmap> {
    val out = LinkedHashMap<String, ImageBitmap>()
    tracks.filter { it.missingFrames == 0 }.take(6).forEach { track ->
        val rect = android.graphics.Rect(
            track.bounds.left.coerceIn(0, bitmap.width - 1),
            track.bounds.top.coerceIn(0, bitmap.height - 1),
            track.bounds.right.coerceIn(1, bitmap.width),
            track.bounds.bottom.coerceIn(1, bitmap.height)
        )
        if (rect.width() < 8 || rect.height() < 8) return@forEach
        val crop = runCatching { Bitmap.createBitmap(bitmap, rect.left, rect.top, rect.width(), rect.height()) }.getOrNull() ?: return@forEach
        val scaled = runCatching { Bitmap.createScaledBitmap(crop, 96, 96, true) }.getOrNull()
        if (scaled != null) out[track.trackId] = scaled.asImageBitmap()
        if (scaled !== crop && !crop.isRecycled) crop.recycle()
    }
    return out
}

private fun recycleFramePair(raw: Bitmap, liveFrame: Bitmap) {
    if (liveFrame !== raw && !liveFrame.isRecycled) liveFrame.recycle()
    if (!raw.isRecycled) raw.recycle()
}

private fun scaleLiveFrame(source: Bitmap, maxSide: Int): Bitmap {
    val largest = max(source.width, source.height)
    if (largest <= maxSide) return source
    val scale = maxSide.toFloat() / largest.toFloat()
    val width = (source.width * scale).toInt().coerceAtLeast(1)
    val height = (source.height * scale).toInt().coerceAtLeast(1)
    return Bitmap.createScaledBitmap(source, width, height, true)
}
