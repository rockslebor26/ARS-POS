package com.arspos.anglerriausyndicate

/**
 * V8.8.5 NORMAL completeness gate.
 *
 * Purity answers "is this crop visually owned by a NORMAL foreground body?".
 * Completeness answers the different question "does this crop represent enough
 * of that owner to be treated as one independent physical object?".
 *
 * This policy never relaxes product-recognition thresholds. It only prevents a
 * clean fragment of a larger foreground owner from becoming independent
 * transaction quantity before canonical object resolution.
 */
object NormalCompletenessPolicy {
    const val STATE_COMPLETE = "COMPLETE"
    const val STATE_PARTIAL = "PARTIAL"
    const val STATE_NOT_MEASURED = "NOT_MEASURED"

    data class Result(
        val score: Int,
        val state: String,
        val reason: String,
        val safeForQuantity: Boolean
    )

    fun evaluate(
        foregroundComponent: Int,
        ownerAreaRatio: Float,
        mergedProposals: Int
    ): Result {
        if (foregroundComponent <= 0 || ownerAreaRatio <= 0f || !ownerAreaRatio.isFinite()) {
            // Do not create a new false-negative for compact NORMAL objects where the
            // foreground owner could not be measured. In that case completeness is
            // neutral and existing purity/identity safety remains authoritative.
            return Result(0, STATE_NOT_MEASURED, "NORMAL_COMPLETENESS_NOT_MEASURED", true)
        }

        // ownerAreaRatio = ownerArea / cropArea. Values > 1 are meaningful and
        // must not be clamped: 4.0 means the crop covers only about 25% of the
        // physical foreground owner.
        val baseScore = (100f / ownerAreaRatio.coerceAtLeast(1f)).toInt().coerceIn(0, 100)
        val mergeBonus = if (mergedProposals > 1) 6 else 0
        val score = (baseScore + mergeBonus).coerceIn(0, 100)

        return if (score >= 70) {
            Result(score, STATE_COMPLETE, "NORMAL_COMPLETENESS_VERIFIED", true)
        } else {
            Result(score, STATE_PARTIAL, "NORMAL_OWNER_EXTENDS_BEYOND_CROP", false)
        }
    }
}
