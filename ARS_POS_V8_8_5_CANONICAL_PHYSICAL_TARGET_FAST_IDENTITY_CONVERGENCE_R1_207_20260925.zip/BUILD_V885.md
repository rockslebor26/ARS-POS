# V8.8.5 Build Notes

Build the supplied source ZIP with the matching `build-apk.yml` GitHub Actions workflow. The workflow verifies the exact source SHA-256, all source-file hashes, static safety invariants, Android debug/release Kotlin compilation, JVM/Android unit tests, signed release assembly, package/version metadata, ZIP alignment and the official ARS signing certificate.

Required update transition: `1.10.6 (206) -> 1.10.7 (207)` in place. Do not uninstall the official application before device acceptance because uninstall resets app-private update history and local data.
