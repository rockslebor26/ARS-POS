# Current Release Candidate

ARS POS **1.10.7 (207)** — Phase **4.3.5.5** / **V8.8.5 Canonical Physical Target + Fast Identity Convergence R1**.

Primary acceptance focus: post-recovery NORMAL fragments must resolve into canonical physical objects before identity/quantity, the selected or automatic identity owner must remain sticky, single-object scenes must use the visual-first fast path, multi-object identity work must be scheduled rather than run heavy evidence on every track, low-utility OCR must be skipped, and final lock must not reuse stale evidence.

Recognition thresholds, package, Room v5 and official signer are unchanged. Cloud Identity remains `SHADOW`; Self Learning remains `ACTIVE_CONFIRMED_ONLY`; ARS AI Engineer is `DEV_CENTER_DIAGNOSTIC_ONLY` and outside the automatic cashier scan path.

Install only as an in-place update from official 1.10.6 (206). This candidate is not device-finished until the signed workflow build passes and real-device regression evidence satisfies the V8.8.5 acceptance matrix.
