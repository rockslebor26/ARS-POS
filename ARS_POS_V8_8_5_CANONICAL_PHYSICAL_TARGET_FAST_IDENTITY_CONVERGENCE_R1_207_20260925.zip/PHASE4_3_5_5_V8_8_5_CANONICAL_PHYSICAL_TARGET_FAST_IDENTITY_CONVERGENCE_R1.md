# Phase 4.3.5.5 / V8.8.5 — Canonical Physical Target + Fast Identity Convergence R1

## Why this phase exists

V8.8.4 field evidence showed four linked failure modes: rescued NORMAL fragments could remain multiple quantity-eligible objects despite sharing one foreground owner; physical lock did not guarantee one sticky identity owner; selected live track did not always scope final identity; and OCR/high-resolution ambiguity recovery often consumed hundreds to thousands of milliseconds without adding discriminative evidence.

V8.8.5 fixes ordering and ownership rather than lowering any recognition threshold.

## Mandatory invariants

1. **Canonical before identity.** Base NORMAL plus NON_ROD-to-NORMAL rescue output must pass one post-recovery canonical resolver before final identity/quantity.
2. **Purity is not completeness.** `normalPurityScore` cannot prove a crop represents a complete independent object. `normalCompletenessScore/state` preserves owner-area ratios above 1 instead of clamping away fragmentation evidence.
3. **No quantity invention.** Canonical resolution may remove quantity eligibility; it may not grant quantity if no input member was eligible.
4. **Sticky identity owner.** While a selected/automatic owner is still valid, scheduler cooldown returns no expensive identity work rather than rotating to a different physical object.
5. **Explicit selected-track finalization.** In single-target use, a valid selected persistent ID scopes final identity; all proposals remain available to physical safety checks.
6. **Visual-first evidence.** OCR is scheduled only when expected identity information gain is useful. Strong visual-only/HYBRID_VISUAL ambiguity can escalate directly to high-resolution visual evidence.
7. **Fresh lock transaction.** Best-frame evidence older than the bounded age cannot be silently used at final lock.
8. **Candidate-level convergence.** Live/final consistency must be measurable even when the authoritative final decision remains AMBIGUOUS.
9. **Safety unchanged.** Cloud cannot create quantity; AI Engineer remains outside critical scan path; 14 recognition thresholds remain unchanged.

## New telemetry

- `canonicalObjectsBeforeResolve/AfterResolve`
- `normalFragmentsMerged`
- `sharedForegroundMerges`
- `independentNormalInstancesConfirmed`
- `normalCompletenessScore/state/reason`
- `normalFragmentState`
- `canonicalPhysicalObjectId`
- `identityOwner`, `identityOwnerHoldMs`, `identityOwnerSwitchCount`
- `ocrUtilityScore`, `ocrSkippedLowUtility`
- `freshFrameForced`, `lockFrameAgeMs`
- `SCAN_SELECTED_TRACK_FINALIZATION`
- candidate-level `LIVE_FINAL_DECISION_CONVERGENCE`

## Device acceptance matrix

### Single object
- one physical product must yield one canonical object;
- median first candidate target `<= 800 ms`, P95 target `<= 1.5 s`;
- known product stable identity target `<= 1.5 s` in the majority of tests;
- no identity-owner switch after lock unless an explicit valid release reason occurs;
- visual-only product should not repeatedly invoke empty OCR.

### Multi object
- all visible independent products may be tracked concurrently;
- expensive identity jobs are scheduled selectively;
- fragments/shared foreground must not become duplicate quantities;
- independent objects must remain independently resolvable;
- UI preview must remain responsive while identities converge progressively.

### Safety/distribution
- crash/ANR/fatal = 0 in acceptance window;
- false quantity = 0;
- duplicate quantity = 0;
- package/signature unchanged;
- in-place transition `206 -> 207` recorded;
- Room database stays v5;
- Cloud Identity stays SHADOW and AI Engineer diagnostic-only.
