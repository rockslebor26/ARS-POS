# ARS POS — FASE 5 — Full Operational Core

ANGLER RIAU SYNDICATE

Added:
- Expanded Room database v2
- Users/roles schema
- Customers schema
- Cash in/out ledger
- Returns schema
- Audit log
- Product master add dialog
- Payment method selection: CASH / QRIS / TRANSFER / DEBIT
- Automatic cash ledger entry for completed sales
- Stock movement + sale + audit log in one database transaction
- Dashboard revenue, transactions and cash balance
- Bluetooth printer screen
- ESC/POS test print
- Checkout flow ready for receipt printing

Important:
- QRIS/TRANSFER/DEBIT here are payment records, not payment gateway integrations.
- Bluetooth printing targets common Bluetooth Classic ESC/POS SPP printers.
- Before production, printer MAC/address persistence, direct "Bayar & Cetak",
  authentication, returns UI, debt settlement, backup/restore and full reports
  should be completed and tested on the exact shop device/printer.

Version: 0.5.0
