# ARS POS — FASE 4
## Bluetooth Thermal Printer + ESC/POS

Implemented in this phase:
- Bluetooth Classic permission declarations for Android 12+
- Discovery of already-paired Bluetooth devices
- SPP/RFCOMM connection for common thermal printers
- ESC/POS receipt generator
- ARS branding on receipt
- Automatic receipt cutting command for printers that support it

Printer target:
- Thermal 58 mm / 80 mm
- Bluetooth Classic
- ESC/POS compatible
- SPP UUID 00001101-0000-1000-8000-00805F9B34FB

How to use:
1. Pair the printer from Android Bluetooth settings.
2. Grant Bluetooth permissions to ARS POS.
3. Call BluetoothPrinter.pairedDevices() to show paired printers.
4. Select the printer and call print(device, EscPosReceipt.build(...)).

Note:
BLE-only printers can require a different protocol. The next hardware
refinement can add BLE support after the exact printer model is chosen.

Remaining Phase 4 integration:
- Add Printer Settings screen to the navigation
- Save selected printer MAC/address in local settings
- Add "Bayar & Cetak" directly to checkout
- Test print button
- 58/80 mm paper profile
