# ARS POS — FASE 6 — Production Ready Foundation

Implemented:
- Database version 3 with stock receipts and settings
- Product CRUD entry (add)
- Stock-in transaction with supplier/invoice and stock movement
- Cash-out and audit log
- Real login verification against local user table
- Payment method records: CASH / QRIS / TRANSFER / DEBIT
- Sale + stock + cash + audit committed transactionally
- Bluetooth Classic ESC/POS printer module retained
- Production-style dashboard, cashier, product, report and printer screens
- Cost price retained per sale item for future profit reporting

Default demo login:
username: admin
PIN: 0000

Important:
- Change the default PIN before real store use.
- QRIS/TRANSFER/DEBIT are bookkeeping methods only, not payment gateway integrations.
- Bluetooth printer support targets common Classic SPP ESC/POS printers.
- Database migration currently uses fallbackToDestructiveMigration; do not use as a production upgrade strategy until a tested migration path is added.
- Camera barcode scanning, direct auto-print after checkout, returns UI, debt settlement,
  full report/export, backup/restore UI and stronger PIN hashing are the remaining hardening items.

Version: 0.6.0
