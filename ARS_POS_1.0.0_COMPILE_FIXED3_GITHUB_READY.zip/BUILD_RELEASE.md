# Build ARS POS 1.0.0

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select `app` > `Build` > `Generate Signed Bundle / APK` > APK.
4. Build the `release` variant.
5. Install on Android 8+.
6. Pair the Bluetooth Classic ESC/POS printer in Android settings.
7. Open ARS POS > Printer > Cari Printer Paired > select printer > Test Print.
8. Make a test sale and verify automatic printing.
9. Verify stock, return, report, reprint, and backup procedures before live use.
