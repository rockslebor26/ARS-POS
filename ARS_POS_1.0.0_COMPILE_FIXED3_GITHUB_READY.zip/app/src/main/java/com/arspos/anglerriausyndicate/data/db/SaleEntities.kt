package com.arspos.anglerriausyndicate.data.db
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="sales")
data class SaleEntity(
    @PrimaryKey(autoGenerate=true) val id: Long=0,
    val invoiceNumber: String,
    val userId: Long=1,
    val subtotal: Long,
    val discount: Long,
    val grandTotal: Long,
    val paidAmount: Long,
    val changeAmount: Long,
    val paymentMethod: String,
    val status: String="PAID",
    val createdAt: Long=System.currentTimeMillis()
)

@Entity(tableName="sale_items")
data class SaleItemEntity(
    @PrimaryKey(autoGenerate=true) val id: Long=0,
    val saleId: Long,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val costPrice: Long,
    val sellPrice: Long,
    val discount: Long,
    val subtotal: Long
)

@Entity(tableName="stock_movements")
data class StockMovementEntity(
    @PrimaryKey(autoGenerate=true) val id: Long=0,
    val productId: Long,
    val type: String,
    val quantity: Int,
    val stockBefore: Int,
    val stockAfter: Int,
    val referenceId: Long?=null,
    val userId: Long=1,
    val note: String?=null,
    val createdAt: Long=System.currentTimeMillis()
)
