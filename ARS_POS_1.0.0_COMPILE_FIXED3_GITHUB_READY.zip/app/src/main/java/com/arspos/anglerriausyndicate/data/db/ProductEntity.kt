package com.arspos.anglerriausyndicate.data.db
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName="products", indices=[
    Index(value=["sku"], unique=true),
    Index(value=["barcode"], unique=true)
])
data class ProductEntity(
    @PrimaryKey(autoGenerate=true) val id: Long=0,
    val sku: String,
    val barcode: String?=null,
    val name: String,
    val category: String="LAINNYA",
    val brand: String?=null,
    val variant: String?=null,
    val unit: String="pcs",
    val costPrice: Long,
    val sellPrice: Long,
    val wholesalePrice: Long?=null,
    val stock: Int=0,
    val minimumStock: Int=0,
    val active: Boolean=true,
    val createdAt: Long=System.currentTimeMillis(),
    val updatedAt: Long=System.currentTimeMillis()
)
