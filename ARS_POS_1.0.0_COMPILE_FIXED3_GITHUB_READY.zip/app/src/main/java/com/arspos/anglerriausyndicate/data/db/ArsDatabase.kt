package com.arspos.anglerriausyndicate.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities=[
        ProductEntity::class, SaleEntity::class, SaleItemEntity::class,
        StockMovementEntity::class, UserEntity::class, CustomerEntity::class,
        CashTransactionEntity::class, ReturnEntity::class, ReturnItemEntity::class,
        AuditLogEntity::class, StockReceiptEntity::class, StockReceiptItemEntity::class,
        SettingEntity::class
    ],
    version=3, exportSchema=false
)
abstract class ArsDatabase:RoomDatabase(){
    abstract fun dao():ArsDao
    companion object{
        @Volatile private var instance:ArsDatabase?=null
        fun get(context:Context):ArsDatabase =
            instance ?: synchronized(this){
                instance ?: Room.databaseBuilder(
                    context.applicationContext,ArsDatabase::class.java,"ars_pos.db"
                ).build().also{instance=it}
            }
    }
}
