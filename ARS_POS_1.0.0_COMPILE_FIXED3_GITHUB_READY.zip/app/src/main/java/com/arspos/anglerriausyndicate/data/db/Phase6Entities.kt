package com.arspos.anglerriausyndicate.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="stock_receipts")
data class StockReceiptEntity(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val supplier:String?,
    val invoice:String?,
    val totalCost:Long,
    val userId:Long=1,
    val createdAt:Long=System.currentTimeMillis()
)

@Entity(tableName="stock_receipt_items")
data class StockReceiptItemEntity(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val receiptId:Long,
    val productId:Long,
    val quantity:Int,
    val unitCost:Long
)

@Entity(tableName="settings")
data class SettingEntity(
    @PrimaryKey val key:String,
    val value:String
)
