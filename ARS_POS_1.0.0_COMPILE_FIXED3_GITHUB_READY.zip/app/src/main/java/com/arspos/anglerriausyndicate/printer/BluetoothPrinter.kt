package com.arspos.anglerriausyndicate.printer

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import java.io.IOException
import java.util.UUID

class BluetoothPrinter {
    private val sppUuid =
        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    @SuppressLint("MissingPermission")
    fun pairedDevices(): List<BluetoothDevice> =
        BluetoothAdapter.getDefaultAdapter()
            ?.bondedDevices
            ?.toList()
            ?.sortedBy { it.name ?: it.address }
            ?: emptyList()

    @SuppressLint("MissingPermission")
    fun print(device: BluetoothDevice, data: ByteArray) {
        val adapter = BluetoothAdapter.getDefaultAdapter()
            ?: throw IOException("Perangkat tidak memiliki Bluetooth")
        if (!adapter.isEnabled) throw IOException("Bluetooth belum aktif")

        adapter.cancelDiscovery()
        val socket = device.createRfcommSocketToServiceRecord(sppUuid)
        try {
            socket.connect()
            socket.outputStream.use { stream ->
                stream.write(data)
                stream.flush()
            }
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }
}
