package com.arspos.anglerriausyndicate.printer

import com.arspos.anglerriausyndicate.data.CartLine
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object EscPosReceipt {
    private val charset = Charset.forName("CP437")

    private fun bytes(vararg values: Int) =
        values.map { it.toByte() }.toByteArray()

    private fun text(value: String) =
        value.toByteArray(charset)

    fun build(
        cart: List<CartLine>,
        total: Long,
        paid: Long,
        change: Long,
        invoice: String,
        paymentMethod: String = "CASH"
    ): ByteArray {
        val result = ArrayList<Byte>()
        fun add(value: ByteArray) { value.forEach(result::add) }
        fun line(value: String) { add(text(value + "\n")) }

        add(bytes(0x1B, 0x40))
        add(bytes(0x1B, 0x61, 1))
        add(bytes(0x1B, 0x45, 1))
        line("ANGLER RIAU SYNDICATE")
        add(bytes(0x1B, 0x45, 0))
        line("FISHING STORE")
        add(bytes(0x1B, 0x61, 0))
        line("--------------------------------")
        line("TRX : $invoice")
        line("DATE: " + SimpleDateFormat(
            "dd-MM-yyyy HH:mm", Locale.US
        ).format(Date()))
        line("--------------------------------")

        cart.forEach { item ->
            line(item.product.name.take(32))
            line("${item.quantity} x Rp ${item.product.sellPrice}    Rp ${item.subtotal}")
        }

        line("--------------------------------")
        line("TOTAL       Rp $total")
        line("BAYAR       Rp $paid")
        line("METODE      $paymentMethod")
        line("KEMBALI     Rp $change")
        line("--------------------------------")
        add(bytes(0x1B, 0x61, 1))
        line("TERIMA KASIH")
        line("FISHING IS NOT CRIME")
        line("\n")
        add(bytes(0x1D, 0x56, 66, 0))
        return result.toByteArray()
    }
}
