package com.arspos.anglerriausyndicate.data

import androidx.room.withTransaction
import com.arspos.anglerriausyndicate.data.db.*
import java.text.SimpleDateFormat
import java.util.*

data class CartLine(val product:ProductEntity,val quantity:Int){
    val subtotal get()=product.sellPrice*quantity
}
data class CheckoutResult(
    val saleId:Long,val invoice:String,val cart:List<CartLine>,
    val total:Long,val paid:Long,val change:Long,val paymentMethod:String
)

class PosRepository(private val db:ArsDatabase){
    private val dao=db.dao()
    fun products()=dao.products()
    fun search(q:String)=if(q.isBlank())products() else dao.search(q)
    fun revenue(start:Long)=dao.revenue(start)
    fun transactionCount(start:Long)=dao.transactionCount(start)
    fun cashBalance()=dao.cashBalance()
    fun customers()=dao.customers()

    suspend fun seed(){
        if(dao.countProducts()==0){
            listOf(
                ProductEntity(sku="JRG001",barcode="899000000001",name="Joran BC Elito Sidat 180",category="JORAN",brand="Elito",costPrice=95000,sellPrice=150000,wholesalePrice=135000,stock=15,minimumStock=5),
                ProductEntity(sku="REL001",barcode="899000000002",name="Reel Shimano FX 2500",category="REEL",brand="Shimano",costPrice=210000,sellPrice=275000,stock=8,minimumStock=3),
                ProductEntity(sku="SNR001",barcode="899000000003",name="PE Jabrik X9 2.0",category="SENAR",brand="Jabrik",costPrice=55000,sellPrice=85000,stock=12,minimumStock=4),
                ProductEntity(sku="LDR001",barcode="899000000004",name="Leader Relix 40lb",category="LEADER",brand="Relix",costPrice=28000,sellPrice=45000,stock=9,minimumStock=4),
                ProductEntity(sku="KIL001",barcode="899000000005",name="Kail BKK 1/0",category="KAIL",brand="BKK",costPrice=11000,sellPrice=18000,stock=20,minimumStock=5)
            ).forEach{dao.insertProduct(it)}
        }
        dao.insertUser(UserEntity(username="admin",displayName="Administrator",role="ADMIN",pinHash="0000"))
    }

    suspend fun addProduct(name:String,sku:String,barcode:String?,category:String,cost:Long,price:Long,stock:Int){
        dao.insertProduct(ProductEntity(sku=sku,barcode=barcode,name=name,category=category,costPrice=cost,sellPrice=price,stock=stock))
    }

    suspend fun addCashOut(amount:Long,category:String,description:String?){
        require(amount>0){"Nominal harus lebih dari 0"}
        dao.insertCash(CashTransactionEntity(type="OUT",category=category,amount=amount,description=description))
    }

    suspend fun checkout(cart:List<CartLine>,paid:Long,method:String):CheckoutResult{
        require(cart.isNotEmpty()){"Keranjang kosong"}
        val subtotal=cart.sumOf{it.subtotal}
        require(paid>=subtotal){"Uang pembayaran kurang"}
        return db.withTransaction{
            cart.forEach{
                val current=dao.product(it.product.id) ?: error("Produk tidak ditemukan")
                require(current.stock>=it.quantity){"Stok ${current.name} tidak mencukupi"}
            }
            val invoice="ARS-"+SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(Date())
            val saleId=dao.insertSale(SaleEntity(invoiceNumber=invoice,subtotal=subtotal,discount=0,
                grandTotal=subtotal,paidAmount=paid,changeAmount=paid-subtotal,paymentMethod=method))
            dao.insertItems(cart.map{SaleItemEntity(saleId=saleId,productId=it.product.id,
                productName=it.product.name,quantity=it.quantity,costPrice=it.product.costPrice,
                sellPrice=it.product.sellPrice,discount=0,subtotal=it.subtotal)})
            cart.forEach{
                val before=dao.product(it.product.id)!!.stock
                dao.changeStock(it.product.id,-it.quantity)
                dao.insertMovement(StockMovementEntity(productId=it.product.id,type="SALE",
                    quantity=-it.quantity,stockBefore=before,stockAfter=before-it.quantity,referenceId=saleId,note=invoice))
            }
            dao.insertCash(CashTransactionEntity(type="IN",category="PENJUALAN",amount=subtotal,referenceId=saleId))
            dao.audit(AuditLogEntity(action="SALE",referenceId=saleId,detail="$invoice | $method | Rp $subtotal"))
            CheckoutResult(saleId,invoice,cart,subtotal,paid,paid-subtotal,method)
        }
    }
}
