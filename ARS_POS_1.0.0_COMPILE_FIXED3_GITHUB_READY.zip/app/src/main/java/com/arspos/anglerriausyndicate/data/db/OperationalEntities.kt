package com.arspos.anglerriausyndicate.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="users")
data class UserEntity(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val username:String,
    val displayName:String,
    val role:String,
    val pinHash:String,
    val active:Boolean=true
)

@Entity(tableName="customers")
data class CustomerEntity(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val name:String,
    val phone:String?=null,
    val address:String?=null,
    val points:Int=0,
    val outstandingDebt:Long=0
)

@Entity(tableName="cash_transactions")
data class CashTransactionEntity(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val type:String,
    val category:String,
    val amount:Long,
    val description:String?=null,
    val referenceId:Long?=null,
    val userId:Long=1,
    val createdAt:Long=System.currentTimeMillis()
)

@Entity(tableName="returns")
data class ReturnEntity(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val saleId:Long,
    val userId:Long=1,
    val reason:String,
    val total:Long,
    val createdAt:Long=System.currentTimeMillis()
)

@Entity(tableName="return_items")
data class ReturnItemEntity(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val returnId:Long,
    val productId:Long,
    val quantity:Int,
    val amount:Long
)

@Entity(tableName="audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val userId:Long=1,
    val action:String,
    val referenceId:Long?=null,
    val detail:String?=null,
    val createdAt:Long=System.currentTimeMillis()
)
