package com.arspos.anglerriausyndicate.data

import java.security.MessageDigest

object PinHasher {
    fun hash(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return "sha256\$" + digest.digest(pin.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    fun matches(stored: String, pin: String): Boolean =
        if (stored.startsWith("sha256\$")) stored == hash(pin) else stored == pin
}
