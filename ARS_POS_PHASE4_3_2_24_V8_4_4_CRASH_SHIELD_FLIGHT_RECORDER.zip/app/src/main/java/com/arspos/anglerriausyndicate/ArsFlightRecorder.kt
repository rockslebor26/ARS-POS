package com.arspos.anglerriausyndicate

import android.content.Context
import android.os.Build
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Phase 4.3.2.24 V8.4.4 — ARS Flight Recorder.
 *
 * A tiny, offline-first rolling diagnostic log for development. It intentionally
 * stores technical scanner/app metadata only. Transaction details, PINs and
 * customer data are not written here.
 */
object ArsFlightRecorder {
    private const val DIR = "ars_diagnostics"
    private const val LOG = "flight_recorder.jsonl"
    private const val MAX_BYTES = 1_500_000L
    private const val KEEP_BYTES = 900_000L
    private const val MAX_REPORT_LINES = 160

    @Volatile private var appContext: Context? = null
    @Volatile private var installedCrashHandler = false

    fun install(context: Context) {
        appContext = context.applicationContext
        if (!installedCrashHandler) {
            synchronized(this) {
                if (!installedCrashHandler) {
                    installedCrashHandler = true
                    val previous = Thread.getDefaultUncaughtExceptionHandler()
                    Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
                        runCatching {
                            event(
                                type = "UNCAUGHT_CRASH",
                                message = throwable.message ?: throwable::class.java.simpleName,
                                fields = mapOf(
                                    "thread" to thread.name,
                                    "exception" to throwable::class.java.name,
                                    "stack" to throwable.stackTraceToString().take(18_000)
                                )
                            )
                        }
                        previous?.uncaughtException(thread, throwable)
                    }
                }
            }
        }
        event("APP_START", "ARS POS started", baseDeviceFields())
    }

    fun newSession(prefix: String = "scan"): String =
        "$prefix-${System.currentTimeMillis()}-${UUID.randomUUID().toString().take(6)}"

    @Synchronized
    fun event(type: String, message: String = "", fields: Map<String, Any?> = emptyMap()) {
        val context = appContext ?: return
        runCatching {
            val dir = File(context.filesDir, DIR).apply { mkdirs() }
            val file = File(dir, LOG)
            rotateIfNeeded(file)

            val obj = JSONObject()
            obj.put("ts", System.currentTimeMillis())
            obj.put("time", isoNow())
            obj.put("type", type)
            obj.put("message", message)
            fields.forEach { (key, value) -> obj.put(key, sanitize(value)) }
            file.appendText(obj.toString() + "\n")
        }
    }

    @Synchronized
    fun buildReport(context: Context): String {
        if (appContext == null) appContext = context.applicationContext
        val file = File(File(context.filesDir, DIR), LOG)
        val lines = if (file.exists()) file.readLines().takeLast(MAX_REPORT_LINES) else emptyList()
        val crashes = lines.count { it.contains("\"type\":\"UNCAUGHT_CRASH\"") || it.contains("\"type\":\"SCAN_FATAL\"") }
        val scanStarts = lines.count { it.contains("\"type\":\"SCAN_START\"") }
        val scanCompleted = lines.count { it.contains("\"type\":\"SCAN_COMPLETE\"") }
        val scanErrors = lines.count { it.contains("\"type\":\"SCAN_ERROR\"") || it.contains("\"type\":\"SCAN_FATAL\"") }

        return buildString {
            appendLine("ARS POS DEVELOPMENT DIAGNOSTIC REPORT")
            appendLine("Phase: 4.3.2.24 V8.4.4")
            appendLine("Version: 1.3.9 (139)")
            appendLine("Generated: ${isoNow()}")
            appendLine("Android: ${Build.VERSION.RELEASE} / SDK ${Build.VERSION.SDK_INT}")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine()
            appendLine("SUMMARY")
            appendLine("- Scan sessions started: $scanStarts")
            appendLine("- Scan sessions completed: $scanCompleted")
            appendLine("- Scan errors/fatal events: $scanErrors")
            appendLine("- Uncaught/fatal crash records: $crashes")
            appendLine()
            appendLine("PRIVACY")
            appendLine("Technical diagnostics only. PIN, payment data and customer details are intentionally excluded.")
            appendLine()
            appendLine("RECENT EVENTS (oldest -> newest)")
            if (lines.isEmpty()) appendLine("No diagnostic events yet.")
            lines.forEach { appendLine(it) }
        }
    }

    @Synchronized
    fun clear(context: Context) {
        val file = File(File(context.filesDir, DIR), LOG)
        if (file.exists()) file.delete()
        event("LOG_CLEARED", "Diagnostic log cleared")
    }

    private fun rotateIfNeeded(file: File) {
        if (!file.exists() || file.length() < MAX_BYTES) return
        val bytes = file.readBytes()
        val start = (bytes.size - KEEP_BYTES.toInt()).coerceAtLeast(0)
        val tail = bytes.copyOfRange(start, bytes.size)
        var firstNewline = 0
        while (firstNewline < tail.size && tail[firstNewline] != '\n'.code.toByte()) firstNewline++
        val clean = if (firstNewline < tail.size - 1) tail.copyOfRange(firstNewline + 1, tail.size) else tail
        file.writeBytes(clean)
    }

    private fun sanitize(value: Any?): Any = when (value) {
        null -> JSONObject.NULL
        is Number, is Boolean, is String -> if (value is String) value.take(18_000) else value
        else -> value.toString().take(18_000)
    }

    private fun baseDeviceFields(): Map<String, Any?> = mapOf(
        "android" to Build.VERSION.RELEASE,
        "sdk" to Build.VERSION.SDK_INT,
        "device" to "${Build.MANUFACTURER} ${Build.MODEL}"
    )

    private fun isoNow(): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).format(Date())
}
