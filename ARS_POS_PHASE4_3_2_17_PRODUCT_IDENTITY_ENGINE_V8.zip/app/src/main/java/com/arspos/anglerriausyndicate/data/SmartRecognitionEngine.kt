package com.arspos.anglerriausyndicate.data

import android.graphics.Bitmap
import com.arspos.anglerriausyndicate.SmartProductInput
import com.arspos.anglerriausyndicate.VisualProductMatch
import com.arspos.anglerriausyndicate.data.db.ProductEntity
import kotlin.math.roundToInt

/**
 * Phase 4.3.2.17: ARS Product Identity Engine V8.
 *
 * Identity-first safety model: textual identity and barcode are evidence of
 * what the product IS; visual evidence is supporting evidence. Unknown objects
 * must never become sellable candidates merely because they look similar.
 *
 * Decision model:
 * 1) Barcode exact match is the strongest identity proof.
 * 2) OCR is normalized and evaluated using distinctive identity tokens.
 * 3) Visual evidence is aggregated across many master frames, not one frame.
 * 4) A large score is never enough by itself: the winner must also beat the
 *    second candidate by a meaningful margin.
 * 5) The final score is an identity-confidence score, not a raw OCR score.
 */
object SmartRecognitionEngine {
    data class Result(
        val match: VisualProductMatch?,
        val visualScore: Int,
        val textScore: Int,
        val finalScore: Int,
        val ocrText: String,
        val barcode: String = "",
        val reason: String,
        val candidates: List<RecognitionCandidate> = emptyList()
    )

    // Phase 4.3.2.17: Product Identity Engine V8.
    // Barcode remains strongest, but barcode is optional. Distinctive product
    // identity (brand/name/model/variant/profile) can now carry recognition.
    private const val ACCEPT_EXACT_BARCODE = 90
    private const val ACCEPT_STRONG_IDENTITY = 82
    private const val ACCEPT_IDENTITY_WITH_VISUAL = 68
    private const val ACCEPT_CANONICAL_TEXT = 78
    private const val ACCEPT_PROFILE_IDENTITY = 78
    private const val ACCEPT_VISUAL_ONLY = 80
    private const val ACCEPT_LONG_VISUAL_ONLY = 76
    private const val MIN_VISUAL_SUPPORT = 34
    private const val MIN_MARGIN = 10
    private const val MIN_VISUAL_MARGIN = 15
    private const val MIN_LONG_VISUAL_MARGIN = 12
    private const val MIN_TEXT_GATE = 58

    suspend fun recognize(
        crop: Bitmap,
        products: List<ProductEntity>,
        references: List<VisualProductMatch>,
        ocr: SmartProductInput.Draft,
        identityProfiles: Map<Long, ProductIdentityProfile> = emptyMap(),
        verifiedProductIds: Set<Long> = emptySet()
    ): Result {
        if (products.isEmpty()) return Result(null, 0, 0, 0, ocr.rawText, ocr.barcode, "Katalog kosong")

        val normalizedOcr = normalize(ocr.rawText)
        val detectedBarcode = normalizeCode(ocr.barcode)
        val detectedModel = normalizeCode(ocr.modelCode)
        val refsByProduct = references.groupBy { it.product.id }

        val candidates = products.map { product ->
            val refs = refsByProduct[product.id].orEmpty()
            val visual = aggregateVisual(refs)
            val profile = identityProfiles[product.id]
            val profileScore = profileScore(profile, normalizedOcr)
            val text = identityScore(product, normalizedOcr, detectedBarcode, detectedModel, profileScore, profile)
            val final = fuse(visual, text, detectedBarcode, detectedModel, product, refs)
            RecognitionCandidate(
                product = product,
                visualScore = visual,
                textScore = text,
                profileScore = profileScore,
                finalScore = final,
                evidence = evidence(product, visual, text, detectedBarcode, detectedModel, refs, profileScore),
                hasMaster = refs.isNotEmpty(),
                masterVerified = verifiedProductIds.contains(product.id),
                isLongObject = profile?.isLongObject == true
            )
        }.sortedWith(
            compareByDescending<RecognitionCandidate> { it.finalScore }
                .thenByDescending { it.textScore }
                .thenByDescending { it.visualScore }
        ).take(5)

        val best = candidates.firstOrNull()
        val second = candidates.getOrNull(1)
        val margin = if (best != null && second != null) best.finalScore - second.finalScore else 100
        val accepted = best != null && accept(best, second, margin, detectedBarcode, detectedModel, ocr.rawText.isNotBlank())
        val bestReference = best?.let { refsByProduct[it.product.id].orEmpty().maxByOrNull { ref -> ref.score } }

        val reason = when {
            best == null -> "Tidak ada kandidat katalog"
            accepted -> acceptedReason(best, margin, detectedBarcode, detectedModel)
            else -> rejectionReason(best, second, margin, detectedBarcode, detectedModel)
        }

        return Result(
            match = if (accepted) bestReference else null,
            visualScore = best?.visualScore ?: 0,
            textScore = best?.textScore ?: 0,
            finalScore = best?.finalScore ?: 0,
            ocrText = ocr.rawText,
            barcode = ocr.barcode,
            reason = reason,
            candidates = candidates
        )
    }

    /** Public for master verification and diagnostics. */
    fun textScore(product: ProductEntity, ocrText: String, barcode: String = "", model: String = "", profile: ProductIdentityProfile? = null): Int =
        identityScore(product, normalize(ocrText), normalizeCode(barcode), normalizeCode(model), profileScore(profile, normalize(ocrText)), profile)

    private fun identityScore(product: ProductEntity, ocr: String, barcode: String, model: String, profileBonus: Int = 0, profile: ProductIdentityProfile? = null): Int {
        val productBarcode = normalizeCode(product.barcode.orEmpty())
        val profileBarcode = normalizeCode(profile?.barcode.orEmpty())
        if (barcode.isNotBlank() && productBarcode.isNotBlank() && barcode == productBarcode) return 100
        if (barcode.isNotBlank() && profileBarcode.isNotBlank() && barcode == profileBarcode) return 100
        if (ocr.isBlank()) return 0

        val ocrTokens = tokenize(ocr)
        val identity = (
            identityTokens(product.brand.orEmpty()) +
            identityTokens(product.name) +
            identityTokens(product.variant.orEmpty()) +
            extractModelTokens(product.name) +
            extractModelTokens(product.variant.orEmpty()) +
            extractModelTokens(product.sku) +
            identityTokens(profile?.brand.orEmpty()) +
            identityTokens(profile?.name.orEmpty()) +
            identityTokens(profile?.variant.orEmpty()) +
            extractModelTokens(profile?.modelCode.orEmpty())
        ).map(::normalizeCode)
            .filter { it.length >= 3 && !STOP_WORDS.contains(it) }
            .distinct()

        if (identity.isEmpty()) return profileBonus.coerceIn(0, 100)

        // Exact normalized product-name phrase is an especially strong clue for
        // packages without barcodes. OCR may contain warnings/manufacturer text,
        // so we compare the meaningful name tokens rather than the whole OCR.
        // IMPORTANT V5: aliases are evidence, not canonical identity.
        // Previous versions mixed every historical OCR line into phraseTokens,
        // diluting a perfect match such as "LIGHTS AMERICAN BLEND".
        val nameTokens = identityTokens(product.name)
            .filter { it.length >= 3 && !STOP_WORDS.contains(it) }
        val profileNameTokens = identityTokens(profile?.name.orEmpty())
            .filter { it.length >= 3 && !STOP_WORDS.contains(it) }
        val canonicalNameTokens = (nameTokens + profileNameTokens).distinct()
        val phraseHits = canonicalNameTokens.count { expected ->
            ocrTokens.any { actual -> fuzzyToken(expected, actual) }
        }
        val phraseRatio = if (canonicalNameTokens.isNotEmpty()) {
            phraseHits.toFloat() / canonicalNameTokens.size
        } else 0f

        // V8 canonical text lane: OCR often returns the exact package words but
        // the generic profile scorer may underweight them when the product has
        // many other identity fields. A distinctive two-or-more-token product
        // name can therefore become strong evidence even without a barcode.
        if (canonicalNameTokens.size >= 2 && phraseRatio >= 0.67f) {
            score += (phraseRatio * 34f).roundToInt().coerceIn(22, 34)
            if (phraseRatio >= 0.90f) strongHits += 2 else strongHits++
        }

        val aliasTokens = profile?.aliases.orEmpty()
            .flatMap { identityTokens(it) }
            .filter { it.length >= 3 && !STOP_WORDS.contains(it) }
            .distinct()

        var score = 0
        var strongHits = 0

        // Brand: useful but deliberately capped so a common brand cannot
        // identify a product by itself.
        val brandTokens = identityTokens(product.brand.orEmpty())
            .filter { it.length >= 3 && !STOP_WORDS.contains(it) }
        val brandHits = fuzzyHits(brandTokens, ocrTokens)
        if (brandTokens.isNotEmpty() && brandHits > 0) {
            score += minOf(16, 10 + brandHits * 3)
            strongHits++
        }

        // Product name carries the largest no-barcode weight.
        if (phraseHits > 0) {
            score += (phraseRatio * 58f).roundToInt().coerceIn(0, 58)
            if (phraseHits >= 2) strongHits++
            if (phraseRatio >= 0.67f) strongHits++
            if (phraseRatio >= 0.90f && canonicalNameTokens.size >= 2) {
                score += 14
                strongHits += 2
            }
        }

        val variantTokens = identityTokens(product.variant.orEmpty())
            .filter { it.length >= 3 && !STOP_WORDS.contains(it) }
        val variantHits = fuzzyHits(variantTokens, ocrTokens)
        if (variantTokens.isNotEmpty() && variantHits > 0) {
            score += ((variantHits.toFloat() / variantTokens.size) * 18f).roundToInt().coerceIn(0, 18)
            if (variantHits >= 1) strongHits++
        }

        val modelTokens = (buildList {
            addAll(extractModelTokens(product.name))
            addAll(extractModelTokens(product.variant.orEmpty()))
            addAll(extractModelTokens(product.sku))
            addAll(extractModelTokens(profile?.modelCode.orEmpty()))
        }).distinct()

        if (model.isNotBlank() && modelTokens.any { fuzzyCode(it, model) }) {
            score += 25
            strongHits += 2
        } else if (modelTokens.isNotEmpty()) {
            val modelHit = fuzzyHits(modelTokens, ocrTokens, codeMode = true)
            if (modelHit > 0) {
                score += minOf(25, 18 + modelHit * 4)
                strongHits += 2
            }
        }

        val skuTokens = identityTokens(product.sku).filter { it.length >= 3 }
        val skuHit = fuzzyHits(skuTokens, ocrTokens, codeMode = true)
        if (skuHit > 0) {
            score += minOf(15, 10 + skuHit * 3)
            strongHits++
        }

        if (productBarcode.isNotBlank() && containsCode(ocr, productBarcode)) {
            score += 20
            strongHits += 2
        }

        // Identity aliases are product-specific memory gathered from OCR/master
        // enrollment. They are useful for imperfect OCR (for example a clipped
        // brand word), but are never allowed to override a barcode mismatch.
        if (profile != null && profile.aliases.isNotEmpty()) {
            val aliasTokens = profile.aliases
                .flatMap { identityTokens(it) }
                .filter { it.length >= 3 && !STOP_WORDS.contains(it) }
                .distinct()
            val aliasHits = fuzzyHits(aliasTokens, ocrTokens)
            if (aliasHits > 0) {
                score += minOf(18, aliasHits * 4)
                if (aliasHits >= 3) strongHits++
            }
        }

        // Profile bonus is evidence collected during master enrollment. It is
        // intentionally capped and cannot override a barcode mismatch.
        score += profileBonus.coerceAtMost(28)
        if (strongHits >= 2) score += 8
        if (strongHits >= 4) score += 7

        // A near-complete match of a distinctive product name is enough to
        // identify many no-barcode packages even when the visual angle differs.
        if (phraseRatio >= 0.80f && phraseHits >= 2) score += 12

        return score.coerceIn(0, 100)
    }

    private fun profileScore(profile: ProductIdentityProfile?, ocr: String): Int {
        if (profile == null || ocr.isBlank()) return 0
        val expected = (tokenize(normalize(profile.rawText)) +
                profile.aliases.flatMap { identityTokens(it) } +
                identityTokens(profile.brand) + identityTokens(profile.name) +
                identityTokens(profile.variant) + extractModelTokens(profile.modelCode))
            .distinct()
            .filter { it.length >= 4 && !STOP_WORDS.contains(it) && !it.all(Char::isDigit) }
            .take(48)
        if (expected.isEmpty()) return 0
        val actual = tokenize(ocr)
        val hits = expected.count { e -> actual.any { a -> fuzzyToken(e, a) } }
        return when {
            hits >= 5 -> 36
            hits == 4 -> 32
            hits == 3 -> 27
            hits == 2 -> 20
            hits == 1 -> 10
            else -> 0
        }
    }

    private fun aggregateVisual(refs: List<VisualProductMatch>): Int {
        if (refs.isEmpty()) return 0

        // Prefer one strong reference per capture angle. This prevents a single
        // repeated angle from dominating the whole master.
        val angleBest = refs
            .filter { it.photo.captureAngle != "UNKNOWN" }
            .groupBy { it.photo.captureAngle }
            .values
            .mapNotNull { group -> group.maxByOrNull { it.score }?.score }

        val scores = if (angleBest.isNotEmpty()) angleBest else refs.map { it.score }
        val sorted = scores.sortedDescending()
        val best = sorted.first()
        val top = sorted.take(6)
        val support = top.count { it >= 50 }
        val strong = top.count { it >= 65 }
        val average = top.average()
        val median = sorted[sorted.size / 2]

        var value = best * 0.50 + average * 0.25 + median * 0.10
        value += support.coerceAtMost(6) * 1.8
        value += strong.coerceAtMost(6) * 1.2
        if (best - average >= 25) value -= 7

        return value.roundToInt().coerceIn(0, 100)
    }

    private fun fuse(
        visual: Int,
        text: Int,
        barcode: String,
        model: String,
        product: ProductEntity,
        refs: List<VisualProductMatch>
    ): Int {
        if (barcode.isNotBlank() && normalizeCode(product.barcode.orEmpty()) == barcode) return 100

        return when {
            text >= 92 && visual >= MIN_VISUAL_SUPPORT -> maxOf(text, (text * .82f + visual * .18f).roundToInt())
            text >= ACCEPT_STRONG_IDENTITY && visual >= MIN_VISUAL_SUPPORT -> (text * .76f + visual * .24f).roundToInt()
            text >= ACCEPT_PROFILE_IDENTITY && visual >= MIN_VISUAL_SUPPORT -> (text * .74f + visual * .26f).roundToInt()
            text >= ACCEPT_IDENTITY_WITH_VISUAL && visual >= 45 -> (text * .66f + visual * .34f).roundToInt()
            model.isNotBlank() && text >= 75 && visual >= 30 -> (text * .72f + visual * .28f).roundToInt()
            else -> visual
        }.coerceIn(0, 100)
    }

    private fun accept(
        c: RecognitionCandidate,
        second: RecognitionCandidate?,
        margin: Int,
        barcode: String,
        model: String,
        hasOcr: Boolean
    ): Boolean {
        // V8 HYBRID: barcode exact is definitive.
        if (barcode.isNotBlank() && c.textScore >= ACCEPT_EXACT_BARCODE) return true

        // Text-bearing products still require a dominant identity candidate.
        // OCR can be imperfect, so V8 allows strong canonical identity with
        // moderate visual support instead of requiring an arbitrary OCR score.
        if (hasOcr) {
            if (c.textScore < MIN_TEXT_GATE) return false
            if (margin < MIN_MARGIN) return false
            if (c.visualScore < MIN_VISUAL_SUPPORT && c.textScore < 92) return false
            if (model.isNotBlank() && c.textScore >= 70 && c.visualScore >= 25) return true
            if (c.textScore >= 90 && c.visualScore >= 22) return true
            if (c.textScore >= ACCEPT_CANONICAL_TEXT && c.visualScore >= 28) return true
            if (c.textScore >= ACCEPT_STRONG_IDENTITY && c.visualScore >= MIN_VISUAL_SUPPORT) return true
            if (c.textScore >= ACCEPT_IDENTITY_WITH_VISUAL && c.visualScore >= 45) return true
            return false
        }

        // VISUAL MASTER MODE: for products with no barcode and no useful text,
        // the enrolled master becomes the identity. It must have been verified
        // by the owner first and must beat competing products by a margin.
        if (!c.masterVerified || !c.hasMaster) return false
        val threshold = if (c.isLongObject) ACCEPT_LONG_VISUAL_ONLY else ACCEPT_VISUAL_ONLY
        val requiredMargin = if (c.isLongObject) MIN_LONG_VISUAL_MARGIN else MIN_VISUAL_MARGIN
        if (c.visualScore < threshold) return false
        if (margin < requiredMargin) return false
        if (second != null && c.visualScore - second.visualScore < requiredMargin) return false
        return true
    }

    private fun acceptedReason(c: RecognitionCandidate, margin: Int, barcode: String, model: String): String = when {
        barcode.isNotBlank() && c.textScore >= ACCEPT_EXACT_BARCODE -> "BARCODE EXACT + identitas database"
        c.textScore >= 92 -> "Identitas OCR sangat kuat + dukungan visual + margin $margin%"
        model.isNotBlank() && c.textScore >= 75 -> "MODEL + OCR + visual master + margin $margin%"
        c.textScore >= ACCEPT_STRONG_IDENTITY -> "Identity key + visual master + margin $margin%"
        c.textScore >= ACCEPT_IDENTITY_WITH_VISUAL -> "OCR + visual master + margin $margin%"
        c.isLongObject -> "MASTER VISUAL JORAN/OBJEK PANJANG + orientasi fleksibel + margin $margin%"
        else -> "MASTER VISUAL TERVERIFIKASI + identitas visual + margin $margin%"
    }

    private fun evidence(product: ProductEntity, visual: Int, text: Int, barcode: String, model: String, refs: List<VisualProductMatch>, profile: Int = 0): String = when {
        barcode.isNotBlank() && normalizeCode(product.barcode.orEmpty()) == barcode -> "BARCODE EXACT"
        profile >= 20 && text >= ACCEPT_PROFILE_IDENTITY -> "MASTER IDENTITY + OCR + visual"
        model.isNotBlank() && text >= 75 -> "MODEL + OCR + visual"
        text >= ACCEPT_STRONG_IDENTITY && visual >= MIN_VISUAL_SUPPORT -> "IDENTITY KEY + visual master"
        text >= ACCEPT_IDENTITY_WITH_VISUAL && visual >= 50 -> "OCR + visual master"
        visual >= ACCEPT_VISUAL_ONLY && refs.isNotEmpty() -> "Master visual kuat"
        text > 0 && visual > 0 -> "OCR + visual"
        text > 0 -> "OCR sebagian"
        refs.isNotEmpty() -> "Visual master lemah"
        else -> "Bukti belum cukup"
    }

    private fun rejectionReason(best: RecognitionCandidate, second: RecognitionCandidate?, margin: Int, barcode: String, model: String): String = when {
        barcode.isNotBlank() && best.textScore < ACCEPT_EXACT_BARCODE ->
            "Barcode terdeteksi tetapi tidak cocok dengan database"
        best.textScore == 0 && !best.masterVerified ->
            "Tidak ada identitas OCR/barcode; master visual produk belum terverifikasi"
        best.textScore == 0 && best.visualScore < ACCEPT_VISUAL_ONLY ->
            "Visual belum cukup kuat untuk mengenali produk secara aman"
        best.textScore == 0 && margin < MIN_VISUAL_MARGIN ->
            "Kandidat visual terlalu berdekatan; objek dianggap UNKNOWN"
        best.textScore in 1 until MIN_TEXT_GATE ->
            "OCR ada tetapi identitas teks terlalu lemah; visual tidak boleh menentukan SKU"
        second != null && margin < MIN_MARGIN ->
            "Kandidat identitas terlalu berdekatan (margin $margin%); identitas belum aman"
        best.textScore >= MIN_TEXT_GATE && best.visualScore < MIN_VISUAL_SUPPORT && best.textScore < 92 ->
            "Identitas teks ada, tetapi dukungan visual master terlalu lemah"
        else -> "Bukti identitas belum cukup kuat; objek dianggap UNKNOWN"
    }

    private fun fieldScore(ocrTokens: List<String>, fieldTokens: List<String>, weight: Int): Pair<Int, Int> {
        if (fieldTokens.isEmpty()) return 0 to 0
        val usable = fieldTokens.filter { it.length >= 3 && !STOP_WORDS.contains(it) }
        if (usable.isEmpty()) return 0 to 0
        val hits = fuzzyHits(usable, ocrTokens)
        if (hits == 0) return 0 to 0
        val ratio = hits.toFloat() / usable.size
        val score = (ratio * weight).roundToInt().coerceIn(0, weight)
        val strong = when {
            hits >= 2 -> 2
            hits == 1 && usable.size <= 2 -> 1
            else -> 0
        }
        return score to strong
    }

    private fun fuzzyHits(expected: List<String>, actual: List<String>, codeMode: Boolean = false): Int =
        expected.count { e -> actual.any { a -> if (codeMode) fuzzyCode(e, a) else fuzzyToken(e, a) } }

    private fun fuzzyToken(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length < 4 || b.length < 4) return false
        if (a.contains(b) || b.contains(a)) return true
        return levenshtein(a, b) <= if (minOf(a.length, b.length) >= 7) 2 else 1
    }

    private fun fuzzyCode(a: String, b: String): Boolean {
        val x = normalizeCode(a)
        val y = normalizeCode(b)
        if (x == y) return true
        if (x.length < 4 || y.length < 4) return false
        if (x.contains(y) || y.contains(x)) return true
        return levenshtein(x, y) <= 1
    }

    private fun identityTokens(value: String): List<String> = tokenize(normalize(value))

    private fun extractModelTokens(value: String): List<String> {
        val normalized = normalize(value)
        return Regex("\\b[A-Z]{1,4}[- ]?[0-9]{1,5}[A-Z0-9-]*\\b|\\b[0-9]{3,8}\\b")
            .findAll(normalized)
            .map { normalizeCode(it.value) }
            .filter { it.length >= 4 }
            .toList()
    }

    private fun containsCode(text: String, code: String): Boolean = normalizeCode(text).contains(code)

    private fun levenshtein(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        val curr = IntArray(b.length + 1)
        for (i in a.indices) {
            curr[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                curr[j + 1] = minOf(curr[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            for (j in prev.indices) prev[j] = curr[j]
        }
        return prev[b.length]
    }

    private fun normalize(value: String): String = value
        .uppercase()
        .replace("0", "0")
        .replace(Regex("[^A-Z0-9]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private fun normalizeCode(value: String): String = normalize(value).replace(" ", "")
    private fun tokenize(value: String): List<String> = value.split(" ").filter { it.isNotBlank() }

    private val STOP_WORDS = setOf(
        "SIZE", "MODEL", "VARIAN", "VARIANT", "KOREA", "KOREAN", "TECHNOLOGY",
        "QUALITY", "PREMIUM", "BEST", "THE", "AND", "FOR", "GO", "PCS", "PC",
        "MADE", "IN", "QTY", "QUANTITY", "COLOR", "COLOUR", "HOOK", "FISHING",
        "CHEMICALLY", "SHARPENED", "CARBON", "HIGH", "EVERYONE", "CREATING", "PLEASURE"
    )
}
