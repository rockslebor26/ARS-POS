package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min

/**
 * V8.4.21 diagnostic continuity bridge from the temporal live preview to the
 * final locked scan. It never changes recognition, quantity, or cart state.
 */
object PersistentPhysicalIdBinder {
    data class LockedTrack(
        val trackId: String,
        val bounds: Rect,
        val frameWidth: Int,
        val frameHeight: Int,
        val proposalType: String,
        val state: String
    )

    data class Binding(
        val objectIndex: Int,
        val physicalObjectId: String,
        val persistentPhysicalId: String,
        val normalizedIou: Float
    )

    fun bind(tracks: List<LockedTrack>, objects: List<VisualScanObject>): List<Binding> {
        if (tracks.isEmpty() || objects.isEmpty()) return emptyList()
        val remaining = tracks.toMutableList()
        val result = ArrayList<Binding>()
        objects.forEach { obj ->
            val best = remaining.mapNotNull { track ->
                val overlap = normalizedIou(
                    track.bounds, track.frameWidth, track.frameHeight,
                    obj.normalizedBounds, obj.frameWidth, obj.frameHeight
                )
                if (overlap < 0.16f) null else {
                    val laneMatch = (track.proposalType == ScanProposal.TYPE_LONG) == (obj.proposalType == ScanProposal.TYPE_LONG)
                    track to (overlap * if (laneMatch) 1f else 0.78f)
                }
            }.maxByOrNull { it.second }
            if (best != null) {
                remaining.remove(best.first)
                result += Binding(
                    objectIndex = obj.index,
                    physicalObjectId = obj.physicalObjectId,
                    persistentPhysicalId = best.first.trackId,
                    normalizedIou = best.second.coerceIn(0f, 1f)
                )
            }
        }
        return result
    }

    private fun normalizedIou(
        a: Rect, aw: Int, ah: Int,
        b: Rect, bw: Int, bh: Int
    ): Float {
        if (aw <= 0 || ah <= 0 || bw <= 0 || bh <= 0) return 0f
        val al = a.left.toFloat() / aw; val at = a.top.toFloat() / ah
        val ar = a.right.toFloat() / aw; val ab = a.bottom.toFloat() / ah
        val bl = b.left.toFloat() / bw; val bt = b.top.toFloat() / bh
        val br = b.right.toFloat() / bw; val bb = b.bottom.toFloat() / bh
        val l = max(al, bl); val t = max(at, bt); val r = min(ar, br); val bot = min(ab, bb)
        if (r <= l || bot <= t) return 0f
        val inter = (r - l) * (bot - t)
        val areaA = (ar - al).coerceAtLeast(0f) * (ab - at).coerceAtLeast(0f)
        val areaB = (br - bl).coerceAtLeast(0f) * (bb - bt).coerceAtLeast(0f)
        val union = areaA + areaB - inter
        return if (union <= 0f) 0f else inter / union
    }
}
