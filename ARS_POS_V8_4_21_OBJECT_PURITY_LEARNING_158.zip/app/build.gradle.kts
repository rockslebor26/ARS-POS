plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.kapt")
}

android {
    namespace = "com.arspos.anglerriausyndicate"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.arspos.anglerriausyndicate"
        minSdk = 26
        targetSdk = 35
        versionCode = 158
        versionName = "1.5.8"
    }

    val releaseStorePath = System.getenv("ARS_RELEASE_STORE_FILE")
    val releaseStorePassword = System.getenv("ARS_RELEASE_STORE_PASSWORD")
    val releaseKeyAlias = System.getenv("ARS_RELEASE_KEY_ALIAS")
    val releaseKeyPassword = System.getenv("ARS_RELEASE_KEY_PASSWORD")

    val releaseRequested = gradle.startParameter.taskNames.any {
        it.contains("release", ignoreCase = true)
    }

    val releaseSigningAvailable = listOf(
        releaseStorePath,
        releaseStorePassword,
        releaseKeyAlias,
        releaseKeyPassword
    ).all { !it.isNullOrBlank() }

    if (releaseRequested && !releaseSigningAvailable) {
        val missing = buildList {
            if (releaseStorePath.isNullOrBlank()) add("ARS_RELEASE_STORE_FILE")
            if (releaseStorePassword.isNullOrBlank()) add("ARS_RELEASE_STORE_PASSWORD")
            if (releaseKeyAlias.isNullOrBlank()) add("ARS_RELEASE_KEY_ALIAS")
            if (releaseKeyPassword.isNullOrBlank()) add("ARS_RELEASE_KEY_PASSWORD")
        }

        throw GradleException(
            "ARS POS OFFICIAL RELEASE signing belum dikonfigurasi. Missing: ${missing.joinToString()}"
        )
    }

    if (releaseRequested && !file(releaseStorePath!!).exists()) {
        throw GradleException("ARS POS release keystore tidak ditemukan: $releaseStorePath")
    }

    signingConfigs {
        create("arsOfficialRelease") {
            if (releaseSigningAvailable) {
                storeFile = file(releaseStorePath!!)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("arsOfficialRelease")
            isMinifyEnabled = false
        }
    }

    // Keep Java/Kotlin compilation on the same JVM target for Android release builds.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    // Phase 4.3.2.5: guided product-master video capture.
    implementation("androidx.camera:camera-core:1.4.1")
    implementation("androidx.camera:camera-camera2:1.4.1")
    implementation("androidx.camera:camera-lifecycle:1.4.1")
    implementation("androidx.camera:camera-video:1.4.1")
    implementation("androidx.camera:camera-view:1.4.1")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    // Phase 4.3: bundled on-device object detection for offline multi-object scanning.
    implementation("com.google.mlkit:object-detection:17.0.2")
    // Phase 4.3.1: bundled offline OCR + barcode recognition for product intake.
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.9.0")
    kapt("androidx.room:room-compiler:2.6.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
