package com.arspos.anglerriausyndicate

import android.graphics.Rect
import com.arspos.anglerriausyndicate.data.RecognitionCandidate
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.25 V8.4.5 — physical-object aggregation.
 *
 * The scanner intentionally produces overlapping proposals from ML Kit,
 * tiled passes and the long-object lane. Those proposals are useful for
 * recall, but they must not become duplicate products in the cashier UI.
 *
 * This class merges proposals that are very likely to represent the same
 * physical object. It never turns an UNKNOWN proposal into an accepted SKU;
 * the strict recognition gate remains authoritative.
 */
object ScanResultAggregator {
    data class Summary(
        val before: Int,
        val after: Int,
        val merged: Int,
        val longGroups: Int
    )

    data class Aggregated(
        val objects: List<VisualScanObject>,
        val summary: Summary
    )

    fun aggregate(input: List<VisualScanObject>): Aggregated {
        if (input.size <= 1) {
            return Aggregated(input, Summary(input.size, input.size, 0, 0))
        }

        val groups = mutableListOf<MutableList<VisualScanObject>>()
        input.sortedBy { it.index }.forEach { candidate ->
            val group = groups.firstOrNull { existing ->
                existing.any { samePhysicalObject(it, candidate) }
            }
            if (group != null) group += candidate else groups += mutableListOf(candidate)
        }

        var longGroups = 0
        val merged = groups.map { group ->
            if (group.any { topCandidate(it)?.isLongObject == true }) longGroups++
            mergeGroup(group)
        }.sortedBy { it.index }
            .mapIndexed { index, item -> item.copy(index = index + 1) }

        return Aggregated(
            objects = merged,
            summary = Summary(
                before = input.size,
                after = merged.size,
                merged = (input.size - merged.size).coerceAtLeast(0),
                longGroups = longGroups
            )
        )
    }

    private fun mergeGroup(group: List<VisualScanObject>): VisualScanObject {
        if (group.size == 1) return group.first()

        // A recognized member always outranks an UNKNOWN member. Otherwise use
        // the strongest final/visual evidence as the representative. We do not
        // manufacture a new match here, so aggregation cannot bypass safety.
        val representative = group.sortedWith(
            compareByDescending<VisualScanObject> { it.match != null }
                .thenByDescending { it.finalScore }
                .thenByDescending { it.visualScore }
        ).first()

        val bounds = union(group.map { it.bounds })
        val candidates = mergeCandidates(group)
        val suffix = "AGGREGATED ${group.size} proposal"

        return representative.copy(
            index = group.minOf { it.index },
            bounds = bounds,
            reason = if (representative.reason.contains("AGGREGATED")) representative.reason
            else "${representative.reason} • $suffix",
            candidates = candidates
        )
    }

    private fun mergeCandidates(group: List<VisualScanObject>): List<RecognitionCandidate> {
        val all = group.flatMap { it.candidates }
        if (all.isEmpty()) return emptyList()

        return all.groupBy { it.product.id }
            .values
            .map { sameProduct ->
                val best = sameProduct.maxWithOrNull(
                    compareBy<RecognitionCandidate> { it.finalScore }
                        .thenBy { it.textScore }
                        .thenBy { it.visualScore }
                ) ?: sameProduct.first()
                val support = sameProduct.size
                best.copy(
                    evidence = if (support > 1) "${best.evidence} • support=$support" else best.evidence
                )
            }
            .sortedWith(
                compareByDescending<RecognitionCandidate> { it.finalScore }
                    .thenByDescending { it.textScore }
                    .thenByDescending { it.visualScore }
            )
            .take(5)
    }

    private fun samePhysicalObject(a: VisualScanObject, b: VisualScanObject): Boolean {
        val ra = a.bounds
        val rb = b.bounds
        if (iou(ra, rb) >= 0.34f) return true
        if (intersectionOverSmaller(ra, rb) >= 0.66f) return true

        val areaA = area(ra)
        val areaB = area(rb)
        val minArea = min(areaA, areaB).coerceAtLeast(1L)
        val maxArea = max(areaA, areaB).coerceAtLeast(1L)
        val areaRatio = maxArea.toFloat() / minArea.toFloat()

        val distance = centerDistance(ra, rb)
        val minDiag = min(diagonal(ra), diagonal(rb)).coerceAtLeast(1f)
        if (distance <= minDiag * 0.15f && areaRatio <= 2.15f) return true

        val topA = topCandidate(a)
        val topB = topCandidate(b)
        val sameProduct = topA != null && topB != null && topA.product.id == topB.product.id
        val longObject = topA?.isLongObject == true || topB?.isLongObject == true

        // Long products are frequently split into neighboring vertical or
        // horizontal strips. Merge only when both proposals agree on the same
        // top product and their long axes overlap substantially.
        if (sameProduct && longObject && longAligned(ra, rb)) return true

        return false
    }

    private fun longAligned(a: Rect, b: Rect): Boolean {
        val aVertical = a.height() >= a.width() * 1.45f
        val bVertical = b.height() >= b.width() * 1.45f
        val aHorizontal = a.width() >= a.height() * 1.45f
        val bHorizontal = b.width() >= b.height() * 1.45f

        if (aVertical && bVertical) {
            val overlap = axisOverlap(a.top, a.bottom, b.top, b.bottom)
            val minLength = min(a.height(), b.height()).coerceAtLeast(1)
            val centerDx = kotlin.math.abs(centerX(a) - centerX(b))
            val widthScale = max(a.width(), b.width()).coerceAtLeast(1)
            return overlap.toFloat() / minLength >= 0.30f && centerDx <= widthScale * 0.95f
        }

        if (aHorizontal && bHorizontal) {
            val overlap = axisOverlap(a.left, a.right, b.left, b.right)
            val minLength = min(a.width(), b.width()).coerceAtLeast(1)
            val centerDy = kotlin.math.abs(centerY(a) - centerY(b))
            val heightScale = max(a.height(), b.height()).coerceAtLeast(1)
            return overlap.toFloat() / minLength >= 0.30f && centerDy <= heightScale * 0.95f
        }

        return false
    }

    private fun topCandidate(item: VisualScanObject): RecognitionCandidate? =
        item.candidates.firstOrNull()

    private fun union(rects: List<Rect>): Rect = Rect(
        rects.minOf { it.left },
        rects.minOf { it.top },
        rects.maxOf { it.right },
        rects.maxOf { it.bottom }
    )

    private fun area(r: Rect): Long =
        r.width().coerceAtLeast(0).toLong() * r.height().coerceAtLeast(0).toLong()

    private fun iou(a: Rect, b: Rect): Float {
        val intersection = intersectionArea(a, b)
        if (intersection <= 0L) return 0f
        val union = area(a) + area(b) - intersection
        return if (union <= 0L) 0f else intersection.toFloat() / union.toFloat()
    }

    private fun intersectionOverSmaller(a: Rect, b: Rect): Float {
        val intersection = intersectionArea(a, b)
        val smaller = min(area(a), area(b)).coerceAtLeast(1L)
        return intersection.toFloat() / smaller.toFloat()
    }

    private fun intersectionArea(a: Rect, b: Rect): Long {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0L
        return (right - left).toLong() * (bottom - top).toLong()
    }

    private fun centerDistance(a: Rect, b: Rect): Float =
        hypot(centerX(a) - centerX(b), centerY(a) - centerY(b))

    private fun centerX(r: Rect): Float = (r.left + r.right) / 2f
    private fun centerY(r: Rect): Float = (r.top + r.bottom) / 2f
    private fun diagonal(r: Rect): Float = hypot(r.width().toFloat(), r.height().toFloat())

    private fun axisOverlap(a0: Int, a1: Int, b0: Int, b1: Int): Int =
        (min(a1, b1) - max(a0, b0)).coerceAtLeast(0)
}
