# ARS POS Project Continuity Standard

Starting with **Phase 4.3.2.26 / V8.4.6 / 1.4.1 (141)**, this ZIP is the continuation baseline for every future ARS POS version.

Permanent rules:

- Package/applicationId: `com.arspos.anglerriausyndicate`
- Official release signer: dedicated ARS POS release keystore only
- Never fall back to debug signing for release APKs
- `versionCode` increases for every update
- Future APKs are installed over the existing official APK, not by uninstalling it
- Database schema changes must have explicit Room migrations
- ARS Flight Recorder remains enabled for development builds/releases while the app is under active development
- Every ChatGPT diagnostic report includes current version, previous version, install/update transition, package id, signer SHA-256, first install time, last update time, and database version
- Recognition safety remains conservative: UNKNOWN is preferred over an unsafe product match

This file is a project contract for subsequent development phases.
