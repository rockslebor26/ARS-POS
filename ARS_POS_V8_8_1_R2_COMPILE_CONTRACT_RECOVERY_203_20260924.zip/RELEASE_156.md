# ARS POS 1.5.6 (156) — V8.4.20-A test release

- Phase: 4.3.2.40
- Engine: V8.4.20-A — Package Edge Firewall + Bidirectional Anchor Role Truth
- Previous official installed version: 1.5.5 (155)
- Required install mode: in-place update
- applicationId remains `com.arspos.anglerriausyndicate`
- Database remains v5
- Official signer fingerprint must remain `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`

This is the **A-stage validation build**, not the declaration that V8.4.20 is finished. Build must pass source integrity, JVM evidence replay, Android unit tests, signed release assembly, package/version/signer/alignment verification, then device acceptance.

Recognition thresholds are intentionally unchanged from V8.4.19.
