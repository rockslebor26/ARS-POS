# ARS POS 1.5.7 (157)

- Phase: 4.3.2.40
- Engine: V8.4.20 — Scene-Aware Smart Scan
- Package: `com.arspos.anglerriausyndicate`
- Database: v5, tanpa destructive migration
- Update: in-place only; jangan uninstall aplikasi resmi
- Required signer SHA-256: `AA2A8C6C885BA887577A2C2813AEA2F72E5FB51892FC486108B57F8389D56AEB`

## Added

- Live Camera Smart Scan.
- Foreground/scene-change analysis trigger.
- Temporal Scene Object Ledger.
- Live database candidate preview.
- Stable/occluded/unknown object states.
- Final scene lock before production recognition.
- Live telemetry in ARS Flight Recorder.
- Same-version replacement audit telemetry.

## Preserved

- Recognition thresholds from V8.4.19/V8.4.20-A.
- Package Edge Firewall.
- Bidirectional Anchor Role Truth.
- Physical Object Truth.
- Cross-category firewall.
- Atomic quantity confirmation and duplicate-session protection.
- Visual evidence binding for final scan sessions.
