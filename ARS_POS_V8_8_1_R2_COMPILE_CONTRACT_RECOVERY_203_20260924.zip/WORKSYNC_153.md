# ARS POS V8.4.17 WorkSync — 1.5.3 (153)

Tanggal: 14 September 2026. Phase 4.3.2.37. Status: kandidat source untuk uji.

## Sinkronisasi dengan Work

Source diteruskan dari `ARS_POS_V8_4_17_STABLE_RELEASE.zip` yang sudah berisi implementasi Work code 152. Nama lama tersebut tidak dipakai sebagai bukti bahwa APK sudah lolos uji. Tiga fitur dipertahankan: kotak objek interaktif, konfirmasi jumlah/anti-double-add, dan laporan bergambar. Teks teknis tetap berada di Detail diagnostik.

Bukti runtime yang diperiksa pada pekerjaan ini ialah ZIP `ARS_DIAGNOSTIC_V8_4_16_1789384832508.zip`: 18/18 scan selesai, 36 `EVIDENCE_ERROR` tanpa session, rata-rata scan 701,2 ms, trusted=0 dan uncertain=0. Tidak ditemukan file yang hilang dari referensi manifest yang ada, tetapi overlay/anchor memang tidak termanifestasikan. Angka 144 errors dari retrieval percakapan lain tidak digunakan untuk ZIP ini.

## Perubahan source

| Bagian | Perubahan dan batasnya |
|---|---|
| Bitmap | Salinan mutable untuk overlay dipertahankan. Crop penuh kini punya ownership sendiri; recycling crop tidak lagi boleh merecycle source. Alokasi anchor parsial dilepas bila gagal. |
| Evidence | Completion diproses setelah antrean gambar sesi. Error/drop menandai evidence PARTIAL. Export menolak hasil yang masih diproses, sehingga tidak mengekspor diam-diam sebelum selesai. |
| Anchor sebelum identitas | Track bersumbu, termasuk yang ditolak, mendapat crop HANDLE/SIDE/TIP diagnostik. Perannya dilabeli `GEOMETRIC_HYPOTHESIS_NOT_IDENTITY`, bukan klaim bahwa handle/SKU sudah benar. |
| Fisik joran | Track tidak lagi dibuang semata karena ML Kit mendukung track lain. ID dipertahankan tanpa reindex pascapruning. Merge membutuhkan kecocokan terhadap seluruh anggota; sumbu sejajar yang terpisah tidak digabung hanya karena kotak detektor lebar. |
| Authenticity | Sampling memilih support dekat sumbu terlebih dahulu. Variasi shaft dipisahkan dari handle jika pola segmen terukur mendukungnya. Semua gate skor acceptance tetap; perubahan fitur ini belum merupakan bukti akurasi di perangkat. |
| Ownership NORMAL | Hanya `TRUSTED_ROD` memiliki ownership. NON_ROD/uncertain tidak memblokir NORMAL. Gate independen `REJECT_NORMAL_REQUIRES_IDENTITY` tetap melarang penerimaan NORMAL visual-only, termasuk lantai. |
| Rescue | Memerlukan tepat satu uncertain track dengan dukungan segmen dan master terverifikasi. Tidak aktif hanya karena garis lantai/axis ada; tidak menyatukan beberapa joran. Selalu evidence-only, quantity=false. |
| Barcode | Penerimaan exact memerlukan kecocokan barcode katalog/profile yang nyata dan unik. Teks score 100 dengan barcode berbeda tidak boleh melewati gate. Kandidat dihitung per productId. |
| Kasir | Koordinat kotak dan ketukan mengikuti area gambar Fit, termasuk ruang kosong pada preview. Commit memvalidasi session aktif, produk yang diterima scan, duplikat draft, dan stok terhadap isi keranjang sebelum mengubah cart. Kegagalan validasi tidak menambah sebagian isi review. |
| Telemetry | `geometryBridgeSuppressed`, `authenticityRejected`, `backgroundLineSuppressed`, `physicalDuplicateMerged` dipisahkan. Counter legacy tetap ada dengan peringatan cakupannya. |

Harga/SKU/stok berasal dari database, bukan OCR. Review mengambil data produk dari hasil scan yang diterima; pemeriksaan database saat checkout tetap berlaku. Anti-double-add berlaku untuk session yang sama pada ViewModel hidup; scan baru adalah session baru dan dapat menambah unit lagi setelah konfirmasi. Ini bukan dedup objek fisik lintas foto atau persistensi cart lintas process death.

## Yang sengaja belum diklaim selesai

- Identity tie NORMAL 100 vs 100 tetap ditolak. Bobot OCR antarkatalog tidak diubah tanpa data pembeda SKU yang cukup.
- Tidak ada klaim pengenalan joran sudah meningkat, dua joran pasti dihitung dua, atau handle/tip sudah berlabel benar di semua kondisi.
- Perubahan geometri belum diuji terhadap foto ground truth di Android; pedoman uji di bawah adalah release gate, bukan hasil uji yang telah lulus.
- Pengukuran latency/native memory dan audit timestamp update perlu diulang; data sehat V8.4.16 tidak otomatis membuktikan V8.4.17 sehat.

## Build dan update aman

1. Upload `ARS_POS_V8_4_17_WORKSYNC_153.zip` persis dengan nama tersebut ke root repository.
2. Ganti isi `.github/workflows/build-apk.yml` dengan companion `ARS_POS_V8_4_17_WORKSYNC_153.yml`. Tidak perlu menjalankan workflow lama atau merename ZIP menjadi nama versi lama.
3. Gunakan lima GitHub Secrets yang sudah dipakai: `ARS_RELEASE_KEYSTORE_BASE64`, `ARS_RELEASE_STORE_PASSWORD`, `ARS_RELEASE_KEY_ALIAS`, `ARS_RELEASE_KEY_PASSWORD`, `ARS_RELEASE_CERT_SHA256`. Jangan kirim private keystore/password ke percakapan atau repository.
4. Jalankan Actions workflow. Workflow memeriksa checksum source, invariant, unit test, compile, package/version, signer dan alignment. Jika gagal, jangan memasang APK lain untuk melewati gate.
5. Ambil artifact `ARS-POS-V8.4.17-WORKSYNC-153-OFFICIAL`. Ekstrak dan pasang `ARS-POS-1.5.3-V8.4.17-WORKSYNC-SIGNED.apk` langsung di atas APK resmi yang terpasang. Jangan uninstall.

Application ID wajib `com.arspos.anglerriausyndicate`; code 153 lebih tinggi dari 151 maupun 152; DB v5 tidak berubah. Signer wajib `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`.

## Matriks uji di realme RMX3563 / Android 14

Sebelum update, ekspor backup data lewat fasilitas aplikasi yang tersedia dan catat jumlah produk, stok serta transaksi contoh. Gunakan barang uji; jangan selesaikan transaksi penjualan nyata hanya untuk pengujian.

| Uji | Langkah | Kriteria yang diperiksa |
|---|---|---|
| 1. Update | Pasang APK 153 di atas 151/152, buka Dev Center | Versi 1.5.3, code153, phase37, engine17; signer sama; data produk/stok/transaksi tetap; tidak FC. |
| 2. Bukti gambar | Scan satu joran lalu ekspor laporan bergambar | Scene, crop, overlay, pre-identity anchors tersedia dan ID sesuai. Evidence COMPLETE hanya jika tidak ada failure/drop; jangan abaikan PARTIAL. |
| 3. Satu joran | Joran penuh di latar polos, lalu framing handle; ulang tiap posisi 3x | Bandingkan sumbu dengan joran nyata dan periksa handle/shaft/tip. Target satu physical instance; tidak boleh menerima SKU keliru. |
| 4. Dua sejajar | Dua joran, kedua handle jelas, tidak saling menutup; 3x | Dua benda harus tetap dua track; tidak collapse menjadi satu atau count lebih dari dua. Jika belum ada accepted LONG, quantity LONG belum dapat dinyatakan lulus. |
| 5. Dua silang | Dua joran membentuk X, kedua handle terlihat; 3x | Sumbu mengikuti masing-masing joran melewati crossing, ID berbeda; crossing tidak berubah menjadi branch palsu/merge. |
| 6. Negative control | Lantai polos, keramik bernat, bayangan/garis tanpa produk; masing-masing 3x | Accepted product=0 dan cart tidak bertambah. Adanya garis saja tidak memicu full-frame rescue. |
| 7. NORMAL | Produk kemasan beridentitas jelas, lalu dekat joran dan di dekat garis nat | NON_ROD tidak memiliki ownership; teks/barcode tetap crop-scoped. Tie SKU tetap UNKNOWN, tidak dipaksa lulus. |
| 8. Ketuk kotak | Foto portrait/landscape pada preview terbatas tinggi; ketuk tengah objek dan ruang kosong samping | Kotak tepat di objek; ketukan ruang kosong tidak memilih objek; pilihan sesuai objek yang disentuh. |
| 9. Quantity | Gunakan produk yang benar-benar dikenali. Tinjau jumlah, batalkan, buka lagi, konfirmasi dua kali cepat | Batal tidak mengubah cart. Session sama hanya menambah sekali. Stok melebihi sisa cart ditolak keseluruhan dan review tetap terbuka. |
| 10. State lama | Setelah scan baru, atau setelah cart dikosongkan/checkout, coba ulang review lama bila UI memungkinkan | Session lama tidak boleh menambah. Scan baru dapat menambah setelah konfirmasi baru. |
| 11. Soak | 20 scan bergantian NORMAL, single rod, dua rod, floor; ekspor ZIP sebelum membersihkan log | Tidak FC/ANR; error/drop diperiksa; tren native/PSS setelah warm-up dicatat. Bandingkan latency dengan baseline, bukan hanya satu scan. |

Kirim kembali ZIP diagnostik, screenshot About/Dev Center, dan label ground truth singkat (sesi mana berisi 1 joran/2 joran/lantai). Keputusan untuk menyatakan scanner siap produksi menunggu hasil ini.

## Verifikasi pada lingkungan penyusunan

- 31 pemeriksaan statis invariant: lulus.
- Pemeriksaan leksikal delimiter/string pada 49 file Kotlin: lulus; bukan kompilasi.
- Enam unit test Python untuk alat pemeriksaan leksikal: lulus; bukan pengujian engine Android.
- 29 Kotlin/JVM regression tests tersedia untuk workflow: belum dijalankan di lingkungan ini.
- YAML terurai dan seluruh blok shell lolos `bash -n`. ZIP/checksum diverifikasi saat pengemasan.
- Seluruh source Room database sama dengan baseline V8.4.16.
- APK bertanda tangan resmi, emulator, uji perangkat, akurasi gambar: belum dijalankan. Android SDK/Gradle tidak tersedia di lingkungan ini; unduhan Gradle tidak selesai.

Rujukan implementasi: [Android Bitmap ownership/copy](https://developer.android.com/reference/android/graphics/Bitmap), [Gradle on GitHub Actions](https://docs.gradle.org/current/userguide/github-actions.html). Perubahan source dan batas pengujian di atas merupakan hasil pemeriksaan proyek, bukan klaim dari dokumentasi tersebut.
