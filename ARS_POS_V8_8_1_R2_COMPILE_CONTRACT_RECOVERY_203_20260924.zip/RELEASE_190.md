# ARS POS 1.9.0 (190) — V8.7.0

- Phase: 4.3.4.1
- Engine: V8.7.0 Correct-Type Identity Routing
- Update: in-place only from official signer.
- applicationId unchanged: `com.arspos.anglerriausyndicate`
- Room database remains v5.
- Recognition thresholds unchanged.

Primary fix: field-proven `LONG -> NON_ROD -> dropped` failure is replaced by `LONG hypothesis -> NON_ROD -> NORMAL purity -> NORMAL identity scoring` only for ML-owned physical objects.
