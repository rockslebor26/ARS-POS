# Phase 4.3.5.1 / V8.8.1 — Deterministic Object Intelligence

## Objective
Close the field failures observed in V8.8.0 without relaxing any recognition threshold or transaction safety rule.

## Release blockers addressed

1. **ViewModel-owned finalization** — final Smart Scan no longer runs inside a Compose-bound coroutine. The ViewModel owns the job and an immutable copy of the locked frame.
2. **Locked Scene Continuity** — final recognition receives the exact live lock snapshot and preserves one-to-one persistent physical IDs through pre-gate and fallback binding.
3. **Temporal Identity Hold** — a previously proven MATCHED identity can survive at most two weak live frames while the same physical track remains present. It cannot invent or transfer identity and remains preview-only.
4. **Bounded Live OCR Reuse** — OCR can be reused only for the same lane/product/location-size bucket, for a short TTL. A materially better visual frame forces a fresh OCR attempt.
5. **Adaptive LONG Axis Width** — LONG proposal width is measured around each detected axis instead of using the old fixed ~9.5% frame corridor. This reduces floor-grout/background contamination before rod authenticity evaluation.
6. **Automatic AI Failure Handoff** — final-scan errors or loss of a previously identified live scene create a read-only ENGINEERING_PROPOSAL_GATED request. The proposal is surfaced in scan diagnostics. AI still cannot create quantity, mutate stock/payment, lower thresholds, change signer, or install an APK.

## Safety invariants retained

- applicationId: `com.arspos.anglerriausyndicate`
- Room database: v5
- Official release signer must stay unchanged.
- All 14 SmartRecognitionEngine thresholds remain unchanged.
- Cloud Identity remains SHADOW/non-authoritative.
- Self Learning remains ACTIVE_CONFIRMED_ONLY.
- Final quantity remains physical-object-owned and operator reviewed.

## Field acceptance gates

- 0 Compose `LeftCompositionCancellationException` final-scan failures in 100 lock/finalize cycles.
- 0 incomplete scan sessions unless explicitly cancelled by app lifecycle.
- NORMAL first MATCH median <= 1.5 s; P95 <= 2.5 s on verified masters.
- Stable MATCH -> UNKNOWN flicker = 0 for one/two weak frames on the same physical track.
- Cross-type candidate = 0 in the bound regression set.
- Duplicate quantity = 0.
- Background grout/edges must never become quantity-eligible rods.
- Valid rod test set must not resolve entirely as NON_ROD.
- AI failure handoff must emit either a structured proposal or an explicit typed gateway/local-fallback result.
