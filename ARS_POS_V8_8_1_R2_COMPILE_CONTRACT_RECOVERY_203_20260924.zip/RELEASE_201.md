# ARS POS 1.10.1 (201)

Phase 4.3.5.1 / Engine V8.8.1 — Deterministic Object Intelligence.

This is an **in-place official update** from 1.10.0 (200). Do not uninstall the installed official app before updating.

## Primary changes
- Final Smart Scan moved from Compose `rememberCoroutineScope()` to ViewModel-owned lifecycle.
- Locked frame is copied and owned for deterministic finalization.
- Persistent live-to-final object ownership retained one-to-one.
- Two-frame preview identity hold for already proven matches only.
- Short-lived OCR reuse with quality-triggered refresh.
- Adaptive measured LONG axis width instead of a fixed wide corridor.
- Automatic read-only ARS AI Engineer failure handoff.

## Unchanged safety boundaries
- package: `com.arspos.anglerriausyndicate`
- database: v5
- recognition thresholds: unchanged
- quantity/stock/payment: AI cannot mutate
- Cloud Identity: SHADOW
- Self Learning: ACTIVE_CONFIRMED_ONLY
- signer: must equal the existing official certificate in GitHub release secrets
