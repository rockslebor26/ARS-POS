# Build resmi kandidat 156 — V8.4.20-A

Ikuti `README.md` dan gunakan file pendamping `ARS_POS_V8_4_20A_PACKAGE_EDGE_ANCHOR_156.yml` sebagai `.github/workflows/build-apk.yml`.

Source ZIP: `ARS_POS_V8_4_20A_PACKAGE_EDGE_ANCHOR_156.zip`.
Toolchain: AGP 8.7.3 / Gradle 8.9 / Kotlin 2.0.21 / Java 17 / compileSdk 35.

Release hanya dengan signer resmi ARS POS. Workflow wajib memverifikasi package `com.arspos.anglerriausyndicate`, versionCode 156, versionName 1.5.6, kenaikan 156 > 155, signer SHA-256 resmi, zip alignment, source integrity, JVM evidence replay, Android unit tests, dan `assembleRelease`.

Kompilasi Android penuh dan APK bertanda tangan dilakukan oleh GitHub Actions; source package tidak menyertakan keystore dan tidak boleh membuat signer baru.
