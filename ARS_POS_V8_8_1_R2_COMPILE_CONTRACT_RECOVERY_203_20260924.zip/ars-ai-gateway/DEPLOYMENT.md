# ARS AI Gateway — production deployment

This gateway is the only component allowed to hold `OPENAI_API_KEY`. ARS POS Android must never contain that key.

## Required secrets

Generate three independent secrets:

1. `OPENAI_API_KEY` — OpenAI project key with the minimum permissions needed for Responses API.
2. `ARS_AI_GATEWAY_TOKENS` — one or more long random device access tokens (comma separated).
3. `ARS_AI_SAFETY_SALT` — separate random value used to derive a non-PII safety identifier.

Recommended token generation:

```bash
openssl rand -hex 32
```

Never commit `.env` or any real secret.

## Pre-deploy verification

```bash
cd ars-ai-gateway
node --check server.mjs
node --check security.mjs
node --test
```

## Docker

```bash
docker build -t ars-ai-gateway:2.0.0 .
docker run --rm -p 8787:8787 \
  --env-file .env \
  ars-ai-gateway:2.0.0
```

Verify locally:

```bash
curl http://127.0.0.1:8787/health
```

Production must terminate TLS and expose **HTTPS only**. Do not expose the service over cleartext HTTP to the Android device.

## Google Cloud Run example

Cloud Run provides managed HTTPS. Store secrets in Secret Manager; do not pass real secrets on a shared command line or commit them to YAML.

High-level sequence:

1. Create a Google Cloud project and enable Cloud Run, Artifact Registry, Secret Manager.
2. Create secrets for `OPENAI_API_KEY`, `ARS_AI_GATEWAY_TOKENS`, and `ARS_AI_SAFETY_SALT`.
3. Build this Docker image and deploy it to Cloud Run.
4. Map those Secret Manager values to the environment variables above.
5. Set `ARS_AI_MIN_VERSION_CODE=172` and keep `ARS_AI_REQUIRE_SIGNATURE=true`.
6. Restrict ingress/authentication as appropriate for your deployment model and protect the gateway token.
7. Use the generated `https://...run.app` URL (or your custom HTTPS domain) in ARS POS.

## Production acceptance checks

- `/health` returns `ok=true`.
- Authenticated `/v1/ars-ai/status` succeeds from ARS POS.
- Wrong token is rejected with 401.
- Replayed nonce is rejected.
- Old app versions are rejected with 426.
- More than configured requests/minute are rate-limited.
- OpenAI failures do not crash ARS POS; Android falls back to local diagnosis.
- OpenAI key never appears in APK, logs, source ZIP, or diagnostic exports.
- `store:false` remains enabled for OpenAI Responses requests.
- Cloud AI remains read-only and cannot mutate quantity, stock, payments, recognition thresholds, signing, or release state.
