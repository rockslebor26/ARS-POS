import crypto from 'node:crypto';

export function sha256Hex(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

export function hmacHex(secret, value) {
  return crypto.createHmac('sha256', secret).update(value).digest('hex');
}

export function safeEqualHex(a, b) {
  const aa = Buffer.from(String(a || '').toLowerCase(), 'utf8');
  const bb = Buffer.from(String(b || '').toLowerCase(), 'utf8');
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

export function signaturePayload({ method, path, timestamp, nonce, bodySha256, deviceId }) {
  return [
    String(method || '').toUpperCase(),
    String(path || ''),
    String(timestamp || ''),
    String(nonce || ''),
    String(bodySha256 || ''),
    String(deviceId || '')
  ].join('\n');
}

export function verifySignedRequest({
  secret,
  method,
  path,
  timestamp,
  nonce,
  bodySha256,
  deviceId,
  signature,
  body,
  nowMs = Date.now(),
  maxSkewMs = 120_000
}) {
  if (!secret || !timestamp || !nonce || !bodySha256 || !deviceId || !signature) {
    return { ok: false, error: 'SIGNATURE_HEADERS_MISSING' };
  }
  const ts = Number(timestamp);
  if (!Number.isFinite(ts) || Math.abs(nowMs - ts) > maxSkewMs) {
    return { ok: false, error: 'SIGNATURE_TIMESTAMP_INVALID' };
  }
  const actualBodyHash = sha256Hex(body || Buffer.alloc(0));
  if (!safeEqualHex(actualBodyHash, bodySha256)) {
    return { ok: false, error: 'BODY_HASH_MISMATCH' };
  }
  const payload = signaturePayload({ method, path, timestamp, nonce, bodySha256, deviceId });
  const expected = hmacHex(secret, payload);
  if (!safeEqualHex(expected, signature)) {
    return { ok: false, error: 'SIGNATURE_INVALID' };
  }
  return { ok: true };
}

export class NonceWindow {
  constructor(ttlMs = 180_000, maxEntries = 10_000) {
    this.ttlMs = ttlMs;
    this.maxEntries = maxEntries;
    this.seen = new Map();
  }

  accept(key, nowMs = Date.now()) {
    this.cleanup(nowMs);
    if (this.seen.has(key)) return false;
    if (this.seen.size >= this.maxEntries) {
      const oldest = this.seen.keys().next().value;
      if (oldest) this.seen.delete(oldest);
    }
    this.seen.set(key, nowMs + this.ttlMs);
    return true;
  }

  cleanup(nowMs = Date.now()) {
    for (const [key, expiresAt] of this.seen) {
      if (expiresAt <= nowMs) this.seen.delete(key);
    }
  }
}

export class SlidingMinuteLimiter {
  constructor(limit = 12) {
    this.limit = Math.max(1, limit);
    this.buckets = new Map();
  }

  take(key, nowMs = Date.now()) {
    const minute = Math.floor(nowMs / 60_000);
    const current = this.buckets.get(key);
    if (!current || current.minute !== minute) {
      this.buckets.set(key, { minute, count: 1 });
      this.cleanup(minute);
      return { ok: true, remaining: this.limit - 1 };
    }
    if (current.count >= this.limit) {
      return { ok: false, remaining: 0 };
    }
    current.count += 1;
    return { ok: true, remaining: Math.max(0, this.limit - current.count) };
  }

  cleanup(currentMinute) {
    for (const [key, value] of this.buckets) {
      if (value.minute < currentMinute - 2) this.buckets.delete(key);
    }
  }
}

export function opaqueSafetyIdentifier(deviceId, salt) {
  return sha256Hex(`${String(salt || '')}:${String(deviceId || '')}`);
}
