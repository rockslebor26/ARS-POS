import test from 'node:test';
import assert from 'node:assert/strict';
import {
  NonceWindow,
  SlidingMinuteLimiter,
  hmacHex,
  sha256Hex,
  signaturePayload,
  verifySignedRequest
} from '../security.mjs';

test('signed request verifies and detects tampering', () => {
  const secret = 'test-secret-123';
  const body = Buffer.from('{"ok":true}');
  const timestamp = '1780000000000';
  const nonce = 'nonce-1';
  const deviceId = 'device-1';
  const bodySha256 = sha256Hex(body);
  const payload = signaturePayload({ method: 'POST', path: '/v1/ars-ai/analyze', timestamp, nonce, bodySha256, deviceId });
  const signature = hmacHex(secret, payload);
  const good = verifySignedRequest({
    secret, method: 'POST', path: '/v1/ars-ai/analyze', timestamp, nonce, bodySha256,
    deviceId, signature, body, nowMs: Number(timestamp)
  });
  assert.equal(good.ok, true);
  const bad = verifySignedRequest({
    secret, method: 'POST', path: '/v1/ars-ai/analyze', timestamp, nonce, bodySha256,
    deviceId, signature, body: Buffer.from('{"ok":false}'), nowMs: Number(timestamp)
  });
  assert.equal(bad.ok, false);
  assert.equal(bad.error, 'BODY_HASH_MISMATCH');
});

test('nonce window rejects replay', () => {
  const n = new NonceWindow(1000);
  assert.equal(n.accept('same', 100), true);
  assert.equal(n.accept('same', 200), false);
  assert.equal(n.accept('same', 1200), true);
});

test('rate limiter caps requests per minute', () => {
  const l = new SlidingMinuteLimiter(2);
  assert.equal(l.take('d', 0).ok, true);
  assert.equal(l.take('d', 1).ok, true);
  assert.equal(l.take('d', 2).ok, false);
  assert.equal(l.take('d', 60_001).ok, true);
});
