# ARS AI Gateway — V8.6.0 / Gateway 2.1.1

Server-side signed HTTPS gateway for ARS AI Engineer. Android never contains `OPENAI_API_KEY` and never calls the OpenAI endpoint directly.

## Runtime policy

- Signed request authentication and nonce replay protection are mandatory.
- Interactive diagnostic modes use the fast model with low reasoning effort.
- `DEVELOPMENT_PROPOSAL` and `REGRESSION_ANALYSIS` use the deep model.
- Evidence input is bounded; object/crop/anchor images may use high detail and other images use low detail.
- OpenAI timeout is returned as typed `OPENAI_TIMEOUT` (HTTP 504) with gateway deadline metadata.
- Gateway analysis is read-only with respect to quantity, stock, payment and scanner state.

## Rollout compatibility

During the 1.7.2 → 1.8.0 rollout, production `ARS_AI_MIN_VERSION_CODE` should remain **172** so the installed 1.7.2 client can still perform authenticated diagnostics. Raise it to 180 only after the 1.8.0 rollout is complete and older clients should be rejected.

See `DEPLOYMENT.md` and `SECURITY.md` for environment and security requirements.
