# ARS AI Gateway security invariants

- OpenAI API credentials exist only in server secret storage.
- Android stores only the ARS gateway token, encrypted by Android Keystore.
- Every protected request uses HTTPS + bearer token + timestamped HMAC body signing + nonce replay protection.
- Gateway validates package name and minimum ARS POS version code.
- Rate limiting and bounded request sizes are enforced server-side.
- Visual evidence and telemetry are treated as untrusted data; prompt injection inside evidence is explicitly ignored.
- OpenAI request uses `store:false`.
- Logs contain request metadata only, not full telemetry, images, gateway token, or OpenAI key.
- AI Engineer is read-only. It cannot change quantity, stock, payment, recognition thresholds, signing identity, or APK release state.
- Rotate OpenAI keys and gateway tokens periodically and immediately after suspected disclosure.
