import crypto from 'node:crypto';

const token = crypto.randomBytes(32).toString('hex');
const salt = crypto.randomBytes(32).toString('hex');
console.log('ARS_AI_GATEWAY_TOKENS=' + token);
console.log('ARS_AI_SAFETY_SALT=' + salt);
console.log('\nCopy the gateway token into ARS POS > ARS AI ENGINEER > GATEWAY.');
console.log('Store both values only in your server secret manager.');
