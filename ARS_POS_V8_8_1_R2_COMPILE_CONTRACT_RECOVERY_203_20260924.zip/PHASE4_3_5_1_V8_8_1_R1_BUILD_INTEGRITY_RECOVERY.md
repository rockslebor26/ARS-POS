# Phase 4.3.5.1 / V8.8.1-R1 — Build Integrity Recovery

## Purpose
Repackage the validated V8.8.1 Deterministic Object Intelligence source with a corrected and hardened GitHub Actions source-layout gate. This revision does **not** lower recognition thresholds or change the physical quantity safety model.

## Build integrity changes
1. Correct exact package path for `LiveSmartScanCamera.kt`.
2. Verify source ZIP integrity before extraction.
3. Verify exact package/version metadata before artifact publication.
4. Verify official signer fingerprint both before and after build.
5. Emit source-layout diagnostics when a required Kotlin file is missing.
6. Keep source SHA-256 and per-file SHA-256 manifest mandatory.

## Release identity
- phase: 4.3.5.1
- engine: V8.8.1
- release revision: R1_BUILD_INTEGRITY_RECOVERY
- versionName: 1.10.2
- versionCode: 202
- applicationId: com.arspos.anglerriausyndicate

## Acceptance
The release is not considered device-finished until GitHub Actions passes compilation/signing and the existing V8.8.1 field acceptance suite passes on the target device.
