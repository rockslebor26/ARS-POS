# ARS POS 1.5.9 (159)

- Phase: **4.3.2.42**
- Engine: **V8.4.22 — Live Object Temporal Truth + Persistent Owner Binding**
- Package: `com.arspos.anglerriausyndicate`
- Database: **v5 unchanged**
- Update: **install in-place over 1.5.8 (158); do not uninstall**
- Signing: **ARS POS OFFICIAL RELEASE; signer must remain identical**

This release strengthens temporal Live Object identity and live-to-final physical binding. Recognition thresholds are intentionally unchanged.
