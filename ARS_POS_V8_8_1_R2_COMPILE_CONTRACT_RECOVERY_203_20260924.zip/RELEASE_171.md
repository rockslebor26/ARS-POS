# ARS POS 1.7.1 (171)

- Phase: 4.3.3.1
- Engine: V8.5.1 — Adaptive Hybrid Intelligence + ARS AI Engineer Integration
- Package: `com.arspos.anglerriausyndicate`
- Database: v5 unchanged
- Official update path: 1.7.0 (170) -> 1.7.1 (171), in-place only

## New

- Visible `ARS AI ENGINEER` Dashboard action.
- Build-health analysis, latest-scan root-cause analysis, custom engineering question.
- Latest visual evidence binding for AI analysis.
- Secure HTTPS gateway configuration stored with Android Keystore encryption.
- Local diagnostic fallback if the gateway is not configured/unreachable.
- Reference Node.js ARS AI Gateway using OpenAI Responses API.

## Not activated as authority

- Cloud Identity Assist: SHADOW.
- Self Learning: SHADOW.
- AI Engineer: ASSIST_READ_ONLY.

No recognition threshold is lowered. AI cannot create quantity or mutate stock/payment.
