# ARS POS Release 203

- Phase: 4.3.5.1
- Engine: V8.8.1
- Revision: R2_COMPILE_CONTRACT_RECOVERY
- versionName: 1.10.3
- versionCode: 203
- applicationId: com.arspos.anglerriausyndicate
- Room DB: v5

Release 203 is a compile-contract recovery of V8.8.1. It adds the missing `FinalSmartScanState` contract and explicit StateFlow typing while preserving recognition thresholds and transaction/quantity safety boundaries.

Install in-place only. Do not uninstall the existing ARS POS application.
