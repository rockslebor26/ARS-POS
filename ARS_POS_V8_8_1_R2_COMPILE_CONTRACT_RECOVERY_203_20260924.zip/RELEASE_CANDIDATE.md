# Current Release Candidate

ARS POS **1.8.0 (180)** — Phase **4.3.4.0** / **V8.6.0 Adaptive Visual Learning + Multi-Object Checkout Intelligence**.

Primary acceptance focus: phone-based product master, operator-confirmed visual teaching for no-code/text/barcode products, true multi-object checkout with prices/total, one-to-one persistent physical binding, and gateway latency hardening.

Recognition thresholds, package, Room v5 and official signer must remain unchanged. Install only as an in-place update from the official 1.7.2 (172) application.
