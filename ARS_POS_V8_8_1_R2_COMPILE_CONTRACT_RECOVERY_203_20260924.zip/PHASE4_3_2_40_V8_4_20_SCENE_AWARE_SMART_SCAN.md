# ARS POS Phase 4.3.2.40 / V8.4.20 — Scene-Aware Smart Scan

Release target: **1.5.7 (157)**

## Tujuan

Mengubah Smart Scan dari pola foto-satu-kali menjadi scene-aware cashier scanner. Kamera dapat menemukan objek secara live, mempertahankan physical track antarfame, menampilkan kandidat database sebelum transaksi, kemudian tetap mengunci satu snapshot final untuk diproses oleh scanner production yang konservatif.

## Fitur utama

1. **Live Object Discovery**
   - Preview CameraX berjalan langsung di layar kasir.
   - Perubahan scene hanya memicu analisis; perubahan background bukan bukti identitas produk.
   - ML object proposals dan LONG analyzer membentuk kandidat objek live.

2. **Temporal Scene Object Ledger**
   - Satu objek memiliki ID sementara `LIVE-*` lintas beberapa frame.
   - Track perlu stabil dan kandidat perlu konsisten sebelum status database dipercaya.
   - Track yang hilang sesaat menjadi `OCCLUDED`, bukan langsung dihitung sebagai objek baru.

3. **Live Database Candidate Preview**
   - Reference database digunakan untuk menampilkan kandidat produk sebelum final scan.
   - OCR/barcode dipanggil pada cadence analisis yang dibatasi, bukan setiap frame kamera.
   - LONG preview tetap bersifat kandidat sampai physical truth final selesai.

4. **Final Scene Lock**
   - Tombol `KUNCI & TINJAU HASIL` mengambil satu snapshot dari preview.
   - Snapshot tersebut masuk ke `smartVisualScan()` production.
   - Live preview tidak dapat memasukkan produk ke cart.

5. **Physical Quantity Safety tetap final authority**
   - Quantity final hanya berasal dari accepted `physicalObjectId` production.
   - `ScanCommitPolicy`, duplicate-session guard dan Cashier Scan Review tetap aktif.

6. **V8.4.20-A safety tetap dipertahankan**
   - Package Edge Firewall.
   - Bidirectional Anchor Role Truth.
   - Rod authenticity.
   - Cross-category identity firewall.
   - Rescue Gate V2.
   - Recognition thresholds tidak diturunkan.

7. **Update-channel telemetry**
   - `SAME_VERSION_REPLACEMENT` sekarang dicatat bila APK dengan versionCode/name yang sama dipasang ulang.
   - Official build tetap wajib menaikkan versionCode.

## State live preview

`TRACKING -> CANDIDATE / MATCHED / UNKNOWN`

`OCCLUDED` digunakan ketika objek hilang sementara dari frame.

`MATCHED` pada live preview bukan izin transaksi. Final Smart Scan tetap wajib.

## Batas keselamatan

Live Scene Ledger tidak menulis cart, tidak menyimpan quantity transaksi, dan tidak melewati threshold recognition. Semua keputusan transaksi final tetap berasal dari scanner production setelah scene lock.
