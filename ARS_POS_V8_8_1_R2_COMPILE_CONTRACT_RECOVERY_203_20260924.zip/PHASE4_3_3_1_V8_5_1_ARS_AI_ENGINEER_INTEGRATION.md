# Phase 4.3.3.1 / V8.5.1 — ARS AI Engineer Integration

V8.5.1 keeps the full V8.5.0 Adaptive Hybrid Intelligence scanner and adds a visible **ARS AI ENGINEER** entry on Dashboard.

## Active

- ARS AI Engineer UI on Dashboard.
- Read-only diagnostic analysis of current build and latest scan.
- Bound evidence packet: report + latest session manifest + ground truth + selected scene/track/object images.
- Operator-owned HTTPS ARS AI Gateway client.
- Gateway token encrypted by Android Keystore (AES-GCM).
- Deterministic offline diagnostic fallback when gateway is unavailable.
- AI request/response/error telemetry in Flight Recorder.
- Existing Persistent Physical Fragment Fusion, ML-Guided Local Recovery, Safety Kernel, Decision Evidence Ledger, Ground Truth + Replay V2 remain active.

## Safety boundaries

ARS AI Engineer cannot mutate cart quantity, stock, payment, recognition thresholds, signer/package, production model, or APK release state. Cloud Identity Assist and Self Learning remain SHADOW.

The OpenAI API key is never embedded in the APK. OpenAI requests are made by the included `ars-ai-gateway` backend reference using server-side environment variables.
