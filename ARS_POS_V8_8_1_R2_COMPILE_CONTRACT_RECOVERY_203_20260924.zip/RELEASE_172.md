# ARS POS 1.7.2 (172)

Phase **4.3.3.2** / Engine **V8.5.2**.

Primary release goal: make ARS AI Engineer deployment-ready rather than merely UI-ready.

Highlights:

- signed HTTPS gateway requests,
- anti-replay nonce/timestamp,
- Android Keystore gateway credential protection,
- authenticated gateway connectivity test,
- structured AI engineering diagnostics,
- GPT-5.6 Terra/Sol routing at gateway,
- server-side rate limit, retries and circuit breaker,
- Docker/deployment/security package,
- local fallback maintained,
- existing V8.5 adaptive hybrid physical intelligence retained.

Official update requirement: install in-place over 1.7.1 (171); do not uninstall.
