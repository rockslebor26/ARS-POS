# ARS POS Phase 4.3.2.43 / V8.4.23 — Temporal Object Memory + Pre-Gate Persistent Binding

Release target: **1.6.0 (160)**, in-place update from **1.5.9 (159)**.

## Purpose
V8.4.23 moves physical continuity earlier in the scanner pipeline. A stable live object now carries temporal physical evidence into the locked final scan before SKU identity scoring. This addresses the V8.4.22 failure mode where a valid rod could be tracked live but disappear when one final frame had weak pixel evidence. Product-recognition thresholds are not lowered.

## Changes
- **Temporal Object Memory** stores repeated physical evidence per LIVE track: observation count, trusted/uncertain physical hits, foreground support, maximum/average authenticity and structure score.
- **Atomic scene lock context** carries the temporal history from live preview into the final production scanner.
- **Pre-Gate Persistent Binding** associates LIVE physical IDs to final proposals before identity scoring, with strict NORMAL/LONG lane separation.
- **Temporal ML Seed Recovery** may seed missing LONG axis geometry from a stable temporal LONG track when ML sees the object but the global axis detector misses it. Seeded geometry must still pass pixel `RodAuthenticityEvaluator`, Package Edge Firewall, cross-lane safety, anchor truth and identity gates.
- **Bad-final-frame stabilization** may downgrade a previously strongly supported rod to `AUTH_UNCERTAIN` instead of immediately declaring `NON_ROD`; it remains `quantityEligible=false` until final evidence is sufficient.
- **High-resolution LONG identity ROI** uses the locked full-resolution camera bitmap for trusted/uncertain LONG identity crops while retaining the low-resolution analysis frame for fast physical scanning.
- **Compose cancellation handling** rethrows `CancellationException`; normal composition teardown is no longer recorded as `LIVE_SCENE_ERROR`.
- **Evidence integrity V2** finalizes `session.json`, binds replay input SHA-256, records consistent scan/evidence status and records the pre-gate binding stage.
- Evidence queue capacity is increased to reduce diagnostic backpressure. This is not a substitute for later priority-QoS work.

## Safety invariants
1. `applicationId` remains `com.arspos.anglerriausyndicate`.
2. Official signer fingerprint remains `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`.
3. `versionCode` increases **159 -> 160**.
4. Room database remains **v5**; no destructive migration.
5. All **14 product-recognition thresholds remain unchanged**.
6. Live preview and temporal history remain non-transactional.
7. Temporal ML seed is geometry-only; it cannot directly accept identity or quantity.
8. Temporal bad-frame recovery cannot directly create quantity.
9. Package Edge Firewall, NORMAL Purity, Rod Authenticity, cross-lane gate, anchor role truth, rescue safety and atomic cashier review remain active.
10. UNKNOWN/REVIEW remains preferred to false SKU acceptance.

## Device acceptance focus
- One rod held steady for several live observations, then a single poor lock frame: persistent ID must survive; no false `NON_ROD` quantity acceptance.
- Two rods in frame where one lacks a global final axis but has stable temporal LONG evidence: the second object may be recovered only if final pixel authenticity passes.
- Two crossing rods: LIVE IDs must not collapse or switch to NORMAL lane; quantity must remain one per physical object.
- One compact NORMAL product plus one rod: no cross-lane persistent binding.
- Similar rod SKUs: high-resolution ROI should improve discrimination, but margin/text/anchor thresholds remain unchanged.
- Package/container edges: temporal memory must not promote them into a trusted rod.
- Repeated open/close of live camera: no `LeftCompositionCancellationException` recorded as `LIVE_SCENE_ERROR`.
- Evidence export: `session.json` and `replay_manifest.json` must agree on COMPLETE/PARTIAL status and replay input SHA-256 must be present.
- 30+ scans: no force close, ANR, native crash, low-memory kill or progressive native-pressure warning.

## Deferred intentionally
- Full priority-based Evidence QoS (P0/P1/P2) is not implemented in this release; only queue headroom and manifest integrity are improved.
- Multi-frame high-resolution identity burst is not yet implemented; V8.4.23 uses the high-resolution locked ROI as the first safe step.
- Automatic online/self-training is forbidden; human ground truth remains explicit diagnostic data only.
