# Phase 4.3.4.0 / V8.6.0 — Adaptive Visual Learning + Multi-Object Checkout Intelligence

## Objective

This phase targets the ARS POS end state rather than another UNKNOWN-only diagnostic iteration. The implementation connects product setup, visual teaching, physical-object scanning, identity, quantity review, pricing and engineering feedback into one controlled loop.

## 1. Input barang menggunakan HP

The existing mobile product/catalog flow remains the source of product name, SKU, brand/variant, stock and selling price. Product Master Studio now exposes **Produk tanpa kode / text / barcode** so products that cannot depend on OCR/barcode can intentionally use a visual identity profile.

Changing recognition mode invalidates previous master verification. A product is not allowed into the NORMAL visual-only acceptance path until its visual master is verified again.

## 2. Smart Scan multi-object → quantity + price + total

The cashier still separates physical hypotheses before identity and quantity. Recognized objects are aggregated by physical instance, reviewed by the operator, then rendered as quantity × product × price with **TOTAL HASIL SCAN** before cart commit.

V8.6.0 fixes persistent-binding ownership at final scene lock: a LIVE track already bound before identity scoring is reserved and excluded from fallback matching. This preserves one-to-one Live→Final physical identity in crossing scenes and reduces temporal evidence contamination.

## 3. Produk tanpa code/text/barcode

### Operator-confirmed teaching

UNKNOWN objects now expose **AJARKAN KE ARS**. The operator selects the actual catalog product. `ArsAdaptiveLearning` saves a cropped visual sample in app-private storage and `ProductionRepository` records it as `LEARNED_CONFIRMED_*`.

Learning is bounded to three learned reference slots per product. New evidence replaces the oldest learned slot after capacity is reached.

### Safe visual-only acceptance

NORMAL identity can use `NORMAL_VISUAL_MASTER_VERIFIED` only when all of the following hold:

- the product profile explicitly allows visual-only recognition;
- the visual master is verified;
- the existing `ACCEPT_VISUAL_ONLY` threshold is met;
- the existing `MIN_VISUAL_MARGIN` is met;
- the normal object has already passed the existing physical/purity/cross-category safety gates.

The teaching image itself **does not accept the current scan**. It only becomes evidence for subsequent scans. No quantity is created by teaching.

## 4. AI Engineer development loop

ARS AI Engineer exposes **RANCANG UPDATE SELANJUTNYA** and runs in `ENGINEERING_PROPOSAL_GATED` mode. It can inspect structured diagnostics and evidence, identify root causes and propose modules/tests for the next release.

It cannot directly mutate transaction quantity, stock, payment, signing identity, recognition thresholds, or silently install a new APK. Executable-code changes remain a signed release operation.

## 5. Gateway latency hardening

Gateway source is updated to 2.1.1 with:

- signed HTTPS + replay protection;
- interactive requests routed to the fast model with low reasoning effort;
- deep model reserved for explicit development/regression analysis;
- at most three visual evidence images;
- high image detail only for object/crop/anchor evidence and low detail otherwise;
- typed `OPENAI_TIMEOUT` / HTTP 504 telemetry with abort source and gateway deadline;
- gateway deadline shorter than Android's client read timeout.

## 6. Preserved invariants

- Version: 1.8.0 (180)
- Phase/Engine: 4.3.4.0 / V8.6.0
- Package: `com.arspos.anglerriausyndicate` (ASCII source package remains unchanged; see Gradle validation)
- Room: v5
- Official signer: unchanged
- 14 SKU recognition thresholds: unchanged
- Cloud Identity: SHADOW
- Self Learning: ACTIVE_CONFIRMED_ONLY
- AI Engineer: ENGINEERING_PROPOSAL_GATED

## Release gates

The release is not accepted as finished until real-device tests demonstrate:

- in-place update 172 → 180 with exact signer/package;
- teaching an UNKNOWN product from the phone and recognizing it on a later scan;
- verified visual-only recognition for a product with no barcode/text/code;
- multi-object scan with distinct physical quantity, per-item prices, and correct total;
- crossing-object test with no duplicate persistent ID ownership or duplicate quantity;
- false-NORMAL/package-edge/rod authenticity regression suite still passes;
- crash/ANR/native-memory pressure remains acceptable;
- AI Engineer online path either returns analysis within the interactive deadline or reports typed timeout without misleading `offline` state.
