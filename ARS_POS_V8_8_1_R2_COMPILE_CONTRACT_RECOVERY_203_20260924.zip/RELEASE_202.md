# ARS POS 1.10.2 (202)

Phase 4.3.5.1 / Engine V8.8.1 — **R1 Build Integrity Recovery**.

This is a rebuilt in-place official update. It can upgrade the official 1.10.0 (200) baseline and is also monotonic over any 1.10.1 (201) package. Do not uninstall the installed official app before updating.

## Root cause corrected
- The prior GitHub Actions copy contained a malformed package path for `LiveSmartScanCamera.kt`: `com/arspos/anglerriausyndicatel/...` (extra trailing `l`).
- The V8.8.1 source ZIP itself already contained the file at the correct path: `com/arspos/anglerriausyndicate/LiveSmartScanCamera.kt`.
- R1 removes the malformed assertion and adds source-layout diagnostics so a future path mismatch reports the actual source tree before failing.

## Functional scope retained
- ViewModel-owned final Smart Scan.
- Locked Scene Continuity.
- Temporal Identity Hold.
- Bounded OCR Reuse.
- Adaptive Rod Axis Width.
- AI Failure Handoff.
- Identity Intelligence / verified visual fallback / direct teaching.
- Physical quantity safety, package-edge firewall, rod authenticity, anchor role truth, replay/evidence ledger.

## Safety invariants
- package: `com.arspos.anglerriausyndicate`
- Room database: v5
- all recognition thresholds: unchanged
- Cloud Identity: SHADOW / non-authoritative
- Self Learning: ACTIVE_CONFIRMED_ONLY
- AI Engineer: ENGINEERING_PROPOSAL_GATED
- quantity/stock/payment cannot be mutated by AI
- official signer fingerprint must remain unchanged
