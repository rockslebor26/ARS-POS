# ARS POS 1.5.8 (158)

- Phase: **4.3.2.41**
- Engine: **V8.4.21 — Object Purity + Persistent Physical ID + Learning Evidence**
- Package: `com.arspos.anglerriausyndicate`
- Database: **v5**
- Update mode: **IN_PLACE_UPDATE**

## New in this build

- NORMAL Object Purity Gate blocks oversized/ownerless NORMAL containers from cashier quantity.
- `normalPurityScore`, `normalPurityState`, `normalPurityReason`, crop-area and owner-area telemetry.
- Persistent live-to-final physical-object binding (`LIVE-*` → final `physicalObjectId`).
- Human ground-truth feedback embedded in scan diagnostics.
- Lossless replay input and replay manifest for deterministic regression work.
- Failure summary for incomplete recognition sessions.
- Evidence retention increased to 40 sessions / 80 MB during development.

## Safety preserved

Recognition thresholds remain unchanged. Package Edge Firewall, rod authenticity, anchor-role truth, Rescue Gate V2, physical quantity aggregation, cashier review, and duplicate-session commit protection remain active.

## Validation status

Local source/static validation is required to pass before packaging. Full Android compilation, official signing verification and real-device scanner acceptance remain GitHub/device gates.
