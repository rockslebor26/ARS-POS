# ARS POS Phase 4.3.2.42 / V8.4.22 — Live Object Temporal Truth

Release target: **1.5.9 (159)**, in-place update from **1.5.8 (158)**.

## Purpose
V8.4.22 hardens the already-present Live Object preview without relaxing any product-recognition threshold. The primary problem addressed is temporal identity instability: the same physical object must not receive a new LIVE id merely because the camera moves, the box shape changes, or one preview frame produces weak identity evidence.

## Changes
- Strict NORMAL/LONG temporal lane separation; cross-lane LIVE rebinding is forbidden.
- Temporal association uses IoU + centre-motion similarity + area similarity rather than IoU alone.
- Candidate-product hysteresis requires repeated evidence before a stable LIVE track changes candidate SKU.
- MATCHED preview requires repeated accepted identity on the same stable physical track.
- Live-to-final persistent binding uses the same strict lane rule plus motion/size geometry.
- Occluded LIVE tracks cannot be resurrected into a final physical object at scene lock.
- Live preview remains advisory: it cannot commit quantity and cannot bypass final Smart Visual Scan.
- Existing Object Purity, Package Edge Firewall, Rod Authenticity, Anchor Role Truth, Rescue Gate, Evidence Recorder and atomic quantity commit remain active.

## Invariants
1. `applicationId` remains `com.arspos.anglerriausyndicate`.
2. Official signer fingerprint remains unchanged.
3. `versionCode` increases 158 -> 159.
4. Room schema remains v5; no destructive migration.
5. All 14 recognition thresholds remain unchanged.
6. Live preview cannot mutate cart quantity.
7. Final quantity is still derived from accepted final physical objects only.
8. Rescue remains evidence-only and cannot create quantity.
9. UNKNOWN is preferred to false recognition.

## Device acceptance focus
- One compact product moved slowly across the frame: one stable LIVE id.
- One compact product rotated/tilted: LIVE id persists; no duplicate quantity.
- Two compact products crossing/overlapping: IDs do not collapse or swap lanes.
- One rod + one compact product: LONG/NORMAL tracks remain distinct.
- Product temporarily occluded then returned: short occlusion may recover; stale occluded track must not bind to a different final object.
- Repeated lock/review: no cart mutation until explicit cashier confirmation.
- 30 repeated live analyses: no force close/ANR and no progressive native-memory growth warning.
