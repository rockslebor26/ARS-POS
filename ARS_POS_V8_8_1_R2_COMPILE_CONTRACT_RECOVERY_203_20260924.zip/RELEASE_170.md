# ARS POS 1.7.0 (170)

Phase 4.3.3.0 / Engine V8.5.0 — Adaptive Hybrid Intelligence.

This release begins the unified roadmap without weakening recognition thresholds. Production-active changes focus on physical-object truth before identity: ML-guided local LONG recovery, persistent fragment fusion, immutable quantity safety, decision evidence, and LIVE best-evidence metadata. Cloud identity, self-learning and ARS AI Engineer hooks remain shadow/diagnostic-only pending field validation.

Official in-place upgrade requirement: package and release signer must remain unchanged; versionCode increases from 161 to 170. Room database remains version 5.
