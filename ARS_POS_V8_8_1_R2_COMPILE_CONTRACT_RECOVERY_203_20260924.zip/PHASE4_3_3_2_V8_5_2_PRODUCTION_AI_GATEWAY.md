# Phase 4.3.3.2 / V8.5.2 — Production ARS AI Gateway + Structured Engineering Diagnostics

V8.5.2 closes the known gap in V8.5.1 where the ARS AI Engineer UI existed but the online model depended on a minimally protected manually hosted gateway.

## Added

- Production gateway packaging with Docker.
- HTTPS-only Android client and redirect rejection.
- HMAC-SHA256 request signing over method/path/timestamp/nonce/body hash/device ID.
- Nonce replay protection and timestamp window.
- Per-device rate limiting and concurrency bounds.
- Authenticated `UJI KONEKSI AI` status path in the Dashboard AI console.
- OpenAI Responses API structured output (strict JSON Schema).
- Dual model routing: routine diagnostics vs deep root-cause analysis.
- `store:false` and non-PII `safety_identifier`.
- Bounded retry and circuit breaker on OpenAI upstream failures.
- Evidence prompt-injection boundary: telemetry/OCR/images are untrusted evidence, never instructions.
- Deployment, secret management and security runbooks.

## Safety invariants retained

- applicationId unchanged.
- official signer unchanged.
- Room DB remains v5.
- recognition thresholds unchanged.
- cloud identity and self learning remain SHADOW.
- ARS AI Engineer remains ASSIST_READ_ONLY.
- AI cannot create quantity, mutate cart/stock/payment, relax thresholds, change signing identity, promote a production model or release APKs.

## External prerequisites that cannot be embedded in an APK

Online model operation still requires:

1. an OpenAI API project/key owned by the operator,
2. a deployed HTTPS ARS AI Gateway,
3. a per-device gateway token provisioned into ARS POS.

These are infrastructure credentials, not application source code. The APK intentionally does not contain them.
