import unittest
from kotlin_sanity import check_source

class LexicalCheckTests(unittest.TestCase):
    def test_nested_interpolation(self):
        check_source('val x = "${call("nested") { "${1}" }}"')
    def test_raw_string(self):
        check_source('val x = """line\n[ unbalanced raw text ${f()}"""')
    def test_nested_comment(self):
        check_source('/* one /* two */ three */ fun f() { val c = \'{\' }')
    def test_unclosed_string(self):
        with self.assertRaises(ValueError): check_source('val x = "bad')
    def test_mismatch(self):
        with self.assertRaises(ValueError): check_source('fun f() { [) }')
    def test_unclosed_comment(self):
        with self.assertRaises(ValueError): check_source('/* never ends')

if __name__ == '__main__': unittest.main()
