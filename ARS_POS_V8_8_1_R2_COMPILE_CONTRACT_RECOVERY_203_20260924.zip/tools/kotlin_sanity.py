#!/usr/bin/env python3
"""Conservative lexical sanity check, explicitly NOT a Kotlin compiler."""
from pathlib import Path

def check_source(text):
    n = len(text)
    def block_comment(i):
        depth = 1
        i += 2
        while i < n and depth:
            if text.startswith('/*', i): depth += 1; i += 2
            elif text.startswith('*/', i): depth -= 1; i += 2
            else: i += 1
        if depth: raise ValueError('unterminated block comment')
        return i
    def string(i):
        raw = text.startswith('"""', i)
        quote = '"""' if raw else text[i]
        i += len(quote)
        while i < n:
            if text.startswith(quote, i): return i + len(quote)
            if not raw and text[i] == '\\': i += 2; continue
            if quote != "'" and text.startswith('${', i):
                i = code(i + 2, True); continue
            if not raw and text[i] == '\n': raise ValueError('newline in ordinary string/char')
            i += 1
        raise ValueError('unterminated string/char')
    def code(i, interpolation=False):
        stack = []
        while i < n:
            c = text[i]
            if text.startswith('//', i):
                end = text.find('\n', i); i = n if end < 0 else end + 1; continue
            if text.startswith('/*', i): i = block_comment(i); continue
            if c in ['"', "'"]: i = string(i); continue
            if c in '({[': stack.append(c)
            elif c in ')}]':
                if c == '}' and interpolation and not stack: return i + 1
                if not stack or stack.pop() != {')':'(', '}':'{', ']':'['}[c]:
                    raise ValueError(f'mismatched delimiter at line {text.count(chr(10), 0, i)+1}')
            i += 1
        if stack or interpolation: raise ValueError('unclosed delimiter/interpolation')
        return i
    code(0)

def check_tree(root):
    paths = sorted(Path(root).rglob('*.kt'))
    for path in paths:
        try: check_source(path.read_text())
        except ValueError as exc: raise ValueError(f'{path}: {exc}') from exc
    return len(paths)
