#!/usr/bin/env python3
"""Read-only ZIP telemetry audit; does NOT evaluate recognition ground truth."""
import argparse
import collections
import hashlib
import json
import statistics
import zipfile
from pathlib import Path, PurePosixPath

def audit(path):
    with zipfile.ZipFile(path) as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError(f"CRC failure: {bad}")
        names = set(archive.namelist())
        events = [json.loads(line) for line in archive.read("flight_recorder.jsonl").decode().splitlines() if line.strip()]
        counts = collections.Counter(e.get("type", "") for e in events)
        completed = [e for e in events if e.get("type") == "SCAN_COMPLETE"]
        merges = [e for e in events if e.get("type") == "SCAN_PROPOSAL_MERGE"]
        durations = [e["durationMs"] for e in completed if "durationMs" in e]
        manifest_types = collections.Counter()
        missing = []
        for name in sorted(names):
            if not name.endswith("evidence_manifest.jsonl"):
                continue
            for line in archive.read(name).decode().splitlines():
                if not line.strip():
                    continue
                entry = json.loads(line)
                manifest_types[entry.get("type", "")] += 1
                for field in ["file", "handle", "side", "tip"]:
                    ref = entry.get(field)
                    if ref and ref not in names and "evidence/" + ref not in names:
                        missing.append({"manifest": name, "field": field, "file": ref})
        return {
            "archive": Path(path).name,
            "scan_started": counts["SCAN_START"], "scan_completed": len(completed),
            "evidence_errors": counts["EVIDENCE_ERROR"], "evidence_dropped": counts["EVIDENCE_DROPPED"],
            "errors_without_session": sum(1 for e in events if e.get("type") == "EVIDENCE_ERROR" and not e.get("session")),
            "trusted_tracks_sum": sum(e.get("trustedRodTracks", 0) for e in merges),
            "uncertain_tracks_sum": sum(e.get("uncertainRodTracks", 0) for e in merges),
            "mean_scan_ms": round(statistics.mean(durations), 1) if durations else None,
            "manifest_types": dict(manifest_types), "missing_referenced_artifacts": missing,
            "note": "Telemetry audit only; no device execution or image ground-truth acceptance claim.",
        }

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("zip")
    print(json.dumps(audit(parser.parse_args().zip), indent=2))
