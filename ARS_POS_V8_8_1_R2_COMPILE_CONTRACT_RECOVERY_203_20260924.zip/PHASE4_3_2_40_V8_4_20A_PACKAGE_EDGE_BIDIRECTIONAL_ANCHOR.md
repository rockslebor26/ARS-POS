# Phase 4.3.2.40 — V8.4.20-A

## Package Edge Firewall + Bidirectional Anchor Role Truth

Build target: **ARS POS 1.5.6 (156)**.

V8.4.20-A is the first implementation slice of V8.4.20 Physical Truth V2. It does not lower any recognition acceptance threshold. The purpose is to correct physical evidence before SKU scoring.

### P0 changes

1. **Package Edge Firewall**
   - Derives the connected foreground component owned by each NORMAL object.
   - Tests resolved LONG axes against the actual foreground component boundary, not only the broad ML proposal rectangle.
   - A LONG track owned by a compact rectangular NORMAL body is retyped as `NORMAL_BOUNDARY_EDGE` evidence.
   - Such evidence cannot claim `TRUSTED_ROD`, suppress its NORMAL owner, or create cashier quantity.

2. **Bidirectional Anchor Role Truth**
   - Measures both physical endpoints before product identity scoring.
   - A HANDLE side is forced only when physical endpoint evidence has sufficient absolute score and margin.
   - Ambiguous endpoints remain `ANCHOR_ROLE_UNKNOWN`; product-specific similarity is not allowed to manufacture physical certainty.

3. **Evidence integrity**
   - Track audit and decision evidence now retain package-edge ownership metrics and left/right endpoint-role metrics.
   - Diagnostic exports are labeled V8.4.20-A / Phase 4.3.2.40 / 1.5.6 (156).

### Regression bound to V8.4.19 evidence

The source contains the captured KTN/Katana package scene where V8.4.19 incorrectly promoted a package edge to `TRUSTED_ROD`. Replay with the exact production ownership/policy code must classify that axis as `NORMAL_BOUNDARY_EDGE`.

### Intentionally unchanged in A

- Recognition acceptance thresholds.
- LONG shortlist policy (planned for V8.4.20-D).
- Instance-masked crossing crop (planned for V8.4.20-B).
- Physical Quantity Truth V2 / reciprocal NORMAL ownership (planned for V8.4.20-C).
- Database schema remains version 5.

### Device acceptance for V8.4.20-A

A. Package-only scenes must produce zero `TRUSTED_ROD` from package borders.
B. A clearly isolated real rod must remain eligible for physical authenticity; the firewall must not veto it without a NORMAL rectangular owner.
C. For handle-visible rods, endpoint telemetry must show left/right scores and one deterministic role state.
D. No FC/ANR, no update-channel regression, and no quantity from `NORMAL_BOUNDARY_EDGE` evidence.

### Local bound-evidence results before packaging

- Captured false package edge: `NORMAL_BOUNDARY_EDGE`, score 87, NORMAL owner `NORMAL-1`.
- Same policy with no planar NORMAL owner does not reject the isolated real-rod geometry.
- Captured trusted rod oriented crop: endpoint L/R = **55/82**, physical HANDLE = **right**, margin 27.
- Captured crossing blue rod crop: endpoint L/R = **48/33**, physical HANDLE = **left**, margin 15; the short crossing structure does not win because persistent endpoint coverage is low.
- Existing bound `RodMaterialProfile` corpus remains **47/47 PASS**.

These are regression gates, not a claim of general scanner/SKU accuracy. Android CI and real-device acceptance remain mandatory.
