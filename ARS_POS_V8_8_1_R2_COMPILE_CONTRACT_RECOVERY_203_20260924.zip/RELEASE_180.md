# ARS POS 1.8.0 (180) — V8.6.0 Release Candidate

Phase: **4.3.4.0**  
Engine: **V8.6.0 — Adaptive Visual Learning + Multi-Object Checkout Intelligence**

## What changes

- `AJARKAN KE ARS` teaches a selected product from an UNKNOWN object crop.
- Confirmed learned references are stored app-private and bounded to three per product.
- Product Master Studio supports products without code/text/barcode.
- Verified NORMAL visual-only master can be accepted using the existing visual threshold and margin; thresholds are not relaxed.
- Multi-object cashier review retains per-item prices and total shopping amount.
- Live→Final persistent IDs are assigned one-to-one by reserving pre-bound LIVE IDs before fallback matching.
- ARS AI Engineer adds `RANCANG UPDATE SELANJUTNYA` under `ENGINEERING_PROPOSAL_GATED`.
- AI client reports typed gateway errors instead of collapsing every upstream timeout into a generic offline diagnosis.
- Gateway source 2.1.1 uses an interactive latency-bounded path.

## Safety

Teaching never accepts the current scan, never creates quantity, and never modifies stock/payment. Cloud identity remains SHADOW. Product quantity still requires final local identity + physical safety kernel + cashier review.

## Update identity

- applicationId: `com.arspos.anglerriausyndicate`
- previous installed version: 1.7.2 (172)
- target: 1.8.0 (180)
- Room database: 5
- install mode: **IN_PLACE_UPDATE**
- signer SHA-256 must remain:
  `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`

## Required device acceptance tests

1. Teach one UNKNOWN package/fishing product, rescan from several angles, and verify the teaching sample did not retroactively create a cart line.
2. Enable no-code/text/barcode mode for a verified master, then validate correct recognition and rejection against visually similar products.
3. Scan 2–5 mixed objects and verify object count, item price, subtotal, total and atomic cart commit.
4. Cross two rods/long products and confirm one `LIVE-*` cannot bind to two final tracks.
5. Repeat false package-edge, background-line, duplicate quantity and cross-lane tests.
6. Run repeated scans while watching Java/native/PSS and crash/ANR evidence.
7. Run AI Engineer online analysis; accept success within the bounded path or a typed `OPENAI_TIMEOUT`, never a false network/offline diagnosis.
