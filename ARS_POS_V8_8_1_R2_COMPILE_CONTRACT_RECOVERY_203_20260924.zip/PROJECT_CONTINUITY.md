# ARS POS Project Continuity

Current source candidate: **1.8.0 (180) / Phase 4.3.4.0 / V8.6.0 — Adaptive Visual Learning + Multi-Object Checkout Intelligence**.

Direct installed predecessor: **1.7.2 (172) / Phase 4.3.3.2 / V8.5.2**. Database remains v5; package and official signer must remain unchanged. Recognition thresholds remain unchanged.

## Product finish criteria

ARS POS is not considered finished until device evidence proves all three goals:

1. Product input/master workflow is practical from the Android phone.
2. Smart Scan can recognize multiple physical objects, keep quantities physically distinct, show item prices, and show the customer shopping total before commit.
3. Products with no code, text, or barcode can be taught and later recognized reliably through operator-confirmed visual evidence without unsafe threshold relaxation.

## 2026-09-23 — Phase 4.3.4.0 / V8.6.0 (1.8.0/180)

V8.6.0 adds the first production-facing adaptive learning loop. UNKNOWN detections can be explicitly taught to a selected catalog product using a bounded app-private crop. ProductionRepository reserves reference capacity for confirmed learned evidence. Product Master Studio now exposes a no-code/text/barcode mode and requires a verified visual master before NORMAL visual-only identity can be accepted. The current teaching sample never accepts its own scan and cannot create quantity.

Cashier retains multi-object physical quantity review and item-price/total calculation. Live→final persistent binding now excludes already-owned LIVE IDs from fallback matching, preventing the observed single-LIVE-ID-to-two-final-track collision in crossing scenes.

ARS AI Engineer is moved to `ENGINEERING_PROPOSAL_GATED`: it can analyze telemetry/evidence and produce a concrete development proposal, but executable scanner changes and signed APK releases remain gated through the official build/update channel. Cloud Identity remains `SHADOW`; Self Learning is `ACTIVE_CONFIRMED_ONLY`.

The production Railway gateway was separately hardened to gateway 2.1.1 with an interactive fast path and typed deadline failures. During rollout its minimum accepted Android version remains 172 so the installed 1.7.2 client can still reach it before 1.8.0 is installed.

## Preserved safety foundation

V8.5 physical fragment fusion, ML-guided local recovery, best-evidence memory, Decision Evidence Ledger, Safety Kernel, temporal identity consensus, Ground Truth/Replay V2, Package Edge Firewall, NORMAL Object Purity, Rod Authenticity, Anchor Role Truth and Physical Quantity Safety remain active. No recognition threshold has been lowered.
