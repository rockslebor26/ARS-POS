# ARS POS 1.6.1 (161)

- Phase: **4.3.2.44**
- Engine: **V8.4.24 — Live Identity Fast Path + Type-Aware Persistent Binding + Temporal Consensus**
- Package: `com.arspos.anglerriausyndicate`
- Database: **v5 unchanged**
- Update: **install in-place over 1.6.0 (160); do not uninstall**
- Signing: **ARS POS OFFICIAL RELEASE; signer must remain identical**
- Recognition thresholds: **all 14 unchanged**

This release targets perceived Smart Scan latency without weakening recognition. It exposes safe advisory live candidates earlier, uses a coarse LONG visual fast path, gives LONG objects axis-aware temporal continuity, reduces avoidable OCR orientations, recycles OCR rotation bitmaps, adds identity-latency telemetry, and guarantees an exported ground-truth file even when no annotation exists.

## Acceptance rule
Do not mark V8.4.24 finished until GitHub CI passes source validation, JVM evidence replay, Android unit tests, signed release compilation, package/version/signer/alignment verification, followed by device tests for first-candidate latency, persistent LONG ID survival, false NORMAL, duplicate quantity, crossing rods, package edges, memory/native pressure and evidence/replay integrity.
