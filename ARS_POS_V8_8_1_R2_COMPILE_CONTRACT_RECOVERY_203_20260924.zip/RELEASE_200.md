# ARS POS 1.10.0 (200) — V8.8.0

- Phase: 4.3.5.0
- Engine: V8.8.0 Identity Intelligence + Evidence-Aware OCR
- Package: `com.arspos.anglerriausyndicate`
- Database: v5 (unchanged)
- Update model: in-place from 1.9.0 (190); do not uninstall the official app.
- Official signer must remain: `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`

## P0 identity fixes

- Ambiguous visual candidates now trigger live OCR instead of suppressing it.
- Regulatory/generic OCR is separated from identity-bearing OCR.
- Weak non-identity OCR no longer automatically blocks the verified visual path.
- Historical OCR master text is filtered before it contributes identity evidence.
- Direct `AJARKAN OBJEK ... KE ARS` CTA is visible on an unknown result.
- Confirmed teaching can enable conservative `HYBRID_VISUAL` for a verified NORMAL master.
- Raw OCR and identity OCR are both preserved in diagnostics.

## Regression evidence

- V8.6.0 NORMAL-as-LONG bottle fixture retained.
- V8.7.0 ESSE CHANGE DOUBLE UNKNOWN field frame added and SHA-256 bound.
- 151 static source invariants PASS.
- 6 Python validation tests PASS.
- 3 ARS AI Gateway security/runtime tests PASS.
- Standalone Kotlin policy check PASS for warning filtering and low-margin OCR trigger.

## Device acceptance focus

1. Repeat the same V8.7.0 video scenario with the same product.
2. Confirm `ambiguousOcrTriggered > 0` when visual margin is low.
3. Confirm `identityOcr` contains product identity words while generic warning lines are excluded.
4. Target first candidate < 1 s and MATCHED near 1–1.5 s when master data is valid and framing is clear.
5. If still unknown, `AJARKAN OBJEK ... KE ARS` must be immediately visible without opening diagnostics.
6. After teaching a verified NORMAL master, scan again and verify recognition without threshold relaxation.
