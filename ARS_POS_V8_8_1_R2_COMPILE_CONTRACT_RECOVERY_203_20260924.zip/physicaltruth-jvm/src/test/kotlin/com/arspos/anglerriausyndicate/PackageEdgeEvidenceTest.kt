package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test
import java.security.MessageDigest
import javax.imageio.ImageIO

/** Regression from V8.4.19: the top edge of a KTN package became TRUSTED_ROD. */
class PackageEdgeEvidenceTest {
    @Test
    fun capturedPackageBoundaryCannotBecomeIndependentRod() {
        val bytes = requireNotNull(javaClass.getResourceAsStream("/physical_truth/v8419_false_trusted_package_scene.jpg"))
            .use { it.readBytes() }
        val sha = MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it.toInt() and 255) }
        assertEquals("65152d3296f0713e58f068d9925be52d87ddd4aa1f5b814fb29109e00b108c96", sha)
        val image = ImageIO.read(bytes.inputStream())

        // Exact V8.4.19 NORMAL and false TRACK-2 geometry from session
        // smart-scan-1789482022698-d734fe.
        val normal = NormalPixelOwnership.resolve(
            image.width, image.height,
            listOf(NormalPixelOwnership.Box(165, 0, 607, 764)),
            image::getRGB
        )
        val owner = normal.owners.single()
        assertTrue(owner.coverage >= .70f)
        val body = requireNotNull(owner.componentBounds)

        val result = PackageEdgePolicy.evaluate(
            frameWidth = image.width,
            frameHeight = image.height,
            trackBounds = PackageEdgePolicy.Box(161, 341, 608, 413),
            axis = PackageEdgePolicy.Axis(197f, 377f, 572f, 377f),
            measuredWidthPx = 26,
            owners = listOf(
                PackageEdgePolicy.NormalOwner(
                    id = "NORMAL-1",
                    proposalBounds = PackageEdgePolicy.Box(165, 0, 607, 764),
                    foregroundBounds = PackageEdgePolicy.Box(body.left, body.top, body.right, body.bottom),
                    foregroundCoverage = owner.coverage
                )
            )
        )

        assertEquals(PackageEdgePolicy.OWNERSHIP_NORMAL_BOUNDARY, result.ownership)
        assertEquals("NORMAL-1", result.ownerId)
        assertTrue(result.score >= 70)
        assertTrue(result.rejectedAsPackageEdge)
    }

    @Test
    fun noPlanarNormalOwnerNeverRejectsRod() {
        val result = PackageEdgePolicy.evaluate(
            768, 1024,
            PackageEdgePolicy.Box(646, 37, 718, 814),
            PackageEdgePolicy.Axis(682f, 73f, 682f, 778f),
            21,
            emptyList()
        )
        assertFalse(result.rejectedAsPackageEdge)
    }

    @Test
    fun bidirectionalRoleRequiresPhysicalMarginBeforeForcingEndpoint() {
        assertEquals(true, RodEndpointRolePolicy.decide(72, 40).handleOnLeft)
        assertEquals(false, RodEndpointRolePolicy.decide(38, 67).handleOnLeft)
        assertNull(RodEndpointRolePolicy.decide(58, 53).handleOnLeft)
    }
    @Test
    fun capturedRodEndpointsResolveHandleDirectionFromPersistentBody() {
        fun endpointDecision(resource: String, expectedSha: String): RodEndpointRolePolicy.Decision {
            val bytes = requireNotNull(javaClass.getResourceAsStream(resource)).use { it.readBytes() }
            val sha = MessageDigest.getInstance("SHA-256").digest(bytes)
                .joinToString("") { "%02x".format(it.toInt() and 255) }
            assertEquals(expectedSha, sha)
            val image = ImageIO.read(bytes.inputStream())
            val left = RodEndpointProfile.measure(image.width, image.height, true, image::getRGB)
            val right = RodEndpointProfile.measure(image.width, image.height, false, image::getRGB)
            return RodEndpointRolePolicy.decide(left.score, right.score)
        }

        val handleRight = endpointDecision(
            "/physical_truth/v8419_trusted_rod_handle_right.jpg",
            "5f025fb2ab5e88a043eb8c74eac9d830052170e5d6df028ccf7eb9181ba79e11"
        )
        assertEquals(RodEndpointRolePolicy.STATE_CONFIDENT, handleRight.state)
        assertEquals(false, handleRight.handleOnLeft)

        // A crossing floor/rod line on the right side is wide only briefly.
        // Persistent coverage keeps the real wooden grip on the left dominant.
        val handleLeft = endpointDecision(
            "/physical_truth/v8419_crossing_rod_handle_left.jpg",
            "e309d8694b7a29cf0e98e379a5e9e348d27b372c20ae64ee091cfd8b7ab2ddae"
        )
        assertEquals(RodEndpointRolePolicy.STATE_CONFIDENT, handleLeft.state)
        assertEquals(true, handleLeft.handleOnLeft)
    }

}
