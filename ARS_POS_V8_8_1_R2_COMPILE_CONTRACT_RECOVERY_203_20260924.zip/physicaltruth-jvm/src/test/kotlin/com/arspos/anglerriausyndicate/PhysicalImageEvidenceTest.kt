package com.arspos.anglerriausyndicate

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import javax.imageio.ImageIO

/**
 * JPEG evidence replay belongs on the desktop JVM because ImageIO is part of
 * java.desktop, not Android's runtime API surface. The ownership algorithm is
 * compiled from the exact production source used by :app.
 */
class PhysicalImageEvidenceTest {
    @Test
    fun packAndShadowDuplicateSharesOnePhysicalOwner() {
        val stream = requireNotNull(
            javaClass.getResourceAsStream("/physical_truth/smart-scan-1789448694800-f532d4.jpg")
        ) { "physical truth JPEG fixture missing" }
        val image = stream.use { ImageIO.read(it) }
        requireNotNull(image) { "ImageIO could not decode physical truth JPEG fixture" }

        val result = NormalPixelOwnership.resolve(
            image.width,
            image.height,
            listOf(
                NormalPixelOwnership.Box(319, 147, 566, 527),
                NormalPixelOwnership.Box(318, 371, 483, 655)
            ),
            image::getRGB
        )

        assertEquals(1, result.groups.size)
        assertTrue(result.ambiguous.isEmpty())
    }
}
