package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.Parameterized
import java.security.MessageDigest
import javax.imageio.ImageIO

/** Replay of annotated pixels and original axis coordinates, not SKU accuracy. */
@RunWith(Parameterized::class)
class RodMaterialEvidenceTest(private val session: String, private val track: String, private val row: List<String>) {
    @Test fun materialSupportMatchesBoundEvidence() {
        val bytes = javaClass.getResourceAsStream("/physical_truth/${row[3]}")!!.use { it.readBytes() }
        val sha = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
        assertEquals("$session/$track image changed", row[4], sha)
        val image = ImageIO.read(bytes.inputStream())
        val result = RodMaterialProfile.measure(image.width, image.height,
            row[5].toFloat(), row[6].toFloat(), row[7].toFloat(), row[8].toFloat(), image::getRGB)
        assertEquals("$session/$track ${result.reason}", row[9].toBoolean(), result.supported)
        if (row[9].toBoolean()) assertFalse("Partial rod must not invent a visible tip", result.tipVisible)
    }
    companion object {
        @JvmStatic @Parameterized.Parameters(name = "{0}/{1}")
        fun samples(): Collection<Array<Any>> = RodMaterialEvidenceTest::class.java
            .getResourceAsStream("/physical_truth/tracks.tsv")!!.bufferedReader().use { it.readLines() }
            .drop(1).filter { it.isNotBlank() }.map { line ->
                val row = line.split('\t'); arrayOf<Any>(row[0], row[2], row)
            }
    }
}
