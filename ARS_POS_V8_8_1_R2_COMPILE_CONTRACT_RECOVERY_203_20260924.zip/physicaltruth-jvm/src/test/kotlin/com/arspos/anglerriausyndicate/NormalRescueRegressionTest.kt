package com.arspos.anglerriausyndicate

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.awt.image.BufferedImage
import javax.imageio.ImageIO

class NormalRescueRegressionTest {
    @Test
    fun mlOwnedNonRodMayReenterNormalButPureAnalyzerMayNot() {
        assertTrue(
            CorrectTypeRoutingPolicy.shouldRescueNonRodToNormal(
                proposalType = "LONG_OBJECT",
                authenticityState = "NON_ROD",
                proposalId = "ML-1",
                source = "MLKIT",
                bridgeSuppressed = false
            )
        )
        assertTrue(
            CorrectTypeRoutingPolicy.shouldRescueNonRodToNormal(
                proposalType = "LONG_OBJECT",
                authenticityState = "NON_ROD",
                proposalId = "ML-1+LONG-3",
                source = "MERGED",
                bridgeSuppressed = false
            )
        )
        assertFalse(
            CorrectTypeRoutingPolicy.shouldRescueNonRodToNormal(
                proposalType = "LONG_OBJECT",
                authenticityState = "NON_ROD",
                proposalId = "LONG-2",
                source = "LONG_ANALYZER",
                bridgeSuppressed = false
            )
        )
        assertFalse(
            CorrectTypeRoutingPolicy.shouldRescueNonRodToNormal(
                proposalType = "LONG_OBJECT",
                authenticityState = "TRUSTED_ROD",
                proposalId = "ML-1+LONG-3",
                source = "MERGED",
                bridgeSuppressed = false
            )
        )
        assertFalse(
            CorrectTypeRoutingPolicy.shouldRescueNonRodToNormal(
                proposalType = "LONG_OBJECT",
                authenticityState = "NON_ROD",
                proposalId = "ML-1",
                source = "NORMAL_BOUNDARY_EDGE_REJECTED",
                bridgeSuppressed = false
            )
        )
        assertTrue(CorrectTypeRoutingPolicy.shouldPreviewMlTallAsNormal("LONG_OBJECT", "MLKIT"))
        assertFalse(CorrectTypeRoutingPolicy.shouldPreviewMlTallAsNormal("LONG_OBJECT", "LONG_ANALYZER"))
    }

    @Test
    fun fieldFailureBottleRoiPassesNormalPhysicalPurityGate() {
        val image = load("/physical_truth/v860_normal_bottle_misrouted_long.jpg")
        // Exact ML-1 bounds from smart-scan-1790172200200-e1186d.
        val box = NormalPixelOwnership.Box(102, 173, 296, 691)
        val result = NormalPixelOwnership.resolve(
            width = image.width,
            height = image.height,
            boxes = listOf(box)
        ) { x, y -> image.getRGB(x, y) }

        assertTrue(result.groups.size == 1)
        val owner = result.owners.single()
        assertTrue("Bottle ROI must have a physical foreground owner", owner.component > 0)

        val frameArea = image.width.toLong() * image.height.toLong()
        val cropArea = (box.right - box.left).toLong() * (box.bottom - box.top).toLong()
        val ownerArea = owner.componentBounds?.let {
            (it.right - it.left).coerceAtLeast(0).toLong() *
                (it.bottom - it.top).coerceAtLeast(0).toLong()
        } ?: 0L
        val purity = NormalProposalPurityPolicy.evaluate(
            cropAreaRatio = cropArea.toFloat() / frameArea.toFloat(),
            foregroundComponent = owner.component,
            foregroundCoverage = owner.coverage,
            ownerAreaRatio = if (cropArea == 0L) 0f else ownerArea.toFloat() / cropArea.toFloat(),
            ambiguousOverlap = result.ambiguous.isNotEmpty(),
            mergedProposals = 1
        )

        assertTrue("Field-proven NORMAL bottle must reach NORMAL identity scoring", purity.safeForQuantity)
        assertTrue("Purity score should remain safely above gate", purity.score >= 55)
    }

    private fun load(path: String): BufferedImage =
        ImageIO.read(requireNotNull(javaClass.getResourceAsStream(path)) { "Missing fixture $path" })
}
