plugins {
    id("org.jetbrains.kotlin.jvm")
}

kotlin {
    jvmToolchain(17)
    sourceSets {
        named("main") {
            // Compile the exact production implementations used by :app.
            // This is intentionally not a copy of the algorithms.
            kotlin.srcDir("../app/src/main/java")
            kotlin.include(
                "com/arspos/anglerriausyndicate/NormalPixelOwnership.kt",
                "com/arspos/anglerriausyndicate/NormalProposalPurityPolicy.kt",
                "com/arspos/anglerriausyndicate/CorrectTypeRoutingPolicy.kt",
                "com/arspos/anglerriausyndicate/RodMaterialProfile.kt",
                "com/arspos/anglerriausyndicate/PackageEdgePolicy.kt",
                "com/arspos/anglerriausyndicate/RodEndpointRolePolicy.kt",
                "com/arspos/anglerriausyndicate/RodEndpointProfile.kt"
            )
        }
        named("test") {
            kotlin.srcDir("src/test/kotlin")
        }
    }
}

sourceSets {
    named("test") {
        resources.srcDir("../app/src/test/resources")
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}

tasks.test {
    useJUnit()
}
