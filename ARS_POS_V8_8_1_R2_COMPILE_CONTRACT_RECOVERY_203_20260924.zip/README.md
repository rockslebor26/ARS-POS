# ARS POS 1.8.0 (180) — Phase 4.3.4.0 / V8.6.0

**Adaptive Visual Learning + Multi-Object Checkout Intelligence**

ARS POS dikembangkan untuk tiga hasil operasional utama:

1. input/master barang langsung dari HP;
2. Smart Scan multi-object untuk mengenali beberapa barang, menghitung quantity, menampilkan harga per barang, dan menghitung total belanja sebelum commit ke keranjang;
3. pengenalan barang tanpa barcode, kode, atau teks melalui visual master dan pembelajaran visual yang dikonfirmasi operator.

Versi 1.8.0 memindahkan fokus dari sekadar diagnosis `UNKNOWN` ke alur operasional **teach → verify → recognize → review → checkout**. Recognition threshold SKU tidak diturunkan.

## Fitur utama V8.6.0

- **AJARKAN KE ARS** pada objek `UNKNOWN`: operator memilih produk yang benar, lalu aplikasi menyimpan crop visual terikat produk sebagai referensi `LEARNED_CONFIRMED`.
- **Produk tanpa kode/text/barcode** di Product Master Studio: mode visual-only harus diaktifkan dan visual master harus diverifikasi sebelum jalur `NORMAL_VISUAL_MASTER_VERIFIED` dapat menerima identitas.
- Pembelajaran bersifat **operator-confirmed dan bounded**: maksimum tiga slot learned per produk; tidak boleh mengubah quantity, stok, payment, atau threshold.
- **Multi-object checkout** tetap memakai physical-object truth dan review quantity; hasil scan menampilkan harga per item dan `TOTAL HASIL SCAN` sebelum commit.
- **Persistent Live→Final one-to-one binding** mencegah satu `LIVE-*` digunakan oleh lebih dari satu objek final pada scene silang.
- **ARS AI Engineer — ENGINEERING_PROPOSAL_GATED** dapat menganalisis evidence dan merancang perubahan berikutnya. AI Engineer tidak boleh membuat quantity atau mengubah transaksi secara langsung.
- Gateway source V8.6.0/2.1.1 memakai signed HTTPS, selective image detail, interactive low-reasoning path, typed timeout telemetry, dan deadline yang lebih pendek daripada Android read timeout.

## Safety invariants

- Package: `com.arspos.anglerriausyndicate`
- Room database: **v5**, tanpa destructive migration.
- Official signer SHA-256 wajib tetap:
  `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`
- Update harus **in-place** dari 1.7.2 (172) ke 1.8.0 (180). Jangan uninstall aplikasi produksi.
- Ke-14 recognition threshold tetap identik dengan V8.5.2.
- Cloud Identity tetap `SHADOW`; Self Learning adalah `ACTIVE_CONFIRMED_ONLY`.

## Alur penggunaan baru

### Input/master barang dari HP
Tambahkan produk, harga, stok, dan foto master melalui menu Produk/Product Master Studio. Untuk barang yang memang tidak memiliki barcode/kode/text, aktifkan **Produk tanpa kode / text / barcode**, kemudian selesaikan verifikasi visual master.

### Mengajari objek UNKNOWN
Di Smart Scan, pilih `AJARKAN KE ARS` pada objek UNKNOWN → cari produk yang benar → konfirmasi. Crop disimpan sebagai learned reference untuk scan berikutnya. **Scan yang sedang berjalan tetap ditolak**; teaching tidak boleh mengubah hasil transaksi saat itu.

### Smart Scan multi-object
Arahkan kamera ke beberapa barang → tunggu live tracks → `KUNCI & TINJAU HASIL` → periksa item, quantity, harga, dan total → `TINJAU JUMLAH & TAMBAH` → commit ke keranjang hanya setelah review.

## Build resmi

Gunakan source ZIP V8.6.0 dan workflow pendamping `ARS_POS_V8_6_0_ADAPTIVE_VISUAL_LEARNING_180.yml`. Workflow melakukan source-hash verification, regression tests, Android tests, signed release build, package/version check, signer verification, dan zipalign.

Detail release: `PHASE4_3_4_0_V8_6_0_ADAPTIVE_VISUAL_LEARNING.md` dan `RELEASE_180.md`.
