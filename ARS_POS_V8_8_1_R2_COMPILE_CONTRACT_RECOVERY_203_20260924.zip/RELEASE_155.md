# Rilis 1.5.5 / 155 — Phase 4.3.2.39 / V8.4.19

## Perubahan yang diterapkan

1. **Badan objek dan garis lantai.** RodMaterialProfile mengukur komponen foreground yang berbatas di kedua sisi axis, dukungan badan sepanjang track, perubahan lebar gagang/batang, kestabilan bagian lokal, dan arah foreground. Garis seragam atau persilangan lokal tidak cukup untuk TRUSTED_ROD. RodAuthenticityEvaluator memakai variasi per bagian ketika badan terbukti; perubahan lebar gagang tidak otomatis menjadi cabang/balok. Bukti gagang/badan yang tidak terlihat tetap memerlukan foto lebih informatif.
2. **Dukungan ML setelah validasi piksel.** ML_SPANS_MULTIPLE_PHYSICAL_OBJECTS hanya ditautkan ulang apabila tepat satu track mempunyai badan independen yang trusted. Penautan tidak mengubah axis, tidak mengubah physicalObjectId, tidak menciptakan quantity, dan tidak mempromosikan track. Beberapa joran yang bersilangan tetap melalui guard complete-link dan cross-lane.
3. **NORMAL quantity.** NormalPixelOwnership memakai komponen foreground dan irisan piksel untuk menyatukan proposal badan/kemasan yang sama. Satu kemasan plus bayangan pada scene ...f532d4 sekarang menjadi satu kelompok. Produk terpisah tetap terpisah walaupun SKU sama. Overlap yang tidak cukup bukti diberi Q=false dan ditampilkan untuk pemeriksaan; tidak otomatis menjadi dua item. Aggregator mempertahankan keputusan pemilik NORMAL tersebut.
4. **Anchor identity.** Satu produk memakai satu penetapan arah HANDLE/TIP sendiri, sehingga master pesaing tidak menentukan arah produk lain. TIP yang tidak terlihat dikeluarkan dari referensi dan tidak diekspor sebagai gambar tip. Manifest final membawa penetapan arah yang digunakan untuk kandidat itu. HANDLE/SIDE masih memerlukan pembandingan referensi dan gate identitas yang sama.
5. **Kelengkapan kandidat.** Untuk badan joran yang trusted dan katalog sampai 8 produk dengan referensi tersedia, seluruh SKU dibandingkan dengan referensi per sudut yang dibatasi. Kandidat benar tidak dibuang hanya karena coarse top-2. Proposal uncertain/rescue tetap dibatasi dua produk. Risiko tambahan waktu scan harus diukur di perangkat; fitur cache tetap digunakan.
6. **Quantity dan transaksi.** UI dan ViewModel memakai syarat yang sama: identitas diterima, match tersedia, physicalObjectId tidak kosong dan sesuai physicalInstanceHint, Q=true, tidak bridge, lane NORMAL/LONG. Draft menghapus duplikasi physicalObjectId sebelum mengelompokkan SKU. Konfirmasi satu kali per session dan validasi seluruh draft sebelum mutasi dipertahankan. Mutasi cart manual memakai lock yang sama. Event commit mencatat ID produk dan jumlah sebelum/sesudah, tanpa data pembayaran/pelanggan.
7. **Force close/native.** Android 11+ membaca riwayat keluar proses pada peluncuran berikutnya untuk ANR, Java/native crash, dan low-memory kill. Angka ini dipisahkan dari crash handler aplikasi. Native growth dari baseline hangat dan sinyal lowMemory Android dipisahkan; selisih terhadap cold baseline tidak lagi dinamai tekanan OS. Log tidak membuktikan aplikasi bebas crash jika OS tidak menyediakan riwayat.
8. **Evidence dan update.** File ekspor, manifest, report, dan UI diagnostik memakai V8.4.19 / 155. Telemetry menyertakan alasan foreground, ketersediaan tip, ID referensi/skor, kandidat produk, serta orientasi anchor. DB5, package, master produk, alur kasir interaktif, dan gate rescue evidence-only dipertahankan. Track uncertain yang mengizinkan rescue juga wajib memiliki dukungan badan piksel.

## Kriteria uji perangkat sebelum dinyatakan selesai

| Uji | Hasil wajib |
|---|---|
| Update dari 154 | Versi 155, signer sama, produk/stok/riwayat tetap terbaca |
| Lantai kosong dengan nat, garis bayangan, kaki rak | Tidak ada quantity joran; tidak ada SKU NORMAL yang diterima hanya dari visual |
| Scene joran ...0f27ea diulang | Axis badan joran yang memiliki dukungan piksel diproses; nat pada y≈582 tidak menjadi trusted; hasil SKU hanya boleh diterima bila gate identitas dan margin lulus |
| Satu kemasan + bayangan | Maksimal satu quantity dari barang itu; kotak parsial tidak menambah unit |
| Dua kemasan SKU sama, terpisah/dekat | Dua pemilik jika benar-benar terpisah; overlap tak pasti minta pemeriksaan |
| Dua/tiga joran bersilangan atau sejajar | Track tidak tertelan bridge; quantity sesuai objek yang identitasnya diterima |
| Foto gagang/reel seat tanpa ujung | TIP=NOT_VISIBLE; tidak meminjam nat/ujung crop sebagai tip produk |
| Foto joran bersih HANDLE/SIDE dan master SKU serupa | SKU salah tidak diterima; jika margin belum cukup, tetap belum dikenali dan lengkapi referensi produk |
| Tap konfirmasi berulang | Satu commit per session; tidak menambah ulang |
| Draft salah satu SKU melebihi stok | Seluruh commit ditolak, tidak sebagian; setelah diperbaiki bisa dikonfirmasi |
| Rotasi/keluar-masuk scan, 100 scan berulang | Tidak FC/ANR, crop selesai dibersihkan, memori mencapai plateau; ukur median/P95/max dan native/PSS setelah warm-up |
| Ekspor evidence | session/proposal/physicalObject/anchor/decisionRule sama dan semua berkas yang dirujuk tersedia |

Jangan menurunkan threshold recognition untuk meluluskan uji. Perbaiki kualitas master HANDLE/SIDE, pencahayaan, dukungan badan, atau binding crop jika gate identitas tetap gagal. Model dan dataset uji ini tidak menjamin semua bentuk, warna, dan kondisi toko akan dikenali. Simpan report + ZIP evidence versi 155 setelah uji agar regresi baru dapat ditelusuri.

## Batas verifikasi lokal

85 unit test dan 32 replay authenticity lulus. Untuk replay, Bitmap.getPixel diadaptasi dari piksel JPEG asli; ini tidak menjalankan CameraX, ML Kit, UI Compose, Room, signing, atau lifecycle Android. Field yang hilang dari telemetry tidak dibuat-buat. Uji SKU end-to-end dan latency 155 belum tersedia. Belum ada APK resmi hasil build lokal; artifact resmi hanya keluar setelah job GitHub berhasil.

Toolchain build: AGP 8.7.3, Gradle 8.9, Kotlin 2.0.21, JDK17, SDK35. Referensi: https://developer.android.com/build/releases/agp-8-7-0-release-notes dan https://github.com/gradle/actions/blob/main/docs/setup-gradle.md .
