# Phase 4.3.2.38 / Engine V8.4.18

## Atomic Quantity Commit + Physical Evidence Consistency

Release candidate: ARS POS 1.5.4 (154).

### Added / strengthened
- Quantity review is built only from scan objects with a product match, `quantityEligible == true`, `bridgeSuppressed == false`, and non-RESCUE proposal type.
- Multiple physical objects that resolve to the same product are aggregated by product ID; detected quantity remains auditable.
- Initial review quantity is clamped to remaining stock after the current cart, reducing avoidable stock-rejection loops.
- Review cannot open without an active scan session.
- UI-level `quantityCommitInProgress` blocks double taps while ViewModel-level committed-session protection remains authoritative.
- Commit telemetry distinguishes success, duplicate-session block, validation failure and exception.
- Successful/consumed review clears transient scan drafts.

### Safety invariants retained
- No recognition threshold is lowered.
- NORMAL visual-only identity firewall remains.
- Rescue remains evidence-only and quantity-ineligible.
- Anti-bridge, cross-lane, rod authenticity, rod anchors and physical-track truth remain active.
- Cart commit remains atomic: validation occurs before `_cart` mutation.
- Package remains `com.arspos.anglerriausyndicate`; Room DB remains v5; official signer must match the installed release.

### Device release gate
Re-run force-close/ANR, Java/native/PSS memory, scan latency, one rod, two parallel rods, crossing rods, rod + NORMAL, NORMAL-only, background-only, duplicate confirm, stale session, zero stock and existing-cart stock tests on the realme RMX3563 / Android 14. Healthy V8.4.17 telemetry is not automatically treated as V8.4.18 evidence.
