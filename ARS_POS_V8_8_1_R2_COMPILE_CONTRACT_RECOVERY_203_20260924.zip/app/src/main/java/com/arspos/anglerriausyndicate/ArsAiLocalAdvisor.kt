package com.arspos.anglerriausyndicate

/**
 * Deterministic offline fallback. This is intentionally not an AI model and
 * never changes scanner state; it only extracts high-signal diagnostics.
 */
object ArsAiLocalAdvisor {
    fun analyze(report: String): String {
        fun value(label: String): String = report.lineSequence()
            .firstOrNull { it.trimStart().startsWith(label) }
            ?.substringAfter(label)
            ?.trim()
            .orEmpty()

        val version = value("Current Version:")
        val code = value("Version Code:")
        val crash = value("- Uncaught/fatal crash records:")
        val anr = value("- OS ANR records:")
        val scanMs = value("- Average completed scan:")
        val live = value("- Latest live matched/candidate/unknown:")
        val physical = value("- Latest physical objects before/after resolve:")
        val dup = value("- Latest duplicate physical objects prevented:")
        val memory = value("- Latest total PSS:")
        val decision = value("- Latest decision rule:")
        val aiMode = value("- ARS AI Engineer mode:")

        return buildString {
            appendLine("ARS AI ENGINEER — OFFLINE DIAGNOSTIC FALLBACK")
            appendLine()
            appendLine("Build: ${version.ifBlank { "?" }} ($code)")
            appendLine("Crash/ANR: ${crash.ifBlank { "?" }} / ${anr.ifBlank { "?" }}")
            appendLine("Average scan: ${scanMs.ifBlank { "?" }}")
            appendLine("Live matched/candidate/unknown: ${live.ifBlank { "?" }}")
            appendLine("Physical before/after: ${physical.ifBlank { "?" }}")
            appendLine("Duplicate physical prevented: ${dup.ifBlank { "?" }}")
            appendLine("Total PSS: ${memory.ifBlank { "?" }}")
            appendLine("Latest decision: ${decision.ifBlank { "?" }}")
            appendLine("AI Engineer mode: ${aiMode.ifBlank { ArsV850Config.AI_ENGINEER_MODE }}")
            appendLine()
            appendLine("Gateway AI belum terhubung. Analisis ini hanya ekstraksi deterministik lokal; tidak menggantikan analisis model online.")
            appendLine("Scanner/quantity/stock/payment tidak diubah.")
        }
    }
}
