package com.arspos.anglerriausyndicate

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.40 / V8.4.20 — Package Edge Firewall.
 *
 * This policy never recognizes a SKU and never lowers any recognition threshold.
 * It answers a physical-ownership question only: does a resolved LONG axis sit on
 * the boundary of a compact NORMAL foreground component strongly enough that the
 * line should be treated as package/planar structure instead of an independent rod?
 *
 * It is deliberately pure Kotlin so device evidence can be replayed on the JVM.
 */
internal object PackageEdgePolicy {
    const val OWNERSHIP_UNKNOWN = "UNKNOWN"
    const val OWNERSHIP_STANDALONE_LONG = "STANDALONE_LONG_BODY"
    const val OWNERSHIP_NORMAL_BOUNDARY = "NORMAL_BOUNDARY_EDGE"

    data class Box(val left: Int, val top: Int, val right: Int, val bottom: Int) {
        val width: Int get() = (right - left).coerceAtLeast(0)
        val height: Int get() = (bottom - top).coerceAtLeast(0)
        val area: Long get() = width.toLong() * height.toLong()
    }

    data class Axis(val sx: Float, val sy: Float, val ex: Float, val ey: Float) {
        val length: Float get() = hypot(ex - sx, ey - sy)
        val angle: Float get() {
            var a = Math.toDegrees(atan2((ey - sy).toDouble(), (ex - sx).toDouble())).toFloat()
            while (a < 0f) a += 180f
            while (a >= 180f) a -= 180f
            return a
        }
    }

    data class NormalOwner(
        val id: String,
        val proposalBounds: Box,
        val foregroundBounds: Box?,
        val foregroundCoverage: Float
    )

    data class Result(
        val ownership: String = OWNERSHIP_UNKNOWN,
        val ownerId: String = "",
        val score: Int = 0,
        val boundaryDistancePx: Float = Float.MAX_VALUE,
        val parallelEdgeEvidence: Float = 0f,
        val rectangularBoundaryScore: Float = 0f,
        val trackInsideOwnerRatio: Float = 0f,
        val reason: String = "NO_PLANAR_OWNER"
    ) {
        val rejectedAsPackageEdge: Boolean get() = ownership == OWNERSHIP_NORMAL_BOUNDARY
    }

    fun evaluate(
        frameWidth: Int,
        frameHeight: Int,
        trackBounds: Box,
        axis: Axis,
        measuredWidthPx: Int,
        owners: List<NormalOwner>
    ): Result {
        if (frameWidth <= 0 || frameHeight <= 0 || axis.length < 48f || owners.isEmpty()) return Result()
        val frameArea = frameWidth.toLong() * frameHeight.toLong()
        val trackArea = trackBounds.area.coerceAtLeast(1L)
        val best = owners.mapNotNull { owner ->
            val body = owner.foregroundBounds ?: owner.proposalBounds
            if (owner.foregroundCoverage < 0.70f || body.width < 24 || body.height < 24) return@mapNotNull null

            val short = min(body.width, body.height).toFloat().coerceAtLeast(1f)
            val long = max(body.width, body.height).toFloat().coerceAtLeast(1f)
            val aspect = long / short
            val areaRatio = body.area.toFloat() / frameArea.coerceAtLeast(1L).toFloat()
            if (aspect > 2.85f || areaRatio !in 0.018f..0.72f) return@mapNotNull null

            val inside = intersectionArea(trackBounds, body).toFloat() / trackArea.toFloat()
            if (inside < 0.42f) return@mapNotNull null

            val angle = axis.angle
            val horizontalDelta = min(angle, abs(180f - angle))
            val verticalDelta = abs(90f - angle)
            val horizontal = horizontalDelta <= 14f
            val vertical = verticalDelta <= 14f
            if (!horizontal && !vertical) return@mapNotNull null

            val edgeLength: Float
            val boundaryDistance: Float
            val projectionOverlap: Float
            if (horizontal) {
                boundaryDistance = min(abs(axis.sy - body.top), abs(axis.sy - body.bottom))
                edgeLength = body.width.toFloat().coerceAtLeast(1f)
                projectionOverlap = intervalOverlap(
                    min(axis.sx, axis.ex), max(axis.sx, axis.ex),
                    body.left.toFloat(), body.right.toFloat()
                ) / min(axis.length, edgeLength).coerceAtLeast(1f)
            } else {
                boundaryDistance = min(abs(axis.sx - body.left), abs(axis.sx - body.right))
                edgeLength = body.height.toFloat().coerceAtLeast(1f)
                projectionOverlap = intervalOverlap(
                    min(axis.sy, axis.ey), max(axis.sy, axis.ey),
                    body.top.toFloat(), body.bottom.toFloat()
                ) / min(axis.length, edgeLength).coerceAtLeast(1f)
            }

            val width = measuredWidthPx.coerceAtLeast(4).toFloat()
            val boundaryLimit = max(14f, min(short * 0.11f, width * 1.65f + 8f))
            val distanceEvidence = (1f - boundaryDistance / boundaryLimit).coerceIn(0f, 1f)
            val parallelEvidence = projectionOverlap.coerceIn(0f, 1f)
            val narrownessEvidence = (1f - width / (short * 0.24f)).coerceIn(0f, 1f)
            val coverageEvidence = ((owner.foregroundCoverage - 0.70f) / 0.30f).coerceIn(0f, 1f)
            val trackLengthEvidence = (axis.length / (edgeLength * 0.55f)).coerceIn(0f, 1f)
            val planarEvidence = (1f - ((aspect - 1f) / 1.85f)).coerceIn(0f, 1f)

            val rectangular = (
                parallelEvidence * 0.30f +
                    distanceEvidence * 0.27f +
                    trackLengthEvidence * 0.16f +
                    narrownessEvidence * 0.10f +
                    coverageEvidence * 0.10f +
                    planarEvidence * 0.07f
                ).coerceIn(0f, 1f)

            val score = (rectangular * 100f).toInt().coerceIn(0, 100)
            Result(
                ownership = if (score >= 70 && boundaryDistance <= boundaryLimit && projectionOverlap >= 0.60f)
                    OWNERSHIP_NORMAL_BOUNDARY else OWNERSHIP_UNKNOWN,
                ownerId = owner.id,
                score = score,
                boundaryDistancePx = boundaryDistance,
                parallelEdgeEvidence = parallelEvidence,
                rectangularBoundaryScore = rectangular,
                trackInsideOwnerRatio = inside,
                reason = if (score >= 70 && boundaryDistance <= boundaryLimit && projectionOverlap >= 0.60f)
                    "PLANAR_NORMAL_BOUNDARY_OWNS_LONG_AXIS" else "PLANAR_OWNER_NOT_DECISIVE"
            )
        }.maxByOrNull { it.score } ?: return Result()

        return if (best.rejectedAsPackageEdge) best else best.copy(ownership = OWNERSHIP_UNKNOWN)
    }

    private fun intervalOverlap(a0: Float, a1: Float, b0: Float, b1: Float): Float =
        (min(a1, b1) - max(a0, b0)).coerceAtLeast(0f)

    private fun intersectionArea(a: Box, b: Box): Long =
        (min(a.right, b.right) - max(a.left, b.left)).coerceAtLeast(0).toLong() *
            (min(a.bottom, b.bottom) - max(a.top, b.top)).coerceAtLeast(0).toLong()
}
