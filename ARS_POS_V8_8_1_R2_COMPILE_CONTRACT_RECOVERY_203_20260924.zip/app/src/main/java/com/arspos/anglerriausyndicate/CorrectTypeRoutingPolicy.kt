package com.arspos.anglerriausyndicate

/**
 * Phase 4.3.4.1 / V8.7.0 — pure routing policy for field-proven type mistakes.
 *
 * This policy never accepts product identity and never grants quantity. It only
 * decides whether an ML-owned physical observation is allowed to enter the
 * NORMAL evidence lane after rod authenticity proves NON_ROD, or whether an ML
 * tall rectangle should be previewed as NORMAL while the independent LONG
 * analyzer continues to own rod hypotheses.
 *
 * Kept free of Android classes so CI can regression-test the exact production
 * policy in the JVM module.
 */
object CorrectTypeRoutingPolicy {
    fun shouldRescueNonRodToNormal(
        proposalType: String,
        authenticityState: String,
        proposalId: String,
        source: String,
        bridgeSuppressed: Boolean
    ): Boolean =
        proposalType == "LONG_OBJECT" &&
            authenticityState == "NON_ROD" &&
            !bridgeSuppressed &&
            proposalId.contains("ML-") &&
            source != "NORMAL_BOUNDARY_EDGE_REJECTED"

    fun shouldPreviewMlTallAsNormal(
        proposalType: String,
        source: String
    ): Boolean =
        proposalType == "LONG_OBJECT" && source == "MLKIT"
}
