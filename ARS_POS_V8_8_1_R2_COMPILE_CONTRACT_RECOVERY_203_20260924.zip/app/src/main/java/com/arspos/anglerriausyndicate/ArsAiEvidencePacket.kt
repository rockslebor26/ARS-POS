package com.arspos.anglerriausyndicate

import android.content.Context
import android.util.Base64
import java.io.File

/** Compact evidence packet for read-only engineering analysis. */
data class ArsAiImageEvidence(
    val name: String,
    val mimeType: String,
    val base64Data: String
)

data class ArsAiEvidencePacket(
    val sessionId: String,
    val manifestTail: String,
    val groundTruthTail: String,
    val images: List<ArsAiImageEvidence>
)

object ArsAiEvidenceCollector {
    private const val ROOT = "ars_diagnostics/evidence"
    private const val MAX_MANIFEST_LINES = 100
    private const val MAX_GROUND_TRUTH_LINES = 40
    private const val MAX_SINGLE_IMAGE_BYTES = 650_000L
    private const val MAX_TOTAL_IMAGE_BYTES = 1_800_000L

    fun latest(context: Context, maxImages: Int = ArsV850Config.AI_ENGINEER_MAX_IMAGES): ArsAiEvidencePacket {
        val root = File(context.filesDir, ROOT)
        val session = root.listFiles()
            ?.filter { it.isDirectory }
            ?.maxByOrNull { it.lastModified() }
            ?: return ArsAiEvidencePacket("", "", "", emptyList())

        val manifest = File(session, "evidence_manifest.jsonl")
            .takeIf { it.exists() }
            ?.readLines()
            ?.takeLast(MAX_MANIFEST_LINES)
            ?.joinToString("\n")
            .orEmpty()

        val groundTruth = File(session, "ground_truth.jsonl")
            .takeIf { it.exists() }
            ?.readLines()
            ?.takeLast(MAX_GROUND_TRUTH_LINES)
            ?.joinToString("\n")
            .orEmpty()

        val preferred = buildList {
            add(File(session, "scene/analysis_scene.jpg"))
            add(File(session, "overlay/physical_track_overlay.jpg"))
            add(File(session, "overlay/final_proposal_overlay.jpg"))
            val objects = File(session, "objects")
                .listFiles()
                ?.filter { it.isFile && it.extension.equals("jpg", true) }
                ?.sortedByDescending { it.lastModified() }
                .orEmpty()
            addAll(objects.take(3))
        }

        var total = 0L
        val images = mutableListOf<ArsAiImageEvidence>()
        preferred.distinctBy { it.absolutePath }.forEach { file ->
            if (images.size >= maxImages || !file.exists()) return@forEach
            val size = file.length()
            if (size <= 0L || size > MAX_SINGLE_IMAGE_BYTES || total + size > MAX_TOTAL_IMAGE_BYTES) return@forEach
            val encoded = runCatching {
                Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
            }.getOrNull() ?: return@forEach
            images += ArsAiImageEvidence(file.name, "image/jpeg", encoded)
            total += size
        }

        return ArsAiEvidencePacket(
            sessionId = session.name,
            manifestTail = manifest.take(80_000),
            groundTruthTail = groundTruth.take(30_000),
            images = images
        )
    }
}
