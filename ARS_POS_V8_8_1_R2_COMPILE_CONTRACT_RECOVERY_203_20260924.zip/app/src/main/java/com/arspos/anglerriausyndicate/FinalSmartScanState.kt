package com.arspos.anglerriausyndicate

/**
 * Immutable UI contract for the ViewModel-owned final Smart Shopping Scan.
 *
 * This state object deliberately contains no transaction mutation capability.
 * It only transports final scanner status/evidence from PosViewModel to Compose.
 */
data class FinalSmartScanState(
    val status: String = STATUS_IDLE,
    val sessionId: String = "",
    val objects: List<VisualScanObject> = emptyList(),
    val message: String = "",
    val durationMs: Long = 0L,
    val completedAtMs: Long = 0L,
    val aiProposal: String = "",
    val aiProposalSource: String = ""
) {
    companion object {
        const val STATUS_IDLE = "IDLE"
        const val STATUS_RUNNING = "RUNNING"
        const val STATUS_COMPLETE = "COMPLETE"
        const val STATUS_ERROR = "ERROR"
        const val STATUS_FATAL = "FATAL"
        const val STATUS_CANCELLED = "CANCELLED"
    }
}
