package com.arspos.anglerriausyndicate

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/** Signed HTTPS client for ARS AI engineering analysis/proposals. Production mutations remain gated. */
object ArsAiEngineerClient {
    data class Result(
        val ok: Boolean,
        val analysis: String,
        val requestId: String = "",
        val model: String = "",
        val gatewayVersion: String = "",
        val latencyMs: Long = 0L,
        val source: String = "GATEWAY"
    )

    data class GatewayStatus(
        val ok: Boolean,
        val message: String,
        val gatewayVersion: String = "",
        val fastModel: String = "",
        val deepModel: String = "",
        val latencyMs: Long = 0L
    )

    suspend fun testGateway(context: Context): GatewayStatus = withContext(Dispatchers.IO) {
        val settings = ArsAiGatewaySettings.snapshot(context)
        val token = ArsAiGatewaySettings.loadToken(context)
        if (!settings.configured || token.isBlank()) {
            return@withContext GatewayStatus(false, "Gateway URL/token belum lengkap.")
        }
        val body = "{}".toByteArray(Charsets.UTF_8)
        val started = System.currentTimeMillis()
        try {
            val response = postSigned(context, settings.url, token, "/v1/ars-ai/status", body, 20_000)
            val latency = System.currentTimeMillis() - started
            if (response.code !in 200..299) {
                return@withContext GatewayStatus(false, "Gateway menolak koneksi (HTTP ${response.code}).", latencyMs = latency)
            }
            val json = JSONObject(response.body)
            GatewayStatus(
                ok = json.optBoolean("ok", false),
                message = if (json.optBoolean("ok", false)) "ARS AI Gateway online dan autentikasi valid." else "Gateway merespons tetapi status tidak sehat.",
                gatewayVersion = json.optString("gateway_version"),
                fastModel = json.optString("fast_model"),
                deepModel = json.optString("deep_model"),
                latencyMs = latency
            )
        } catch (error: Throwable) {
            GatewayStatus(false, "Gateway tidak dapat dihubungi: ${error.message ?: error::class.java.simpleName}", latencyMs = System.currentTimeMillis() - started)
        }
    }

    suspend fun analyze(
        context: Context,
        mode: String,
        question: String,
        includeVisualEvidence: Boolean
    ): Result = withContext(Dispatchers.IO) {
        val report = ArsFlightRecorder.buildReport(context)
            .takeLast(ArsV850Config.AI_ENGINEER_MAX_REPORT_CHARS)
        val settings = ArsAiGatewaySettings.snapshot(context)
        val token = ArsAiGatewaySettings.loadToken(context)

        if (!settings.configured || token.isBlank()) {
            return@withContext Result(
                ok = false,
                analysis = ArsAiLocalAdvisor.analyze(report),
                source = "LOCAL_FALLBACK"
            )
        }

        val evidence = if (includeVisualEvidence) ArsAiEvidenceCollector.latest(context)
        else ArsAiEvidencePacket("", "", "", emptyList())

        val bodyJson = JSONObject().apply {
            put("mode", mode)
            put("question", question.take(12_000))
            put("phase", ArsV850Config.PHASE)
            put("engine", ArsV850Config.ENGINE)
            put("version", ArsV850Config.VERSION_NAME)
            put("versionCode", ArsV850Config.VERSION_CODE)
            put("package", context.packageName)
            put("report", report)
            put("sessionId", evidence.sessionId)
            put("manifestTail", evidence.manifestTail)
            put("groundTruthTail", evidence.groundTruthTail)
            put("safety", JSONObject().apply {
                put("readOnly", true)
                put("mayChangeQuantity", false)
                put("mayChangeStock", false)
                put("mayChangePayment", false)
                put("mayRelaxThresholds", false)
                put("cloudIdentityMode", ArsV850Config.CLOUD_IDENTITY_MODE)
                put("selfLearningMode", ArsV850Config.SELF_LEARNING_MODE)
            })
            put("images", JSONArray().apply {
                evidence.images.forEach { image ->
                    put(JSONObject().apply {
                        put("name", image.name)
                        put("mimeType", image.mimeType)
                        put("base64", image.base64Data)
                    })
                }
            })
        }
        val body = bodyJson.toString().toByteArray(Charsets.UTF_8)
        val started = System.currentTimeMillis()

        ArsFlightRecorder.event(
            "AI_ENGINEER_REQUEST",
            "ARS AI Engineer signed read-only analysis requested",
            mapOf(
                "mode" to mode,
                "session" to evidence.sessionId,
                "visualEvidence" to evidence.images.size,
                "endpointHost" to runCatching { URL(settings.url).host }.getOrDefault(""),
                "signedRequest" to true,
                "readOnly" to true
            )
        )

        try {
            val response = postSigned(
                context = context,
                baseUrl = settings.url,
                token = token,
                path = "/v1/ars-ai/analyze",
                body = body,
                readTimeoutMs = 95_000
            )
            val latency = System.currentTimeMillis() - started
            if (response.code !in 200..299) {
                val errorJson = runCatching { JSONObject(response.body) }.getOrNull()
                val errorCode = errorJson?.optString("error_code")
                    ?.ifBlank { errorJson.optString("error") }
                    .orEmpty()
                val gatewayDeadline = errorJson?.optLong("gateway_deadline_ms", 0L) ?: 0L
                val friendly = when (errorCode) {
                    "OPENAI_TIMEOUT" -> "Analisis model melewati deadline gateway${if (gatewayDeadline > 0) " ${gatewayDeadline} ms" else ""}. Gunakan analisis ringkas atau ulangi."
                    "APP_UPDATE_REQUIRED" -> "Gateway meminta versi ARS POS yang lebih baru."
                    "GATEWAY_BUSY" -> "Gateway sedang sibuk. Coba lagi beberapa saat."
                    else -> "Gateway AI gagal (HTTP ${response.code}${if (errorCode.isNotBlank()) " • $errorCode" else ""})."
                }
                ArsFlightRecorder.event(
                    "AI_ENGINEER_ERROR",
                    friendly,
                    mapOf(
                        "mode" to mode,
                        "httpCode" to response.code,
                        "errorCode" to errorCode,
                        "gatewayDeadlineMs" to gatewayDeadline,
                        "latencyMs" to latency
                    )
                )
                return@withContext Result(
                    ok = false,
                    analysis = "$friendly\n\n" + ArsAiLocalAdvisor.analyze(report),
                    requestId = response.requestId,
                    latencyMs = latency,
                    source = "LOCAL_FALLBACK"
                )
            }

            val json = JSONObject(response.body)
            val analysis = json.optString("analysis").ifBlank { "Gateway tidak mengembalikan analisis." }
            val result = Result(
                ok = json.optBoolean("ok", true),
                analysis = analysis,
                requestId = json.optString("request_id").ifBlank { response.requestId },
                model = json.optString("model"),
                gatewayVersion = json.optString("gateway_version"),
                latencyMs = latency,
                source = "GATEWAY"
            )
            ArsFlightRecorder.event(
                "AI_ENGINEER_RESPONSE",
                "ARS AI Engineer structured analysis received",
                mapOf(
                    "mode" to mode,
                    "session" to evidence.sessionId,
                    "requestId" to result.requestId,
                    "model" to result.model,
                    "gatewayVersion" to result.gatewayVersion,
                    "latencyMs" to latency,
                    "readOnly" to true
                )
            )
            result
        } catch (error: Throwable) {
            val latency = System.currentTimeMillis() - started
            ArsFlightRecorder.event(
                "AI_ENGINEER_ERROR",
                error.message ?: error::class.java.simpleName,
                mapOf("mode" to mode, "exception" to error::class.java.name, "latencyMs" to latency)
            )
            Result(
                ok = false,
                analysis = "Gateway AI tidak dapat dihubungi: ${error.message ?: error::class.java.simpleName}\n\n" + ArsAiLocalAdvisor.analyze(report),
                latencyMs = latency,
                source = "LOCAL_FALLBACK"
            )
        }
    }

    private data class HttpResponse(
        val code: Int,
        val body: String,
        val requestId: String
    )

    private fun postSigned(
        context: Context,
        baseUrl: String,
        token: String,
        path: String,
        body: ByteArray,
        readTimeoutMs: Int
    ): HttpResponse {
        val base = URL(baseUrl)
        require(base.protocol.equals("https", ignoreCase = true)) { "ARS AI Gateway wajib HTTPS" }
        val endpoint = URL(baseUrl.trimEnd('/') + path)
        val signed = ArsAiRequestSecurity.sign(context, token, "POST", path, body)
        val connection = (endpoint.openConnection() as HttpsURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8_000
            readTimeout = readTimeoutMs
            doOutput = true
            useCaches = false
            instanceFollowRedirects = false
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("X-ARS-Package", context.packageName)
            setRequestProperty("X-ARS-App-Version", ArsV850Config.VERSION_NAME)
            setRequestProperty("X-ARS-Version-Code", ArsV850Config.VERSION_CODE.toString())
            setRequestProperty("X-ARS-Engine", ArsV850Config.ENGINE)
            setRequestProperty("X-ARS-Device-ID", signed.deviceId)
            setRequestProperty("X-ARS-Timestamp", signed.timestamp)
            setRequestProperty("X-ARS-Nonce", signed.nonce)
            setRequestProperty("X-ARS-Body-SHA256", signed.bodySha256)
            setRequestProperty("X-ARS-Signature", signed.signature)
        }
        return try {
            connection.outputStream.use { output -> output.write(body) }
            val code = connection.responseCode
            if (code in 300..399) throw IllegalStateException("Gateway redirect ditolak demi keamanan (HTTP $code)")
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(350_000) }.orEmpty()
            HttpResponse(
                code = code,
                body = text,
                requestId = connection.getHeaderField("X-ARS-Request-ID").orEmpty()
            )
        } finally {
            connection.disconnect()
        }
    }
}
