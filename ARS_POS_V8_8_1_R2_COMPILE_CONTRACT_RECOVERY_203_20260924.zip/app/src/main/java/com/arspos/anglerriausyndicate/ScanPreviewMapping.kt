package com.arspos.anglerriausyndicate

import kotlin.math.min

internal data class ScanPreviewMapping(val scale: Float, val left: Float, val top: Float, val width: Float, val height: Float) {
    fun contains(x: Float, y: Float): Boolean = x >= left && y >= top && x < left + width && y < top + height

    companion object {
        fun fit(frameWidth: Int, frameHeight: Int, viewWidth: Float, viewHeight: Float): ScanPreviewMapping {
            val fw = frameWidth.coerceAtLeast(1).toFloat()
            val fh = frameHeight.coerceAtLeast(1).toFloat()
            val vw = viewWidth.coerceAtLeast(1f)
            val vh = viewHeight.coerceAtLeast(1f)
            val scale = min(vw / fw, vh / fh)
            return ScanPreviewMapping(scale, (vw - fw * scale) / 2f, (vh - fh * scale) / 2f, fw * scale, fh * scale)
        }
    }
}
