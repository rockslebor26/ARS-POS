package com.arspos.anglerriausyndicate

import android.graphics.Bitmap

internal object NormalPhysicalResolver {
    fun resolve(input: List<ScanProposal>, bitmap: Bitmap, session: String): List<ScanProposal> {
        if(input.isEmpty())return emptyList()
        val result=NormalPixelOwnership.resolve(bitmap.width,bitmap.height,input.map {
            val b=it.normalizedBounds;NormalPixelOwnership.Box(b.left,b.top,b.right,b.bottom)
        }) { x,y->bitmap.getPixel(x,y) }
        val frameArea = bitmap.width.coerceAtLeast(1).toLong() * bitmap.height.coerceAtLeast(1).toLong()
        return result.groups.mapIndexed { index,group ->
            val representative=group.maxWithOrNull(compareBy<Int>{ input[it].normalizedBounds.width().toLong()*input[it].normalizedBounds.height() }
                .thenBy { result.owners[it].coverage })!!
            val p=input[representative]
            val ambiguous=group.any { it in result.ambiguous }
            val id="NORMAL-${index+1}"
            val owner = result.owners[representative]
            val ownerBounds = owner.componentBounds
            val cropArea = p.normalizedBounds.width().coerceAtLeast(0).toLong() * p.normalizedBounds.height().coerceAtLeast(0).toLong()
            val ownerArea = ownerBounds?.let { b ->
                (b.right-b.left).coerceAtLeast(0).toLong() * (b.bottom-b.top).coerceAtLeast(0).toLong()
            } ?: 0L
            val cropAreaRatio = cropArea.toFloat() / frameArea.toFloat()
            val ownerAreaRatio = if (cropArea <= 0L) 0f else ownerArea.toFloat() / cropArea.toFloat()
            val purity = NormalProposalPurityPolicy.evaluate(
                cropAreaRatio = cropAreaRatio,
                foregroundComponent = owner.component,
                foregroundCoverage = owner.coverage,
                ownerAreaRatio = ownerAreaRatio,
                ambiguousOverlap = ambiguous,
                mergedProposals = group.size
            )
            val ownershipReason=when { ambiguous->"NORMAL_OVERLAP_REQUIRES_REVIEW";group.size>1->"NORMAL_SHARED_FOREGROUND_COMPONENT";else->"NORMAL_SINGLE_PROPOSAL" }
            val reason = if (purity.safeForQuantity) ownershipReason else "$ownershipReason+${purity.reason}"
            val finalQuantityEligible = p.quantityEligible && !ambiguous && purity.safeForQuantity
            ArsFlightRecorder.event("SCAN_NORMAL_OWNERSHIP",reason,mapOf(
                "session" to session,"physicalObjectId" to id,"proposalIds" to group.map { input[it].proposalId },
                "foregroundComponent" to owner.component,
                "foregroundCoverage" to owner.coverage,
                "foregroundBounds" to ownerBounds?.let { "${it.left},${it.top},${it.right},${it.bottom}" }.orEmpty(),
                "mergedProposals" to group.size,
                "normalPurityScore" to purity.score,
                "normalPurityState" to if (purity.safeForQuantity) "VERIFIED" else "REVIEW_REQUIRED",
                "normalPurityReason" to purity.reason,
                "normalCropAreaRatio" to cropAreaRatio,
                "normalOwnerAreaRatio" to ownerAreaRatio,
                "quantityEligible" to finalQuantityEligible))
            p.copy(proposalId=group.joinToString("+"){input[it].proposalId},physicalObjectId=id,
                physicalInstanceHint=id,lineageId="NORMAL-LINEAGE-$id",hypothesesMerged=group.size,
                physicalMergeReason=reason,quantityEligible=finalQuantityEligible,
                normalForegroundComponent = owner.component,
                normalForegroundCoverage = owner.coverage,
                normalForegroundLeft = ownerBounds?.left ?: 0,
                normalForegroundTop = ownerBounds?.top ?: 0,
                normalForegroundRight = ownerBounds?.right ?: 0,
                normalForegroundBottom = ownerBounds?.bottom ?: 0,
                normalPurityScore = purity.score,
                normalPurityState = if (purity.safeForQuantity) "VERIFIED" else "REVIEW_REQUIRED",
                normalPurityReason = purity.reason,
                normalCropAreaRatio = cropAreaRatio,
                normalOwnerAreaRatio = ownerAreaRatio)
        }
    }
}
