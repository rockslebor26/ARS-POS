package com.arspos.anglerriausyndicate

/**
 * One structured diagnostic event per final decision. This is intentionally
 * telemetry-only: it cannot mutate product identity, stock, payment or quantity.
 */
object ArsDecisionEvidenceLedger {
    fun record(
        session: String,
        proposal: ScanProposal,
        persistentPhysicalId: String,
        candidateProductId: Long?,
        topScore: Int,
        secondScore: Int,
        decisionRuleId: String,
        recognitionAccepted: Boolean,
        quantityAccepted: Boolean,
        localEvidence: String = "FINAL_SCORER",
        cloudEvidence: String = ArsV850Config.CLOUD_IDENTITY_MODE
    ) {
        if (!ArsV850Config.FEATURE_DECISION_EVIDENCE_LEDGER) return
        ArsFlightRecorder.event(
            "DECISION_EVIDENCE_LEDGER",
            "V8.8.1 immutable decision evidence recorded",
            mapOf(
                "session" to session,
                "proposalId" to proposal.proposalId,
                "physicalObjectId" to proposal.physicalObjectId,
                "persistentPhysicalId" to persistentPhysicalId,
                "proposalType" to proposal.proposalType,
                "candidateProductId" to (candidateProductId ?: 0L),
                "topScore" to topScore,
                "secondScore" to secondScore,
                "margin" to (topScore - secondScore),
                "physicalAuthenticity" to proposal.rodAuthenticityScore,
                "physicalAuthenticityState" to proposal.rodAuthenticityState,
                "normalPurityScore" to proposal.normalPurityScore,
                "normalPurityState" to proposal.normalPurityState,
                "fragmentFusion" to proposal.physicalMergeReason.contains("PERSISTENT_FRAGMENT_FUSION"),
                "decisionRuleId" to decisionRuleId,
                "recognitionAccepted" to recognitionAccepted,
                "quantityAccepted" to quantityAccepted,
                "localEvidence" to localEvidence,
                "cloudEvidence" to cloudEvidence,
                "cloudCreatedQuantity" to false,
                "thresholdsRelaxed" to false
            )
        )
    }
}
