package com.arspos.anglerriausyndicate

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Measurement only: no product recognition or acceptance threshold here. */
internal object RodSegmentEvidence {
    data class Result(
        val supported: Boolean,
        val shaftVariation: Float,
        val shaftContinuity: Float,
        val handleAtStart: Boolean
    )

    fun measure(widths: FloatArray, centers: FloatArray): Result {
        if (widths.size < 20 || widths.size != centers.size) return Result(false, 2f, 0f, false)
        val start = widths.size / 5
        val end = widths.size * 4 / 5
        val shaft = (start until end).filter { widths[it].isFinite() && centers[it].isFinite() }
        val continuity = shaft.size.toFloat() / (end - start).coerceAtLeast(1)
        if (shaft.size < 8) return Result(false, 2f, continuity, false)
        val values = shaft.map { widths[it] }
        val mean = values.average().toFloat().coerceAtLeast(0.5f)
        val variation = (sqrt(values.map { (it - mean) * (it - mean) }.average()).toFloat() / mean).coerceIn(0f, 2f)
        fun median(xs: List<Float>): Float = xs.sorted().let { if (it.isEmpty()) 0f else it[it.size / 2] }
        val shaftWidth = median(values).coerceAtLeast(1f)
        val first = widths.take(start).filter { it.isFinite() && it > 0f }
        val last = widths.drop(end).filter { it.isFinite() && it > 0f }
        if (first.size < start / 2 || last.size < (widths.size - end) / 2) return Result(false, variation, continuity, false)
        val firstWidth = median(first)
        val lastWidth = median(last)
        val shaftCenters = shaft.map { centers[it] }
        val centerSpan = (shaftCenters.maxOrNull() ?: 0f) - (shaftCenters.minOrNull() ?: 0f)
        val handleRatio = max(firstWidth, lastWidth) / shaftWidth
        val tipRatio = min(firstWidth, lastWidth) / shaftWidth
        // The wide end must be localised, connected to a stable shaft, and
        // opposed by a narrower tip. A uniform line/beam is not a handle.
        val supported = continuity >= 0.65f && variation <= 0.48f &&
            centerSpan <= max(8f, shaftWidth) && handleRatio in 1.5f..4.8f &&
            tipRatio in 0.2f..1.3f && abs(firstWidth - lastWidth) >= shaftWidth * 0.6f
        return Result(supported, variation, continuity, firstWidth > lastWidth)
    }
}
