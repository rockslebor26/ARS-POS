package com.arspos.anglerriausyndicate

/**
 * Phase 4.3.2.41 / V8.4.21 — NORMAL Proposal Purity Gate.
 *
 * This is physical-quantity safety, not an identity threshold. A NORMAL crop may
 * still carry useful OCR/visual evidence, but it cannot own cashier quantity
 * when the crop is too broad or has no credible foreground owner.
 */
object NormalProposalPurityPolicy {
    data class Result(
        val score: Int,
        val safeForQuantity: Boolean,
        val reason: String
    )

    fun evaluate(
        cropAreaRatio: Float,
        foregroundComponent: Int,
        foregroundCoverage: Float,
        ownerAreaRatio: Float,
        ambiguousOverlap: Boolean,
        mergedProposals: Int
    ): Result {
        val area = cropAreaRatio.coerceIn(0f, 1f)
        val coverage = foregroundCoverage.coerceIn(0f, 1f)
        val ownerRatio = ownerAreaRatio.coerceIn(0f, 1f)

        if (ambiguousOverlap) {
            return Result(0, false, "NORMAL_OVERLAP_REQUIRES_REVIEW")
        }
        if (area >= 0.60f) {
            return Result(5, false, "NORMAL_CONTAINER_FRAME_DOMINANT")
        }
        if (foregroundComponent <= 0 && area >= 0.18f) {
            return Result(12, false, "NORMAL_NO_FOREGROUND_OWNER_LARGE_REGION")
        }
        if (area >= 0.30f && coverage < 0.25f) {
            return Result(18, false, "NORMAL_WEAK_FOREGROUND_LARGE_REGION")
        }
        if (area >= 0.25f && ownerRatio in 0.0001f..0.11f) {
            return Result(25, false, "NORMAL_OWNER_TOO_SMALL_FOR_CONTAINER")
        }

        var score = 100
        if (foregroundComponent <= 0) score -= 28
        if (coverage < 0.20f) score -= 18
        else if (coverage < 0.45f) score -= 10
        if (area > 0.22f) score -= 12
        if (area > 0.35f) score -= 16
        if (ownerRatio in 0.0001f..0.18f) score -= 12
        if (mergedProposals > 1) score -= 8
        score = score.coerceIn(0, 100)

        return if (score >= 55) {
            Result(score, true, "NORMAL_PURITY_VERIFIED")
        } else {
            Result(score, false, "NORMAL_PURITY_INSUFFICIENT")
        }
    }
}
