package com.arspos.anglerriausyndicate

internal object ScanQuantityPolicy {
    fun eligible(accepted: Boolean, hasMatch: Boolean, quantityEligible: Boolean,
                 bridge: Boolean, physicalId: String, instanceHint: String, type: String): Boolean =
        accepted && hasMatch && quantityEligible && !bridge &&
            physicalId.isNotBlank() && physicalId == instanceHint &&
            (type == ScanProposal.TYPE_NORMAL || type == ScanProposal.TYPE_LONG)
}
