package com.arspos.anglerriausyndicate

/**
 * Immutable safety invariants for Adaptive Hybrid Intelligence.
 * Learning/cloud/AI-engineering code must not bypass these rules.
 */
object ArsSafetyKernel {
    data class QuantityDecision(val allowed: Boolean, val reason: String)

    fun quantityDecision(proposal: ScanProposal, recognitionAccepted: Boolean): QuantityDecision {
        if (!recognitionAccepted) return QuantityDecision(false, "IDENTITY_NOT_ACCEPTED")
        if (!proposal.quantityEligible) return QuantityDecision(false, "PHYSICAL_QUANTITY_NOT_ELIGIBLE")
        if (proposal.bridgeSuppressed) return QuantityDecision(false, "BRIDGE_SUPPRESSED")
        if (proposal.proposalType == ScanProposal.TYPE_AMBIGUOUS_CONTAINER) {
            return QuantityDecision(false, "AMBIGUOUS_CONTAINER")
        }
        if (proposal.proposalType == ScanProposal.TYPE_LONG && !proposal.trustedRod) {
            return QuantityDecision(false, "LONG_NOT_TRUSTED")
        }
        if (proposal.proposalType == ScanProposal.TYPE_NORMAL && proposal.normalPurityState == "REVIEW_REQUIRED") {
            return QuantityDecision(false, "NORMAL_PURITY_REVIEW")
        }
        return QuantityDecision(true, "SAFE_PHYSICAL_IDENTITY")
    }

    /** Cloud may strengthen identity evidence, but it can never manufacture a physical quantity. */
    fun cloudMayCreateQuantity(): Boolean = false

    /** Runtime learning never changes recognition thresholds or the cashier commit contract. */
    fun runtimeMayRelaxRecognitionThresholds(): Boolean = false
}
