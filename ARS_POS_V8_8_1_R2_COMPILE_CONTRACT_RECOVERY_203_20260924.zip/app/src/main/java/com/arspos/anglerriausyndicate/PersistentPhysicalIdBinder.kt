package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * V8.7.0 continuity bridge with type-aware LONG axis binding from LIVE tracks to final locked scan.
 *
 * Binding now has a pre-gate proposal path so the persistent physical identity
 * is available before SKU scoring. Binding itself never grants product identity
 * or cashier quantity and cross-lane assignment remains forbidden.
 */
object PersistentPhysicalIdBinder {
    data class LockedTrack(
        val trackId: String,
        val bounds: Rect,
        val frameWidth: Int,
        val frameHeight: Int,
        val proposalType: String,
        val state: String,
        val temporalPhysicalState: String = "NOT_APPLICABLE"
    )

    data class Binding(
        val objectIndex: Int,
        val physicalObjectId: String,
        val persistentPhysicalId: String,
        val normalizedIou: Float
    )

    data class ProposalBinding(
        val proposalId: String,
        val physicalObjectId: String,
        val persistentPhysicalId: String,
        val normalizedIou: Float,
        val totalScore: Float,
        val liveTrack: LiveSceneTrack
    )

    private data class ObjectScore(val track: LockedTrack, val iou: Float, val total: Float)
    private data class ProposalScore(val track: LiveSceneTrack, val iou: Float, val total: Float)

    /** Backward-compatible final-object fallback. */
    fun bind(tracks: List<LockedTrack>, objects: List<VisualScanObject>): List<Binding> {
        if (tracks.isEmpty() || objects.isEmpty()) return emptyList()
        val remaining = tracks.filter { it.state != LiveSceneTrack.STATE_OCCLUDED }.toMutableList()
        val result = ArrayList<Binding>()

        objects.forEach { obj ->
            val objectLong = obj.proposalType == ScanProposal.TYPE_LONG
            val best = remaining.mapNotNull { track ->
                val trackLong = track.proposalType == ScanProposal.TYPE_LONG
                if (trackLong != objectLong) return@mapNotNull null // cross-lane bind forbidden
                val iou = normalizedIou(
                    track.bounds, track.frameWidth, track.frameHeight,
                    obj.normalizedBounds, obj.frameWidth, obj.frameHeight
                )
                val centre = normalizedCentreSimilarity(
                    track.bounds, track.frameWidth, track.frameHeight,
                    obj.normalizedBounds, obj.frameWidth, obj.frameHeight
                )
                val size = normalizedAreaSimilarity(
                    track.bounds, track.frameWidth, track.frameHeight,
                    obj.normalizedBounds, obj.frameWidth, obj.frameHeight
                )
                if (iou < 0.08f && (centre < 0.62f || size < 0.42f)) return@mapNotNull null
                val total = iou * 0.60f + centre * 0.25f + size * 0.15f
                if (total < 0.31f) null else ObjectScore(track, iou, total)
            }.maxByOrNull { it.total }

            if (best != null) {
                remaining.remove(best.track)
                result += Binding(
                    objectIndex = obj.index,
                    physicalObjectId = obj.physicalObjectId,
                    persistentPhysicalId = best.track.trackId,
                    normalizedIou = best.iou.coerceIn(0f, 1f)
                )
            }
        }
        return result
    }

    /**
     * Pre-gate one-to-one LIVE -> final proposal binding. Proposals that were
     * converted to evidence-only containers keep their LONG lane when their
     * physical lineage is TRACK-* or their source is authenticity/background.
     */
    fun bindProposals(
        snapshot: LiveSceneLockSnapshot?,
        proposals: List<ScanProposal>,
        finalFrameWidth: Int,
        finalFrameHeight: Int
    ): List<ProposalBinding> {
        if (snapshot == null || snapshot.tracks.isEmpty() || proposals.isEmpty()) return emptyList()
        val remaining = snapshot.tracks.filter { it.state != LiveSceneTrack.STATE_OCCLUDED }.toMutableList()
        val result = ArrayList<ProposalBinding>()

        proposals.sortedByDescending { area(it.normalizedBounds) }.forEach { proposal ->
            val proposalLong = proposalLaneLong(proposal)
            val best = remaining.mapNotNull { track ->
                val trackLong = track.proposalType == ScanProposal.TYPE_LONG
                if (trackLong != proposalLong) return@mapNotNull null
                val iou = normalizedIou(
                    track.bounds, snapshot.frameWidth, snapshot.frameHeight,
                    proposal.normalizedBounds, finalFrameWidth, finalFrameHeight
                )
                val centre = normalizedCentreSimilarity(
                    track.bounds, snapshot.frameWidth, snapshot.frameHeight,
                    proposal.normalizedBounds, finalFrameWidth, finalFrameHeight
                )
                val size = normalizedAreaSimilarity(
                    track.bounds, snapshot.frameWidth, snapshot.frameHeight,
                    proposal.normalizedBounds, finalFrameWidth, finalFrameHeight
                )
                val aspect = normalizedAspectSimilarity(
                    track.bounds, snapshot.frameWidth, snapshot.frameHeight,
                    proposal.normalizedBounds, finalFrameWidth, finalFrameHeight
                )
                val angle = if (proposalLong && track.axisConfidence > 0 && proposal.axisConfidence > 0) {
                    axisAngleSimilarity(track.axisAngleDeg, proposal.axisAngleDeg)
                } else 1f
                if (proposalLong) {
                    if (iou < 0.04f && (centre < 0.52f || size < 0.30f || angle < 0.52f)) return@mapNotNull null
                } else {
                    if (iou < 0.06f && (centre < 0.60f || size < 0.36f)) return@mapNotNull null
                }
                val temporalBonus = when (track.temporalPhysicalState) {
                    "TEMPORAL_TRUSTED_ROD" -> 0.05f
                    "TEMPORAL_ROD_CANDIDATE" -> 0.02f
                    else -> 0f
                }
                val total = if (proposalLong) {
                    (iou * 0.28f + centre * 0.27f + size * 0.12f + angle * 0.23f + aspect * 0.05f + temporalBonus)
                        .coerceAtMost(1f)
                } else {
                    (iou * 0.58f + centre * 0.27f + size * 0.15f + temporalBonus).coerceAtMost(1f)
                }
                if (total < 0.30f) null else ProposalScore(track, iou, total)
            }.maxByOrNull { it.total }

            if (best != null) {
                remaining.remove(best.track)
                result += ProposalBinding(
                    proposalId = proposal.proposalId,
                    physicalObjectId = proposal.physicalObjectId,
                    persistentPhysicalId = best.track.trackId,
                    normalizedIou = best.iou.coerceIn(0f, 1f),
                    totalScore = best.total,
                    liveTrack = best.track
                )
            }
        }
        return result
    }

    private fun proposalLaneLong(proposal: ScanProposal): Boolean = when {
        proposal.proposalType == ScanProposal.TYPE_LONG -> true
        proposal.proposalType == ScanProposal.TYPE_AMBIGUOUS_CONTAINER &&
            (proposal.physicalInstanceHint.startsWith("TRACK-") ||
                proposal.source == ScanProposal.SOURCE_AUTHENTICITY ||
                proposal.source == ScanProposal.SOURCE_BACKGROUND ||
                proposal.source == ScanProposal.SOURCE_TEMPORAL_SEED) -> true
        else -> false
    }

    private data class NRect(val l: Float, val t: Float, val r: Float, val b: Float)

    private fun norm(rect: Rect, w: Int, h: Int): NRect? {
        if (w <= 0 || h <= 0) return null
        return NRect(
            rect.left.toFloat() / w,
            rect.top.toFloat() / h,
            rect.right.toFloat() / w,
            rect.bottom.toFloat() / h
        )
    }

    private fun normalizedIou(a: Rect, aw: Int, ah: Int, b: Rect, bw: Int, bh: Int): Float {
        val x = norm(a, aw, ah) ?: return 0f
        val y = norm(b, bw, bh) ?: return 0f
        val l = max(x.l, y.l); val t = max(x.t, y.t); val r = min(x.r, y.r); val bot = min(x.b, y.b)
        if (r <= l || bot <= t) return 0f
        val inter = (r - l) * (bot - t)
        val areaA = (x.r - x.l).coerceAtLeast(0f) * (x.b - x.t).coerceAtLeast(0f)
        val areaB = (y.r - y.l).coerceAtLeast(0f) * (y.b - y.t).coerceAtLeast(0f)
        val union = areaA + areaB - inter
        return if (union <= 0f) 0f else inter / union
    }

    private fun normalizedCentreSimilarity(a: Rect, aw: Int, ah: Int, b: Rect, bw: Int, bh: Int): Float {
        val x = norm(a, aw, ah) ?: return 0f
        val y = norm(b, bw, bh) ?: return 0f
        val ax=(x.l+x.r)/2f; val ay=(x.t+x.b)/2f; val bx=(y.l+y.r)/2f; val by=(y.t+y.b)/2f
        val distance = hypot(ax-bx, ay-by)
        return (1f - distance / 0.55f).coerceIn(0f,1f)
    }

    private fun normalizedAreaSimilarity(a: Rect, aw: Int, ah: Int, b: Rect, bw: Int, bh: Int): Float {
        val x = norm(a, aw, ah) ?: return 0f
        val y = norm(b, bw, bh) ?: return 0f
        val areaA=((x.r-x.l).coerceAtLeast(0f)*(x.b-x.t).coerceAtLeast(0f)).coerceAtLeast(0.000001f)
        val areaB=((y.r-y.l).coerceAtLeast(0f)*(y.b-y.t).coerceAtLeast(0f)).coerceAtLeast(0.000001f)
        return min(areaA,areaB)/max(areaA,areaB)
    }

    private fun normalizedAspectSimilarity(a: Rect, aw: Int, ah: Int, b: Rect, bw: Int, bh: Int): Float {
        val x = norm(a, aw, ah) ?: return 0f
        val y = norm(b, bw, bh) ?: return 0f
        fun aspect(n: NRect): Float {
            val w = (n.r - n.l).coerceAtLeast(0.0001f)
            val h = (n.b - n.t).coerceAtLeast(0.0001f)
            val raw = max(w, h) / min(w, h)
            return raw.coerceAtLeast(1f)
        }
        val aa = aspect(x)
        val bb = aspect(y)
        return min(aa, bb) / max(aa, bb)
    }

    private fun axisAngleSimilarity(a: Float, b: Float): Float {
        var delta = kotlin.math.abs(a - b) % 180f
        if (delta > 90f) delta = 180f - delta
        return (1f - delta / 60f).coerceIn(0f, 1f)
    }

    private fun area(rect: Rect): Long = rect.width().coerceAtLeast(0).toLong() * rect.height().coerceAtLeast(0).toLong()
}
