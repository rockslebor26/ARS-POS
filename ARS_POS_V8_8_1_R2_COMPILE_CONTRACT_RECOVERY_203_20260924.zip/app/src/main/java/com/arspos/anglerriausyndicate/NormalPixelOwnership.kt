package com.arspos.anglerriausyndicate

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Bounded foreground-component ownership. SKU/text equality is never evidence
 * that two visible products are the same physical object. No Android dependency.
 */
internal object NormalPixelOwnership {
    data class Box(val left: Int, val top: Int, val right: Int, val bottom: Int)
    data class Owner(
        val component: Int,
        val coverage: Float,
        val support: Int,
        val componentBounds: Box? = null
    )
    data class Result(val groups: List<List<Int>>, val ambiguous: Set<Int>, val owners: List<Owner>)

    fun resolve(width: Int, height: Int, boxes: List<Box>, pixel: (Int, Int) -> Int): Result {
        if (boxes.isEmpty()) return Result(emptyList(), emptySet(), emptyList())
        val scale = min(1f, 256f / max(width, height).coerceAtLeast(1))
        val w = max(3, (width * scale).roundToInt()); val h = max(3, (height * scale).roundToInt())
        val pixels = IntArray(w * h)
        val border = ArrayList<Int>()
        for (y in 0 until h) for (x in 0 until w) {
            val c = pixel((x / scale).toInt().coerceIn(0, width - 1), (y / scale).toInt().coerceIn(0, height - 1))
            pixels[y * w + x] = c
            if (x < 3 || y < 3 || x >= w - 3 || y >= h - 3) border += c
        }
        fun channel(c: Int, shift: Int) = (c ushr shift) and 255
        fun background(shift: Int): Int = border.map { channel(it, shift) }.sorted().let { it[it.size / 2] }
        val br = background(16); val bg = background(8); val bb = background(0)
        val mask = BooleanArray(w * h) { i ->
            val c = pixels[i]
            (abs(channel(c,16)-br) + abs(channel(c,8)-bg) + abs(channel(c,0)-bb)) / 765f >= .22f
        }
        // Close one-cell seams between the faces of a package before removing
        // thin grout/text bridges. This avoids treating its lid as another item.
        val dilated = BooleanArray(w * h)
        val closed = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            for (dy in -1..1) for (dx in -1..1)
                if (mask[(y+dy)*w+x+dx]) dilated[y*w+x] = true
        }
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            var solid = true
            for (dy in -1..1) for (dx in -1..1) if (!dilated[(y+dy)*w+x+dx]) solid = false
            closed[y*w+x] = solid
        }
        val core = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            var solid = true
            for (dy in -1..1) for (dx in -1..1) if (!closed[(y+dy)*w+x+dx]) solid = false
            core[y*w+x] = solid
        }
        val labels = IntArray(w*h); val sizes = mutableListOf(0); val queue = IntArray(w*h)
        val componentBoundsScaled = mutableListOf<Box?>(null)
        var next = 0
        for (i in labels.indices) if (core[i] && labels[i] == 0) {
            next++; var head=0; var tail=1; queue[0]=i; labels[i]=next
            var minX = i % w; var maxX = minX
            var minY = i / w; var maxY = minY
            while(head<tail) {
                val at=queue[head++]; val x=at%w; val y=at/w
                minX = min(minX, x); maxX = max(maxX, x)
                minY = min(minY, y); maxY = max(maxY, y)
                fun add(n: Int) { if(core[n] && labels[n]==0) { labels[n]=next; queue[tail++]=n } }
                if(x>0)add(at-1);if(x<w-1)add(at+1);if(y>0)add(at-w);if(y<h-1)add(at+w)
            }
            sizes += tail
            componentBoundsScaled += Box(minX, minY, maxX + 1, maxY + 1)
        }
        val componentCounts = boxes.map { b ->
            val counts=IntArray(next+1)
            for(y in (b.top*scale).toInt().coerceIn(0,h)..(b.bottom*scale).toInt().coerceIn(0,h-1))
                for(x in (b.left*scale).toInt().coerceIn(0,w)..(b.right*scale).toInt().coerceIn(0,w-1)) {
                    val id=labels[y*w+x]; if(id>0) counts[id]++
                }
            counts
        }
        fun sourceBounds(scaled: Box?): Box? {
            scaled ?: return null
            return Box(
                (scaled.left / scale).toInt().coerceIn(0, width - 1),
                (scaled.top / scale).toInt().coerceIn(0, height - 1),
                kotlin.math.ceil(scaled.right / scale.toDouble()).toInt().coerceIn(1, width),
                kotlin.math.ceil(scaled.bottom / scale.toDouble()).toInt().coerceIn(1, height)
            )
        }
        val owners = componentCounts.map { counts ->
            val id=(1..next).maxByOrNull { counts[it] } ?: 0
            val total=counts.sum()
            if(id==0 || counts[id]<6 || counts[id].toFloat()/total.coerceAtLeast(1)<.80f) Owner(0,0f,total,null)
            else Owner(id,counts[id].toFloat()/sizes[id],counts[id],sourceBounds(componentBoundsScaled[id]))
        }
        fun area(b:Box)=(b.right-b.left).coerceAtLeast(0).toLong()*(b.bottom-b.top).coerceAtLeast(0)
        fun overlap(a:Box,b:Box):Float {
            val n=(min(a.right,b.right)-max(a.left,b.left)).coerceAtLeast(0).toLong()*
                (min(a.bottom,b.bottom)-max(a.top,b.top)).coerceAtLeast(0)
            return n.toFloat()/min(area(a),area(b)).coerceAtLeast(1)
        }
        val ambiguous=mutableSetOf<Int>()
        fun same(i:Int,j:Int):Boolean {
            val o=overlap(boxes[i],boxes[j]);if(o<.14f)return false
            val a=owners[i];val b=owners[j]
            if(a.component>0 && b.component>0 && a.component!=b.component)return false
            val areaRatio=max(area(boxes[i]),area(boxes[j])).toFloat()/min(area(boxes[i]),area(boxes[j])).coerceAtLeast(1)
            val dominantProof=a.component>0 && a.component==b.component && max(a.coverage,b.coverage)>=.75f &&
                min(a.coverage,b.coverage)>=.15f && (areaRatio>=1.4f || o>=.85f)
            // The same package can have disconnected faces (lid, label, body).
            // A partial crop may include its shadow. Prove shared BODY pixels
            // against the complete component, including their exact intersection.
            val sharedProof = o >= .40f && areaRatio >= 1.6f && (1..next).any { id ->
                val ca=componentCounts[i][id]; val cb=componentCounts[j][id]
                if(ca<6 || cb<6 || ca.toFloat()/a.support.coerceAtLeast(1)<.50f ||
                    cb.toFloat()/b.support.coerceAtLeast(1)<.50f) return@any false
                val ba=boxes[i];val bbx=boxes[j]
                var intersection=0
                for(y in (max(ba.top,bbx.top)*scale).toInt().coerceIn(0,h)..(min(ba.bottom,bbx.bottom)*scale).toInt().coerceIn(0,h-1))
                    for(x in (max(ba.left,bbx.left)*scale).toInt().coerceIn(0,w)..(min(ba.right,bbx.right)*scale).toInt().coerceIn(0,w-1))
                        if(labels[y*w+x]==id) intersection++
                // Allow a small component rim outside ML boxes; the boxes may
                // clip cast-shadow edges. This is geometry ownership only.
                (ca+cb-intersection).toFloat()/sizes[id] >= .85f
            }
            val proven=dominantProof || sharedProof
            if(!proven && o>=.35f) { ambiguous+=i;ambiguous+=j }
            return proven
        }
        // Resolve pair relationships once; complete linkage prevents an
        // oversized proposal from joining two independent components.
        val sameMatrix=Array(boxes.size){BooleanArray(boxes.size)}
        for(i in boxes.indices)for(j in i+1 until boxes.size){sameMatrix[i][j]=same(i,j);sameMatrix[j][i]=sameMatrix[i][j]}
        for(i in boxes.indices) {
            val peers=boxes.indices.filter { sameMatrix[i][it] }
            for(a in peers.indices)for(b in a+1 until peers.size) {
                if(!sameMatrix[peers[a]][peers[b]]) {
                    ambiguous+=i;ambiguous+=peers[a];ambiguous+=peers[b]
                }
            }
        }
        val groups=mutableListOf<MutableList<Int>>()
        boxes.indices.forEach { i ->
            val group=groups.firstOrNull { g->g.all { sameMatrix[it][i] } }
            if(group==null)groups+=mutableListOf(i) else group+=i
        }
        return Result(groups,ambiguous,owners)
    }
}
