package com.arspos.anglerriausyndicate

/** Scores supplied here belong to exactly one product. */
internal object RodAnchorRolePolicy {
    fun handleOnLeft(leftHandle: Int, rightHandle: Int, leftTip: Int, rightTip: Int,
                     tipVisible: Boolean, fallback: Boolean): Boolean {
        val left = leftHandle * 3 + if (tipVisible) rightTip * 2 else 0
        val right = rightHandle * 3 + if (tipVisible) leftTip * 2 else 0
        return when {
            left > right -> true
            right > left -> false
            else -> fallback
        }
    }
}
