package com.arspos.anglerriausyndicate

/** Pure validation; a rejected review must not partly mutate the cart. */
internal object ScanCommitPolicy {
    fun rejection(
        session: String,
        activeSession: String,
        committed: Boolean,
        requests: List<Pair<Long, Int>>,
        availableStock: Map<Long, Int>,
        currentQuantity: Map<Long, Int>
    ): String? {
        if (session.isBlank()) return "INVALID_SESSION"
        if (committed) return "DUPLICATE_SESSION"
        if (session != activeSession) return "STALE_SESSION"
        if (requests.isEmpty() || requests.all { it.second == 0 }) return "EMPTY_REVIEW"
        if (requests.map { it.first }.distinct().size != requests.size) return "DUPLICATE_PRODUCT"
        for ((id, quantity) in requests) {
            val stock = availableStock[id] ?: return "PRODUCT_NOT_ACCEPTED_IN_SCAN"
            if (quantity < 0) return "INVALID_QUANTITY"
            val room = (stock.toLong() - (currentQuantity[id] ?: 0).toLong()).coerceAtLeast(0)
            if (quantity.toLong() > room) return "STOCK_LIMIT_REVIEW_REQUIRED"
        }
        return null
    }
}
