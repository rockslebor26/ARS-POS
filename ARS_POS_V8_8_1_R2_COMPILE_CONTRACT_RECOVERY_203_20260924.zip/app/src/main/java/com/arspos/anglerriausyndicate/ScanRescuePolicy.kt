package com.arspos.anglerriausyndicate

internal object ScanRescuePolicy {
    fun skipReason(hasVerifiedLongMaster: Boolean, acceptedLong: Boolean, trustedTracks: Int, qualifiedUncertainTracks: Int): String? = when {
        !hasVerifiedLongMaster -> "NO_VERIFIED_LONG_MASTER"
        acceptedLong -> "LONG_ALREADY_ACCEPTED"
        trustedTracks > 0 -> "TRUSTED_ROD_TRACK_PRESENT"
        qualifiedUncertainTracks == 0 -> "NO_INDEPENDENT_ROD_EVIDENCE"
        qualifiedUncertainTracks > 1 -> "MULTIPLE_PHYSICAL_RODS_NO_FULL_FRAME_RESCUE"
        else -> null
    }
}
