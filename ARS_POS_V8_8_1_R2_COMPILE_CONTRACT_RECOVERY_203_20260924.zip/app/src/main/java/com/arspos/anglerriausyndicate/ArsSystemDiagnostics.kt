package com.arspos.anglerriausyndicate

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import java.util.concurrent.atomic.AtomicBoolean

/** OS signals are recorded independently from native allocation deltas. */
internal object ArsSystemDiagnostics {
    private val exitAuditStarted = AtomicBoolean(false)

    fun memory(context: Context): Map<String, Any?> = runCatching {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(info)
        mapOf<String, Any?>("systemLowMemory" to info.lowMemory,
            "systemAvailableMemoryMb" to info.availMem / 1048576L,
            "systemLowMemoryThresholdMb" to info.threshold / 1048576L)
    }.getOrElse { mapOf("systemLowMemory" to null) }

    fun recordPreviousExits(context: Context) {
        if (Build.VERSION.SDK_INT < 30 || !exitAuditStarted.compareAndSet(false, true)) return
        val app = context.applicationContext
        Thread({
            runCatching {
                val preferences = app.getSharedPreferences("ars_exit_diagnostics", Context.MODE_PRIVATE)
                val previousTimestamp = preferences.getLong("lastExitTimestamp", 0L)
                val manager = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val exits = manager.getHistoricalProcessExitReasons(app.packageName, 0, 8)
                    .filter { it.timestamp > previousTimestamp }.sortedBy { it.timestamp }
                exits.forEach { exit ->
                    val reason = when (exit.reason) {
                        ApplicationExitInfo.REASON_ANR -> "ANR"
                        ApplicationExitInfo.REASON_CRASH -> "JAVA_CRASH"
                        ApplicationExitInfo.REASON_CRASH_NATIVE -> "NATIVE_CRASH"
                        ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW_MEMORY_KILL"
                        ApplicationExitInfo.REASON_USER_REQUESTED -> "USER_REQUESTED"
                        else -> "OTHER_OS_EXIT"
                    }
                    ArsFlightRecorder.event("PROCESS_EXIT_HISTORY", reason, mapOf(
                        "exitTimestamp" to exit.timestamp, "reasonCode" to exit.reason,
                        "importance" to exit.importance, "pssKb" to exit.pss, "rssKb" to exit.rss,
                        "status" to exit.status, "source" to "ANDROID_APPLICATION_EXIT_INFO"))
                }
                exits.lastOrNull()?.let { preferences.edit().putLong("lastExitTimestamp", it.timestamp).apply() }
            }.onFailure { ArsFlightRecorder.event("PROCESS_EXIT_AUDIT_UNAVAILABLE", it.javaClass.simpleName) }
        }, "ars-exit-audit").apply { isDaemon = true; start() }
    }
}
