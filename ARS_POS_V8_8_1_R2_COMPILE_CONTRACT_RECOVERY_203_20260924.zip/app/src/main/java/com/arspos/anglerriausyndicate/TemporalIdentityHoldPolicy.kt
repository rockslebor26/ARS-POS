package com.arspos.anglerriausyndicate

/**
 * V8.8.1 preview-only identity hysteresis.
 *
 * A previously proven MATCHED identity may survive a very short weak-evidence
 * window while the same physical track remains present. This never creates a
 * new identity, never changes recognition thresholds and never grants final
 * transaction quantity.
 */
object TemporalIdentityHoldPolicy {
    const val MAX_WEAK_FRAMES = 2

    fun shouldHold(
        hadMatched: Boolean,
        productStillOwned: Boolean,
        weakEvidenceFrames: Int,
        missingFrames: Int
    ): Boolean = hadMatched &&
        productStillOwned &&
        missingFrames == 0 &&
        weakEvidenceFrames in 1..MAX_WEAK_FRAMES
}
