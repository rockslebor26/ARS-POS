package com.arspos.anglerriausyndicate

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Pixel evidence only. A line detector's confidence cannot satisfy this gate.
 * Pure Kotlin so the EXACT production measurement can replay exported JPEGs on JVM.
 * A visible grip/body is required for automatic physical quantity; an isolated
 * thin shaft remains uncertain until a more informative photograph is supplied.
 */
object RodMaterialProfile {
    private const val STATIONS = 97
    private const val CROSS_SAMPLES = 81
    private const val CORE_CONTRAST = 0.20f

    data class Result(
        val supported: Boolean = false,
        val coverage: Float = 0f,
        val bodyCoverage: Float = 0f,
        val medianWidth: Float = 0f,
        val p15: Float = 0f,
        val p85: Float = 0f,
        val widthRatio: Float = 1f,
        val localVariation: Float = 2f,
        val centerResidual: Float = 0f,
        val directionSlope: Float = 0f,
        val reason: String = "NO_BOUNDED_MATERIAL",
        val tipVisible: Boolean = false
    )

    fun measure(width: Int, height: Int, sx: Float, sy: Float, ex: Float, ey: Float,
                pixel: (Int, Int) -> Int): Result {
        val dx = ex - sx; val dy = ey - sy
        val length = hypot(dx, dy)
        if (width < 2 || height < 2 || length < 48f) return Result()
        val nx = -dy / length; val ny = dx / length
        val short = min(width, height).toFloat()
        val half = min(96f, max(32f, short * 0.09f))
        val step = 2f * half / (CROSS_SAMPLES - 1)
        val widths = FloatArray(STATIONS)
        val centers = FloatArray(STATIONS)
        for (m in 0 until STATIONS) {
            val t = m.toFloat() / (STATIONS - 1)
            val x = sx + dx * t; val y = sy + dy * t
            val values = FloatArray(CROSS_SAMPLES)
            var inFrame = true
            for (i in values.indices) {
                val offset = (i - (CROSS_SAMPLES - 1) * 0.5f) * step
                val px = (x + nx * offset).roundToInt(); val py = (y + ny * offset).roundToInt()
                if (px !in 0 until width || py !in 0 until height) { inFrame = false; break }
                val c = pixel(px, py)
                values[i] = (((c ushr 16) and 255) * .2126f + ((c ushr 8) and 255) * .7152f + (c and 255) * .0722f) / 255f
            }
            // No repeated/clamped border pixels are manufactured as evidence.
            if (!inFrame) continue
            val background = median((values.take(8) + values.takeLast(8)).sorted())
            var start = -1; var bestDistance = Float.MAX_VALUE
            for (i in 0..CROSS_SAMPLES) {
                val active = i < CROSS_SAMPLES && abs(values[i] - background) >= CORE_CONTRAST
                if (active && start < 0) start = i
                if (!active && start >= 0) {
                    // Both sides must close against the background inside the corridor.
                    if (start > 0 && i < CROSS_SAMPLES) {
                        val center = ((start + i - 1) * .5f - (CROSS_SAMPLES - 1) * .5f) * step
                        val distance = abs(center)
                        if (distance <= max(14f, half * .30f) && distance < bestDistance) {
                            widths[m] = (i - start) * step; centers[m] = center; bestDistance = distance
                        }
                    }
                    start = -1
                }
            }
        }
        val valid = widths.indices.filter { widths[it] > 0f }
        if (valid.size < 8) return Result()
        val sorted = valid.map { widths[it] }.sorted()
        val lo = percentile(sorted, .15f); val hi = percentile(sorted, .85f)
        val ratio = hi / max(1f, lo)
        val body = valid.filter { widths[it] >= short * .025f }
        val coverage = valid.size.toFloat() / STATIONS
        val bodyCoverage = body.size.toFloat() / STATIONS
        val meanT = body.map { it * length / (STATIONS - 1) }.average().toFloat()
        val meanC = body.map { centers[it] }.average().toFloat()
        val denominator = body.sumOf { val d = it * length / (STATIONS - 1) - meanT; (d * d).toDouble() }.toFloat()
        val slope = if (denominator > 0f) body.sumOf {
            ((it * length / (STATIONS - 1) - meanT) * (centers[it] - meanC)).toDouble()
        }.toFloat() / denominator else 0f
        val residual = if (body.isEmpty()) 0f else median(body.map {
            abs(centers[it] - meanC - slope * (it * length / (STATIONS - 1) - meanT))
        }.sorted())
        // Evaluate width variation WITHIN local sections. A grip-to-shaft
        // transition is not a branch, and grip width is not beam/shaft width.
        val variations = (0 until 6).mapNotNull { section ->
            val xs = (section * STATIONS / 6 until (section + 1) * STATIONS / 6)
                .filter { widths[it] > 0f }.map { widths[it] }
            if (xs.size < 5) null else {
                val mean = xs.average().toFloat().coerceAtLeast(.5f)
                sqrt(xs.map { (it - mean) * (it - mean) }.average()).toFloat() / mean
            }
        }
        val localVariation = if (variations.isEmpty()) 2f else median(variations.sorted())
        val reason = when {
            bodyCoverage < .35f -> "NO_INDEPENDENT_GRIP_BODY"
            coverage < .55f -> "LOCAL_CROSSING_NOT_LONGITUDINAL_BODY"
            abs(slope) > .12f -> "FOREGROUND_DIRECTION_CONFLICT"
            ratio < 1.5f -> "UNIFORM_LINE_OR_BEAM"
            ratio > 12f -> "DISCONNECTED_WIDTH_PROFILE"
            localVariation > .60f -> "IRREGULAR_MATERIAL_PROFILE"
            else -> "BOUNDED_GRIP_SHAFT_PROFILE"
        }
        // TIP requires actual visible termination, not the opposite rectangle.
        fun terminated(atStart: Boolean): Boolean {
            val ids = if (atStart) widths.indices.toList() else widths.indices.reversed()
            val ending = ids.take(4).all { widths[it] == 0f }
            val shaft = ids.drop(4).take(12).map { widths[it] }.filter { it > 0f }
            return ending && shaft.size >= 9 && median(shaft.sorted()) < max(4f, lo * .65f)
        }
        val endpointsInside = listOf(sx, ex).all { it > half && it < width - half } &&
            listOf(sy, ey).all { it > half && it < height - half }
        return Result(reason == "BOUNDED_GRIP_SHAFT_PROFILE", coverage, bodyCoverage,
            median(sorted), lo, hi, ratio, localVariation, residual, slope, reason,
            endpointsInside && (terminated(true) || terminated(false)))
    }

    private fun median(xs: List<Float>): Float = if (xs.isEmpty()) 0f else
        if (xs.size % 2 == 1) xs[xs.size / 2] else (xs[xs.size / 2 - 1] + xs[xs.size / 2]) * .5f
    private fun percentile(xs: List<Float>, p: Float): Float {
        val n = (xs.size - 1) * p; val i = n.toInt()
        return xs[i] + (xs[min(i + 1, xs.lastIndex)] - xs[i]) * (n - i)
    }
}
