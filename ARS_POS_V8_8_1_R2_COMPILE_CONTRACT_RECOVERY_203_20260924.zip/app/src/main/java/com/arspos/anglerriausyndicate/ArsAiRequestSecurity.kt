package com.arspos.anglerriausyndicate

import android.content.Context
import java.security.MessageDigest
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * V8.7.0 request integrity for the ARS AI Gateway.
 *
 * The operator-provisioned gateway token remains encrypted by Android Keystore.
 * Every protected request is additionally signed with HMAC-SHA256 over method,
 * path, timestamp, nonce, body hash and a random app-install device ID.
 */
object ArsAiRequestSecurity {
    private const val PREFS = "ars_ai_engineer_identity"
    private const val KEY_DEVICE_ID = "device_id_v1"

    data class SignedHeaders(
        val deviceId: String,
        val timestamp: String,
        val nonce: String,
        val bodySha256: String,
        val signature: String
    )

    fun deviceId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.getString(KEY_DEVICE_ID, null)?.takeIf { it.isNotBlank() }?.let { return it }
        val created = UUID.randomUUID().toString()
        prefs.edit().putString(KEY_DEVICE_ID, created).apply()
        return created
    }

    fun sign(
        context: Context,
        token: String,
        method: String,
        path: String,
        body: ByteArray
    ): SignedHeaders {
        require(token.isNotBlank()) { "Gateway token kosong" }
        val deviceId = deviceId(context)
        val timestamp = System.currentTimeMillis().toString()
        val nonce = UUID.randomUUID().toString()
        val bodySha256 = sha256Hex(body)
        val canonical = listOf(
            method.uppercase(),
            path,
            timestamp,
            nonce,
            bodySha256,
            deviceId
        ).joinToString("\n")
        return SignedHeaders(
            deviceId = deviceId,
            timestamp = timestamp,
            nonce = nonce,
            bodySha256 = bodySha256,
            signature = hmacSha256Hex(token, canonical.toByteArray(Charsets.UTF_8))
        )
    }

    private fun sha256Hex(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256")
            .digest(bytes)
            .joinToString("") { "%02x".format(it) }

    private fun hmacSha256Hex(secret: String, bytes: ByteArray): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(bytes).joinToString("") { "%02x".format(it) }
    }
}
