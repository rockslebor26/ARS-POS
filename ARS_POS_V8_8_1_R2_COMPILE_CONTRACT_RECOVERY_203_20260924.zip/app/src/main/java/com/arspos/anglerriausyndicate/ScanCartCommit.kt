package com.arspos.anglerriausyndicate

import com.arspos.anglerriausyndicate.data.db.ProductEntity

data class ScanQuantityDraft(
    val product: ProductEntity,
    val detectedQuantity: Int,
    val quantity: Int
)

data class ScanCartCommitResult(
    val committed: Boolean,
    val duplicateSession: Boolean,
    val addedQuantity: Int,
    val affectedProducts: Int,
    val message: String
)
