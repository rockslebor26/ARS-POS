package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Phase 4.3.2.34: ARS Product Identity Engine V8.4.14 multi-anchor foundation.
 *
 * V8.3 keeps the deterministic offline matcher but makes it more tolerant of
 * camera framing, orientation and background changes. It uses several center
 * windows plus edge/gradient descriptors. Long objects (rods) are compared at
 * 0/90/180/270 degrees and receive a small elongated-shape agreement signal.
 * This is still a reference matcher, not a trained AI model.
 */
object ProductVisualMatcher {
    private const val SIZE = 32
    private const val HASH_WIDTH = 9
    private const val HASH_HEIGHT = 8
    private const val GRID = 4
    private const val PROJECTION_BINS = 16
    private const val LONG_PROFILE_BINS = 24

    private data class Fingerprint(
        val pixels: FloatArray,
        val histogram: FloatArray,
        val hash: Long,
        val shape: FloatArray,
        val gradient: FloatArray,
        val projectionX: FloatArray,
        val projectionY: FloatArray,
        val aspect: Float
    )

    private data class FingerprintBank(
        val full: Fingerprint,
        val center90: Fingerprint,
        val center82: Fingerprint,
        val center68: Fingerprint
    )

    private val referenceCache = ConcurrentHashMap<String, FingerprintBank>()
    private val referenceStripCache = ConcurrentHashMap<String, FingerprintBank>()

    fun score(scan: Bitmap, referencePath: String): Int = score(scan, referencePath, false)

    /**
     * Phase 4.3.2.25 V8.4.5 — batch scoring for one scan crop.
     *
     * Normal products reuse a single scan fingerprint bank across all references
     * instead of recalculating the scan fingerprint for every photo. Long-object
     * references keep the specialized rod pipeline because it needs orientation
     * and strip processing. Reference fingerprints remain cached by file metadata.
     */
    fun scoreBatch(scan: Bitmap, referencePaths: List<String>, longObject: Boolean): Map<String, Int> {
        if (referencePaths.isEmpty()) return emptyMap()
        val unique = referencePaths.distinct()
        if (longObject) {
            return scoreBatchLongCached(scan, unique)
        }

        val scanBank = fingerprintBank(scan)
        return scoreBatchPrepared(scanBank, unique)
    }

    /** V8.4.12: reuse one scan fingerprint bank across multiple anchor-role hypotheses. */
    private fun scoreBatchPrepared(scanBank: FingerprintBank, referencePaths: List<String>): Map<String, Int> {
        val unique = referencePaths.distinct()
        val result = LinkedHashMap<String, Int>(unique.size)
        unique.forEach { path ->
            val file = File(path)
            if (!file.exists()) {
                result[path] = 0
            } else {
                val cacheKey = "${file.absolutePath}:${file.lastModified()}:${file.length()}"
                val bank = referenceCache[cacheKey]
                    ?: loadReferenceBank(path)?.also { referenceCache[cacheKey] = it }
                val score = if (bank == null) 0 else bestBankSimilarity(scanBank, bank, false).roundToInt().coerceIn(0, 100)
                result[path] = score
            }
        }
        return result
    }

    data class RodAnchorReference(val path: String, val angle: String, val productId: Long = 0L)
    data class RodAnchorScores(
        val scores: Map<String, Int>,
        val handleOnLeftByProduct: Map<Long, Boolean>,
        val physicalHandleOnLeft: Boolean? = null,
        val endpointLeftScore: Int = 0,
        val endpointRightScore: Int = 0,
        val roleMargin: Int = 0,
        val roleConfidence: Int = 0,
        val roleState: String = "ANCHOR_ROLE_UNKNOWN"
    )

    /** V8.4.20: one endpoint-role assignment per product. Missing TIP is excluded.
     * References/crops are compared without changing recognition thresholds.
     */
    fun scoreBatchRodAnchorAware(
        scan: Bitmap, references: List<RodAnchorReference>, tipVisible: Boolean = false
    ): RodAnchorScores {
        if (references.isEmpty()) return RodAnchorScores(emptyMap(), emptyMap())
        val result = LinkedHashMap<String, Int>()
        val roles = LinkedHashMap<Long, Boolean>()
        val anchors = RodAnchorExtractor.extract(scan)
        try {
            val valid = references.distinctBy { it.path }
                .filter { tipVisible || !it.angle.equals("LONG_TIP", ignoreCase = true) }
            val grouped = valid.groupBy { it.angle.uppercase() }
            val handleRefs = grouped["LONG_HANDLE"].orEmpty()
            val tipRefs = grouped["LONG_TIP"].orEmpty()
            val sideRefs = grouped["LONG_SIDE"].orEmpty()
            if (anchors != null) {
                val leftBank = fingerprintBank(anchors.leftEnd)
                val rightBank = fingerprintBank(anchors.rightEnd)
                val leftHandle = scoreBatchPrepared(leftBank, handleRefs.map { it.path })
                val rightHandle = scoreBatchPrepared(rightBank, handleRefs.map { it.path })
                val leftTip = scoreBatchPrepared(leftBank, tipRefs.map { it.path })
                val rightTip = scoreBatchPrepared(rightBank, tipRefs.map { it.path })
                // Each SKU must use one internally consistent orientation. A
                // competitor's HANDLE may never choose this product's TIP.
                valid.groupBy { it.productId }.forEach { (productId, productRefs) ->
                    fun best(scores: Map<String, Int>): Int = productRefs.maxOfOrNull { scores[it.path] ?: 0 } ?: 0
                    // Physical endpoint truth is evaluated before SKU matching.
                    // When the physical role is confident, every product must use
                    // the same HANDLE endpoint; product references may not flip
                    // the rod orientation merely to obtain a higher score.
                    val left = anchors.physicalHandleOnLeft ?: RodAnchorRolePolicy.handleOnLeft(
                        best(leftHandle), best(rightHandle), best(leftTip), best(rightTip),
                        tipVisible, anchors.handleOnLeft
                    )
                    roles[productId] = left
                    productRefs.forEach { ref ->
                        when (ref.angle.uppercase()) {
                            "LONG_HANDLE" -> result[ref.path] = (if (left) leftHandle else rightHandle)[ref.path] ?: 0
                            "LONG_TIP" -> result[ref.path] = (if (left) rightTip else leftTip)[ref.path] ?: 0
                        }
                    }
                }
                if (sideRefs.isNotEmpty()) result.putAll(scoreBatchPrepared(fingerprintBank(anchors.side), sideRefs.map { it.path }))
            }
            val fullRefs = valid.filter { it.angle.uppercase() !in setOf("LONG_HANDLE", "LONG_SIDE", "LONG_TIP") }
            if (fullRefs.isNotEmpty()) result.putAll(scoreBatchLongCached(scan, fullRefs.map { it.path }))
            valid.forEach { if (!result.containsKey(it.path)) result[it.path] = 0 }
        } finally { anchors?.recycle() }
        return RodAnchorScores(
            scores = result,
            handleOnLeftByProduct = roles,
            physicalHandleOnLeft = anchors?.physicalHandleOnLeft,
            endpointLeftScore = anchors?.endpointLeftScore ?: 0,
            endpointRightScore = anchors?.endpointRightScore ?: 0,
            roleMargin = anchors?.roleMargin ?: 0,
            roleConfidence = anchors?.roleConfidence ?: 0,
            roleState = anchors?.roleState ?: RodEndpointRolePolicy.STATE_UNKNOWN
        )
    }

    /**
     * V8.4.12 cached long-object batch.
     *
     * Previous builds rotated + isolated the same scan four times for EVERY
     * reference image. That multiplied native bitmap work and was the dominant
     * scanner latency source. V8.4.9 extracts scan features once, recycles all
     * temporary bitmaps immediately, then scores every shortlisted rod reference
     * against those immutable descriptors.
     */
    private fun scoreBatchLongCached(scan: Bitmap, referencePaths: List<String>): Map<String, Int> {
        if (referencePaths.isEmpty()) return emptyMap()

        val scanBanks = ArrayList<FingerprintBank>(4)
        val scanFingerprints = ArrayList<Fingerprint>(4)
        val scanStripBanks = ArrayList<FingerprintBank>(4)

        for (angle in intArrayOf(0, 90, 180, 270)) {
            val rotated = if (angle == 0) scan else rotate(scan, angle.toFloat())
            val focused = RodFocusProcessor.isolate(rotated).bitmap
            try {
                val bank = fingerprintBank(focused)
                scanBanks += bank
                scanFingerprints += bank.full

                val strip = verticalStrip(focused)
                try {
                    scanStripBanks += fingerprintBank(strip)
                } finally {
                    if (!strip.isRecycled) strip.recycle()
                }
            } finally {
                if (!focused.isRecycled) focused.recycle()
                if (rotated !== scan && !rotated.isRecycled) rotated.recycle()
            }
        }

        val result = LinkedHashMap<String, Int>(referencePaths.size)
        referencePaths.distinct().forEach { path ->
            val file = File(path)
            if (!file.exists()) {
                result[path] = 0
                return@forEach
            }

            val cacheKey = "${file.absolutePath}:${file.lastModified()}:${file.length()}"
            val refBank = referenceCache[cacheKey]
                ?: loadReferenceBank(path)?.also { referenceCache[cacheKey] = it }
            if (refBank == null) {
                result[path] = 0
                return@forEach
            }

            val refStripBank = referenceStripCache[cacheKey]
                ?: loadReferenceStripBank(path)?.also { referenceStripCache[cacheKey] = it }

            val direct = scanBanks.maxOfOrNull { bestBankSimilarity(it, refBank, true) } ?: 0f
            val strip = if (refStripBank == null) 0f else
                (scanStripBanks.maxOfOrNull { bestBankSimilarity(it, refStripBank, false) } ?: 0f)

            val profile = scanFingerprints.maxOfOrNull { fp ->
                longProfileSimilarity(fp, refBank.full)
            } ?: 0f

            val projection = scanFingerprints.maxOfOrNull { fp ->
                projectionSimilarity(fp, refBank.full)
            } ?: 0f

            val aspect = scanFingerprints.maxOfOrNull { fp ->
                aspectSimilarity(fp.aspect, refBank.full.aspect)
            } ?: 0f

            val combined = maxOf(
                direct * 0.46f + profile * 100f * 0.24f + strip * 0.22f +
                    projection * 100f * 0.05f + aspect * 100f * 0.03f,
                direct * 0.62f + strip * 0.24f + profile * 100f * 0.10f +
                    projection * 100f * 0.04f
            )

            result[path] = combined.roundToInt().coerceIn(0, 100)
        }

        return result
    }

    private fun loadReferenceStripBank(path: String): FingerprintBank? {
        val bitmap = decodeReference(path) ?: return null
        return try {
            val strip = verticalStrip(bitmap)
            try {
                fingerprintBank(strip)
            } finally {
                if (!strip.isRecycled) strip.recycle()
            }
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    private fun longProfileSimilarity(scan: Fingerprint, reference: Fingerprint): Float {
        val axis = if (scan.aspect >= 1.35f) scan.projectionY else scan.projectionX
        val refAxis = if (reference.aspect >= 1.35f) reference.projectionY else reference.projectionX
        val projection = vectorSimilarity(axis, refAxis)
        val aspect = aspectSimilarity(scan.aspect, reference.aspect)
        val orientation = orientationBalance(scan)
        val refOrientation = orientationBalance(reference)
        val orientationSim = 1f - abs(orientation - refOrientation).coerceIn(0f, 1f)
        return (projection * 0.52f + aspect * 0.28f + orientationSim * 0.20f).coerceIn(0f, 1f)
    }

    /**
     * V8.4.12 cheap coarse pass used only to shortlist long-product references.
     * It deliberately does not change recognition acceptance thresholds. The
     * expensive rod-specific matcher still decides the final visual score.
     */
    fun scoreBatchCoarse(scan: Bitmap, referencePaths: List<String>): Map<String, Int> {
        if (referencePaths.isEmpty()) return emptyMap()
        val scanBank = fingerprintBank(scan)
        val result = LinkedHashMap<String, Int>()
        referencePaths.distinct().forEach { path ->
            val file = File(path)
            if (!file.exists()) {
                result[path] = 0
            } else {
                val cacheKey = "${file.absolutePath}:${file.lastModified()}:${file.length()}"
                val bank = referenceCache[cacheKey]
                    ?: loadReferenceBank(path)?.also { referenceCache[cacheKey] = it }
                result[path] = if (bank == null) 0 else
                    bestBankSimilarity(scanBank, bank, false).roundToInt().coerceIn(0, 100)
            }
        }
        return result
    }

    /** V8.1: elongated products such as rods are orientation-agnostic. */
    fun score(scan: Bitmap, referencePath: String, longObject: Boolean): Int {
        val file = File(referencePath)
        if (!file.exists()) return 0

        val cacheKey = "${file.absolutePath}:${file.lastModified()}:${file.length()}"
        val bank = referenceCache[cacheKey]
            ?: loadReferenceBank(referencePath)?.also { referenceCache[cacheKey] = it }
            ?: return 0

        fun direct(source: Bitmap): Float {
            val sb = fingerprintBank(source)
            return bestBankSimilarity(sb, bank, longObject)
        }

        var best = if (longObject) {
            val focused = RodFocusProcessor.isolate(scan).bitmap
            try {
                direct(focused)
            } finally {
                focused.recycle()
            }
        } else {
            direct(scan)
        }

        if (longObject) {
            for (angle in intArrayOf(90, 180, 270)) {
                val rotated = rotate(scan, angle.toFloat())
                val focused = RodFocusProcessor.isolate(rotated).bitmap
                val value = try {
                    direct(focused)
                } finally {
                    focused.recycle()
                    rotated.recycle()
                }
                best = maxOf(best, value)
            }
            // V8.4.3: long-object comparison uses the same rod-focus isolation
            // on the scan side that Master Studio used while creating refs.
            // This keeps floor/wall texture from dominating the rod identity.
            val reference = bank.full
            val focusedPrimary = RodFocusProcessor.isolate(scan).bitmap
            val scanFp = fingerprint(focusedPrimary)
            val projection = projectionSimilarity(scanFp, reference)
            val aspect = elongatedShapeBonus(focusedPrimary, reference) / 100f
            val longProfile = longObjectProfileSimilarity(focusedPrimary, reference)
            val strip = longStripSimilarity(focusedPrimary, referencePath)
            focusedPrimary.recycle()
            // V8.3: the long-object lane now emphasizes the product strip
            // (the rod itself) instead of letting the surrounding floor/background
            // dominate the fingerprint. Shape/projection remain supporting lanes.
            best = maxOf(
                best * 0.46f + longProfile * 0.24f + strip * 0.22f + projection * 100f * 0.05f + aspect * 100f * 0.03f,
                best * 0.62f + strip * 0.24f + longProfile * 0.10f + projection * 100f * 0.04f
            )
        }

        return best.roundToInt().coerceIn(0, 100)
    }

    private fun bestBankSimilarity(a: FingerprintBank, b: FingerprintBank, longObject: Boolean): Float {
        val candidates = listOf(
            compare(a.full, b.full),
            compare(a.center90, b.center90),
            compare(a.center82, b.center82),
            compare(a.center68, b.center68)
        )
        val best = candidates.maxOrNull() ?: 0f
        val sorted = candidates.sortedDescending()
        val agreement = if (sorted.size >= 2 && sorted[1] >= sorted[0] - 6f) 2.5f else 0f
        val stable = (best * 0.96f + agreement).coerceIn(0f, 100f)
        return if (longObject) stable else stable
    }

    private fun compare(a: Fingerprint, b: Fingerprint): Float = (
        structuralSimilarity(a.pixels, b.pixels) * 0.18f +
        histogramSimilarity(a.histogram, b.histogram) * 0.06f +
        hashSimilarity(a.hash, b.hash) * 0.08f +
        vectorSimilarity(a.shape, b.shape) * 0.31f +
        vectorSimilarity(a.gradient, b.gradient) * 0.25f +
        projectionSimilarity(a, b) * 0.12f
    ).coerceIn(0f, 1f) * 100f

    private fun fingerprintBank(source: Bitmap): FingerprintBank = FingerprintBank(
        full = fingerprint(source),
        center90 = fingerprintWindow(source, 0.90f),
        center82 = fingerprintWindow(source, 0.82f),
        center68 = fingerprintWindow(source, 0.68f)
    )

    private fun fingerprintWindow(source: Bitmap, fraction: Float): Fingerprint {
        val crop = centerCrop(source, fraction)
        return try {
            fingerprint(crop)
        } finally {
            if (crop !== source) crop.recycle()
        }
    }

    private fun centerCrop(source: Bitmap, fraction: Float): Bitmap {
        val f = fraction.coerceIn(0.55f, 1f)
        val w = (source.width * f).toInt().coerceAtLeast(24).coerceAtMost(source.width)
        val h = (source.height * f).toInt().coerceAtLeast(24).coerceAtMost(source.height)
        val left = (source.width - w) / 2
        val top = (source.height - h) / 2
        return Bitmap.createBitmap(source, left, top, w, h)
    }

    private fun loadReferenceBank(path: String): FingerprintBank? {
        val bitmap = decodeReference(path) ?: return null
        return try {
            fingerprintBank(bitmap)
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    private fun decodeReference(path: String): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        val maxDimension = BitmapSafety.MATCH_MAX_DIMENSION
        while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) {
            sample *= 2
        }
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeFile(path, options)
    }

    private fun fingerprint(source: Bitmap): Fingerprint {
        val scaled = Bitmap.createScaledBitmap(source, SIZE, SIZE, true)
        val pixels = FloatArray(SIZE * SIZE)
        val histogram = FloatArray(24)
        var index = 0
        var sum = 0f

        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val c = scaled.getPixel(x, y)
                val r = Color.red(c) / 255f
                val g = Color.green(c) / 255f
                val b = Color.blue(c) / 255f
                val gray = 0.299f * r + 0.587f * g + 0.114f * b
                pixels[index++] = gray
                sum += gray
                histogram[(r * 8).toInt().coerceIn(0, 7)] += 1f
                histogram[8 + (g * 8).toInt().coerceIn(0, 7)] += 1f
                histogram[16 + (b * 8).toInt().coerceIn(0, 7)] += 1f
            }
        }

        val mean = sum / pixels.size
        var variance = 0f
        for (i in pixels.indices) {
            pixels[i] -= mean
            variance += pixels[i] * pixels[i]
        }
        val std = sqrt((variance / pixels.size).toDouble()).toFloat().coerceAtLeast(0.0001f)
        for (i in pixels.indices) pixels[i] /= std

        val total = (SIZE * SIZE).toFloat()
        for (i in histogram.indices) histogram[i] /= total

        val shape = shapeDescriptor(scaled)
        val gradient = gradientDescriptor(scaled)
        val projections = edgeProjections(scaled)
        val hash = differenceHash(scaled)

        if (scaled !== source) scaled.recycle()

        val aspect = maxOf(source.width, source.height).toFloat() /
            minOf(source.width, source.height).coerceAtLeast(1)

        return Fingerprint(
            pixels, histogram, hash, shape, gradient,
            projections.first, projections.second, aspect
        )
    }

    private fun shapeDescriptor(bitmap: Bitmap): FloatArray {
        val result = FloatArray(GRID * GRID)
        for (gy in 0 until GRID) for (gx in 0 until GRID) {
            var total = 0f
            var count = 0
            val x0 = gx * SIZE / GRID
            val x1 = (gx + 1) * SIZE / GRID
            val y0 = gy * SIZE / GRID
            val y1 = (gy + 1) * SIZE / GRID
            for (y in y0 until y1) for (x in x0 until x1) {
                if (x <= 0 || y <= 0 || x >= SIZE - 1 || y >= SIZE - 1) continue
                val dx = gray(bitmap.getPixel(x + 1, y)) - gray(bitmap.getPixel(x - 1, y))
                val dy = gray(bitmap.getPixel(x, y + 1)) - gray(bitmap.getPixel(x, y - 1))
                val magnitude = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                val cx = (x - SIZE / 2f) / (SIZE / 2f)
                val cy = (y - SIZE / 2f) / (SIZE / 2f)
                val centerWeight = (1f - 0.50f * sqrt((cx * cx + cy * cy).toDouble()).toFloat()).coerceAtLeast(0.30f)
                total += magnitude * centerWeight
                count++
            }
            result[gy * GRID + gx] = if (count == 0) 0f else total / count
        }
        normalize(result)
        return result
    }

    private fun gradientDescriptor(bitmap: Bitmap): FloatArray {
        val bins = 8
        val result = FloatArray(GRID * GRID * bins)
        for (gy in 0 until GRID) for (gx in 0 until GRID) {
            val x0 = gx * SIZE / GRID
            val x1 = (gx + 1) * SIZE / GRID
            val y0 = gy * SIZE / GRID
            val y1 = (gy + 1) * SIZE / GRID
            for (y in maxOf(1, y0) until minOf(SIZE - 1, y1)) for (x in maxOf(1, x0) until minOf(SIZE - 1, x1)) {
                val dx = gray(bitmap.getPixel(x + 1, y)) - gray(bitmap.getPixel(x - 1, y))
                val dy = gray(bitmap.getPixel(x, y + 1)) - gray(bitmap.getPixel(x, y - 1))
                val magnitude = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                if (magnitude < 0.025f) continue
                var angle = atan2(dy.toDouble(), dx.toDouble())
                if (angle < 0) angle += Math.PI
                if (angle >= Math.PI) angle -= Math.PI
                val bin = ((angle / Math.PI) * bins).toInt().coerceIn(0, bins - 1)
                result[(gy * GRID + gx) * bins + bin] += magnitude
            }
        }
        normalize(result)
        return result
    }

    private fun edgeProjections(bitmap: Bitmap): Pair<FloatArray, FloatArray> {
        val x = FloatArray(PROJECTION_BINS)
        val y = FloatArray(PROJECTION_BINS)
        for (py in 1 until SIZE - 1) for (px in 1 until SIZE - 1) {
            val dx = gray(bitmap.getPixel(px + 1, py)) - gray(bitmap.getPixel(px - 1, py))
            val dy = gray(bitmap.getPixel(px, py + 1)) - gray(bitmap.getPixel(px, py - 1))
            val mag = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            val bx = (px * PROJECTION_BINS / SIZE).coerceIn(0, PROJECTION_BINS - 1)
            val by = (py * PROJECTION_BINS / SIZE).coerceIn(0, PROJECTION_BINS - 1)
            x[bx] += mag
            y[by] += mag
        }
        normalize(x)
        normalize(y)
        return x to y
    }

    private fun projectionSimilarity(a: Fingerprint, b: Fingerprint): Float {
        val direct = (vectorSimilarity(a.projectionX, b.projectionX) + vectorSimilarity(a.projectionY, b.projectionY)) / 2f
        val rotated = (vectorSimilarity(a.projectionX, b.projectionY) + vectorSimilarity(a.projectionY, b.projectionX)) / 2f
        return maxOf(direct, rotated).coerceIn(0f, 1f)
    }

    private fun normalize(values: FloatArray) {
        var sum = 0f
        for (v in values) sum += v * v
        val norm = sqrt(sum.toDouble()).toFloat().coerceAtLeast(0.0001f)
        for (i in values.indices) values[i] /= norm
    }

    private fun structuralSimilarity(a: FloatArray, b: FloatArray): Float {
        var mse = 0.0
        for (i in a.indices) {
            val d = (a[i] - b[i]).toDouble()
            mse += d * d
        }
        return (1.0 / (1.0 + (mse / a.size) / 4.0)).toFloat().coerceIn(0f, 1f)
    }

    private fun histogramSimilarity(a: FloatArray, b: FloatArray): Float {
        var distance = 0f
        for (i in a.indices) distance += abs(a[i] - b[i])
        return (1f - distance / 2f).coerceIn(0f, 1f)
    }

    private fun vectorSimilarity(a: FloatArray, b: FloatArray): Float {
        var dot = 0f
        var na = 0f
        var nb = 0f
        for (i in a.indices) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        if (na <= 0f || nb <= 0f) return 0f
        return (dot / (sqrt(na.toDouble()).toFloat() * sqrt(nb.toDouble()).toFloat())).coerceIn(0f, 1f)
    }

    private fun hashSimilarity(a: Long, b: Long): Float =
        1f - (java.lang.Long.bitCount(a xor b) / 64f)

    private fun differenceHash(bitmap: Bitmap): Long {
        val scaled = if (bitmap.width == HASH_WIDTH && bitmap.height == HASH_HEIGHT) bitmap
        else Bitmap.createScaledBitmap(bitmap, HASH_WIDTH, HASH_HEIGHT, true)
        var hash = 0L
        var bit = 0
        for (y in 0 until HASH_HEIGHT) for (x in 0 until HASH_WIDTH - 1) {
            if (gray(scaled.getPixel(x, y)) > gray(scaled.getPixel(x + 1, y))) hash = hash or (1L shl bit)
            bit++
        }
        if (scaled !== bitmap) scaled.recycle()
        return hash
    }

    private fun rotate(source: Bitmap, degrees: Float): Bitmap {
        val matrix = android.graphics.Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    /** V8.2: background-tolerant signature for rods and other elongated products.
     * It compares the distribution of strong edges along the dominant axis,
     * orientation balance and aspect ratio instead of relying on raw pixels.
     */
    private fun longObjectProfileSimilarity(scan: Bitmap, reference: Fingerprint): Float {
        val best = mutableListOf<Float>()
        val angles = floatArrayOf(0f, 90f, 180f, 270f)
        for (angle in angles) {
            val rotated = if (angle == 0f) scan else rotate(scan, angle)
            try {
                val fp = fingerprint(rotated)
                val axis = if (fp.aspect >= 1.35f) fp.projectionY else fp.projectionX
                val refAxis = if (reference.aspect >= 1.35f) reference.projectionY else reference.projectionX
                val projection = vectorSimilarity(axis, refAxis)
                val aspect = aspectSimilarity(fp.aspect, reference.aspect)
                val orientation = orientationBalance(fp)
                val refOrientation = orientationBalance(reference)
                val orientationSim = 1f - abs(orientation - refOrientation).coerceIn(0f, 1f)
                best += (projection * 0.52f + aspect * 0.28f + orientationSim * 0.20f).coerceIn(0f, 1f)
            } finally {
                if (rotated !== scan) rotated.recycle()
            }
        }
        return (best.maxOrNull() ?: 0f).coerceIn(0f, 1f) * 100f
    }


    /** V8.3: compare a narrow full-length product strip after normalizing
     * orientation. This reduces the influence of tile/background outside a rod. */
    private fun longStripSimilarity(scan: Bitmap, referencePath: String): Float {
        val ref = decodeReference(referencePath) ?: return 0f
        val scores = ArrayList<Float>()
        try {
            for (angle in floatArrayOf(0f, 90f, 180f, 270f)) {
                val scanRotated = if (angle == 0f) scan else rotate(scan, angle)
                val refRotated = if (angle == 0f) ref else rotate(ref, angle)
                try {
                    val scanStrip = verticalStrip(scanRotated)
                    val refStrip = verticalStrip(refRotated)
                    try {
                        val a = fingerprint(scanStrip)
                        val b = fingerprint(refStrip)
                        val structural = structuralSimilarity(a.pixels, b.pixels)
                        val shape = vectorSimilarity(a.shape, b.shape)
                        val gradient = vectorSimilarity(a.gradient, b.gradient)
                        val projection = projectionSimilarity(a, b)
                        scores += (structural * 0.24f + shape * 0.30f + gradient * 0.28f + projection * 0.18f).coerceIn(0f, 1f)
                    } finally {
                        scanStrip.recycle()
                        refStrip.recycle()
                    }
                } finally {
                    if (scanRotated !== scan) scanRotated.recycle()
                    if (refRotated !== ref) refRotated.recycle()
                }
            }
        } finally {
            ref.recycle()
        }
        return (scores.maxOrNull() ?: 0f) * 100f
    }

    private fun verticalStrip(source: Bitmap): Bitmap {
        val w = (source.width * 0.30f).toInt().coerceAtLeast(24).coerceAtMost(source.width)
        val h = (source.height * 0.94f).toInt().coerceAtLeast(24).coerceAtMost(source.height)
        val left = (source.width - w) / 2
        val top = (source.height - h) / 2
        return Bitmap.createBitmap(source, left, top, w, h)
    }

    private fun aspectSimilarity(a: Float, b: Float): Float {
        val aa = a.coerceAtLeast(1f)
        val bb = b.coerceAtLeast(1f)
        val delta = abs(kotlin.math.ln((aa / bb).coerceAtLeast(0.01f).toDouble())).toFloat()
        return (1f - delta / 1.6f).coerceIn(0f, 1f)
    }

    private fun orientationBalance(fp: Fingerprint): Float {
        val x = fp.projectionX.sum()
        val y = fp.projectionY.sum()
        val total = (x + y).coerceAtLeast(0.0001f)
        return abs(x - y) / total
    }

    private fun elongatedShapeBonus(scan: Bitmap, reference: Fingerprint): Float {
        val sr = maxOf(scan.width, scan.height).toFloat() / minOf(scan.width, scan.height).coerceAtLeast(1)
        val rr = reference.aspect.coerceAtLeast(1f)
        val delta = abs(kotlin.math.ln((sr / rr).coerceAtLeast(0.01f).toDouble())).toFloat()
        return (100f - delta * 28f).coerceIn(45f, 100f)
    }

    private fun gray(c: Int): Float =
        0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
}
