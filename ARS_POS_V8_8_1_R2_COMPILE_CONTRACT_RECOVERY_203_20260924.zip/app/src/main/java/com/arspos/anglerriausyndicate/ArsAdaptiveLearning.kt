package com.arspos.anglerriausyndicate

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import java.io.File
import java.io.FileOutputStream

/**
 * V8.7.0 operator-confirmed visual teaching.
 *
 * This module may add a bounded visual reference after the cashier explicitly
 * binds an unknown physical object to an existing product. It never changes
 * stock, cart quantity, recognition thresholds, or accepts the current scan.
 */
object ArsAdaptiveLearning {
    data class SavedReference(
        val path: String,
        val width: Int,
        val height: Int,
        val sourceBounds: Rect
    )

    fun saveConfirmedObjectCrop(
        context: Context,
        source: Bitmap,
        obj: VisualScanObject,
        productId: Long
    ): Result<SavedReference> = runCatching {
        require(productId > 0L) { "Product ID tidak valid" }
        require(!source.isRecycled) { "Bitmap sumber sudah dilepas" }
        require(source.width > 0 && source.height > 0) { "Bitmap sumber kosong" }

        val frameW = obj.frameWidth.takeIf { it > 0 } ?: source.width
        val frameH = obj.frameHeight.takeIf { it > 0 } ?: source.height
        val scaleX = source.width.toFloat() / frameW.toFloat()
        val scaleY = source.height.toFloat() / frameH.toFloat()

        val b = obj.normalizedBounds.takeIf { it.width() > 0 && it.height() > 0 } ?: obj.bounds
        val marginX = (b.width() * 0.04f).toInt().coerceAtLeast(2)
        val marginY = (b.height() * 0.04f).toInt().coerceAtLeast(2)
        val left = (((b.left - marginX) * scaleX).toInt()).coerceIn(0, source.width - 1)
        val top = (((b.top - marginY) * scaleY).toInt()).coerceIn(0, source.height - 1)
        val right = (((b.right + marginX) * scaleX).toInt()).coerceIn(left + 1, source.width)
        val bottom = (((b.bottom + marginY) * scaleY).toInt()).coerceIn(top + 1, source.height)
        val sourceRect = Rect(left, top, right, bottom)

        val crop = Bitmap.createBitmap(source, left, top, right - left, bottom - top)
        try {
            val dir = File(context.filesDir, "product_photos/learned/$productId").apply { mkdirs() }
            val file = File(dir, "learned_${System.currentTimeMillis()}_${obj.index}.jpg")
            FileOutputStream(file).use { out ->
                check(crop.compress(Bitmap.CompressFormat.JPEG, 92, out)) { "Gagal menyimpan referensi visual" }
            }
            SavedReference(file.absolutePath, crop.width, crop.height, sourceRect)
        } finally {
            if (!crop.isRecycled) crop.recycle()
        }
    }
}
