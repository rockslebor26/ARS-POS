package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale

/**
 * Phase 4.3.2.41 V8.4.21 cashier review surface.
 * Bounding boxes are interaction aids only; they never change engine decisions.
 */
@Composable
fun InteractiveScanPreview(
    bitmap: Bitmap,
    objects: List<VisualScanObject>,
    selectedObjectIndex: Int?,
    onObjectSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val ratio = (bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1).toFloat()).coerceAtLeast(0.1f)
    val frameWidth = objects.firstOrNull()?.frameWidth?.takeIf { it > 0 } ?: bitmap.width
    val frameHeight = objects.firstOrNull()?.frameHeight?.takeIf { it > 0 } ?: bitmap.height

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(ratio)
    ) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Foto barang pelanggan dengan kotak objek",
            modifier = Modifier.matchParentSize(),
            contentScale = ContentScale.Fit
        )

        Canvas(
            modifier = Modifier
                .matchParentSize()
                .pointerInput(objects, frameWidth, frameHeight) {
                    detectTapGestures { tap ->
                        val mapping = ScanPreviewMapping.fit(frameWidth, frameHeight, size.width.toFloat(), size.height.toFloat())
                        if (!mapping.contains(tap.x, tap.y)) return@detectTapGestures
                        val x = (tap.x - mapping.left) / mapping.scale
                        val y = (tap.y - mapping.top) / mapping.scale
                        val hit = objects
                            .filter { it.bounds.contains(x.toInt(), y.toInt()) }
                            .minByOrNull { it.bounds.width().toLong() * it.bounds.height().toLong() }
                        hit?.let { onObjectSelected(it.index) }
                    }
                }
        ) {
            val mapping = ScanPreviewMapping.fit(frameWidth, frameHeight, size.width, size.height)
            objects.forEach { item ->
                val selected = item.index == selectedObjectIndex
                val recognized = item.match != null
                val color = when {
                    selected -> Color(0xFFFFD166)
                    recognized -> Color(0xFF4DD599)
                    else -> Color(0xFFE57373)
                }
                val left = mapping.left + item.bounds.left * mapping.scale
                val top = mapping.top + item.bounds.top * mapping.scale
                val width = item.bounds.width().coerceAtLeast(1) * mapping.scale
                val height = item.bounds.height().coerceAtLeast(1) * mapping.scale
                drawRect(
                    color = color,
                    topLeft = Offset(left, top),
                    size = Size(width, height),
                    style = Stroke(width = if (selected) 6f else 3.5f)
                )
            }
        }
    }
}
