package com.arspos.anglerriausyndicate

import android.graphics.Point
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.4.1: fuses complementary LONG fragments (for example HANDLE and
 * SHAFT) only when they are supported by the same locked persistent LIVE object.
 *
 * The fusion is deliberately conservative: at least one fragment must already
 * be a TRUSTED_ROD, or the locked LIVE track must carry strong temporal rod
 * evidence. NON_ROD and cross-lane proposals can never be rescued by fusion.
 */
object PersistentPhysicalFragmentFusion {
    data class Result(
        val proposals: List<ScanProposal>,
        val fusionGroups: Int,
        val fragmentsMerged: Int
    )

    private data class Match(
        val proposal: ScanProposal,
        val track: LiveSceneTrack,
        val score: Float
    )

    fun fuse(
        proposals: List<ScanProposal>,
        snapshot: LiveSceneLockSnapshot?,
        frameWidth: Int,
        frameHeight: Int
    ): Result {
        if (!ArsV850Config.FEATURE_PERSISTENT_FRAGMENT_FUSION || snapshot == null) {
            return Result(proposals, 0, 0)
        }
        if (frameWidth <= 0 || frameHeight <= 0) return Result(proposals, 0, 0)

        val longCandidates = proposals.filter {
            it.proposalType == ScanProposal.TYPE_LONG &&
                !it.bridgeSuppressed &&
                it.hasResolvedAxis &&
                it.rodAuthenticityState != ScanProposal.AUTH_NON_ROD
        }
        if (longCandidates.size < 2) return Result(proposals, 0, 0)

        val liveLong = snapshot.tracks.filter {
            it.proposalType == ScanProposal.TYPE_LONG && it.state != LiveSceneTrack.STATE_OCCLUDED
        }
        if (liveLong.isEmpty()) return Result(proposals, 0, 0)

        val matches = longCandidates.mapNotNull { proposal ->
            liveLong.mapNotNull { track ->
                val angle = angleSimilarity(proposal.axisAngleDeg, track.axisAngleDeg)
                if (proposal.axisConfidence > 0 && track.axisConfidence > 0 && angle < 0.70f) return@mapNotNull null
                val iou = normalizedIou(
                    proposal.normalizedBounds, frameWidth, frameHeight,
                    track.bounds, snapshot.frameWidth, snapshot.frameHeight
                )
                val centre = normalizedCentreSimilarity(
                    proposal.normalizedBounds, frameWidth, frameHeight,
                    track.bounds, snapshot.frameWidth, snapshot.frameHeight
                )
                val containment = normalizedContainment(
                    proposal.normalizedBounds, frameWidth, frameHeight,
                    track.bounds, snapshot.frameWidth, snapshot.frameHeight
                )
                if (iou < 0.025f && containment < 0.20f && centre < 0.45f) return@mapNotNull null
                val temporalBonus = when (track.temporalPhysicalState) {
                    "TEMPORAL_TRUSTED_ROD" -> 0.10f
                    "TEMPORAL_ROD_CANDIDATE" -> 0.04f
                    else -> 0f
                }
                val score = (iou * 0.22f + containment * 0.25f + centre * 0.23f + angle * 0.20f + temporalBonus)
                    .coerceIn(0f, 1f)
                if (score < 0.34f) null else Match(proposal, track, score)
            }.maxByOrNull { it.score }
        }

        val groups = matches.groupBy { it.track.trackId }
        val consumed = HashSet<String>()
        val fused = ArrayList<ScanProposal>()
        var fusionGroups = 0
        var fragmentsMerged = 0

        groups.values.forEach { groupMatches ->
            val group = groupMatches.map { it.proposal }.distinctBy { it.proposalId }
            if (group.size < 2) return@forEach
            val track = groupMatches.maxByOrNull { it.score }!!.track
            if (!safeToFuse(group, track)) return@forEach

            val merged = mergeGroup(group, track.trackId)
            group.forEach { consumed += it.proposalId }
            fused += merged
            fusionGroups++
            fragmentsMerged += group.size - 1

            ArsFlightRecorder.event(
                "SCAN_PHYSICAL_FRAGMENT_FUSION",
                "Persistent LONG fragments fused before identity scoring",
                mapOf(
                    "persistentPhysicalId" to track.trackId,
                    "inputProposalIds" to group.joinToString(",") { it.proposalId },
                    "inputPhysicalObjectIds" to group.joinToString(",") { it.physicalObjectId },
                    "outputProposalId" to merged.proposalId,
                    "outputPhysicalObjectId" to merged.physicalObjectId,
                    "fragments" to group.size,
                    "trustedFragments" to group.count { it.trustedRod },
                    "maxAuthenticity" to group.maxOf { it.rodAuthenticityScore },
                    "temporalPhysicalState" to track.temporalPhysicalState,
                    "quantityEligible" to merged.quantityEligible
                )
            )
        }

        if (fused.isEmpty()) return Result(proposals, 0, 0)
        val output = proposals.filterNot { consumed.contains(it.proposalId) }.toMutableList()
        output += fused
        return Result(output, fusionGroups, fragmentsMerged)
    }

    private fun safeToFuse(group: List<ScanProposal>, track: LiveSceneTrack): Boolean {
        if (group.any { it.rodAuthenticityState == ScanProposal.AUTH_NON_ROD || it.bridgeSuppressed }) return false
        val hasTrusted = group.any { it.trustedRod && it.rodAuthenticityState == ScanProposal.AUTH_TRUSTED }
        val temporalTrusted = track.temporalPhysicalState == "TEMPORAL_TRUSTED_ROD" &&
            track.trustedPhysicalHits >= 2 && track.maxRodAuthenticityScore >= 80
        if (!hasTrusted && !temporalTrusted) return false
        if (group.maxOf { it.branchPenalty } > 24) return false
        for (i in group.indices) for (j in i + 1 until group.size) {
            if (angleSimilarity(group[i].axisAngleDeg, group[j].axisAngleDeg) < 0.82f) return false
        }
        return true
    }

    private fun mergeGroup(group: List<ScanProposal>, persistentId: String): ScanProposal {
        val primary = group.maxWithOrNull(
            compareBy<ScanProposal> { if (it.trustedRod) 1 else 0 }
                .thenBy { it.rodAuthenticityScore }
                .thenBy { it.foregroundBodyCoverage }
                .thenBy { it.axisConfidence }
        )!!
        val unionNormalized = union(group.map { it.normalizedBounds })
        val unionOriginal = union(group.map { it.originalBounds })
        val endpoints = group.flatMap {
            listOf(Point(it.axisStartX, it.axisStartY), Point(it.axisEndX, it.axisEndY))
        }
        val pair = farthestPair(endpoints)
        val axisAngle = if (pair != null) {
            Math.toDegrees(atan2((pair.second.y - pair.first.y).toDouble(), (pair.second.x - pair.first.x).toDouble())).toFloat()
        } else primary.axisAngleDeg
        val trusted = group.any { it.trustedRod && it.rodAuthenticityState == ScanProposal.AUTH_TRUSTED }
        val bestState = if (trusted) ScanProposal.AUTH_TRUSTED else ScanProposal.AUTH_UNCERTAIN
        val ids = group.map { it.proposalId }.sorted()

        return primary.copy(
            proposalId = "FUSED-${persistentId}-${ids.joinToString("+")}",
            source = ScanProposal.SOURCE_MERGED,
            originalBounds = unionOriginal,
            normalizedBounds = unionNormalized,
            lineageId = "PERSISTENT-LINEAGE-$persistentId",
            physicalInstanceHint = persistentId,
            physicalObjectId = "PHYS-$persistentId",
            quantityEligible = trusted,
            bridgeSuppressed = false,
            axisStartX = pair?.first?.x ?: primary.axisStartX,
            axisStartY = pair?.first?.y ?: primary.axisStartY,
            axisEndX = pair?.second?.x ?: primary.axisEndX,
            axisEndY = pair?.second?.y ?: primary.axisEndY,
            axisAngleDeg = axisAngle,
            axisConfidence = group.maxOf { it.axisConfidence },
            rodStructureScore = group.maxOf { it.rodStructureScore },
            rodPositiveEvidence = group.maxOf { it.rodPositiveEvidence },
            rodAuthenticityScore = group.maxOf { it.rodAuthenticityScore },
            rodAuthenticityState = bestState,
            trustedRod = trusted,
            foregroundSupported = group.any { it.foregroundSupported },
            foregroundCoverage = group.maxOf { it.foregroundCoverage },
            foregroundBodyCoverage = group.maxOf { it.foregroundBodyCoverage },
            foregroundReason = if (group.any { it.foregroundSupported }) "PERSISTENT_FRAGMENT_FUSION" else primary.foregroundReason,
            branchPenalty = group.minOf { it.branchPenalty },
            beamPenalty = group.minOf { it.beamPenalty },
            floorLinePenalty = group.minOf { it.floorLinePenalty },
            shadowPenalty = group.minOf { it.shadowPenalty },
            hypothesesMerged = group.sumOf { it.hypothesesMerged.coerceAtLeast(1) },
            physicalMergeReason = listOf(
                group.joinToString("|") { it.physicalMergeReason }.take(500),
                "PERSISTENT_FRAGMENT_FUSION:$persistentId"
            ).filter { it.isNotBlank() }.joinToString("+")
        )
    }

    private fun union(rects: List<Rect>): Rect {
        val out = Rect(rects.first())
        rects.drop(1).forEach { out.union(it) }
        return out
    }

    private fun farthestPair(points: List<Point>): Pair<Point, Point>? {
        if (points.size < 2) return null
        var best: Pair<Point, Point>? = null
        var bestD = -1.0
        for (i in points.indices) for (j in i + 1 until points.size) {
            val d = hypot((points[j].x - points[i].x).toDouble(), (points[j].y - points[i].y).toDouble())
            if (d > bestD) { bestD = d; best = points[i] to points[j] }
        }
        return best
    }

    private data class NRect(val l: Float, val t: Float, val r: Float, val b: Float)
    private fun norm(r: Rect, w: Int, h: Int): NRect? {
        if (w <= 0 || h <= 0) return null
        return NRect(r.left.toFloat()/w, r.top.toFloat()/h, r.right.toFloat()/w, r.bottom.toFloat()/h)
    }
    private fun normalizedIou(a: Rect, aw: Int, ah: Int, b: Rect, bw: Int, bh: Int): Float {
        val x=norm(a,aw,ah)?:return 0f; val y=norm(b,bw,bh)?:return 0f
        val l=max(x.l,y.l); val t=max(x.t,y.t); val r=min(x.r,y.r); val bot=min(x.b,y.b)
        if (r<=l || bot<=t) return 0f
        val inter=(r-l)*(bot-t)
        val aa=(x.r-x.l).coerceAtLeast(0f)*(x.b-x.t).coerceAtLeast(0f)
        val ab=(y.r-y.l).coerceAtLeast(0f)*(y.b-y.t).coerceAtLeast(0f)
        val u=aa+ab-inter
        return if(u<=0f)0f else inter/u
    }
    private fun normalizedContainment(a: Rect, aw: Int, ah: Int, b: Rect, bw: Int, bh: Int): Float {
        val x=norm(a,aw,ah)?:return 0f; val y=norm(b,bw,bh)?:return 0f
        val l=max(x.l,y.l); val t=max(x.t,y.t); val r=min(x.r,y.r); val bot=min(x.b,y.b)
        if(r<=l || bot<=t) return 0f
        val inter=(r-l)*(bot-t)
        val aa=((x.r-x.l)*(x.b-x.t)).coerceAtLeast(0.000001f)
        return (inter/aa).coerceIn(0f,1f)
    }
    private fun normalizedCentreSimilarity(a: Rect, aw: Int, ah: Int, b: Rect, bw: Int, bh: Int): Float {
        val x=norm(a,aw,ah)?:return 0f; val y=norm(b,bw,bh)?:return 0f
        val ax=(x.l+x.r)/2f; val ay=(x.t+x.b)/2f; val bx=(y.l+y.r)/2f; val by=(y.t+y.b)/2f
        return (1f-(hypot((ax-bx).toDouble(),(ay-by).toDouble())/0.60).toFloat()).coerceIn(0f,1f)
    }
    private fun angleSimilarity(a: Float, b: Float): Float {
        var d = abs(a-b) % 180f
        if (d > 90f) d = 180f-d
        return (1f-d/45f).coerceIn(0f,1f)
    }
}
