# Bound regression fixtures

Sumber: ARS_DIAGNOSTIC_V8_4_17_1789448849511.zip. Metadata internal engine V8.4.18; nama ZIP lama bukan label engine sebenarnya.

tracks.tsv mengikat setiap gambar JPEG scene asli pada sessionId, proposalId, physicalObjectId, SHA-256, axisStart/axisEnd dan label dukungan badan. 47 baris dari 18 scene. Label manual: 9 axis badan joran, 38 axis bukan badan joran. Semua 9 foto joran menampilkan bagian gagang/batang tanpa tip fisik yang terbukti terlihat. Ini data regresi pengembangan, bukan holdout independen atau metrik akurasi SKU.

axisConfidence berasal dari SCAN_TRACK_AUDIT. recordedStructureScore berasal dari SCAN_OBJECT/SCAN_PROPOSAL_SUPPRESSED yang terikat session + physicalObjectId. Nilai -1 berarti tidak tersedia; JUnit piksel tidak memakai nilai tersebut. Replay authenticity lokal mengecualikan -1 dan memakai 32 baris tersisa. Tidak ada skor struktur atau identitas produk yang diimputasi.

JPEG ini hanya masuk test resources, tidak dikemas ke APK produksi. Scene ...f532d4 dipakai kembali untuk regresi dua proposal NORMAL pada satu kemasan: ML-1 [319,147,566,527], ML-2 [318,371,483,655].
