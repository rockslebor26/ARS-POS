package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test

class TemporalIdentityHoldPolicyTest {
    @Test fun provenIdentitySurvivesTwoWeakFramesOnly() {
        assertTrue(TemporalIdentityHoldPolicy.shouldHold(true, true, 1, 0))
        assertTrue(TemporalIdentityHoldPolicy.shouldHold(true, true, 2, 0))
        assertFalse(TemporalIdentityHoldPolicy.shouldHold(true, true, 3, 0))
    }

    @Test fun holdCannotCreateOrTransferIdentity() {
        assertFalse(TemporalIdentityHoldPolicy.shouldHold(false, true, 1, 0))
        assertFalse(TemporalIdentityHoldPolicy.shouldHold(true, false, 1, 0))
        assertFalse(TemporalIdentityHoldPolicy.shouldHold(true, true, 1, 1))
    }
}
