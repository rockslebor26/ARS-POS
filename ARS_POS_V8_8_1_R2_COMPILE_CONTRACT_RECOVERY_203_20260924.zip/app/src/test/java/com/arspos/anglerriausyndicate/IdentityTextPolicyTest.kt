package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test

class IdentityTextPolicyTest {
    private val esseRaw = """
        PERINGATAN
        KARENA MEROKOK DAPAT MENYEBABKAN KANKER TENGGOROKAN
        LAYANAN BERHENTI MEROKOK 0-800-177-6565
        ESSE
        CHANGE
        DOUBLE
        MANGO BURST & APPLE CRUSH
        20 BATANG
    """.trimIndent()

    @Test fun regulatoryWarningsAreExcludedFromIdentityText() {
        val text = IdentityTextPolicy.identityBearingText(esseRaw)
        assertFalse(text.contains("PERINGATAN", ignoreCase = true))
        assertFalse(text.contains("MEROKOK", ignoreCase = true))
        assertFalse(text.contains("20 BATANG", ignoreCase = true))
        assertTrue(text.contains("ESSE"))
        assertTrue(text.contains("CHANGE"))
        assertTrue(text.contains("DOUBLE"))
        assertTrue(text.contains("MANGO BURST & APPLE CRUSH"))
    }

    @Test fun productDraftUsesIdentityBearingLinesNotHealthWarningAsBrand() {
        val draft = SmartProductInput.buildDraft(esseRaw)
        assertEquals("ESSE", draft.brand)
        assertEquals("ESSE CHANGE DOUBLE", draft.name)
        assertTrue(draft.variant.contains("MANGO BURST", ignoreCase = true))
        assertFalse(draft.identityText.contains("MEROKOK", ignoreCase = true))
    }
}
