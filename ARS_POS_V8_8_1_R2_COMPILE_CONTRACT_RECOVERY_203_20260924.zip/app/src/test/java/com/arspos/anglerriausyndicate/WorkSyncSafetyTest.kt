package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test

class WorkSyncSafetyTest {
    @Test fun portraitPreviewLetterboxHasCorrectCoordinates() {
        val m = ScanPreviewMapping.fit(768, 1024, 400f, 260f)
        assertEquals(102.5f, m.left, 0.01f)
        assertEquals(0f, m.top, 0.01f)
        assertFalse(m.contains(50f, 100f))
        assertTrue(m.contains(200f, 130f))
        assertEquals(384f, (200f - m.left) / m.scale, 0.01f)
    }
    @Test fun landscapePreviewLetterboxHasCorrectCoordinates() {
        val m = ScanPreviewMapping.fit(1024, 768, 200f, 300f)
        assertEquals(0f, m.left, 0.01f)
        assertEquals(75f, m.top, 0.01f)
        assertFalse(m.contains(100f, 50f))
        assertEquals(384f, (150f - m.top) / m.scale, 0.01f)
    }
    private fun commit(session: String = "S1", active: String = "S1", done: Boolean = false,
        requests: List<Pair<Long, Int>> = listOf(1L to 2), stock: Map<Long, Int> = mapOf(1L to 3),
        current: Map<Long, Int> = emptyMap()) = ScanCommitPolicy.rejection(session, active, done, requests, stock, current)

    @Test fun validReviewIsAllowed() { assertNull(commit()) }
    @Test fun duplicateTapIsRejected() { assertEquals("DUPLICATE_SESSION", commit(done = true)) }
    @Test fun staleSessionIsRejected() { assertEquals("STALE_SESSION", commit(active = "S2")) }
    @Test fun unknownProductIsRejected() { assertEquals("PRODUCT_NOT_ACCEPTED_IN_SCAN", commit(requests = listOf(2L to 1))) }
    @Test fun stockIncludesExistingCart() { assertEquals("STOCK_LIMIT_REVIEW_REQUIRED", commit(current = mapOf(1L to 2))) }
    @Test fun negativeQuantityIsRejected() { assertEquals("INVALID_QUANTITY", commit(requests = listOf(1L to -1))) }
    @Test fun duplicateDraftCannotDoubleQuantity() { assertEquals("DUPLICATE_PRODUCT", commit(requests = listOf(1L to 1, 1L to 1))) }
    @Test fun emptyReviewDoesNotConsumeSession() { assertEquals("EMPTY_REVIEW", commit(requests = emptyList())); assertNull(commit()) }
    @Test fun integerLimitDoesNotOverflow() { assertEquals("STOCK_LIMIT_REVIEW_REQUIRED", commit(requests = listOf(1L to Int.MAX_VALUE), current = mapOf(1L to 1))) }

    @Test fun floorCannotTriggerRescue() { assertEquals("NO_INDEPENDENT_ROD_EVIDENCE", ScanRescuePolicy.skipReason(true, false, 0, 0)) }
    @Test fun trustedRodBlocksRescue() { assertEquals("TRUSTED_ROD_TRACK_PRESENT", ScanRescuePolicy.skipReason(true, false, 1, 1)) }
    @Test fun twoRodsCannotBecomeOneFullFrameRescue() { assertEquals("MULTIPLE_PHYSICAL_RODS_NO_FULL_FRAME_RESCUE", ScanRescuePolicy.skipReason(true, false, 0, 2)) }
    @Test fun qualifiedUncertainRodPermitsEvidenceOnlyRescue() { assertNull(ScanRescuePolicy.skipReason(true, false, 0, 1)) }
    @Test fun rescueRequiresVerifiedMaster() { assertEquals("NO_VERIFIED_LONG_MASTER", ScanRescuePolicy.skipReason(false, false, 0, 1)) }

    @Test fun uniformFloorLineIsNotSegmentEvidence() {
        assertFalse(RodSegmentEvidence.measure(FloatArray(72) { 3f }, FloatArray(72)).supported)
    }
    @Test fun handleShaftTipMeasurementsAreSeparated() {
        val widths = FloatArray(72) { when { it < 14 -> 18f; it >= 57 -> 4f; else -> 8f } }
        val result = RodSegmentEvidence.measure(widths, FloatArray(72))
        assertTrue(result.supported)
        assertTrue(result.handleAtStart)
        assertEquals(0f, result.shaftVariation, 0.001f)
        val reverse = RodSegmentEvidence.measure(widths.reversedArray(), FloatArray(72))
        assertTrue(reverse.supported)
        assertFalse(reverse.handleAtStart)
    }
    @Test fun missingShaftCannotBecomeRodByEndpointWidths() {
        val widths = FloatArray(72) { if (it in 14..56) Float.NaN else 18f }
        assertFalse(RodSegmentEvidence.measure(widths, FloatArray(72)).supported)
    }
    @Test fun wanderingBranchCannotMasqueradeAsStableShaft() {
        val widths = FloatArray(72) { if (it < 14) 18f else 8f }
        assertFalse(RodSegmentEvidence.measure(widths, FloatArray(72) { it.toFloat() }).supported)
    }
}
