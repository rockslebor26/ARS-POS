package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test

class LiveIdentityPolicyTest {
    @Test fun ambiguousNormalVisualTriggersIdentityOcr() {
        assertTrue(LiveIdentityPolicy.shouldRunNormalIdentity(laneLong = false, visualScore = 76))
        assertEquals("AMBIGUOUS_VISUAL_REQUIRES_OCR", LiveIdentityPolicy.triggerReason(false, 76, 1))
    }

    @Test fun weakVisualDoesNotSpendLiveOcr() {
        assertFalse(LiveIdentityPolicy.shouldRunNormalIdentity(laneLong = false, visualScore = 60))
        assertEquals("VISUAL_BELOW_LIVE_IDENTITY_TRIGGER", LiveIdentityPolicy.triggerReason(false, 60, 0))
    }

    @Test fun longPreviewStillWaitsForFinalLongIdentity() {
        assertFalse(LiveIdentityPolicy.shouldRunNormalIdentity(laneLong = true, visualScore = 99))
        assertEquals("LONG_PREVIEW_FINAL_IDENTITY_REQUIRED", LiveIdentityPolicy.triggerReason(true, 99, 0))
    }
}
