package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test

class PhysicalPolicyTest {
    private fun box(l:Int,t:Int,r:Int,b:Int) = NormalPixelOwnership.Box(l,t,r,b)
    private fun scene(boxes: List<NormalPixelOwnership.Box>, pixel: (Int,Int)->Int) =
        NormalPixelOwnership.resolve(240,240,boxes,pixel)

    @Test fun twoSeparatedIdenticalProductsRemainTwo() {
        val result=scene(listOf(box(25,40,100,200),box(140,40,215,200))) { x,y ->
            if(y in 50..190 && (x in 35..90 || x in 150..205)) 0xff111111.toInt() else 0xffffffff.toInt()
        }
        assertEquals(2,result.groups.size);assertTrue(result.ambiguous.isEmpty())
    }
    @Test fun overlappingUnknownForegroundCannotCreateTwoAutomaticQuantities() {
        val result=scene(listOf(box(25,40,150,200),box(60,70,190,230))) { _,_ -> 0xffffffff.toInt() }
        assertEquals(setOf(0,1),result.ambiguous)
    }
    @Test fun broadContainerCannotBridgeTwoProducts() {
        val result=scene(listOf(box(25,40,100,200),box(140,40,215,200),box(25,40,215,200))) { x,y ->
            if(y in 50..190 && (x in 35..90 || x in 150..205)) 0xff111111.toInt() else 0xffffffff.toInt()
        }
        assertTrue(result.groups.size>=2);assertTrue(2 in result.ambiguous)
    }
    @Test fun partialRodIgnoresTipScoreWhenChoosingHandle() {
        assertTrue(RodAnchorRolePolicy.handleOnLeft(90,70,100,0,false,false))
        assertFalse(RodAnchorRolePolicy.handleOnLeft(70,90,0,100,false,true))
    }
    @Test fun roleAssignmentRemainsConsistentWithinEachProduct() {
        assertTrue(RodAnchorRolePolicy.handleOnLeft(90,30,10,85,true,false))
        assertFalse(RodAnchorRolePolicy.handleOnLeft(35,95,80,10,true,true))
    }
    @Test fun uniformBeamDoesNotBecomeRodEvenWithPerfectContinuity() {
        val result=RodMaterialProfile.measure(400,400,200f,40f,200f,360f) { x,_ ->
            if(x in 185..215) 0xff111111.toInt() else 0xffffffff.toInt()
        }
        assertFalse(result.supported)
    }
    @Test fun acceptedSkuStillRequiresPhysicalOwnerForQuantity() {
        assertFalse(ScanQuantityPolicy.eligible(true,true,true,false,"","NORMAL-1",ScanProposal.TYPE_NORMAL))
        assertFalse(ScanQuantityPolicy.eligible(true,true,true,false,"TRACK-1","TRACK-2",ScanProposal.TYPE_LONG))
        assertTrue(ScanQuantityPolicy.eligible(true,true,true,false,"NORMAL-1","NORMAL-1",ScanProposal.TYPE_NORMAL))
    }
    @Test fun rescueAndUncertainAndRejectedIdentityNeverCommitQuantity() {
        assertFalse(ScanQuantityPolicy.eligible(true,true,true,false,"TRACK-1","TRACK-1",ScanProposal.TYPE_RESCUE))
        assertFalse(ScanQuantityPolicy.eligible(true,true,false,false,"TRACK-1","TRACK-1",ScanProposal.TYPE_LONG))
        assertFalse(ScanQuantityPolicy.eligible(false,true,true,false,"TRACK-1","TRACK-1",ScanProposal.TYPE_LONG))
    }
    @Test fun packageBoundaryOwnedByNormalCannotBecomeIndependentLong() {
        val result = PackageEdgePolicy.evaluate(
            frameWidth = 768, frameHeight = 1024,
            trackBounds = PackageEdgePolicy.Box(161,341,608,413),
            axis = PackageEdgePolicy.Axis(197f,377f,572f,377f),
            measuredWidthPx = 26,
            owners = listOf(PackageEdgePolicy.NormalOwner(
                id = "NORMAL-1",
                proposalBounds = PackageEdgePolicy.Box(165,0,607,764),
                foregroundBounds = PackageEdgePolicy.Box(216,364,576,752),
                foregroundCoverage = 1f
            ))
        )
        assertEquals(PackageEdgePolicy.OWNERSHIP_NORMAL_BOUNDARY, result.ownership)
        assertTrue(result.rejectedAsPackageEdge)
    }

    @Test fun bidirectionalPhysicalRoleDoesNotForceAmbiguousEndpoint() {
        assertTrue(RodEndpointRolePolicy.decide(72,40).handleOnLeft == true)
        assertTrue(RodEndpointRolePolicy.decide(38,67).handleOnLeft == false)
        assertNull(RodEndpointRolePolicy.decide(58,53).handleOnLeft)
    }

    @Test fun largeOwnerlessNormalCannotOwnQuantity() {
        val result = NormalProposalPurityPolicy.evaluate(
            cropAreaRatio = 0.45f,
            foregroundComponent = 0,
            foregroundCoverage = 0f,
            ownerAreaRatio = 0f,
            ambiguousOverlap = false,
            mergedProposals = 1
        )
        assertFalse(result.safeForQuantity)
        assertEquals("NORMAL_NO_FOREGROUND_OWNER_LARGE_REGION", result.reason)
    }

    @Test fun compactVerifiedNormalRemainsQuantityEligible() {
        val result = NormalProposalPurityPolicy.evaluate(
            cropAreaRatio = 0.20f,
            foregroundComponent = 5,
            foregroundCoverage = 1f,
            ownerAreaRatio = 0.72f,
            ambiguousOverlap = false,
            mergedProposals = 1
        )
        assertTrue(result.safeForQuantity)
        assertEquals("NORMAL_PURITY_VERIFIED", result.reason)
    }

    @Test fun ambiguousNormalOverlapAlwaysRequiresReview() {
        val result = NormalProposalPurityPolicy.evaluate(
            cropAreaRatio = 0.10f,
            foregroundComponent = 2,
            foregroundCoverage = 0.9f,
            ownerAreaRatio = 0.8f,
            ambiguousOverlap = true,
            mergedProposals = 2
        )
        assertFalse(result.safeForQuantity)
        assertEquals("NORMAL_OVERLAP_REQUIRES_REVIEW", result.reason)
    }

}
