package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test

class LiveOcrReusePolicyTest {
    @Test fun identityOcrMayBeReusedInsideBoundedTtl() {
        assertTrue(LiveOcrReusePolicy.mayReuse(900, true, 78, 79))
        assertFalse(LiveOcrReusePolicy.mayReuse(1600, true, 78, 79))
    }

    @Test fun emptyOcrExpiresFastAndBetterFrameForcesRefresh() {
        assertTrue(LiveOcrReusePolicy.mayReuse(500, false, 75, 75))
        assertFalse(LiveOcrReusePolicy.mayReuse(700, false, 75, 75))
        assertFalse(LiveOcrReusePolicy.mayReuse(300, true, 75, 80))
    }
}
