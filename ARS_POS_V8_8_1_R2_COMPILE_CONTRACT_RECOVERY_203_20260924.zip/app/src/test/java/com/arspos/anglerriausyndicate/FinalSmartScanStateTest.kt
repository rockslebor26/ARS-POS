package com.arspos.anglerriausyndicate

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FinalSmartScanStateTest {
    @Test
    fun defaultsAreSafeAndIdle() {
        val state = FinalSmartScanState()
        assertEquals(FinalSmartScanState.STATUS_IDLE, state.status)
        assertTrue(state.sessionId.isBlank())
        assertTrue(state.objects.isEmpty())
        assertTrue(state.aiProposal.isBlank())
        assertTrue(state.aiProposalSource.isBlank())
        assertEquals(0L, state.durationMs)
        assertEquals(0L, state.completedAtMs)
    }

    @Test
    fun copyPreservesTypedScanContract() {
        val running = FinalSmartScanState(
            status = FinalSmartScanState.STATUS_RUNNING,
            sessionId = "smart-scan-test"
        )
        val completed = running.copy(
            status = FinalSmartScanState.STATUS_COMPLETE,
            message = "Final scan selesai.",
            completedAtMs = 123L,
            aiProposal = "bounded proposal",
            aiProposalSource = "LOCAL_FALLBACK"
        )
        assertEquals("smart-scan-test", completed.sessionId)
        assertEquals(FinalSmartScanState.STATUS_COMPLETE, completed.status)
        assertEquals("bounded proposal", completed.aiProposal)
        assertEquals("LOCAL_FALLBACK", completed.aiProposalSource)
    }
}
