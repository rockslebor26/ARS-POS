# ARS POS Phase 4.3.2.44 / V8.4.24 — Live Identity Fast Path + Type-Aware Persistent Binding + Temporal Consensus

Release target: **1.6.1 (161)**, in-place update from **1.6.0 (160)**.

## Purpose
V8.4.24 targets the main latency observed on V8.4.23: a physical object could already be visible/stable in live preview while useful product identity remained unavailable until the locked final scan. This phase moves low-cost identity work earlier, improves LONG-object temporal binding, removes avoidable OCR work, and adds end-to-end latency telemetry. Product-recognition thresholds are not lowered.

## Changes
- **Live Identity Fast Path** surfaces an advisory product `CANDIDATE` as soon as safe live evidence exists; `MATCHED` still requires repeated temporal agreement and remains non-transactional.
- **Faster live cadence** shortens live analysis delay and periodic refresh while keeping final cart mutation behind the locked production scan.
- **Type-Aware Persistent Binding** retains NORMAL rectangle continuity but gives LONG objects additional axis-angle/aspect/center evidence so rods can preserve a persistent physical ID through rotation and partial-box changes.
- **LONG axis-aware live tracking** uses physical axis orientation as part of same-object continuity rather than relying primarily on rectangle IoU.
- **Coarse LONG Live Visual Fast Path** uses the cached coarse fingerprint matcher during live preview; the expensive four-orientation rod matcher remains reserved for the locked production scan.
- **Adaptive OCR Fast Paths** use one-orientation OCR for advisory live NORMAL identity and 0/180 OCR for already-oriented LONG final identity. NORMAL final identity keeps the existing multi-orientation OCR path.
- **Temporary OCR bitmap recycling** explicitly recycles generated rotated bitmaps after OCR analysis to avoid unnecessary native-memory churn.
- **Latency telemetry** records live analysis duration, time to first candidate, time to first matched state, LONG axis-tracked objects, average crop OCR time and end-to-end object latency.
- **Ground-truth export integrity** now always materializes a valid `ground_truth.jsonl`, including the zero-annotation case, so replay/failure manifests never point to a missing file.

## Safety invariants
1. `applicationId` remains `com.arspos.anglerriausyndicate`.
2. Official signer fingerprint remains `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`.
3. `versionCode` increases **160 -> 161** and `versionName` becomes **1.6.1**.
4. Room database remains **v5**; no destructive migration.
5. All **14 product-recognition thresholds remain unchanged**.
6. Live `CANDIDATE` / `MATCHED` is advisory and cannot mutate cart quantity.
7. Final recognition still passes the existing purity, authenticity, package-edge, cross-lane, anchor, margin and identity gates.
8. Physical quantity remains based on resolved physical instances, not proposal count or live preview count.
9. Temporal binding cannot itself accept SKU identity or quantity.
10. UNKNOWN/REVIEW remains preferred to false SKU acceptance.

## Device acceptance focus
- **Live latency:** measure `firstCandidateMs`, `firstMatchedMs`, `analysisDurationMs`, final scan duration, crop OCR duration and end-to-end object duration over repeated runs.
- **Stable NORMAL product:** candidate should appear before scene lock when visual evidence is sufficient; final decision must remain identical to the locked production rules.
- **Rotating/moving rod:** `persistentPhysicalId` should survive moderate angle/bounding-box changes without cross-lane binding.
- **Two similar rods:** live candidate may appear early, but final acceptance must still honor visual margin, anchor truth and identity thresholds.
- **Crossing rods:** persistent IDs must not collapse; duplicate quantity prevention must remain effective.
- **NORMAL + rod overlap:** cross-category firewall must continue to reject non-independent NORMAL identity; faster paths must not bypass it.
- **Package/background lines:** type-aware binding must not promote container/package edges into trusted rods.
- **30+ scans:** no force close, ANR, native crash, low-memory kill, progressive native pressure, or unrecycled temporary crop/rotation growth.
- **Evidence export:** `ground_truth.jsonl`, `session.json`, `replay_manifest.json` and decision-bound crops/overlays must be present and internally consistent.

## Performance goals for this phase
These are validation targets, not claims before device testing:
- first physical box P50 < 350 ms;
- first useful live candidate P50 < 700 ms;
- first useful live candidate P95 < 1.5 s;
- cached/familiar final verification P50 < 500 ms where the temporal identity path has sufficient evidence;
- final verification P95 < 900 ms for normal single-object scenes;
- stable trusted LONG `persistentPhysicalId` survival >= 95% after temporal stabilization;
- zero cart quantity mutation from live-only identity;
- zero recognition-threshold relaxation.

## Deferred intentionally
- Full identity-result cache keyed by `persistentPhysicalId` is not allowed to bypass final production verification in this release; V8.4.24 first establishes faster live candidates and stronger physical continuity.
- Multi-ROI rod fingerprinting (handle/reel-seat/blank/logo) remains the next identity-quality phase after latency and persistent-ID behavior are proven on device.
- Shared scene OCR and automatic online/self-training are not introduced here. Human ground truth remains explicit diagnostic data only.
