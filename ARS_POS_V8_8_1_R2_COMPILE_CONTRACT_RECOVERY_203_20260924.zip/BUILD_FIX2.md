# ARS POS V8.4.19 / 1.5.5 (155) — BUILD FIX2

This package fixes the CI-only `:app:compileDebugUnitTestKotlin` failure caused by
`javax.imageio.ImageIO` being compiled inside the Android application test source set.

Changes are intentionally limited to build/test architecture:

- production files under `app/src/main` are unchanged;
- JPEG physical-truth replay moved to `:physicaltruth-jvm`;
- the JVM module compiles the exact production `NormalPixelOwnership.kt` and
  `RodMaterialProfile.kt` files from `app/src/main/java`;
- Android-compatible unit tests remain in `:app:testDebugUnitTest`;
- release package/version/signer policy remains 1.5.5 (155), V8.4.19, Phase 4.3.2.39.

Required CI gates:

1. `:physicaltruth-jvm:test`
2. `:app:testDebugUnitTest`
3. `:app:assembleRelease`
4. APK package/version/signature/alignment verification

Device scanner acceptance testing is still required after a successful signed build.
