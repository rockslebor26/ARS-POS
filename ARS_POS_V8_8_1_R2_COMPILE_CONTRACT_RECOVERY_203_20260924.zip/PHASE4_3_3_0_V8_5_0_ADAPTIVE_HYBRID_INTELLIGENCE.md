# ARS POS — Phase 4.3.3.0 / V8.5.0 Adaptive Hybrid Intelligence

Release target: 1.7.0 (170)
Baseline: 1.6.1 (161) / V8.4.24
Database: v5 unchanged
Update mode: official in-place update required
Recognition thresholds: unchanged

## Production-active foundations

- Persistent Physical Fragment Fusion: complementary LONG fragments may be fused before identity only when the same locked LIVE physical object supports them and rod safety evidence is adequate.
- ML-Guided Local Rod Recovery: ML-owned LONG regions receive a local physical-axis second chance when global scene geometry fails. Recovery itself never grants quantity.
- ARS Safety Kernel: cloud, learning and diagnostic intelligence cannot manufacture physical quantity or relax recognition thresholds.
- Decision Evidence Ledger: final identity/quantity decisions receive a structured immutable diagnostic event.
- Best Evidence Metadata: each LIVE-ID remembers the strongest visual/margin evidence observed during the live session.

## Shadow-only foundations

- Cloud Identity Assist: SHADOW.
- Controlled self-learning: SHADOW.
- ARS AI Engineer: DIAGNOSTIC_ONLY.

These modes may observe and evaluate evidence but cannot change cashier transaction identity or quantity in this initial V8.5 build.

## Safety invariants retained

- Package/applicationId remains com.arspos.anglerriausyndicate.
- Official release signer configuration remains unchanged.
- Room DB remains v5; no destructive migration.
- NORMAL purity, Package Edge Firewall, cross-lane gate, anti-bridge, rod authenticity, anchor role truth, replay V2 and physical quantity safety remain enabled.
- Full-frame rescue remains evidence-only unless existing production policy permits independent identity; it never creates LONG quantity from weak evidence.

## Field goals

1. One real rod split into handle/shaft fragments should resolve to one persistent physical instance before SKU scoring.
2. ML long proposals should receive a local ROI physical recovery attempt when scene-wide line detection misses the rod.
3. Two real rods must remain two physical instances; crossing must not exchange persistent IDs.
4. Background seams/package edges must remain non-sellable evidence.
5. No regression in NORMAL false-match safety or duplicate quantity prevention.
6. Live candidate/matched latency and memory/native pressure must remain measurable in evidence packages.
