# Phase 4.3.4.1 / V8.7.0 — Correct-Type Live Identity

## Field failure fixed
A compact NORMAL product with a tall box could be typed LONG by ML aspect ratio, correctly become NON_ROD after pixel authenticity, and then be suppressed before NORMAL database scoring.

## Changes
- ML-owned `NON_ROD` LONG hypotheses are cloned into `NORMAL_OBJECT` and must pass `NormalPhysicalResolver` + `NORMAL Object Purity`; pure LONG-analyzer lines are never rescued.
- Live ML tall detections are treated as provisional NORMAL observations; independent rod analyzer evidence remains the LONG authority.
- Live overlap de-dup prioritizes authenticated LONG evidence for real rods.
- Live cadence uses 180 ms loop delay / 500 ms stable refresh with explicit frame-acquire and analysis-gap telemetry.
- `catalog_snapshot.json` is added to evidence so diagnostics prove which products/references were available.
- Recognition thresholds, Safety Kernel, physical quantity truth, package/signing identity and Room DB version remain unchanged.

## Acceptance gate
For a verified NORMAL master under good capture conditions: first candidate target < 1.0 s and matched preview target ~1.5 s. No live result may mutate cart quantity. Final quantity still requires locked scan + identity acceptance + NORMAL purity/physical safety.
