# ARS POS 1.6.0 (160)

- Phase: **4.3.2.43**
- Engine: **V8.4.23 — Temporal Object Memory + Pre-Gate Persistent Binding + High-Resolution Identity**
- Package: `com.arspos.anglerriausyndicate`
- Database: **v5 unchanged**
- Update: **install in-place over 1.5.9 (159); do not uninstall**
- Signing: **ARS POS OFFICIAL RELEASE; signer must remain identical**
- Recognition thresholds: **unchanged**

This release makes live physical history part of the final scanner before identity scoring, adds safe ML-seeded LONG recovery that still requires pixel authenticity, and uses the locked high-resolution frame for LONG identity ROI scoring. It also fixes normal Compose cancellation telemetry and strengthens replay/session evidence integrity.

## Acceptance rule
Do not mark V8.4.23 finished until GitHub CI passes JVM evidence replay, Android unit tests, signed release compilation, package/version/signer/alignment verification, followed by device tests for temporal binding, multiple rods, false NORMAL, duplicate quantity, package edges, memory and evidence export.
