# ARS POS Phase 4.3.2.41 / V8.4.21 — Object Purity + Learning Evidence

Release target: **1.5.8 (158)**

## Scope

V8.4.21 is a safety-and-observability release built on V8.4.20 Scene-Aware Smart Scan. It does not lower any recognition threshold.

### 1. NORMAL Object Purity Gate

A NORMAL proposal no longer owns cashier quantity only because ML Kit returned one rectangle. The gate now evaluates:

- proposal area relative to the scene,
- foreground ownership component,
- foreground coverage,
- foreground-owner area relative to the proposal,
- ambiguous overlap,
- merged-proposal count.

Large ownerless/container-like NORMAL regions are marked `REVIEW_REQUIRED` and `quantityEligible=false`. OCR/visual evidence may still be recorded for diagnostics, but the region cannot create quantity.

### 2. Persistent Physical ID bridge

The live temporal track (`LIVE-*`) is correlated to final physical objects after the scene lock using normalized geometry. The mapping is diagnostic only and produces `SCAN_LIVE_FINAL_BIND` plus `PERSISTENT_PHYSICAL_BINDING` evidence.

### 3. Human Ground Truth Feedback

Cashier diagnostics can mark:

- `CORRECT`,
- `WRONG_SKU`,
- `REAL_OBJECT_UNRECOGNIZED`,
- `FALSE_OBJECT`,
- `MISSED_OBJECT`.

Annotations are stored in `ground_truth.jsonl` under the bound scan session and are included in diagnostic exports. Ground truth never edits product master, recognition decisions, cart, or stock.

### 4. Replay-ready evidence

Each final scan stores a lossless `replay/analysis_replay.png` plus `replay_manifest.json`. Failed/partial recognition additionally writes `failure_summary.json`. This enables the same scene to be evaluated against later engines without relying on a new photo.

### 5. Existing safety preserved

- Package Edge Firewall
- Bidirectional Anchor Role Truth
- Physical Quantity Safety
- Cashier Scan Review
- Rescue Gate V2
- duplicate-session cart commit guard
- package `com.arspos.anglerriausyndicate`
- Room database version 5
- official signer continuity

## Recognition thresholds

All 14 production thresholds are unchanged from V8.4.20/V8.4.20-A.

## Required device acceptance

1. Large mixed scene: Hercules + LIGHTS + rod must not become one quantity-owning NORMAL container.
2. Compact real NORMAL product must remain quantity-eligible when foreground ownership is credible.
3. Live `LIVE-*` track should map to the expected final `physicalObjectId` when the scene is locked without moving the camera.
4. Ground-truth buttons must write evidence without changing cart or product data.
5. Diagnostic ZIP must contain `ground_truth.jsonl` when annotated, `replay_manifest.json`, and lossless replay input.
6. Repeated live/final scans must remain crash/ANR/memory safe.
7. In-place update must preserve package, signer, database and local data.
