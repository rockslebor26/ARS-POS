# Phase 4.3.5.0 / V8.8.0 — Identity Intelligence

## Field failure that triggered this phase

A V8.7.0 field video showed one stable NORMAL retail package already present in the catalog remaining UNKNOWN for a long time even though live visual similarity stayed around 76–78% and the locked scan reached about 85% visual. The same session produced weak OCR dominated by generic/regulatory package text.

## Root causes fixed

1. **Low visual margin suppressed live OCR.** V8.7.0 only ran live identity when `visualMargin >= 6`, so ambiguous products could remain UNKNOWN indefinitely even though OCR was exactly the evidence needed to break the tie.
2. **Any OCR text was treated as identity-bearing OCR.** Generic warnings such as tobacco health warnings could force the text branch and block a verified visual master.
3. **Historical master OCR could be polluted by regulatory text.** The identity profile previously retained generic package text as aliases/raw profile evidence.
4. **Teaching was hard to discover and weak for HYBRID products.** The cashier had to scroll to the object detail, and an operator-confirmed learned image did not automatically enable the conservative HYBRID_VISUAL path for an already verified NORMAL master.

## V8.8.0 changes

- `LiveIdentityPolicy`: NORMAL visual score >= 72 now runs live identity regardless of low visual margin. A low margin is logged as `AMBIGUOUS_VISUAL_REQUIRES_OCR`; it is no longer a reason to skip OCR.
- `IdentityTextPolicy`: deterministic local filtering separates identity-bearing lines from regulatory/generic text. Raw OCR is still preserved for evidence.
- `SmartProductInput.Draft.identityText`: raw OCR and identity OCR are now separate.
- `SmartRecognitionEngine`: uses identity-bearing OCR, cleans historical profile raw text/aliases, and can fall through from weak OCR to the unchanged verified visual-only gate.
- `AJARKAN OBJEK ... KE ARS`: direct cashier CTA appears without opening diagnostic details.
- Operator-confirmed teaching on a verified NORMAL master may activate `HYBRID_VISUAL`; the existing visual score/margin thresholds are unchanged and Safety Kernel remains authoritative.
- Diagnostic telemetry now records `identityOcr`, ignored OCR line count, live OCR requested/present, ambiguous-OCR trigger count, and OCR gate reasons.
- The user-provided V8.7.0 failure frame is hash-bound as a regression fixture.

## Safety invariants retained

- Recognition thresholds are unchanged.
- Cloud Identity remains SHADOW/non-authoritative.
- AI cannot create quantity, change stock/payment, relax thresholds, change signer, or install an APK.
- Quantity still requires accepted identity plus final Physical Object Truth and Safety Kernel approval.
- Package, official signing channel, and Room database v5 remain unchanged.
