package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Phase 4.3.2.14: ARS visual identity matcher V5.
 *
 * V5 reduces background-driven false positives by combining:
 * - normalized grayscale structure
 * - color histogram
 * - difference hash
 * - center-weighted edge/gradient shape descriptor
 * - spatial gradient orientation descriptor
 *
 * It is still a deterministic offline descriptor, not a trained AI model.
 */
object ProductVisualMatcher {
    private const val SIZE = 32
    private const val HASH_WIDTH = 9
    private const val HASH_HEIGHT = 8
    private const val GRID = 4

    private data class Fingerprint(
        val pixels: FloatArray,
        val histogram: FloatArray,
        val hash: Long,
        val shape: FloatArray,
        val gradient: FloatArray
    )

    private val referenceCache = ConcurrentHashMap<String, Fingerprint>()

    fun score(scan: Bitmap, referencePath: String): Int {
        val file = File(referencePath)
        if (!file.exists()) return 0

        val cacheKey = "${file.absolutePath}:${file.lastModified()}:${file.length()}"
        val a = fingerprint(scan)
        val b = referenceCache[cacheKey]
            ?: decodeReference(referencePath)?.let(::fingerprint)?.also {
                referenceCache[cacheKey] = it
            }
            ?: return 0

        val structure = structuralSimilarity(a.pixels, b.pixels)
        val histogram = histogramSimilarity(a.histogram, b.histogram)
        val hash = hashSimilarity(a.hash, b.hash)
        val shape = vectorSimilarity(a.shape, b.shape)
        val gradient = vectorSimilarity(a.gradient, b.gradient)

        // Shape/gradient are deliberately stronger than raw RGB similarity so
        // the same shop table/background does not create a false product match.
        return (
            structure * 0.25f +
            histogram * 0.10f +
            hash * 0.10f +
            shape * 0.30f +
            gradient * 0.25f
        ).coerceIn(0f, 1f).times(100f).toInt()
    }

    private fun decodeReference(path: String): Bitmap? =
        BitmapFactory.decodeFile(path)

    private fun fingerprint(source: Bitmap): Fingerprint {
        val scaled = Bitmap.createScaledBitmap(source, SIZE, SIZE, true)
        val pixels = FloatArray(SIZE * SIZE)
        val histogram = FloatArray(24)
        var index = 0
        var sum = 0f

        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val c = scaled.getPixel(x, y)
                val r = Color.red(c) / 255f
                val g = Color.green(c) / 255f
                val b = Color.blue(c) / 255f
                val gray = 0.299f * r + 0.587f * g + 0.114f * b
                pixels[index++] = gray
                sum += gray

                histogram[(r * 8).toInt().coerceIn(0, 7)] += 1f
                histogram[8 + (g * 8).toInt().coerceIn(0, 7)] += 1f
                histogram[16 + (b * 8).toInt().coerceIn(0, 7)] += 1f
            }
        }

        val mean = sum / pixels.size
        var variance = 0f
        for (i in pixels.indices) {
            pixels[i] -= mean
            variance += pixels[i] * pixels[i]
        }
        val std = sqrt((variance / pixels.size).toDouble()).toFloat().coerceAtLeast(0.0001f)
        for (i in pixels.indices) pixels[i] /= std

        val histogramTotal = (SIZE * SIZE).toFloat()
        for (i in histogram.indices) histogram[i] /= histogramTotal

        val shape = shapeDescriptor(scaled)
        val gradient = gradientDescriptor(scaled)
        val hash = differenceHash(scaled)

        if (scaled !== source) scaled.recycle()

        return Fingerprint(pixels, histogram, hash, shape, gradient)
    }

    /** Center-weighted edge occupancy: robust to flat/background regions. */
    private fun shapeDescriptor(bitmap: Bitmap): FloatArray {
        val result = FloatArray(GRID * GRID)
        for (gy in 0 until GRID) {
            for (gx in 0 until GRID) {
                var total = 0f
                var count = 0
                val x0 = gx * SIZE / GRID
                val x1 = (gx + 1) * SIZE / GRID
                val y0 = gy * SIZE / GRID
                val y1 = (gy + 1) * SIZE / GRID

                for (y in y0 until y1) {
                    for (x in x0 until x1) {
                        if (x <= 0 || y <= 0 || x >= SIZE - 1 || y >= SIZE - 1) continue
                        val gxv = gray(bitmap.getPixel(x + 1, y)) - gray(bitmap.getPixel(x - 1, y))
                        val gyv = gray(bitmap.getPixel(x, y + 1)) - gray(bitmap.getPixel(x, y - 1))
                        val magnitude = sqrt((gxv * gxv + gyv * gyv).toDouble()).toFloat()
                        val centerX = (x - SIZE / 2f) / (SIZE / 2f)
                        val centerY = (y - SIZE / 2f) / (SIZE / 2f)
                        val centerWeight = (1f - 0.45f * sqrt((centerX * centerX + centerY * centerY).toDouble()).toFloat()).coerceAtLeast(0.35f)
                        total += magnitude * centerWeight
                        count++
                    }
                }
                result[gy * GRID + gx] = if (count == 0) 0f else total / count
            }
        }
        normalize(result)
        return result
    }

    /** Spatial gradient direction histogram, similar to a lightweight HOG. */
    private fun gradientDescriptor(bitmap: Bitmap): FloatArray {
        val bins = 8
        val result = FloatArray(GRID * GRID * bins)
        for (gy in 0 until GRID) {
            for (gx in 0 until GRID) {
                val x0 = gx * SIZE / GRID
                val x1 = (gx + 1) * SIZE / GRID
                val y0 = gy * SIZE / GRID
                val y1 = (gy + 1) * SIZE / GRID
                for (y in maxOf(1, y0) until minOf(SIZE - 1, y1)) {
                    for (x in maxOf(1, x0) until minOf(SIZE - 1, x1)) {
                        val dx = gray(bitmap.getPixel(x + 1, y)) - gray(bitmap.getPixel(x - 1, y))
                        val dy = gray(bitmap.getPixel(x, y + 1)) - gray(bitmap.getPixel(x, y - 1))
                        val magnitude = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                        if (magnitude < 0.025f) continue
                        var angle = atan2(dy.toDouble(), dx.toDouble())
                        if (angle < 0) angle += Math.PI
                        if (angle >= Math.PI) angle -= Math.PI
                        val bin = ((angle / Math.PI) * bins).toInt().coerceIn(0, bins - 1)
                        result[(gy * GRID + gx) * bins + bin] += magnitude
                    }
                }
            }
        }
        normalize(result)
        return result
    }

    private fun normalize(values: FloatArray) {
        var sum = 0f
        for (v in values) sum += v * v
        val norm = sqrt(sum.toDouble()).toFloat().coerceAtLeast(0.0001f)
        for (i in values.indices) values[i] /= norm
    }

    private fun structuralSimilarity(a: FloatArray, b: FloatArray): Float {
        var mse = 0.0
        for (i in a.indices) {
            val d = (a[i] - b[i]).toDouble()
            mse += d * d
        }
        return (1.0 / (1.0 + (mse / a.size) / 4.0)).toFloat().coerceIn(0f, 1f)
    }

    private fun histogramSimilarity(a: FloatArray, b: FloatArray): Float {
        var distance = 0f
        for (i in a.indices) distance += abs(a[i] - b[i])
        return (1f - distance / 2f).coerceIn(0f, 1f)
    }

    private fun vectorSimilarity(a: FloatArray, b: FloatArray): Float {
        var dot = 0f
        var na = 0f
        var nb = 0f
        for (i in a.indices) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        if (na <= 0f || nb <= 0f) return 0f
        return (dot / (sqrt(na.toDouble()).toFloat() * sqrt(nb.toDouble()).toFloat()))
            .coerceIn(0f, 1f)
    }

    private fun hashSimilarity(a: Long, b: Long): Float {
        val distance = java.lang.Long.bitCount(a xor b)
        return 1f - (distance / 64f)
    }

    private fun differenceHash(bitmap: Bitmap): Long {
        val scaled = if (bitmap.width == HASH_WIDTH && bitmap.height == HASH_HEIGHT) bitmap
        else Bitmap.createScaledBitmap(bitmap, HASH_WIDTH, HASH_HEIGHT, true)
        var hash = 0L
        var bit = 0
        for (y in 0 until HASH_HEIGHT) {
            for (x in 0 until HASH_WIDTH - 1) {
                if (gray(scaled.getPixel(x, y)) > gray(scaled.getPixel(x + 1, y))) {
                    hash = hash or (1L shl bit)
                }
                bit++
            }
        }
        if (scaled !== bitmap) scaled.recycle()
        return hash
    }

    private fun gray(c: Int): Float =
        0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
}
