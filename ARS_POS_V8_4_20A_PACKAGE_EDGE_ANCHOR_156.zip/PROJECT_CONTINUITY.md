# ARS POS Project Continuity

Current source candidate: **1.5.6 (156) / Phase 4.3.2.40 / V8.4.20-A**.

Direct predecessor: **1.5.5 (155) / Phase 4.3.2.39 / V8.4.19**. Database remains v5; package and official signer must remain unchanged. Recognition thresholds remain unchanged.

V8.4.20 implementation sequence: A Package Edge Firewall + Bidirectional Anchor Role; B Instance-Masked Track + Crossing Preservation; C Physical Quantity Truth V2 + Reciprocal NORMAL Ownership; D LONG Shortlist Safety + Rescue Gate V3.
