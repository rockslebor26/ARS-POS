#!/usr/bin/env python3
"""Static release invariants only. This is not Kotlin compilation/device QA."""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from kotlin_sanity import check_tree

EXPECTED_THRESHOLDS = {
    "ACCEPT_EXACT_BARCODE": 90, "ACCEPT_STRONG_IDENTITY": 82,
    "ACCEPT_IDENTITY_WITH_VISUAL": 68, "ACCEPT_CANONICAL_TEXT": 78,
    "ACCEPT_PROFILE_IDENTITY": 78, "ACCEPT_VISUAL_ONLY": 80,
    "ACCEPT_LONG_VISUAL_ONLY": 72, "MIN_VISUAL_SUPPORT": 34,
    "MIN_MARGIN": 10, "MIN_VISUAL_MARGIN": 15, "MIN_LONG_VISUAL_MARGIN": 14,
    "MIN_TEXT_GATE": 58, "MIN_LONG_ANCHOR_SCORE": 55, "MIN_LONG_ANCHOR_MARGIN": 8,
}

def validate(root):
    root = Path(root)
    pkg = root / "app/src/main/java/com/arspos/anglerriausyndicate"
    checks = []
    def check(ok, label):
        if not ok:
            raise ValueError(label)
        checks.append(label)
    gradle = (root / "app/build.gradle.kts").read_text()
    check('applicationId = "com.arspos.anglerriausyndicate"' in gradle, "package unchanged")
    check('versionCode = 156' in gradle and 'versionName = "1.5.6"' in gradle, "release 1.5.6/156")
    check('signingConfig = signingConfigs.getByName("arsOfficialRelease")' in gradle, "official signer configuration")
    check('getByName("debug")' not in gradle, "no debug release signer")
    database = (pkg / "data/db/ArsDatabase.kt").read_text()
    check(bool(re.search(r"version\s*=\s*5\b", database)), "Room DB remains v5")
    check("fallbackToDestructiveMigration" not in database, "no destructive migration")
    engine = (pkg / "data/SmartRecognitionEngine.kt").read_text()
    thresholds = {k:int(v) for k,v in re.findall(r"private const val (\w+) = (\d+)", engine)}
    check(thresholds == EXPECTED_THRESHOLDS, "all 14 recognition thresholds unchanged")
    for rule in ["REJECT_NORMAL_REQUIRES_IDENTITY", "REJECT_IDENTITY_MARGIN", "REJECT_ROD_ANCHOR_MARGIN",
                 "REJECT_BARCODE_MISMATCH", "REJECT_BARCODE_AMBIGUOUS"]:
        check(rule in engine, rule)
    recorder = (pkg / "ArsVisualEvidenceRecorder.kt").read_text()
    for literal in ['snapshotBitmap(scene, mutable = true)', 'PRE_IDENTITY_ANCHORS',
                    'GEOMETRIC_HYPOTHESIS_NOT_IDENTITY', 'evidenceFailures', 'check(flushPending(4_000L))']:
        check(literal in recorder, literal)
    scanner = (pkg / "SmartVisualScanner.kt").read_text()
    check('if (created === bitmap) bitmap.copy(Bitmap.Config.ARGB_8888, false)' in scanner, "owned full-frame crop")
    firewall = (pkg / "CrossCategorySceneFirewall.kt").read_text()
    check('it.rodAuthenticityState == ScanProposal.AUTH_TRUSTED' in firewall, "trusted-only ownership")
    resolver = (pkg / "RodPhysicalTrackResolver.kt").read_text()
    check('ANALYZER_TRACK_WITHOUT_ML_SUPPORT' not in resolver, "ML absence does not prune pixel evaluation")
    check('if (score <= 0) return 0' in resolver, "complete-link merge guard")
    vm = (pkg / "PosViewModel.kt").read_text()
    for literal in ['ScanCommitPolicy.rejection', 'reviewProducts.getValue', 'committedScanSessions.contains(session)']:
        check(literal in vm, literal)
    ui = (pkg / "MainActivity.kt").read_text()
    for literal in ['InteractiveScanPreview', 'TINJAU JUMLAH & TAMBAH', 'DETAIL DIAGNOSTIK', 'LAPORKAN HASIL SCAN BERGAMBAR', 'quantityCommitInProgress', 'SCAN_REVIEW_OPEN', 'SCAN_CART_COMMIT_OK']:
        check(literal in ui, literal)
    repository = (pkg / "data/ProductionRepository.kt").read_text()
    rescue = repository[repository.index('proposalId = "RESCUE-'):]
    check('quantityEligible = false' in rescue[:1600], "rescue cannot create quantity")
    for path in [root / "app/src/test/java/com/arspos/anglerriausyndicate/WorkSyncSafetyTest.kt",
                 root / "app/src/test/java/com/arspos/anglerriausyndicate/data/RecognitionSafetyTest.kt"]:
        check(path.is_file(), path.name)

    # ImageIO is a Java SE java.desktop API. Keep JPEG evidence replay out of the
    # Android app test source set and isolate it in the dedicated JVM module.
    settings = (root / "settings.gradle.kts").read_text()
    root_gradle = (root / "build.gradle.kts").read_text()
    jvm_gradle_path = root / "physicaltruth-jvm/build.gradle.kts"
    jvm_evidence_path = root / "physicaltruth-jvm/src/test/kotlin/com/arspos/anglerriausyndicate/RodMaterialEvidenceTest.kt"
    jvm_image_path = root / "physicaltruth-jvm/src/test/kotlin/com/arspos/anglerriausyndicate/PhysicalImageEvidenceTest.kt"
    android_tests = "\n".join(p.read_text() for p in (root / "app/src/test").rglob("*.kt"))
    check('include(":physicaltruth-jvm")' in settings, "physical truth JPEG replay isolated in JVM module")
    check('id("org.jetbrains.kotlin.jvm") version "2.0.21" apply false' in root_gradle, "JVM evidence plugin pinned to Kotlin 2.0.21")
    check(jvm_gradle_path.is_file() and jvm_evidence_path.is_file() and jvm_image_path.is_file(), "JVM evidence module files present")
    check("javax.imageio" not in android_tests and "ImageIO" not in android_tests, "no java.desktop ImageIO in Android test source set")
    jvm_evidence = jvm_evidence_path.read_text() + "\n" + jvm_image_path.read_text()
    check("javax.imageio.ImageIO" in jvm_evidence and "ImageIO.read" in jvm_evidence, "bound JPEG replay retains Java SE ImageIO")
    jvm_gradle = jvm_gradle_path.read_text()
    check("../app/src/main/java" in jvm_gradle and "RodMaterialProfile.kt" in jvm_gradle and "NormalPixelOwnership.kt" in jvm_gradle and "PackageEdgePolicy.kt" in jvm_gradle and "RodEndpointRolePolicy.kt" in jvm_gradle and "RodEndpointProfile.kt" in jvm_gradle, "JVM replay compiles exact production physical-truth policies")
    check('"V8.4.20-A"' in recorder and '"4.3.2.40"' in recorder, "evidence phase/engine 4.3.2.40/V8.4.20-A")
    check('ARS_DIAGNOSTIC_V8_4_20A_' in recorder and 'ARS_SCAN_REPORT_V8_4_20A_' in recorder, "export filenames match engine")
    check('"versionCode", 156' in recorder and '"version", "1.5.6"' in recorder, "export application version matches APK")
    check('tipVisible = proposal.rodTipVisible' in repository and 'proposal.anchorHandleOnLeft' in recorder, "anchor role availability bound to evidence")
    check('results.filter { it.canCommitQuantity }' in vm and '.distinctBy { it.physicalObjectId }' in ui, "physical quantity guard used by UI and backend")
    check('material.supported' in (pkg / "RodAuthenticityEvaluator.kt").read_text(), "pixel body required for trusted rod")
    check("it.segmentSupport && it.foregroundSupported && !it.bridgeSuppressed" in repository, "rescue needs independent pixel body evidence")
    package_edge = (pkg / "PackageEdgePolicy.kt").read_text()
    endpoint_role = (pkg / "RodEndpointRolePolicy.kt").read_text()
    endpoint_profile = (pkg / "RodEndpointProfile.kt").read_text()
    check("NORMAL_BOUNDARY_EDGE" in package_edge and "rejectedAsPackageEdge" in package_edge, "package edge ownership firewall present")
    check("ANCHOR_ROLE_PHYSICAL_CONFIDENT" in endpoint_role and "handleOnLeft" in endpoint_role, "bidirectional anchor role policy present")
    check("persistentCoverage" in endpoint_profile and "persistentWidth" in endpoint_profile, "persistent endpoint body profile present")
    check("applyPackageEdgeFirewall" in scanner and "SOURCE_NORMAL_EDGE" in scanner, "package edge firewall wired before cross-category scoring")
    check("endpointLeftScore" in repository and "anchorRoleState" in repository, "anchor-role truth recorded in scoring telemetry")
    fixtures = root / "app/src/test/resources/physical_truth"
    rows = (fixtures / "tracks.tsv").read_text().splitlines()[1:]
    check(len(rows) == 47, "47 bound material regression cases")
    for row in rows:
        parts = row.split("\t")
        if hashlib.sha256((fixtures / parts[3]).read_bytes()).hexdigest() != parts[4]:
            raise ValueError(f"Fixture SHA mismatch: {parts[0]}/{parts[2]}")
    check(True, "all fixture image hashes match bound telemetry")
    regression = fixtures / "v8419_false_trusted_package_scene.jpg"
    check(regression.is_file(), "V8.4.19 false trusted package regression image present")
    check(hashlib.sha256(regression.read_bytes()).hexdigest() == "65152d3296f0713e58f068d9925be52d87ddd4aa1f5b814fb29109e00b108c96", "package-edge regression image hash bound")
    endpoint_right = fixtures / "v8419_trusted_rod_handle_right.jpg"
    endpoint_left = fixtures / "v8419_crossing_rod_handle_left.jpg"
    check(hashlib.sha256(endpoint_right.read_bytes()).hexdigest() == "5f025fb2ab5e88a043eb8c74eac9d830052170e5d6df028ccf7eb9181ba79e11", "trusted-rod endpoint regression hash bound")
    check(hashlib.sha256(endpoint_left.read_bytes()).hexdigest() == "e309d8694b7a29cf0e98e379a5e9e348d27b372c20ae64ee091cfd8b7ab2ddae", "crossing-rod endpoint regression hash bound")
    kotlin_files = check_tree(root / "app/src") + check_tree(root / "physicaltruth-jvm/src")
    return {"static_invariants": "PASS", "checks": len(checks), "details": checks,
            "kotlin_files_lexically_checked": kotlin_files,
            "kotlin_compilation": "NOT_RUN_BY_THIS_SCRIPT", "device_tests": "NOT_RUN_BY_THIS_SCRIPT"}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    try:
        print(json.dumps(validate(args.root), indent=2))
    except (ValueError, OSError) as exc:
        sys.exit(f"SOURCE VALIDATION FAILED: {exc}")
