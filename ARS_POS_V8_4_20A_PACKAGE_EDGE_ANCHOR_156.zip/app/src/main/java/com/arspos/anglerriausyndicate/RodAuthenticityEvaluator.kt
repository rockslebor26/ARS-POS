package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Phase 4.3.2.40 V8.4.20-A — intersection-aware continuity rod-authenticity gate.
 *
 * This evaluator does not recognize a SKU. It answers a narrower question:
 * "does the resolved LONG physical object have enough rod-like structure to be
 * trusted as a rod?"  A branch, beam, grout line or shadow may be long and may
 * score visually like a rod, but it must not become a TRUSTED_ROD track merely
 * because a line detector found a strong axis.
 *
 * Conservative policy:
 * - NON_ROD: removed from recognition/quantity.
 * - ROD_UNCERTAIN: may be identity-scored for diagnostics, but cannot create
 *   cashier quantity and cannot own NORMAL regions.
 * - TRUSTED_ROD: eligible for normal LONG identity/quantity rules.
 */
object RodAuthenticityEvaluator {
    private const val MAJOR_SAMPLES = 72
    private const val MINOR_SAMPLES = 31
    private const val ACTIVE_DELTA = 0.080f

    data class Evidence(
        val measuredWidthMedianPx: Int,
        val measuredWidthP10Px: Int,
        val measuredWidthP90Px: Int,
        val widthVariance: Float,
        val taperRatio: Float,
        val curvatureScore: Int,
        val positiveEvidence: Int,
        val branchPenalty: Int,
        val beamPenalty: Int,
        val floorLinePenalty: Int,
        val shadowPenalty: Int,
        val authenticityScore: Int,
        val state: String,
        val continuity: Float,
        val multipleClusterRatio: Float,
        val crossThroughIntersections: Int,
        val trueBranchIntersections: Int,
        val segmentSupport: Boolean = false,
        val shaftVariation: Float = 0f,
        val shaftContinuity: Float = 0f,
        val material: RodMaterialProfile.Result = RodMaterialProfile.Result()
    )

    fun evaluate(bitmap: Bitmap, proposal: ScanProposal): Evidence {
        if (!proposal.hasResolvedAxis || proposal.proposalType != ScanProposal.TYPE_LONG) {
            return emptyEvidence()
        }

        val sx = proposal.axisStartX.toFloat()
        val sy = proposal.axisStartY.toFloat()
        val ex = proposal.axisEndX.toFloat()
        val ey = proposal.axisEndY.toFloat()
        val vx = ex - sx
        val vy = ey - sy
        val length = hypot(vx, vy)
        if (length < 48f) return emptyEvidence()

        val material = RodMaterialProfile.measure(bitmap.width, bitmap.height, sx, sy, ex, ey) { x, y -> bitmap.getPixel(x, y) }

        val ux = vx / length
        val uy = vy / length
        val nx = -uy
        val ny = ux
        val halfCorridor = min(
            72f,
            max(16f, proposal.axisWidthPx.coerceAtLeast(24) * 0.62f)
        )

        val widths = ArrayList<Float>(MAJOR_SAMPLES)
        val centerOffsets = ArrayList<Float>(MAJOR_SAMPLES)
        val contrastStrength = ArrayList<Float>(MAJOR_SAMPLES)
        var activeStations = 0
        var multiClusterStations = 0
        val multiClusterByStation = BooleanArray(MAJOR_SAMPLES)
        // Preserve station-indexed center/width evidence so a crossing can be
        // distinguished from a real branch by continuity before/after it.
        val stationCenters = FloatArray(MAJOR_SAMPLES) { Float.NaN }
        val stationWidths = FloatArray(MAJOR_SAMPLES) { Float.NaN }

        for (m in 0 until MAJOR_SAMPLES) {
            val t = m.toFloat() / (MAJOR_SAMPLES - 1).toFloat()
            val cx = sx + vx * t
            val cy = sy + vy * t
            // Clamping an off-frame station fabricates repeated border pixels.
            if (cx < 0f || cy < 0f || cx >= bitmap.width || cy >= bitmap.height) continue
            val samples = FloatArray(MINOR_SAMPLES)
            for (s in 0 until MINOR_SAMPLES) {
                val u = s.toFloat() / (MINOR_SAMPLES - 1).toFloat()
                val offset = (u - 0.5f) * 2f * halfCorridor
                samples[s] = sampleLuminance(bitmap, cx + nx * offset, cy + ny * offset)
            }

            val edgeCount = max(2, MINOR_SAMPLES / 7)
            var background = 0f
            var backgroundN = 0
            for (s in 0 until edgeCount) {
                background += samples[s]
                background += samples[MINOR_SAMPLES - 1 - s]
                backgroundN += 2
            }
            background /= backgroundN.coerceAtLeast(1)

            val active = BooleanArray(MINOR_SAMPLES)
            var stationContrast = 0f
            for (s in samples.indices) {
                val delta = abs(samples[s] - background)
                active[s] = delta >= ACTIVE_DELTA
                if (active[s]) stationContrast += delta
            }

            val runs = activeRuns(active)
            if (runs.isEmpty()) continue
            activeStations++
            if (runs.size >= 2) {
                val meaningful = runs.count { it.second - it.first + 1 >= 2 }
                if (meaningful >= 2) {
                    multiClusterStations++
                    multiClusterByStation[m] = true
                }
            }

            // Follow axis-near support first. The widest run may be floor,
            // packaging or the OTHER rod at a crossing.
            val centerIndex = (MINOR_SAMPLES - 1) * 0.5f
            val best = runs.minWithOrNull(
                compareBy<Pair<Int, Int>> { abs((it.first + it.second) * 0.5f - centerIndex) }
                    .thenByDescending { it.second - it.first + 1 }
            ) ?: continue

            val runSamples = (best.second - best.first + 1).coerceAtLeast(1)
            val physicalWidth = runSamples.toFloat() / (MINOR_SAMPLES - 1).toFloat() * (halfCorridor * 2f)
            widths += physicalWidth
            stationWidths[m] = physicalWidth
            val runCenter = (best.first + best.second) * 0.5f
            val normalizedCenter = (runCenter / (MINOR_SAMPLES - 1).toFloat() - 0.5f) * 2f
            val physicalCenterOffset = normalizedCenter * halfCorridor
            centerOffsets += physicalCenterOffset
            stationCenters[m] = physicalCenterOffset
            contrastStrength += stationContrast / runSamples.toFloat()
        }

        val continuity = if (material.supported) material.coverage else activeStations.toFloat() / MAJOR_SAMPLES.toFloat()
        if (widths.size < 8) {
            return Evidence(
                measuredWidthMedianPx = 0,
                measuredWidthP10Px = 0,
                measuredWidthP90Px = 0,
                widthVariance = 1f,
                taperRatio = 0f,
                curvatureScore = 100,
                positiveEvidence = 0,
                branchPenalty = 20,
                beamPenalty = 0,
                floorLinePenalty = 20,
                shadowPenalty = 10,
                authenticityScore = 0,
                state = ScanProposal.AUTH_NON_ROD,
                continuity = continuity,
                multipleClusterRatio = 0f,
                crossThroughIntersections = 0,
                trueBranchIntersections = 0
            )
        }

        val sortedWidths = widths.sorted()
        val p10 = if (material.supported) material.p15 else percentile(sortedWidths, 0.10f)
        val median = if (material.supported) material.medianWidth else percentile(sortedWidths, 0.50f)
        val p90 = if (material.supported) material.p85 else percentile(sortedWidths, 0.90f)
        val mean = widths.average().toFloat().coerceAtLeast(0.5f)
        val variance = widths.map { (it - mean) * (it - mean) }.average().toFloat()
        val coefficientOfVariation = (sqrt(variance) / mean).coerceIn(0f, 2f)
        val segments = RodSegmentEvidence.measure(stationWidths, stationCenters)
        val structuralVariation = when {
            material.supported -> material.localVariation
            segments.supported -> segments.shaftVariation
            else -> coefficientOfVariation
        }

        val endWindow = max(5, widths.size / 5)
        val firstMedian = percentile(widths.take(endWindow).sorted(), 0.50f).coerceAtLeast(1f)
        val lastMedian = percentile(widths.takeLast(endWindow).sorted(), 0.50f).coerceAtLeast(1f)
        val taperRatio = if (material.supported) material.widthRatio.coerceIn(1f, 8f) else
            (max(firstMedian, lastMedian) / min(firstMedian, lastMedian)).coerceIn(1f, 8f)

        val centerRange = if (centerOffsets.isEmpty()) 0f else
            ((centerOffsets.maxOrNull() ?: 0f) - (centerOffsets.minOrNull() ?: 0f)).coerceAtLeast(0f)
        var abruptChanges = 0
        for (i in 1 until centerOffsets.size) {
            if (abs(centerOffsets[i] - centerOffsets[i - 1]) > max(5f, median * 0.55f)) abruptChanges++
        }
        val curvature = if (material.supported) (material.centerResidual / max(8f, median * .4f) * 35f).roundToInt().coerceIn(0, 100) else (
            (centerRange / max(12f, halfCorridor) * 65f) +
                (abruptChanges.toFloat() / max(1, centerOffsets.size - 1).toFloat() * 70f)
            ).roundToInt().coerceIn(0, 100)

        val multiClusterRatio = multiClusterStations.toFloat() / activeStations.coerceAtLeast(1).toFloat()
        // Short, isolated multi-cluster runs are normally grout/background
        // lines crossing through the shaft. Sustained runs are much more
        // consistent with a true attached branch or a non-rod structure.
        var crossThroughIntersections = 0
        var trueBranchIntersections = 0
        var runStart = -1
        for (i in 0..multiClusterByStation.size) {
            val active = i < multiClusterByStation.size && multiClusterByStation[i]
            if (active && runStart < 0) runStart = i
            if (!active && runStart >= 0) {
                val runEnd = i - 1
                val runLength = i - runStart
                val continuityAcross = crossingContinuity(
                    stationCenters = stationCenters,
                    stationWidths = stationWidths,
                    runStart = runStart,
                    runEnd = runEnd,
                    medianWidth = median,
                    halfCorridor = halfCorridor
                )
                // A crossing may occupy several sampling stations when another
                // product lies over a rod. If the dominant shaft center/width
                // recovers on both sides, classify it as CROSS_THROUGH instead
                // of penalising the rod as a branch. Recognition thresholds are
                // unchanged; only the physical evidence interpretation improves.
                if (runLength <= 3 || (runLength <= 9 && continuityAcross)) {
                    crossThroughIntersections++
                } else {
                    trueBranchIntersections++
                }
                runStart = -1
            }
        }
        val frameShort = min(bitmap.width, bitmap.height).coerceAtLeast(1).toFloat()
        val medianRatio = (if (material.supported) p10 else median) / frameShort
        val meanContrast = contrastStrength.average().toFloat()

        var positive = 0f
        positive += (continuity / 0.78f).coerceIn(0f, 1f) * 28f
        positive += (proposal.axisConfidence / 75f).coerceIn(0f, 1f) * 14f
        positive += (proposal.rodStructureScore / 90f).coerceIn(0f, 1f) * 18f
        positive += when {
            medianRatio in 0.004f..0.045f -> 16f
            medianRatio in 0.002f..0.065f -> 9f
            else -> 2f
        }
        positive += when {
            structuralVariation in 0.10f..0.48f -> 12f
            structuralVariation < 0.62f -> 7f
            else -> 1f
        }
        positive += when {
            taperRatio in 1.10f..3.80f -> 12f
            taperRatio < 5.0f -> 6f
            else -> 0f
        }

        var branchPenalty = 0
        if (structuralVariation > 0.58f) branchPenalty += 12
        if (structuralVariation > 0.82f) branchPenalty += 10
        if (curvature >= 42) branchPenalty += 10
        if (curvature >= 65) branchPenalty += 10
        // Multiple contrast runs from a reel seat, grip or neighbouring grout
        // are diagnostic geometry. Penalise them only when the independent
        // foreground profile has not established longitudinal body ownership.
        if (!material.supported && trueBranchIntersections >= 1) branchPenalty += 10
        if (!material.supported && (trueBranchIntersections >= 2 || (multiClusterRatio >= 0.35f && trueBranchIntersections > 0))) branchPenalty += 8
        // CROSS_THROUGH is recorded but intentionally receives no branch
        // penalty; width/beam/floor/shadow gates still protect false rods.
        branchPenalty = branchPenalty.coerceAtMost(40)

        var beamPenalty = 0
        if (medianRatio > 0.055f && coefficientOfVariation < 0.38f) beamPenalty += 14
        if (medianRatio > 0.080f) beamPenalty += 14
        if (medianRatio > 0.10f) beamPenalty += 8
        beamPenalty = beamPenalty.coerceAtMost(32)

        var floorPenalty = 0
        if (median <= 3.5f && continuity >= 0.62f) floorPenalty += 14
        if (p90 <= 5.0f && taperRatio < 1.18f) floorPenalty += 10
        if (proposal.rodStructureScore < 48) floorPenalty += 6
        floorPenalty = floorPenalty.coerceAtMost(28)

        var shadowPenalty = 0
        if (meanContrast < 0.095f) shadowPenalty += 9
        if (meanContrast < 0.070f) shadowPenalty += 8
        if (medianRatio > 0.05f && meanContrast < 0.10f) shadowPenalty += 6
        shadowPenalty = shadowPenalty.coerceAtMost(22)

        val score = (
            positive - branchPenalty - beamPenalty - floorPenalty - shadowPenalty
            ).roundToInt().coerceIn(0, 100)

        val state = when {
            !material.supported && material.bodyCoverage < .10f -> ScanProposal.AUTH_NON_ROD
            branchPenalty >= 30 || beamPenalty >= 26 || floorPenalty >= 22 -> ScanProposal.AUTH_NON_ROD
            material.supported && score >= 62 &&
                proposal.rodStructureScore >= 56 &&
                proposal.axisConfidence >= 34 &&
                continuity >= 0.44f &&
                branchPenalty < 28 &&
                beamPenalty < 24 -> ScanProposal.AUTH_TRUSTED
            score < 34 || continuity < 0.25f -> ScanProposal.AUTH_NON_ROD
            else -> ScanProposal.AUTH_UNCERTAIN
        }

        return Evidence(
            measuredWidthMedianPx = median.roundToInt(),
            measuredWidthP10Px = p10.roundToInt(),
            measuredWidthP90Px = p90.roundToInt(),
            widthVariance = coefficientOfVariation,
            taperRatio = taperRatio,
            curvatureScore = curvature,
            positiveEvidence = positive.roundToInt().coerceIn(0, 100),
            branchPenalty = branchPenalty,
            beamPenalty = beamPenalty,
            floorLinePenalty = floorPenalty,
            shadowPenalty = shadowPenalty,
            authenticityScore = score,
            state = state,
            continuity = continuity,
            multipleClusterRatio = multiClusterRatio,
            crossThroughIntersections = crossThroughIntersections,
            trueBranchIntersections = trueBranchIntersections,
            segmentSupport = segments.supported,
            shaftVariation = segments.shaftVariation,
            shaftContinuity = segments.shaftContinuity,
            material = material
        )
    }

    fun apply(bitmap: Bitmap, proposal: ScanProposal): ScanProposal {
        if (proposal.proposalType != ScanProposal.TYPE_LONG || proposal.bridgeSuppressed) return proposal
        val evidence = evaluate(bitmap, proposal)
        val trusted = evidence.state == ScanProposal.AUTH_TRUSTED
        val claimScore = (
            proposal.rodStructureScore * 0.50f +
                proposal.axisConfidence * 0.30f +
                evidence.continuity.coerceIn(0f, 1f) * 20f
            ).roundToInt().coerceIn(0, 100)
        val claim = evidence.material.supported && proposal.hasResolvedAxis &&
            proposal.rodStructureScore >= 55 &&
            proposal.axisConfidence >= 32 &&
            evidence.continuity >= 0.30f &&
            evidence.beamPenalty < 26 && evidence.floorLinePenalty < 22
        return proposal.copy(
            measuredWidthMedianPx = evidence.measuredWidthMedianPx,
            measuredWidthP10Px = evidence.measuredWidthP10Px,
            measuredWidthP90Px = evidence.measuredWidthP90Px,
            widthVariance = evidence.widthVariance,
            taperRatio = evidence.taperRatio,
            curvatureScore = evidence.curvatureScore,
            rodPositiveEvidence = evidence.positiveEvidence,
            branchPenalty = evidence.branchPenalty,
            beamPenalty = evidence.beamPenalty,
            floorLinePenalty = evidence.floorLinePenalty,
            shadowPenalty = evidence.shadowPenalty,
            rodAuthenticityScore = evidence.authenticityScore,
            rodAuthenticityState = evidence.state,
            trustedRod = trusted,
            rodClaim = claim || trusted,
            rodClaimScore = claimScore,
            crossThroughIntersections = evidence.crossThroughIntersections,
            trueBranchIntersections = evidence.trueBranchIntersections,
            segmentSupport = evidence.segmentSupport,
            shaftVariation = evidence.shaftVariation,
            shaftContinuity = evidence.shaftContinuity,
            foregroundSupported = evidence.material.supported,
            foregroundCoverage = evidence.material.coverage,
            foregroundBodyCoverage = evidence.material.bodyCoverage,
            foregroundReason = evidence.material.reason,
            rodTipVisible = evidence.material.tipVisible,
            // Only a trusted physical rod may become cashier quantity. An
            // uncertain object can still pass through identity scoring solely
            // to produce diagnostics; it cannot create a sale line.
            quantityEligible = proposal.quantityEligible && trusted
        )
    }


    private fun crossingContinuity(
        stationCenters: FloatArray,
        stationWidths: FloatArray,
        runStart: Int,
        runEnd: Int,
        medianWidth: Float,
        halfCorridor: Float
    ): Boolean {
        fun nearestValid(start: Int, step: Int): Int? {
            var i = start
            var attempts = 0
            while (i in stationCenters.indices && attempts < 6) {
                if (!stationCenters[i].isNaN() && !stationWidths[i].isNaN()) return i
                i += step
                attempts++
            }
            return null
        }

        val before = nearestValid(runStart - 1, -1) ?: return false
        val after = nearestValid(runEnd + 1, 1) ?: return false
        val centerTolerance = max(6f, min(halfCorridor * 0.55f, medianWidth * 0.90f))
        val centerDelta = abs(stationCenters[before] - stationCenters[after])
        val w1 = stationWidths[before].coerceAtLeast(1f)
        val w2 = stationWidths[after].coerceAtLeast(1f)
        val widthRatio = max(w1, w2) / min(w1, w2)
        return centerDelta <= centerTolerance && widthRatio <= 2.4f
    }

    private fun activeRuns(active: BooleanArray): List<Pair<Int, Int>> {
        val runs = ArrayList<Pair<Int, Int>>()
        var start = -1
        for (i in active.indices) {
            if (active[i] && start < 0) start = i
            val ends = start >= 0 && (!active[i] || i == active.lastIndex)
            if (ends) {
                val end = if (active[i] && i == active.lastIndex) i else i - 1
                if (end >= start) runs += start to end
                start = -1
            }
        }
        return runs
    }

    private fun percentile(sorted: List<Float>, p: Float): Float {
        if (sorted.isEmpty()) return 0f
        val index = ((sorted.size - 1) * p.coerceIn(0f, 1f)).roundToInt().coerceIn(0, sorted.lastIndex)
        return sorted[index]
    }

    private fun sampleLuminance(bitmap: Bitmap, x: Float, y: Float): Float {
        val ix = x.roundToInt().coerceIn(0, bitmap.width - 1)
        val iy = y.roundToInt().coerceIn(0, bitmap.height - 1)
        val color = bitmap.getPixel(ix, iy)
        return (Color.red(color) * 0.2126f + Color.green(color) * 0.7152f + Color.blue(color) * 0.0722f) / 255f
    }

    private fun emptyEvidence() = Evidence(
        measuredWidthMedianPx = 0,
        measuredWidthP10Px = 0,
        measuredWidthP90Px = 0,
        widthVariance = 0f,
        taperRatio = 0f,
        curvatureScore = 0,
        positiveEvidence = 0,
        branchPenalty = 0,
        beamPenalty = 0,
        floorLinePenalty = 0,
        shadowPenalty = 0,
        authenticityScore = 0,
        state = ScanProposal.AUTH_UNKNOWN,
        continuity = 0f,
        multipleClusterRatio = 0f,
        crossThroughIntersections = 0,
        trueBranchIntersections = 0
    )
}
