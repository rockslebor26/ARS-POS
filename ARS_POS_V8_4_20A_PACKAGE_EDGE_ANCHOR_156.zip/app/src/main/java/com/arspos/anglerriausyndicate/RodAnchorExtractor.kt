package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max

/**
 * V8.4.20-A HANDLE + MID-SHAFT + TIP anchor extractor.
 *
 * Both endpoints are measured physically before SKU identity. Only a confident
 * persistent-body margin may force HANDLE/TIP orientation; otherwise the legacy
 * energy side remains a non-binding crop hypothesis and identity cannot claim
 * physical certainty from it.
 */
object RodAnchorExtractor {
    data class Anchors(
        val leftEnd: Bitmap,
        val side: Bitmap,
        val rightEnd: Bitmap,
        val handleOnLeft: Boolean,
        val physicalHandleOnLeft: Boolean?,
        val endpointLeftScore: Int,
        val endpointRightScore: Int,
        val roleMargin: Int,
        val roleConfidence: Int,
        val roleState: String
    ) {
        val handle: Bitmap
            get() = if (handleOnLeft) leftEnd else rightEnd
        val tip: Bitmap
            get() = if (handleOnLeft) rightEnd else leftEnd

        fun recycle() {
            listOf(leftEnd, side, rightEnd).distinct().forEach { if (!it.isRecycled) it.recycle() }
        }
    }

    fun extract(orientedRod: Bitmap, handleOnLeftOverride: Boolean? = null): Anchors? {
        if (orientedRod.width < 72 || orientedRod.height < 24) return null
        val endpointFraction = 0.34f
        val leftScore = endpointRoleScore(orientedRod, true)
        val rightScore = endpointRoleScore(orientedRod, false)
        val role = RodEndpointRolePolicy.decide(leftScore, rightScore)
        val energyFallback = endpointEnergy(orientedRod, true) >= endpointEnergy(orientedRod, false)
        val physicalHandle = role.handleOnLeft
        val handleOnLeft = handleOnLeftOverride ?: physicalHandle ?: energyFallback

        val endpointW = max(36, (orientedRod.width * endpointFraction).toInt()).coerceAtMost(orientedRod.width)
        val sideW = max(48, (orientedRod.width * 0.52f).toInt()).coerceAtMost(orientedRod.width)
        val sideLeft = ((orientedRod.width - sideW) / 2).coerceAtLeast(0)

        val allocated = ArrayList<Bitmap>(3)
        return try {
            fun own(x: Int, width: Int): Bitmap {
                val created = Bitmap.createBitmap(orientedRod, x, 0, width, orientedRod.height)
                return (if (created === orientedRod) requireNotNull(orientedRod.copy(Bitmap.Config.ARGB_8888, false)) else created)
                    .also { allocated += it }
            }
            Anchors(
                own(0, endpointW),
                own(sideLeft, sideW),
                own(orientedRod.width - endpointW, endpointW),
                handleOnLeft = handleOnLeft,
                physicalHandleOnLeft = physicalHandle,
                endpointLeftScore = leftScore,
                endpointRightScore = rightScore,
                roleMargin = role.margin,
                roleConfidence = role.confidence,
                roleState = role.state
            )
        } catch (_: Throwable) {
            allocated.filter { it !== orientedRod }.distinct().forEach { if (!it.isRecycled) it.recycle() }
            null
        }
    }

    /** Physical HANDLE/TIP evidence is measured from both endpoints before SKU identity. */
    private fun endpointRoleScore(bitmap: Bitmap, left: Boolean): Int =
        RodEndpointProfile.measure(bitmap.width, bitmap.height, left, bitmap::getPixel).score

    private fun endpointEnergy(bitmap: Bitmap, left: Boolean): Float {
        val w = max(24, (bitmap.width * 0.30f).toInt()).coerceAtMost(bitmap.width)
        val startX = if (left) 0 else bitmap.width - w
        val stepX = max(1, w / 36)
        val stepY = max(1, bitmap.height / 24)
        var texture = 0f
        var darkMass = 0f
        var samples = 0

        var y = 0
        while (y < bitmap.height) {
            var x = startX
            while (x < startX + w) {
                val current = luminance(bitmap.getPixel(x, y))
                val x2 = (x + stepX).coerceAtMost(startX + w - 1)
                val y2 = (y + stepY).coerceAtMost(bitmap.height - 1)
                texture += abs(current - luminance(bitmap.getPixel(x2, y)))
                texture += abs(current - luminance(bitmap.getPixel(x, y2)))
                darkMass += (1f - current).coerceIn(0f, 1f)
                samples++
                x += stepX
            }
            y += stepY
        }
        if (samples == 0) return 0f
        return texture / samples.toFloat() * 0.62f + darkMass / samples.toFloat() * 0.38f
    }

    private fun luminance(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
}
