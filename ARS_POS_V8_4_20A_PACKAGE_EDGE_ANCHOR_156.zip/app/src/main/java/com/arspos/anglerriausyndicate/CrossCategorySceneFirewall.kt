package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.40 V8.4.20-A WorkSync — trusted-only physical ownership firewall.
 *
 * The field failure we are protecting against is specific and high impact:
 * a compact ML Kit NORMAL proposal created from a rod handle/intersection may
 * visually resemble a verified NORMAL product and become a sellable SKU even
 * though the scene is physically dominated by LONG rod tracks.
 *
 * This firewall does NOT lower any recognition threshold and does NOT delete
 * OCR/barcode evidence. Only TRUSTED_ROD creates physical ownership.
 * NON_ROD and uncertain geometry never own NORMAL regions; NORMAL visual-only
 * rejection remains an independent identity-engine rule.
 * Exact barcode / sufficiently strong OCR can still identify a real NORMAL
 * product that happens to sit close to a rod.
 */
object CrossCategorySceneFirewall {
    private const val MIN_STRONG_ROD_STRUCTURE = 55
    private const val MIN_STRONG_AXIS_CONFIDENCE = 32
    private const val MAX_COMPACT_ASPECT = 1.80f
    private const val MIN_COMPACT_AREA_RATIO = 0.0045f
    private const val MAX_COMPACT_AREA_RATIO = 0.17f
    private const val LARGE_NORMAL_AREA_RATIO = 0.20f

    data class Result(
        val normals: List<ScanProposal>,
        val strongRodTracks: Int,
        val visualOnlyBlocked: Int,
        val isolatedNormals: Int,
        val rodConflicts: Int
    )

    fun apply(
        normalInput: List<ScanProposal>,
        resolvedLongInput: List<ScanProposal>,
        imageWidth: Int,
        imageHeight: Int
    ): Result {
        if (normalInput.isEmpty()) {
            return Result(emptyList(), strongTracks(resolvedLongInput).size, 0, 0, 0)
        }

        val tracks = ownershipTracks(resolvedLongInput)
        if (tracks.isEmpty()) {
            return Result(
                normals = normalInput.map { it.copy(
                    normalOwnershipConflict = false,
                    crossCategoryConflict = false,
                    crossCategoryConflictScore = 0,
                    rodTrackHits = 0,
                    visualOnlyBlocked = false,
                    crossCategoryReason = "NO_ROD_OWNERSHIP_CLAIM"
                ) },
                strongRodTracks = 0,
                visualOnlyBlocked = 0,
                isolatedNormals = normalInput.size,
                rodConflicts = 0
            )
        }

        val frameArea = imageWidth.coerceAtLeast(1).toLong() * imageHeight.coerceAtLeast(1).toLong()
        var blocked = 0
        var isolatedCount = 0
        var conflictCount = 0

        val output = normalInput.map { normal ->
            val r = normal.normalizedBounds
            val w = r.width().coerceAtLeast(1)
            val h = r.height().coerceAtLeast(1)
            val shortSide = min(w, h).toFloat()
            val longSide = max(w, h).toFloat()
            val aspect = longSide / shortSide.coerceAtLeast(1f)
            val areaRatio = area(r).toFloat() / frameArea.toFloat()

            val directHits = tracks.count { track ->
                val physicalWidth = track.measuredWidthMedianPx.takeIf { it > 0 } ?: track.axisWidthPx.coerceAtLeast(18)
                val corridor = max(12f, min(42f, physicalWidth * 1.45f))
                segmentIntersectsExpandedRect(track, r, corridor)
            }
            val nearHits = tracks.count { track ->
                val physicalWidth = track.measuredWidthMedianPx.takeIf { it > 0 } ?: track.axisWidthPx.coerceAtLeast(18)
                val corridor = max(
                    18f,
                    min(58f, physicalWidth * 2.10f + shortSide * 0.10f)
                )
                segmentIntersectsExpandedRect(track, r, corridor)
            }

            val compact = aspect <= MAX_COMPACT_ASPECT &&
                areaRatio >= MIN_COMPACT_AREA_RATIO &&
                areaRatio <= MAX_COMPACT_AREA_RATIO
            val isolated = compact && directHits == 0 && nearHits == 0
            val elongated = aspect > MAX_COMPACT_ASPECT
            val large = areaRatio >= LARGE_NORMAL_AREA_RATIO
            val multiRodConflict = directHits >= 2 || nearHits >= 2

            // Multi-rod scenes are the highest-risk case observed in field logs.
            // NORMAL visual-only is allowed there only when the compact object is
            // geometrically isolated from every resolved rod corridor.
            val shouldBlockVisualOnly = when {
                tracks.size >= 2 -> !isolated
                directHits > 0 -> true
                nearHits > 0 && !isolated -> true
                elongated -> true
                large -> true
                else -> false
            }

            var score = 0
            score += min(60, directHits * 35)
            score += min(25, nearHits * 12)
            if (multiRodConflict) score += 20
            if (elongated) score += 18
            if (large) score += 18
            if (tracks.size >= 2 && !isolated) score += 12
            if (isolated) score -= 25
            score = score.coerceIn(0, 100)

            val reason = when {
                !shouldBlockVisualOnly && isolated -> "INDEPENDENT_COMPACT_NORMAL"
                multiRodConflict -> "NORMAL_INTERSECTS_MULTIPLE_ROD_TRACKS"
                directHits > 0 -> "NORMAL_INTERSECTS_ROD_AXIS"
                nearHits > 0 -> "NORMAL_NEAR_ROD_AXIS"
                tracks.size >= 2 && !isolated -> "MULTI_ROD_SCENE_NORMAL_NOT_ISOLATED"
                elongated -> "ELONGATED_NORMAL_IN_ROD_SCENE"
                large -> "LARGE_NORMAL_REGION_IN_ROD_SCENE"
                else -> "ROD_SCENE_NORMAL_ALLOWED"
            }

            if (shouldBlockVisualOnly) blocked++ else if (isolated) isolatedCount++
            if (score > 0 || shouldBlockVisualOnly) conflictCount++

            normal.copy(
                normalOwnershipConflict = normal.normalOwnershipConflict || shouldBlockVisualOnly,
                crossCategoryConflict = shouldBlockVisualOnly,
                crossCategoryConflictScore = score,
                rodTrackHits = max(directHits, nearHits),
                visualOnlyBlocked = shouldBlockVisualOnly,
                crossCategoryReason = reason
            )
        }

        return Result(
            normals = output,
            strongRodTracks = tracks.size,
            visualOnlyBlocked = blocked,
            isolatedNormals = isolatedCount,
            rodConflicts = conflictCount
        )
    }

    private fun strongTracks(input: List<ScanProposal>): List<ScanProposal> = ownershipTracks(input)

    private fun ownershipTracks(input: List<ScanProposal>): List<ScanProposal> = input.filter {
        (it.proposalType == ScanProposal.TYPE_LONG ||
            it.proposalType == ScanProposal.TYPE_AMBIGUOUS_CONTAINER) &&
            !it.bridgeSuppressed &&
            // A geometric claim is not physical ownership. NORMAL has its own
            // identity gate (REJECT_NORMAL_REQUIRES_IDENTITY), including floors.
            it.rodAuthenticityState == ScanProposal.AUTH_TRUSTED &&
            it.trustedRod &&
            it.hasResolvedAxis &&
            it.rodStructureScore >= MIN_STRONG_ROD_STRUCTURE &&
            it.axisConfidence >= MIN_STRONG_AXIS_CONFIDENCE &&
            it.physicalInstanceHint.startsWith("TRACK-")
    }

    /** Liang-Barsky segment/expanded-rectangle intersection. */
    private fun segmentIntersectsExpandedRect(track: ScanProposal, rect: Rect, margin: Float): Boolean {
        val left = rect.left.toFloat() - margin
        val top = rect.top.toFloat() - margin
        val right = rect.right.toFloat() + margin
        val bottom = rect.bottom.toFloat() + margin
        val x0 = track.axisStartX.toFloat()
        val y0 = track.axisStartY.toFloat()
        val x1 = track.axisEndX.toFloat()
        val y1 = track.axisEndY.toFloat()

        if (pointInside(x0, y0, left, top, right, bottom) ||
            pointInside(x1, y1, left, top, right, bottom)
        ) return true

        val dx = x1 - x0
        val dy = y1 - y0
        var u1 = 0f
        var u2 = 1f

        fun clip(p: Float, q: Float): Boolean {
            if (p == 0f) return q >= 0f
            val t = q / p
            if (p < 0f) {
                if (t > u2) return false
                if (t > u1) u1 = t
            } else {
                if (t < u1) return false
                if (t < u2) u2 = t
            }
            return true
        }

        return clip(-dx, x0 - left) &&
            clip(dx, right - x0) &&
            clip(-dy, y0 - top) &&
            clip(dy, bottom - y0) &&
            u1 <= u2
    }

    private fun pointInside(x: Float, y: Float, left: Float, top: Float, right: Float, bottom: Float): Boolean =
        x in left..right && y in top..bottom

    private fun area(r: Rect): Long =
        r.width().coerceAtLeast(0).toLong() * r.height().coerceAtLeast(0).toLong()
}
