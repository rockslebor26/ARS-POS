package com.arspos.anglerriausyndicate

import kotlin.math.abs
import kotlin.math.max

/** Pure policy for V8.4.20-A bidirectional HANDLE/TIP endpoint evidence. */
internal object RodEndpointRolePolicy {
    const val STATE_CONFIDENT = "ANCHOR_ROLE_PHYSICAL_CONFIDENT"
    const val STATE_WEAK = "ANCHOR_ROLE_PHYSICAL_WEAK"
    const val STATE_UNKNOWN = "ANCHOR_ROLE_UNKNOWN"

    data class Decision(
        val handleOnLeft: Boolean?,
        val leftScore: Int,
        val rightScore: Int,
        val margin: Int,
        val confidence: Int,
        val state: String
    )

    fun decide(leftScore: Int, rightScore: Int): Decision {
        val left = leftScore.coerceIn(0, 100)
        val right = rightScore.coerceIn(0, 100)
        val strongest = max(left, right)
        val margin = abs(left - right)
        val confidence = (strongest * 0.72f + margin * 1.35f).toInt().coerceIn(0, 100)
        val state = when {
            strongest >= 38 && margin >= 14 -> STATE_CONFIDENT
            strongest >= 30 && margin >= 8 -> STATE_WEAK
            else -> STATE_UNKNOWN
        }
        return Decision(
            handleOnLeft = if (state == STATE_CONFIDENT) left > right else null,
            leftScore = left,
            rightScore = right,
            margin = margin,
            confidence = confidence,
            state = state
        )
    }
}
