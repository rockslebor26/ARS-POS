package com.arspos.anglerriausyndicate

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Phase 4.3.2.40 / V8.4.20-A — pure bidirectional endpoint body profiler.
 *
 * HANDLE evidence must be persistent across the endpoint window. A one-off
 * crossing line, grout seam or branch can create a wide gradient at a few
 * columns, but it must not beat a physical grip that stays wide for most of the
 * endpoint. The implementation is Android-free so captured scanner pixels can
 * be replayed byte-for-byte on the JVM.
 */
internal object RodEndpointProfile {
    data class Result(
        val score: Int,
        val persistentCoverage: Float,
        val medianWidthRatio: Float,
        val widthConsistency: Float,
        val sampledColumns: Int,
        val validColumns: Int
    )

    fun measure(
        width: Int,
        height: Int,
        left: Boolean,
        pixel: (Int, Int) -> Int
    ): Result {
        if (width < 48 || height < 18) return Result(0, 0f, 0f, 0f, 0, 0)
        val window = max(36, (width * 0.28f).toInt()).coerceAtMost(width)
        val startX = if (left) 0 else width - window
        val stepX = max(1, window / 32)
        val widths = ArrayList<Int>()
        var sampled = 0

        var x = startX
        while (x < startX + window) {
            sampled++
            val mid = height / 2
            var topStrength = 0f
            var topY = -1
            var bottomStrength = 0f
            var bottomY = -1

            var y = 2
            while (y < max(3, mid)) {
                val strength = colorGradient(pixel(x, y - 2), pixel(x, y + 2))
                if (strength > topStrength) {
                    topStrength = strength
                    topY = y
                }
                y++
            }
            y = mid
            while (y < height - 2) {
                val strength = colorGradient(pixel(x, y - 2), pixel(x, y + 2))
                if (strength > bottomStrength) {
                    bottomStrength = strength
                    bottomY = y
                }
                y++
            }

            // Both silhouette boundaries must be independently visible. A
            // single line crossing the crop is not a bounded body.
            if (topStrength >= 0.10f && bottomStrength >= 0.10f && bottomY > topY && topY >= 0) {
                widths += bottomY - topY
            }
            x += stepX
        }

        if (sampled == 0 || widths.isEmpty()) return Result(0, 0f, 0f, 0f, sampled, 0)
        val sorted = widths.sorted()
        val median = sorted[sorted.size / 2]
        val q1 = sorted[((sorted.size - 1) * 0.25f).toInt()]
        val q3 = sorted[((sorted.size - 1) * 0.75f).toInt()]
        val coverage = widths.size.toFloat() / sampled.toFloat()
        val widthRatio = median.toFloat() / height.coerceAtLeast(1).toFloat()
        val consistency = (1f - (q3 - q1).toFloat() / median.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
        val widthEvidence = (widthRatio / 0.65f).coerceIn(0f, 1f)

        // Persistent coverage gates the apparent width. This is the key
        // anti-crossing property: a very wide line seen in only a few columns
        // cannot outrank a real grip that persists across the endpoint.
        val persistentWidth = widthEvidence * (0.45f + 0.55f * coverage)
        val score = (
            persistentWidth * 65f +
                coverage.coerceIn(0f, 1f) * 25f +
                consistency * 10f
            ).toInt().coerceIn(0, 100)

        return Result(
            score = score,
            persistentCoverage = coverage,
            medianWidthRatio = widthRatio,
            widthConsistency = consistency,
            sampledColumns = sampled,
            validColumns = widths.size
        )
    }

    private fun colorGradient(a: Int, b: Int): Float {
        val dr = (red(a) - red(b)).toFloat() / 255f
        val dg = (green(a) - green(b)).toFloat() / 255f
        val db = (blue(a) - blue(b)).toFloat() / 255f
        return sqrt(dr * dr + dg * dg + db * db)
    }

    private fun red(c: Int): Int = (c ushr 16) and 255
    private fun green(c: Int): Int = (c ushr 8) and 255
    private fun blue(c: Int): Int = c and 255
}
