package com.arspos.anglerriausyndicate.visualdna

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.room.withTransaction
import com.arspos.anglerriausyndicate.data.db.*
import kotlinx.coroutines.flow.first
import java.io.File
import java.security.MessageDigest
import kotlin.math.roundToInt

data class SmartCatalogRebuildResult(
    val catalogVersion: Long,
    val readyProducts: Int,
    val stagingProducts: Int,
    val skippedProducts: Int,
    val collisionPairs: Int,
    val checksum: String
)

/**
 * Explicit operator-triggered DB-v6 rebuild. It never deletes POS/stock/sales
 * data and never auto-promotes visually colliding products.
 */
class SmartCatalogRebuilder(private val db: ArsDatabase) {
    private val dao = db.dao()

    private data class BuiltProduct(
        val product: ProductEntity,
        val dnaId: String,
        val descriptors: List<ByteArray>,
        val global: ByteArray,
        val local: List<VisualLocalFeatureEntity>,
        val views: List<VisualReferenceViewEntity>
    )

    suspend fun rebuild(): SmartCatalogRebuildResult {
        val products = dao.products().first().filter { it.active }
        val allPhotos = dao.allProductPhotos()
        val verified = dao.masterVerificationSettings().mapNotNull { setting ->
            if (setting.key.startsWith("master_verified_") && setting.value == "1") {
                setting.key.removePrefix("master_verified_").toLongOrNull()
            } else null
        }.toSet()

        val built = ArrayList<BuiltProduct>()
        var skipped = 0
        products.forEach { product ->
            val refs = allPhotos.filter { it.productId == product.id && File(it.localPath).exists() }
            if (product.id !in verified || refs.size < 2) {
                skipped++
                return@forEach
            }
            val dnaId = "APVD-${product.id}-${System.currentTimeMillis()}"
            val globals = ArrayList<ByteArray>()
            val locals = ArrayList<VisualLocalFeatureEntity>()
            val views = ArrayList<VisualReferenceViewEntity>()

            refs.take(10).forEachIndexed { viewIndex, photo ->
                val bitmap = BitmapFactory.decodeFile(photo.localPath) ?: return@forEachIndexed
                try {
                    val descriptor = PrivateVisualDnaRuntime.descriptor(bitmap)
                    globals += descriptor
                    val viewId = "REBUILD-${product.id}-${photo.id}-${viewIndex}"
                    views += VisualReferenceViewEntity(
                        viewId = viewId,
                        productId = product.id,
                        enrollmentSessionId = "REBUILD_SMART_CATALOG",
                        viewType = photo.captureAngle,
                        rawImagePath = photo.localPath,
                        enhancedImagePath = null,
                        maskPath = null,
                        qualityScore = 80,
                        coverageScore = 75,
                        segmentationScore = 70,
                        featureDensity = 70,
                        accepted = true,
                        rejectionReason = "",
                        createdAt = photo.createdAt
                    )
                    locals += denseLocalFeatures(bitmap, dnaId, viewId, viewIndex)
                } finally {
                    if (!bitmap.isRecycled) bitmap.recycle()
                }
            }
            if (globals.size < 2) {
                skipped++
                return@forEach
            }
            built += BuiltProduct(product, dnaId, globals, averageDescriptor(globals), locals, views)
        }

        val collisions = ArrayList<CatalogCollisionEntity>()
        val maxSimilarityByProduct = HashMap<Long, Int>()
        for (i in built.indices) for (j in i + 1 until built.size) {
            val a = built[i]
            val b = built[j]
            val similarity = PrivateVisualDnaRuntime.descriptorSimilarity(a.global, b.global)
            maxSimilarityByProduct[a.product.id] = maxOf(maxSimilarityByProduct[a.product.id] ?: 0, similarity)
            maxSimilarityByProduct[b.product.id] = maxOf(maxSimilarityByProduct[b.product.id] ?: 0, similarity)
            val severity = when {
                similarity >= 92 -> VisualDnaContract.COLLISION_CRITICAL
                similarity >= 86 -> VisualDnaContract.COLLISION_HIGH
                similarity >= 78 -> VisualDnaContract.COLLISION_MEDIUM
                similarity >= 68 -> VisualDnaContract.COLLISION_LOW
                else -> VisualDnaContract.COLLISION_NONE
            }
            if (severity != VisualDnaContract.COLLISION_NONE) {
                collisions += CatalogCollisionEntity(
                    sourceProductId = a.product.id,
                    targetProductId = b.product.id,
                    globalSimilarity = similarity / 100f,
                    localSimilarity = 0f,
                    geometrySimilarity = 0f,
                    textureSimilarity = 0f,
                    collisionSeverity = severity,
                    resolvedByRegionId = null,
                    status = if (severity == VisualDnaContract.COLLISION_HIGH || severity == VisualDnaContract.COLLISION_CRITICAL) "NEEDS_EVIDENCE" else "OBSERVED"
                )
            }
        }

        val checksum = checksum(built)
        return db.withTransaction {
            val now = System.currentTimeMillis()
            val nextVersion = dao.maxCatalogVersion() + 1L
            dao.supersedeActiveCatalog()
            var ready = 0
            var staging = 0

            built.forEach { item ->
                val maxSim = maxSimilarityByProduct[item.product.id] ?: 0
                val unsafeCollision = maxSim >= 86
                val status = if (unsafeCollision) VisualDnaContract.DNA_STATUS_STAGING else VisualDnaContract.DNA_STATUS_RECOGNITION_READY
                if (unsafeCollision) staging++ else ready++
                dao.supersedeProductVisualDna(item.product.id, now)
                dao.upsertProductVisualDna(
                    ProductVisualDnaEntity(
                        dnaId = item.dnaId,
                        productId = item.product.id,
                        dnaVersion = VisualDnaContract.DNA_VERSION,
                        embeddingModelVersion = VisualDnaContract.EMBEDDING_MODEL_VERSION,
                        segmentationModelVersion = VisualDnaContract.SEGMENTATION_MODEL_VERSION,
                        catalogVersion = nextVersion,
                        globalEmbedding = item.global,
                        shapeSignature = "OBJECT_RELATIVE_ASPECT_MULTI_VIEW",
                        geometrySignature = "VIEWS=${item.descriptors.size}",
                        textureSignature = "DENSE_LOCAL=${item.local.size}",
                        enrollmentQualityScore = 80,
                        coverageScore = minOf(100, 60 + item.descriptors.size * 5),
                        intraProductVariation = descriptorVariation(item.descriptors),
                        nearestNeighborDistance = 1f - maxSim / 100f,
                        acceptedFeatureRange = 0.86f,
                        collisionGroupId = if (unsafeCollision) "COLLISION-${item.product.id}" else null,
                        calibrationProfileId = "CAL-${VisualDnaContract.DNA_VERSION}",
                        status = status,
                        createdAt = now,
                        updatedAt = now
                    )
                )
                dao.deleteVisualLocalFeatures(item.dnaId)
                if (item.local.isNotEmpty()) dao.upsertVisualLocalFeatures(item.local)
                val rebuildSessionId = "REBUILD-${nextVersion}-${item.product.id}"
                item.views.forEach { view ->
                    dao.upsertVisualReferenceView(view.copy(enrollmentSessionId = rebuildSessionId))
                }
                dao.upsertEnrollmentSession(
                    ProductEnrollmentEntity(
                        sessionId = rebuildSessionId,
                        productId = item.product.id,
                        state = if (unsafeCollision) EnrollmentState.MORE_EVIDENCE.name else EnrollmentState.RECOGNITION_READY.name,
                        requestedEvidence = if (unsafeCollision) "DISCRIMINATIVE_EVIDENCE_REQUIRED" else "",
                        qualityScore = 80,
                        coverageScore = minOf(100, 60 + item.descriptors.size * 5),
                        collisionSeverity = when {
                            maxSim >= 92 -> VisualDnaContract.COLLISION_CRITICAL
                            maxSim >= 86 -> VisualDnaContract.COLLISION_HIGH
                            maxSim >= 78 -> VisualDnaContract.COLLISION_MEDIUM
                            maxSim >= 68 -> VisualDnaContract.COLLISION_LOW
                            else -> VisualDnaContract.COLLISION_NONE
                        },
                        startedAt = now,
                        updatedAt = now
                    )
                )
                dao.deleteCatalogCollisionsForProduct(item.product.id)
            }
            if (collisions.isNotEmpty()) dao.upsertCatalogCollisions(collisions)
            dao.insertCatalogSnapshot(
                CatalogSnapshotEntity(
                    catalogVersion = nextVersion,
                    embeddingModelVersion = VisualDnaContract.EMBEDDING_MODEL_VERSION,
                    segmentationModelVersion = VisualDnaContract.SEGMENTATION_MODEL_VERSION,
                    visualDnaVersion = VisualDnaContract.DNA_VERSION,
                    productCount = products.size,
                    dnaCount = ready,
                    checksum = checksum,
                    state = VisualDnaContract.CATALOG_STATE_ACTIVE,
                    createdAt = now,
                    activatedAt = now
                )
            )
            SmartCatalogRebuildResult(nextVersion, ready, staging, skipped, collisions.size, checksum)
        }
    }

    private fun denseLocalFeatures(bitmap: Bitmap, dnaId: String, viewId: String, viewIndex: Int): List<VisualLocalFeatureEntity> {
        val out = ArrayList<VisualLocalFeatureEntity>()
        val cells = 2
        for (gy in 0 until cells) for (gx in 0 until cells) {
            val left = gx * bitmap.width / cells
            val top = gy * bitmap.height / cells
            val right = (gx + 1) * bitmap.width / cells
            val bottom = (gy + 1) * bitmap.height / cells
            if (right - left < 8 || bottom - top < 8) continue
            val region = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
            try {
                out += VisualLocalFeatureEntity(
                    featureId = "$dnaId-$viewIndex-$gx-$gy",
                    dnaId = dnaId,
                    viewId = viewId,
                    regionId = "GRID_${gx}_${gy}",
                    descriptor = PrivateVisualDnaRuntime.descriptor(region),
                    normalizedX = gx / cells.toFloat(),
                    normalizedY = gy / cells.toFloat(),
                    normalizedWidth = 1f / cells,
                    normalizedHeight = 1f / cells,
                    stabilityScore = 0.72f,
                    discriminativeScore = 0.65f
                )
            } finally {
                if (!region.isRecycled) region.recycle()
            }
        }
        return out
    }

    private fun averageDescriptor(values: List<ByteArray>): ByteArray {
        val n = values.minOf { it.size }
        return ByteArray(n) { index ->
            values.map { it[index].toInt() and 0xFF }.average().roundToInt().coerceIn(0, 255).toByte()
        }
    }

    private fun descriptorVariation(values: List<ByteArray>): Float {
        if (values.size < 2) return 0f
        val mean = averageDescriptor(values)
        val similarities = values.map { PrivateVisualDnaRuntime.descriptorSimilarity(it, mean) }
        return (1f - similarities.average().toFloat() / 100f).coerceIn(0f, 1f)
    }

    private fun checksum(items: List<BuiltProduct>): String {
        val md = MessageDigest.getInstance("SHA-256")
        items.sortedBy { it.product.id }.forEach { item ->
            md.update(item.product.id.toString().toByteArray())
            md.update(item.global)
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
