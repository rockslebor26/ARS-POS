package com.arspos.anglerriausyndicate.visualdna

/** Stable contract shared by enrollment, catalog storage and V8.9.0-B transaction runtime. */
object VisualDnaContract {
    const val DNA_VERSION = "APVD_V1_RUNTIME"
    const val EMBEDDING_MODEL_VERSION = "ARS_DETERMINISTIC_DNA_1"
    const val SEGMENTATION_MODEL_VERSION = "OBJECT_CROP_MASK_V1"

    const val DNA_STATUS_STAGING = "STAGING"
    const val DNA_STATUS_RECOGNITION_READY = "RECOGNITION_READY"
    const val DNA_STATUS_SUPERSEDED = "SUPERSEDED"

    const val CATALOG_STATE_BUILDING = "BUILDING"
    const val CATALOG_STATE_ACTIVE = "ACTIVE"
    const val CATALOG_STATE_SUPERSEDED = "SUPERSEDED"
    const val CATALOG_STATE_FAILED = "FAILED"

    const val COLLISION_NONE = "NONE"
    const val COLLISION_LOW = "LOW"
    const val COLLISION_MEDIUM = "MEDIUM"
    const val COLLISION_HIGH = "HIGH"
    const val COLLISION_CRITICAL = "CRITICAL"
}
