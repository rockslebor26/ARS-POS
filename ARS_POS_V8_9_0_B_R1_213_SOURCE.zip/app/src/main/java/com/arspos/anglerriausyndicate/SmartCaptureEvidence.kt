package com.arspos.anglerriausyndicate

import android.graphics.Bitmap

/**
 * V8.9.0-B frozen capture contract. One operator action may contribute 1-3
 * already captured frames; recognition is executed once against this immutable set.
 */
data class FrozenCaptureFrame(
    val frameId: String,
    val bitmap: Bitmap,
    val capturedAtMs: Long,
    val qualityScore: Int,
    val role: String
)

data class FrozenCaptureEvidenceSet(
    val captureId: String,
    val frames: List<FrozenCaptureFrame>,
    val masterFrameId: String,
    val createdAtMs: Long = System.currentTimeMillis()
) {
    val burstFrameCount: Int get() = frames.size
    fun master(): FrozenCaptureFrame = frames.firstOrNull { it.frameId == masterFrameId } ?: frames.first()
}

object SmartCaptureEvidenceFactory {
    fun fromFinalLock(
        captureId: String,
        freshPhysical: Bitmap,
        bestIdentity: Bitmap?,
        identityQuality: Int,
        identityAgeMs: Long
    ): FrozenCaptureEvidenceSet {
        val now = System.currentTimeMillis()
        val frames = buildList {
            add(FrozenCaptureFrame("FRESH_PHYSICAL", freshPhysical, now, 100, "PHYSICAL_TRUTH"))
            if (bestIdentity != null && bestIdentity !== freshPhysical) {
                add(FrozenCaptureFrame("BEST_IDENTITY", bestIdentity, now - identityAgeMs.coerceAtLeast(0L), identityQuality, "IDENTITY_EVIDENCE"))
            }
        }.take(3)
        val master = frames.maxByOrNull { frame ->
            when (frame.role) {
                "IDENTITY_EVIDENCE" -> frame.qualityScore + 20
                else -> frame.qualityScore
            }
        } ?: frames.first()
        return FrozenCaptureEvidenceSet(captureId, frames, master.frameId)
    }
}
