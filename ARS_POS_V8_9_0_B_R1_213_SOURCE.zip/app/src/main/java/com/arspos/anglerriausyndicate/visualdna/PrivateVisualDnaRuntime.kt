package com.arspos.anglerriausyndicate.visualdna

import android.graphics.Bitmap
import android.graphics.Color
import com.arspos.anglerriausyndicate.data.db.ProductVisualDnaEntity
import com.arspos.anglerriausyndicate.data.db.VisualLocalFeatureEntity
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * V8.9.0-B deterministic ARS Private Visual DNA runtime.
 *
 * The descriptor is intentionally non-generative and object-centric. It only
 * summarizes pixels that already exist in the captured object crop. Query
 * rotation banks make 0/90/180/270 orientation changes non-authoritative.
 */
data class VisualDnaEvidence(
    val productId: Long,
    val score: Int,
    val localScore: Int,
    val evidenceCount: Int,
    val rawScore: Int,
    val enhancedScore: Int,
    val rawEnhancedAgreement: String,
    val decision: String,
    val margin: Int,
    val recognitionReady: Boolean = true
)

data class VisualDnaQueryResult(
    val decision: String,
    val candidates: List<VisualDnaEvidence>,
    val topScore: Int,
    val margin: Int,
    val rawEnhancedAgreement: String
) {
    companion object {
        const val KNOWN = "KNOWN"
        const val AMBIGUOUS = "AMBIGUOUS"
        const val UNKNOWN = "UNKNOWN"
        const val EVIDENCE_CONFLICT = "EVIDENCE_CONFLICT"
    }
}

data class VisualDnaRuntimeEntry(
    val dna: ProductVisualDnaEntity,
    val localFeatures: List<VisualLocalFeatureEntity>
)

object PrivateVisualDnaRuntime {
    /** New APVD acceptance gates. Existing SmartRecognitionEngine thresholds are untouched. */
    private const val KNOWN_MIN_SCORE = 86
    private const val KNOWN_MIN_MARGIN = 8
    private const val LOCAL_SUPPORT_MIN = 78
    private const val MIN_INDEPENDENT_EVIDENCE = 2

    fun query(rawCrop: Bitmap, entries: List<VisualDnaRuntimeEntry>): VisualDnaQueryResult {
        if (entries.isEmpty()) return VisualDnaQueryResult(
            VisualDnaQueryResult.UNKNOWN, emptyList(), 0, 0, "NOT_AVAILABLE"
        )

        val rawBank = VisualDnaDescriptor.rotationBank(rawCrop)
        val enhanced = SafeEvidenceEnhancer.enhance(rawCrop)
        val enhancedBank = try {
            VisualDnaDescriptor.rotationBank(enhanced)
        } finally {
            if (enhanced !== rawCrop && !enhanced.isRecycled) enhanced.recycle()
        }

        val rawRank = entries.map { it to bestSimilarity(rawBank, it.dna.globalEmbedding) }
            .sortedByDescending { it.second }
        val enhancedRank = entries.map { it to bestSimilarity(enhancedBank, it.dna.globalEmbedding) }
            .sortedByDescending { it.second }

        val rawTop = rawRank.firstOrNull()
        val enhancedTop = enhancedRank.firstOrNull()
        val rawEnhancedAgreement = when {
            rawTop == null || enhancedTop == null -> "NOT_AVAILABLE"
            rawTop.first.dna.productId == enhancedTop.first.dna.productId -> "AGREE"
            abs(rawTop.second - enhancedTop.second) <= 3 -> "WEAK_CONFLICT"
            else -> "EVIDENCE_CONFLICT"
        }

        val candidates = entries.map { entry ->
            val rawScore = rawRank.firstOrNull { it.first.dna.productId == entry.dna.productId }?.second ?: 0
            val enhancedScore = enhancedRank.firstOrNull { it.first.dna.productId == entry.dna.productId }?.second ?: 0
            val globalScore = if (rawEnhancedAgreement == "AGREE") {
                ((rawScore + enhancedScore) / 2f).roundToInt()
            } else minOf(rawScore, enhancedScore)
            val localScore = localSupport(rawBank, entry.localFeatures)
            val evidenceCount = listOf(
                globalScore >= KNOWN_MIN_SCORE,
                localScore >= LOCAL_SUPPORT_MIN,
                rawEnhancedAgreement == "AGREE"
            ).count { it }
            VisualDnaEvidence(
                productId = entry.dna.productId,
                score = max(globalScore, ((globalScore * 0.75f) + (localScore * 0.25f)).roundToInt()),
                localScore = localScore,
                evidenceCount = evidenceCount,
                rawScore = rawScore,
                enhancedScore = enhancedScore,
                rawEnhancedAgreement = rawEnhancedAgreement,
                decision = VisualDnaQueryResult.UNKNOWN,
                margin = 0
            )
        }.sortedByDescending { it.score }

        val first = candidates.firstOrNull()
        val second = candidates.getOrNull(1)
        val margin = if (first != null && second != null) first.score - second.score else 100
        val decision = when {
            first == null -> VisualDnaQueryResult.UNKNOWN
            rawEnhancedAgreement == "EVIDENCE_CONFLICT" -> VisualDnaQueryResult.EVIDENCE_CONFLICT
            first.score >= KNOWN_MIN_SCORE && margin >= KNOWN_MIN_MARGIN &&
                first.evidenceCount >= MIN_INDEPENDENT_EVIDENCE -> VisualDnaQueryResult.KNOWN
            first.score >= 72 -> VisualDnaQueryResult.AMBIGUOUS
            else -> VisualDnaQueryResult.UNKNOWN
        }

        val withDecision = candidates.mapIndexed { index, c ->
            c.copy(
                decision = if (index == 0) decision else VisualDnaQueryResult.AMBIGUOUS,
                margin = if (index == 0) margin else 0
            )
        }
        return VisualDnaQueryResult(decision, withDecision, first?.score ?: 0, margin, rawEnhancedAgreement)
    }

    fun descriptor(bitmap: Bitmap): ByteArray = VisualDnaDescriptor.extract(bitmap)

    private fun localSupport(queryBank: List<ByteArray>, localFeatures: List<VisualLocalFeatureEntity>): Int {
        if (localFeatures.isEmpty()) return 0
        return localFeatures.asSequence()
            .filter { it.stabilityScore >= 0.55f }
            .sortedByDescending { it.discriminativeScore }
            .take(12)
            .map { feature -> bestSimilarity(queryBank, feature.descriptor) }
            .sortedDescending()
            .take(4)
            .toList()
            .let { values -> if (values.isEmpty()) 0 else values.average().roundToInt() }
    }

    private fun bestSimilarity(bank: List<ByteArray>, reference: ByteArray): Int =
        bank.maxOfOrNull { descriptorSimilarity(it, reference) } ?: 0

    fun descriptorSimilarity(a: ByteArray, b: ByteArray): Int {
        val n = minOf(a.size, b.size)
        if (n <= 0) return 0
        var dot = 0.0
        var aa = 0.0
        var bb = 0.0
        for (i in 0 until n) {
            val x = (a[i].toInt() and 0xFF) / 255.0
            val y = (b[i].toInt() and 0xFF) / 255.0
            dot += x * y
            aa += x * x
            bb += y * y
        }
        if (aa <= 1e-9 || bb <= 1e-9) return 0
        return ((dot / (sqrt(aa) * sqrt(bb))).coerceIn(0.0, 1.0) * 100.0).roundToInt()
    }
}

/** Safe, bounded, non-generative enhancement. No content synthesis. */
object SafeEvidenceEnhancer {
    fun enhance(source: Bitmap): Bitmap {
        if (source.width < 2 || source.height < 2) return source
        val copy = source.copy(Bitmap.Config.ARGB_8888, true) ?: return source
        val sample = IntArray(copy.width * copy.height)
        copy.getPixels(sample, 0, copy.width, 0, 0, copy.width, copy.height)
        val luminance = sample.map { c ->
            (Color.red(c) * 0.299f + Color.green(c) * 0.587f + Color.blue(c) * 0.114f).toInt()
        }.sorted()
        if (luminance.isEmpty()) return copy
        val low = luminance[(luminance.size * 0.04f).toInt().coerceIn(0, luminance.lastIndex)]
        val high = luminance[(luminance.size * 0.96f).toInt().coerceIn(0, luminance.lastIndex)]
        if (high - low < 28) return copy
        val out = IntArray(sample.size)
        for (i in sample.indices) {
            val c = sample[i]
            fun norm(v: Int): Int = (((v - low) * 255f) / (high - low).coerceAtLeast(1)).roundToInt().coerceIn(0, 255)
            out[i] = Color.argb(Color.alpha(c), norm(Color.red(c)), norm(Color.green(c)), norm(Color.blue(c)))
        }
        copy.setPixels(out, 0, copy.width, 0, 0, copy.width, copy.height)
        return copy
    }
}

private object VisualDnaDescriptor {
    private const val SIZE = 32
    private const val GRID = 4

    fun rotationBank(bitmap: Bitmap): List<ByteArray> {
        val result = ArrayList<ByteArray>(4)
        result += extract(bitmap)

        var previous: Bitmap = bitmap
        repeat(3) {
            val rotated = rotate90(previous)
            if (previous !== bitmap && !previous.isRecycled) previous.recycle()
            result += extract(rotated)
            previous = rotated
        }
        if (previous !== bitmap && !previous.isRecycled) previous.recycle()
        return result
    }

    fun extract(bitmap: Bitmap): ByteArray {
        val scaled = if (bitmap.width == SIZE && bitmap.height == SIZE) bitmap else Bitmap.createScaledBitmap(bitmap, SIZE, SIZE, true)
        try {
            val pixels = IntArray(SIZE * SIZE)
            scaled.getPixels(pixels, 0, SIZE, 0, 0, SIZE, SIZE)
            val border = borderMean(pixels)
            val gray = FloatArray(pixels.size)
            val weight = FloatArray(pixels.size)
            for (i in pixels.indices) {
                val c = pixels[i]
                val r = Color.red(c).toFloat()
                val g = Color.green(c).toFloat()
                val b = Color.blue(c).toFloat()
                gray[i] = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
                val dr = r - border[0]
                val dg = g - border[1]
                val db = b - border[2]
                val d = sqrt(dr * dr + dg * dg + db * db) / 441.7f
                weight[i] = (0.28f + d * 0.72f).coerceIn(0.28f, 1f)
            }

            val values = ArrayList<Int>(64)
            val cell = SIZE / GRID
            for (gy in 0 until GRID) for (gx in 0 until GRID) {
                var sum = 0f; var wsum = 0f
                for (y in gy * cell until (gy + 1) * cell) for (x in gx * cell until (gx + 1) * cell) {
                    val idx = y * SIZE + x
                    sum += gray[idx] * weight[idx]; wsum += weight[idx]
                }
                values += ((sum / wsum.coerceAtLeast(1e-4f)) * 255f).roundToInt().coerceIn(0, 255)
            }
            // 16 weighted edge cells.
            for (gy in 0 until GRID) for (gx in 0 until GRID) {
                var sum = 0f; var count = 0
                val y0 = gy * cell; val y1 = minOf(SIZE - 1, (gy + 1) * cell)
                val x0 = gx * cell; val x1 = minOf(SIZE - 1, (gx + 1) * cell)
                for (y in maxOf(1, y0) until y1) for (x in maxOf(1, x0) until x1) {
                    val idx = y * SIZE + x
                    val dx = abs(gray[idx] - gray[idx - 1])
                    val dy = abs(gray[idx] - gray[idx - SIZE])
                    sum += (dx + dy) * 0.5f * weight[idx]; count++
                }
                values += ((sum / count.coerceAtLeast(1)) * 255f * 2f).roundToInt().coerceIn(0, 255)
            }
            // 16-bin luminance histogram.
            val hist = IntArray(16)
            for (i in gray.indices) hist[(gray[i] * 15f).roundToInt().coerceIn(0, 15)]++
            val maxHist = hist.maxOrNull()?.coerceAtLeast(1) ?: 1
            hist.forEach { values += (it * 255 / maxHist).coerceIn(0, 255) }
            // 8 horizontal + 8 vertical object-relative projections.
            for (bin in 0 until 8) {
                var sum = 0f
                val y0 = bin * SIZE / 8; val y1 = (bin + 1) * SIZE / 8
                for (y in y0 until y1) for (x in 0 until SIZE) sum += gray[y * SIZE + x]
                values += (sum / ((y1 - y0) * SIZE) * 255f).roundToInt().coerceIn(0, 255)
            }
            for (bin in 0 until 8) {
                var sum = 0f
                val x0 = bin * SIZE / 8; val x1 = (bin + 1) * SIZE / 8
                for (x in x0 until x1) for (y in 0 until SIZE) sum += gray[y * SIZE + x]
                values += (sum / ((x1 - x0) * SIZE) * 255f).roundToInt().coerceIn(0, 255)
            }
            return ByteArray(values.size) { values[it].toByte() }
        } finally {
            if (scaled !== bitmap && !scaled.isRecycled) scaled.recycle()
        }
    }

    private fun borderMean(pixels: IntArray): FloatArray {
        var r = 0f; var g = 0f; var b = 0f; var n = 0
        for (x in 0 until SIZE) for (y in intArrayOf(0, SIZE - 1)) {
            val c = pixels[y * SIZE + x]; r += Color.red(c); g += Color.green(c); b += Color.blue(c); n++
        }
        for (y in 1 until SIZE - 1) for (x in intArrayOf(0, SIZE - 1)) {
            val c = pixels[y * SIZE + x]; r += Color.red(c); g += Color.green(c); b += Color.blue(c); n++
        }
        return floatArrayOf(r / n.coerceAtLeast(1), g / n.coerceAtLeast(1), b / n.coerceAtLeast(1))
    }

    private fun rotate90(source: Bitmap): Bitmap {
        val matrix = android.graphics.Matrix().apply { postRotate(90f) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }
}
