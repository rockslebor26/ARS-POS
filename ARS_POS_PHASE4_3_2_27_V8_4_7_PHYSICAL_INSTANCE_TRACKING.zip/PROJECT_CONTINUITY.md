# ARS POS — OFFICIAL CONTINUOUS PROJECT BASELINE

Baseline resmi saat ini: **Phase 4.3.2.27 / V8.4.7 / 1.4.2 (142)**.

Aturan permanen setiap update berikutnya:
1. `applicationId` harus tetap `com.arspos.anglerriausyndicate`.
2. Gunakan ARS POS OFFICIAL RELEASE signing key yang sama.
3. `versionCode` harus selalu meningkat.
4. Jangan uninstall official app saat upgrade; install APK baru sebagai update in-place.
5. Room database migration wajib aman bila schema berubah.
6. Flight Recorder + ChatGPT report wajib membawa current/previous version, transition, package, signer SHA-256, dan scanner pipeline metadata.
7. Full-frame rescue tidak boleh menghasilkan quantity penjualan.
8. Satu physical long object tidak boleh dihitung dua kali hanya karena beberapa proposal/crop.
9. Jangan menurunkan threshold hanya untuk memaksa recognition.
10. Setiap ZIP release dan `build-apk.yml` harus memakai penamaan yang sama persis.
