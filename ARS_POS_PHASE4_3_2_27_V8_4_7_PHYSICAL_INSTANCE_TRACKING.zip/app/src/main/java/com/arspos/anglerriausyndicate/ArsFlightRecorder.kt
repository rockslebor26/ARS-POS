package com.arspos.anglerriausyndicate

import android.content.Context
import android.os.Build
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Phase 4.3.2.27 V8.4.7 — ARS Flight Recorder + Physical Instance Tracking.
 *
 * A tiny, offline-first rolling diagnostic log for development. It intentionally
 * stores technical scanner/app metadata only. Transaction details, PINs and
 * customer data are not written here.
 */
object ArsFlightRecorder {
    private const val DIR = "ars_diagnostics"
    private const val LOG = "flight_recorder.jsonl"
    private const val MAX_BYTES = 1_500_000L
    private const val KEEP_BYTES = 900_000L
    private const val MAX_REPORT_LINES = 160

    @Volatile private var appContext: Context? = null
    @Volatile private var installedCrashHandler = false

    fun install(context: Context) {
        appContext = context.applicationContext
        if (!installedCrashHandler) {
            synchronized(this) {
                if (!installedCrashHandler) {
                    installedCrashHandler = true
                    val previous = Thread.getDefaultUncaughtExceptionHandler()
                    Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
                        runCatching {
                            event(
                                type = "UNCAUGHT_CRASH",
                                message = throwable.message ?: throwable::class.java.simpleName,
                                fields = mapOf(
                                    "thread" to thread.name,
                                    "exception" to throwable::class.java.name,
                                    "stack" to throwable.stackTraceToString().take(18_000)
                                )
                            )
                        }
                        previous?.uncaughtException(thread, throwable)
                    }
                }
            }
        }
        val update = ArsUpdateChannel.observeLaunch(context)
        event(
            "APP_START",
            "ARS POS started",
            baseDeviceFields() + mapOf(
                "version" to update.versionName,
                "versionCode" to update.versionCode,
                "installTransition" to update.lastTransition,
                "signingChannel" to update.signingChannel,
                "signerSha256" to update.signerSha256
            )
        )
    }

    fun newSession(prefix: String = "scan"): String =
        "$prefix-${System.currentTimeMillis()}-${UUID.randomUUID().toString().take(6)}"

    @Synchronized
    fun event(type: String, message: String = "", fields: Map<String, Any?> = emptyMap()) {
        val context = appContext ?: return
        runCatching {
            val dir = File(context.filesDir, DIR).apply { mkdirs() }
            val file = File(dir, LOG)
            rotateIfNeeded(file)

            val obj = JSONObject()
            obj.put("ts", System.currentTimeMillis())
            obj.put("time", isoNow())
            obj.put("type", type)
            obj.put("message", message)
            fields.forEach { (key, value) -> obj.put(key, sanitize(value)) }
            file.appendText(obj.toString() + "\n")
        }
    }

    @Synchronized
    fun buildReport(context: Context): String {
        if (appContext == null) appContext = context.applicationContext
        val update = ArsUpdateChannel.snapshot(context)
        val file = File(File(context.filesDir, DIR), LOG)
        val lines = if (file.exists()) file.readLines().takeLast(MAX_REPORT_LINES) else emptyList()
        val parsed = lines.mapNotNull { runCatching { JSONObject(it) }.getOrNull() }
        val crashes = parsed.count { it.optString("type") == "UNCAUGHT_CRASH" || it.optString("type") == "SCAN_FATAL" }
        val scanStarts = parsed.count { it.optString("type") == "SCAN_START" }
        val scanCompleted = parsed.count { it.optString("type") == "SCAN_COMPLETE" }
        val scanErrors = parsed.count { it.optString("type") == "SCAN_ERROR" || it.optString("type") == "SCAN_FATAL" }
        val completeDurations = parsed.filter { it.optString("type") == "SCAN_COMPLETE" }.map { it.optLong("durationMs", 0L) }.filter { it > 0L }
        val avgScanMs = if (completeDurations.isEmpty()) 0L else completeDurations.sum() / completeDurations.size
        val scoringDurations = parsed.filter { it.optString("type") == "SCAN_SCORING" }.map { it.optLong("durationMs", 0L) }.filter { it > 0L }
        val avgScoringMs = if (scoringDurations.isEmpty()) 0L else scoringDurations.sum() / scoringDurations.size
        val latestAggregation = parsed.lastOrNull { it.optString("type") == "SCAN_AGGREGATION" }
        val latestProposalMerge = parsed.lastOrNull { it.optString("type") == "SCAN_PROPOSAL_MERGE" }
        val latestUpdate = parsed.lastOrNull { it.optString("type") == "APP_UPDATE" }

        return buildString {
            appendLine("ARS POS DEVELOPMENT DIAGNOSTIC REPORT")
            appendLine("Application: ARS POS — ANGLER RIAU SYNDICATE")
            appendLine("Package: ${update.packageName}")
            appendLine("Current Version: ${update.versionName}")
            appendLine("Version Code: ${update.versionCode}")
            appendLine("Phase: 4.3.2.27")
            appendLine("Engine: V8.4.7 — Physical Instance Tracking + Long Object Coordinate Normalization")
            appendLine("Signing Channel: ${update.signingChannel}")
            appendLine("Signer SHA-256: ${update.signerSha256}")
            appendLine("Last Install Transition: ${update.lastTransition}")
            appendLine("Previous Installed Version: ${update.previousVersionName ?: "-"} (${update.previousVersionCode ?: "-"})")
            appendLine("Current Installed Version: ${update.versionName} (${update.versionCode})")
            appendLine("First Install Time: ${ArsUpdateChannel.formatTime(update.firstInstallTime)}")
            appendLine("Last Update Time: ${ArsUpdateChannel.formatTime(update.lastUpdateTime)}")
            appendLine("Transition Recorded At: ${ArsUpdateChannel.formatTime(update.lastTransitionAt)}")
            appendLine("Database Version: 5")
            appendLine("Generated: ${isoNow()}")
            appendLine("Android: ${Build.VERSION.RELEASE} / SDK ${Build.VERSION.SDK_INT}")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
            if (latestUpdate != null) {
                appendLine(
                    "Latest Recorded Update: ${latestUpdate.optString("fromVersion", "?")} " +
                        "(${latestUpdate.optLong("fromVersionCode", -1L)}) -> " +
                        "${latestUpdate.optString("toVersion", "?")} " +
                        "(${latestUpdate.optLong("toVersionCode", -1L)})"
                )
            } else {
                appendLine("Latest Recorded Update: none yet on this installation")
            }
            appendLine()
            appendLine("UPDATE CHANNEL RULE")
            appendLine("- applicationId must remain com.arspos.anglerriausyndicate")
            appendLine("- signer SHA-256 must remain identical across official updates")
            appendLine("- versionCode must always increase")
            appendLine("- uninstalling the official app resets app-private update history and local data")
            appendLine()
            appendLine("SUMMARY")
            appendLine("- Scan sessions started: $scanStarts")
            appendLine("- Scan sessions completed: $scanCompleted")
            appendLine("- Scan errors/fatal events: $scanErrors")
            appendLine("- Uncaught/fatal crash records: $crashes")
            appendLine("- Average completed scan: ${avgScanMs} ms")
            appendLine("- Average object scoring: ${avgScoringMs} ms")
            if (latestProposalMerge != null) {
                appendLine("- Latest proposal merge: ${latestProposalMerge.optInt("input", 0)} -> ${latestProposalMerge.optInt("output", 0)}")
            }
            if (latestAggregation != null) {
                appendLine("- Latest physical aggregation: ${latestAggregation.optInt("before", 0)} -> ${latestAggregation.optInt("after", 0)} (merged ${latestAggregation.optInt("merged", 0)})")
                appendLine("- Latest lineage merges: ${latestAggregation.optInt("lineageMerges", 0)}")
                appendLine("- Latest quantity suppressed: ${latestAggregation.optInt("quantitySuppressed", 0)}")
            }
            appendLine()
            appendLine("PRIVACY")
            appendLine("Technical diagnostics only. PIN, payment data and customer details are intentionally excluded.")
            appendLine()
            appendLine("RECENT EVENTS (oldest -> newest)")
            if (lines.isEmpty()) appendLine("No diagnostic events yet.")
            lines.forEach { appendLine(it) }
        }
    }

    @Synchronized
    fun clear(context: Context) {
        val file = File(File(context.filesDir, DIR), LOG)
        if (file.exists()) file.delete()
        event("LOG_CLEARED", "Diagnostic log cleared")
    }

    private fun rotateIfNeeded(file: File) {
        if (!file.exists() || file.length() < MAX_BYTES) return
        val bytes = file.readBytes()
        val start = (bytes.size - KEEP_BYTES.toInt()).coerceAtLeast(0)
        val tail = bytes.copyOfRange(start, bytes.size)
        var firstNewline = 0
        while (firstNewline < tail.size && tail[firstNewline] != '\n'.code.toByte()) firstNewline++
        val clean = if (firstNewline < tail.size - 1) tail.copyOfRange(firstNewline + 1, tail.size) else tail
        file.writeBytes(clean)
    }

    private fun sanitize(value: Any?): Any = when (value) {
        null -> JSONObject.NULL
        is Number, is Boolean, is String -> if (value is String) value.take(18_000) else value
        else -> value.toString().take(18_000)
    }

    private fun baseDeviceFields(): Map<String, Any?> = mapOf(
        "android" to Build.VERSION.RELEASE,
        "sdk" to Build.VERSION.SDK_INT,
        "device" to "${Build.MANUFACTURER} ${Build.MODEL}"
    )

    private fun isoNow(): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).format(Date())
}
