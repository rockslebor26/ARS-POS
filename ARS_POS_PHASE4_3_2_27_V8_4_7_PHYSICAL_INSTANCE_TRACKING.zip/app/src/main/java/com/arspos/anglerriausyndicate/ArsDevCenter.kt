package com.arspos.anglerriausyndicate

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** V8.4.7 diagnostics + official update metadata + physical-instance lineage report. */
@Composable
fun ArsDevCenterDialog(context: Context, onDismiss: () -> Unit) {
    var report by remember { mutableStateOf(ArsFlightRecorder.buildReport(context)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("ARS DEV CENTER", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 520.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("FLIGHT RECORDER • OFFICIAL UPDATE CHANNEL", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(
                    "Mencatat scan, source/type/lineage proposal, normalized bounds, agregasi physical-instance, quantity safety, skor kandidat, durasi, error/crash, versi terpasang, riwayat update dan fingerprint signing. Data transaksi/PIN tidak dimasukkan.",
                    fontSize = 11.sp
                )
                Text(report, fontSize = 9.sp)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { report = ArsFlightRecorder.buildReport(context) }) {
                        Text("REFRESH", fontSize = 10.sp)
                    }
                    Button(onClick = { shareReportToChatGPT(context, report) }) {
                        Text("🤖 CHATGPT REPORT", fontSize = 10.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("SELESAI") }
        },
        dismissButton = {
            TextButton(onClick = {
                ArsFlightRecorder.clear(context)
                report = ArsFlightRecorder.buildReport(context)
            }) { Text("HAPUS LOG") }
        }
    )
}

fun shareReportToChatGPT(context: Context, report: String) {
    val prompt = buildString {
        appendLine("Tolong analisis report ARS POS berikut sebagai software engineer Android.")
        appendLine("Report ini berasal dari build ARS POS terbaru yang sedang terpasang; metadata versi, previous version, update transition, package, dan signer SHA-256 ada di bagian atas report.")
        appendLine("Prioritaskan penyebab force close, memory pressure, scanner pipeline, keamanan update in-place, dan rekomendasi perbaikan yang paling aman.")
        appendLine("Jika metadata update menunjukkan perubahan signer/package atau versionCode tidak meningkat, tandai sebagai masalah distribusi prioritas tinggi.")
        appendLine("Jangan sarankan menurunkan threshold recognition hanya agar produk terlihat dikenali. Prioritaskan duplicate quantity, proposal lineage, coordinate normalization, typed NORMAL/LONG lane, dan full-frame rescue safety.")
        appendLine()
        append(report)
    }

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "ARS POS Diagnostic Report")
        putExtra(Intent.EXTRA_TEXT, prompt)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    // Prefer the ChatGPT Android app if installed. Fall back to Android chooser.
    val chatGptIntent = Intent(intent).apply { setPackage("com.openai.chatgpt") }
    val manager = context.packageManager
    if (chatGptIntent.resolveActivity(manager) != null) {
        context.startActivity(chatGptIntent)
    } else {
        context.startActivity(Intent.createChooser(intent, "Kirim report ke ChatGPT / OpenAI").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
