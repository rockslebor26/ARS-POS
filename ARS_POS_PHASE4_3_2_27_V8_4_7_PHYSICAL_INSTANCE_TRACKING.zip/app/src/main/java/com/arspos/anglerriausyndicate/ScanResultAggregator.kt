package com.arspos.anglerriausyndicate

import android.graphics.Rect
import com.arspos.anglerriausyndicate.data.RecognitionCandidate
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.27 V8.4.7 — physical-instance aggregation + quantity safety.
 *
 * The cashier must count physical products, not scanner proposals. Long-object
 * proposals can describe different segments/orientations of one rod. This
 * aggregator therefore gives proposal lineage and long-SKU quantity safety a
 * higher priority than raw rectangle IoU.
 *
 * Important safety rule: aggregation never promotes UNKNOWN to accepted.
 */
object ScanResultAggregator {
    data class Summary(
        val before: Int,
        val after: Int,
        val merged: Int,
        val longGroups: Int,
        val lineageMerges: Int = 0,
        val quantitySuppressed: Int = 0
    )

    data class Aggregated(
        val objects: List<VisualScanObject>,
        val summary: Summary
    )

    fun aggregate(input: List<VisualScanObject>): Aggregated {
        val eligible = input.filter { it.quantityEligible }
        if (eligible.size <= 1) {
            return Aggregated(
                eligible,
                Summary(
                    before = eligible.size,
                    after = eligible.size,
                    merged = 0,
                    longGroups = eligible.count { isLong(it) }
                )
            )
        }

        var lineageMerges = 0
        val groups = mutableListOf<MutableList<VisualScanObject>>()
        eligible.sortedBy { it.index }.forEach { candidate ->
            val group = groups.firstOrNull { existing ->
                existing.any { current ->
                    val same = samePhysicalObject(current, candidate)
                    if (same && current.lineageId.isNotBlank() && current.lineageId == candidate.lineageId) {
                        lineageMerges++
                    }
                    same
                }
            }
            if (group != null) group += candidate else groups += mutableListOf(candidate)
        }

        var longGroups = 0
        var firstPass = groups.map { group ->
            if (group.any { isLong(it) }) longGroups++
            mergeGroup(group)
        }.sortedBy { it.index }

        // Quantity-safety second pass. If the same accepted LONG SKU appears in
        // several ambiguous proposal groups, count one unless we can prove the
        // groups are physically distinct parallel instances.
        var quantitySuppressed = 0
        val safe = mutableListOf<VisualScanObject>()
        firstPass.forEach { candidate ->
            val acceptedProductId = candidate.match?.product?.id
            if (acceptedProductId == null || !isLong(candidate)) {
                safe += candidate
                return@forEach
            }

            val existingIndex = safe.indexOfFirst { existing ->
                existing.match?.product?.id == acceptedProductId &&
                    isLong(existing) &&
                    !confirmedDistinctParallel(existing, candidate)
            }
            if (existingIndex >= 0) {
                val merged = mergeGroup(listOf(safe[existingIndex], candidate)).copy(
                    reason = mergeReason(safe[existingIndex].reason, candidate.reason, "QUANTITY-SAFETY LONG SKU")
                )
                safe[existingIndex] = merged
                quantitySuppressed++
            } else {
                safe += candidate
            }
        }

        firstPass = safe.sortedBy { it.index }
            .mapIndexed { index, item -> item.copy(index = index + 1) }

        return Aggregated(
            objects = firstPass,
            summary = Summary(
                before = eligible.size,
                after = firstPass.size,
                merged = (eligible.size - firstPass.size).coerceAtLeast(0),
                longGroups = longGroups,
                lineageMerges = lineageMerges,
                quantitySuppressed = quantitySuppressed
            )
        )
    }

    private fun mergeGroup(group: List<VisualScanObject>): VisualScanObject {
        if (group.size == 1) return group.first()

        val representative = group.sortedWith(
            compareByDescending<VisualScanObject> { it.match != null }
                .thenByDescending { it.finalScore }
                .thenByDescending { it.visualScore }
        ).first()

        val bounds = union(group.map { it.normalizedBounds })
        val original = union(group.map { it.originalBounds })
        val candidates = mergeCandidates(group)
        val proposalIds = group.map { it.proposalId }.filter { it.isNotBlank() }.distinct().joinToString("+")
        val lineages = group.map { it.lineageId }.filter { it.isNotBlank() }.distinct()
        val sources = group.map { it.proposalSource }.filter { it.isNotBlank() }.distinct().joinToString("+")

        return representative.copy(
            index = group.minOf { it.index },
            bounds = bounds,
            originalBounds = original,
            normalizedBounds = bounds,
            proposalId = proposalIds.ifBlank { representative.proposalId },
            proposalSource = sources.ifBlank { representative.proposalSource },
            lineageId = if (lineages.size == 1) lineages.first() else representative.lineageId,
            reason = mergeReason(representative.reason, "", "AGGREGATED ${group.size} proposal"),
            candidates = candidates
        )
    }

    private fun mergeReason(first: String, second: String, suffix: String): String {
        val base = listOf(first, second).map { it.trim() }.filter { it.isNotBlank() }.distinct().joinToString(" • ")
        return if (base.contains(suffix)) base else listOf(base, suffix).filter { it.isNotBlank() }.joinToString(" • ")
    }

    private fun mergeCandidates(group: List<VisualScanObject>): List<RecognitionCandidate> {
        val all = group.flatMap { it.candidates }
        if (all.isEmpty()) return emptyList()

        return all.groupBy { it.product.id }
            .values
            .map { sameProduct ->
                val best = sameProduct.maxWithOrNull(
                    compareBy<RecognitionCandidate> { it.finalScore }
                        .thenBy { it.textScore }
                        .thenBy { it.visualScore }
                ) ?: sameProduct.first()
                val support = sameProduct.size
                best.copy(
                    evidence = if (support > 1) "${best.evidence} • support=$support" else best.evidence
                )
            }
            .sortedWith(
                compareByDescending<RecognitionCandidate> { it.finalScore }
                    .thenByDescending { it.textScore }
                    .thenByDescending { it.visualScore }
            )
            .take(5)
    }

    private fun samePhysicalObject(a: VisualScanObject, b: VisualScanObject): Boolean {
        if (
            a.lineageId.isNotBlank() &&
            a.lineageId == b.lineageId &&
            (isLong(a) || isLong(b))
        ) return true

        val ra = a.normalizedBounds
        val rb = b.normalizedBounds
        if (iou(ra, rb) >= 0.34f) return true
        if (intersectionOverSmaller(ra, rb) >= 0.66f) return true

        val areaA = area(ra)
        val areaB = area(rb)
        val minArea = min(areaA, areaB).coerceAtLeast(1L)
        val maxArea = max(areaA, areaB).coerceAtLeast(1L)
        val areaRatio = maxArea.toFloat() / minArea.toFloat()

        val distance = centerDistance(ra, rb)
        val minDiag = min(diagonal(ra), diagonal(rb)).coerceAtLeast(1f)
        if (distance <= minDiag * 0.15f && areaRatio <= 2.15f) return true

        val topA = topCandidate(a)
        val topB = topCandidate(b)
        val sameProduct = topA != null && topB != null && topA.product.id == topB.product.id
        val longObject = isLong(a) || isLong(b) || topA?.isLongObject == true || topB?.isLongObject == true

        if (sameProduct && longObject) {
            // Same accepted long SKU from perpendicular/segment proposals is
            // ambiguous, so merge unless we can prove two parallel instances.
            if (!confirmedDistinctParallel(a, b)) return true
            if (longAligned(ra, rb)) return true
        }

        return false
    }

    /**
     * Proves two long proposals are separate physical instances. We require:
     * same orientation, strong overlap along the long axis, and a clear gap on
     * the short axis. Without all three, counting two units would be unsafe.
     */
    private fun confirmedDistinctParallel(a: VisualScanObject, b: VisualScanObject): Boolean {
        val ra = a.normalizedBounds
        val rb = b.normalizedBounds
        val aVertical = isVertical(ra)
        val bVertical = isVertical(rb)
        val aHorizontal = isHorizontal(ra)
        val bHorizontal = isHorizontal(rb)

        if (aVertical && bVertical) {
            val longOverlap = axisOverlap(ra.top, ra.bottom, rb.top, rb.bottom)
            val minLength = min(ra.height(), rb.height()).coerceAtLeast(1)
            val shortGap = abs(centerX(ra) - centerX(rb))
            val shortScale = max(ra.width(), rb.width()).coerceAtLeast(1)
            return longOverlap.toFloat() / minLength >= 0.55f && shortGap >= shortScale * 1.65f
        }

        if (aHorizontal && bHorizontal) {
            val longOverlap = axisOverlap(ra.left, ra.right, rb.left, rb.right)
            val minLength = min(ra.width(), rb.width()).coerceAtLeast(1)
            val shortGap = abs(centerY(ra) - centerY(rb))
            val shortScale = max(ra.height(), rb.height()).coerceAtLeast(1)
            return longOverlap.toFloat() / minLength >= 0.55f && shortGap >= shortScale * 1.65f
        }

        // Perpendicular long proposals cannot independently prove quantity.
        return false
    }

    private fun longAligned(a: Rect, b: Rect): Boolean {
        if (isVertical(a) && isVertical(b)) {
            val overlap = axisOverlap(a.top, a.bottom, b.top, b.bottom)
            val minLength = min(a.height(), b.height()).coerceAtLeast(1)
            val centerDx = abs(centerX(a) - centerX(b))
            val widthScale = max(a.width(), b.width()).coerceAtLeast(1)
            return overlap.toFloat() / minLength >= 0.30f && centerDx <= widthScale * 0.95f
        }

        if (isHorizontal(a) && isHorizontal(b)) {
            val overlap = axisOverlap(a.left, a.right, b.left, b.right)
            val minLength = min(a.width(), b.width()).coerceAtLeast(1)
            val centerDy = abs(centerY(a) - centerY(b))
            val heightScale = max(a.height(), b.height()).coerceAtLeast(1)
            return overlap.toFloat() / minLength >= 0.30f && centerDy <= heightScale * 0.95f
        }

        return false
    }

    private fun isLong(item: VisualScanObject): Boolean =
        item.proposalType == ScanProposal.TYPE_LONG ||
            item.candidates.firstOrNull()?.isLongObject == true ||
            item.match?.let { match -> item.candidates.firstOrNull { it.product.id == match.product.id }?.isLongObject } == true

    private fun topCandidate(item: VisualScanObject): RecognitionCandidate? = item.candidates.firstOrNull()

    private fun union(rects: List<Rect>): Rect = Rect(
        rects.minOf { it.left },
        rects.minOf { it.top },
        rects.maxOf { it.right },
        rects.maxOf { it.bottom }
    )

    private fun area(r: Rect): Long =
        r.width().coerceAtLeast(0).toLong() * r.height().coerceAtLeast(0).toLong()

    private fun iou(a: Rect, b: Rect): Float {
        val intersection = intersectionArea(a, b)
        if (intersection <= 0L) return 0f
        val union = area(a) + area(b) - intersection
        return if (union <= 0L) 0f else intersection.toFloat() / union.toFloat()
    }

    private fun intersectionOverSmaller(a: Rect, b: Rect): Float {
        val intersection = intersectionArea(a, b)
        val smaller = min(area(a), area(b)).coerceAtLeast(1L)
        return intersection.toFloat() / smaller.toFloat()
    }

    private fun intersectionArea(a: Rect, b: Rect): Long {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0L
        return (right - left).toLong() * (bottom - top).toLong()
    }

    private fun centerDistance(a: Rect, b: Rect): Float = hypot(centerX(a) - centerX(b), centerY(a) - centerY(b))
    private fun centerX(r: Rect): Float = (r.left + r.right) / 2f
    private fun centerY(r: Rect): Float = (r.top + r.bottom) / 2f
    private fun diagonal(r: Rect): Float = hypot(r.width().toFloat(), r.height().toFloat())
    private fun isVertical(r: Rect): Boolean = r.height() >= r.width() * 1.45f
    private fun isHorizontal(r: Rect): Boolean = r.width() >= r.height() * 1.45f
    private fun axisOverlap(a0: Int, a1: Int, b0: Int, b1: Int): Int =
        (min(a1, b1) - max(a0, b0)).coerceAtLeast(0)
}
