package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Phase 4.3.2.27 V8.4.7 scanner proposal frontend.
 *
 * ML Kit and long-object proposals are kept as typed metadata instead of bare
 * rectangles. This prevents a floor line/rod band from silently becoming a
 * normal product proposal and gives the aggregator a stable lineage for
 * quantity safety.
 */
object SmartVisualScanner {
    private const val MAX_OBJECTS = 6
    private const val MIN_OBJECT_AREA_RATIO = 0.012f
    private const val MAX_BOX_IOU = 0.32f
    private const val LONG_ASPECT = 2.15f

    private val options = ObjectDetectorOptions.Builder()
        .setDetectorMode(ObjectDetectorOptions.SINGLE_IMAGE_MODE)
        .enableMultipleObjects()
        .build()

    private val detector by lazy { ObjectDetection.getClient(options) }

    suspend fun detectProposals(bitmap: Bitmap): List<ScanProposal> {
        val rects = detectObjectRects(bitmap)
        return rects.mapIndexed { index, rect ->
            val normalized = ScanCoordinateNormalizer.normalize(rect, 0, bitmap.width, bitmap.height)
            val longLike = isLongRect(normalized)
            ScanProposal(
                proposalId = "ML-${index + 1}",
                source = ScanProposal.SOURCE_MLKIT,
                proposalType = if (longLike) ScanProposal.TYPE_LONG else ScanProposal.TYPE_NORMAL,
                originalBounds = Rect(rect),
                normalizedBounds = normalized,
                rotationDegrees = 0,
                lineageId = if (longLike) longLineage(normalized, bitmap.width, bitmap.height) else "ML-${index + 1}",
                quantityEligible = true,
                orientation = orientationOf(normalized),
                strength = 70
            )
        }
    }

    /** Backward-compatible helper for older callers. */
    suspend fun detectObjects(bitmap: Bitmap): List<Rect> =
        detectProposals(bitmap).map { Rect(it.normalizedBounds) }

    private suspend fun detectObjectRects(bitmap: Bitmap): List<Rect> {
        val imageW = bitmap.width
        val imageH = bitmap.height
        val imageArea = imageW.toLong() * imageH.toLong()
        val regions = listOf(
            Rect(0, 0, imageW, imageH),
            tile(imageW, imageH, 0, 0),
            tile(imageW, imageH, 1, 0),
            tile(imageW, imageH, 0, 1),
            tile(imageW, imageH, 1, 1)
        )

        val all = ArrayList<Rect>()
        for (region in regions.distinctBy { "${it.left}:${it.top}:${it.right}:${it.bottom}" }) {
            val crop = runCatching {
                Bitmap.createBitmap(bitmap, region.left, region.top, region.width(), region.height())
            }.getOrNull() ?: continue
            val detected = runCatching {
                detector.process(InputImage.fromBitmap(crop, 0)).await()
            }.getOrElse { emptyList() }
            detected.forEach { obj ->
                val b = obj.boundingBox
                val mapped = Rect(
                    region.left + b.left,
                    region.top + b.top,
                    region.left + b.right,
                    region.top + b.bottom
                )
                val safe = expandAndClamp(mapped, imageW, imageH)
                val area = safe.width().toLong() * safe.height().toLong()
                if (
                    safe.width() >= 24 &&
                    safe.height() >= 24 &&
                    area.toDouble() / imageArea.toDouble() >= MIN_OBJECT_AREA_RATIO
                ) {
                    all += safe
                }
            }
            if (crop !== bitmap && !crop.isRecycled) crop.recycle()
        }

        val selected = ArrayList<Rect>()
        all.sortedByDescending { it.width().toLong() * it.height().toLong() }.forEach { candidate ->
            if (selected.none { samePhysicalProposal(it, candidate) }) selected += candidate
        }

        return selected.sortedWith(
            compareBy<Rect> { fullFramePenalty(it, imageW, imageH) }
                .thenByDescending { it.width().toLong() * it.height().toLong() }
        ).take(MAX_OBJECTS)
    }

    /**
     * V8.4.7 typed proposal merge. NORMAL and LONG lanes are deliberately not
     * collapsed together unless the ML Kit rectangle is itself clearly long
     * and aligned with the long proposal. Compact products therefore cannot be
     * converted into a rod proposal merely because a floor/tile line crosses
     * their box.
     */
    fun mergeProposalMetadata(
        base: List<ScanProposal>,
        extra: List<ScanProposal>,
        maxObjects: Int = MAX_OBJECTS
    ): List<ScanProposal> {
        val normal = ArrayList<ScanProposal>()
        val long = ArrayList<ScanProposal>()

        (base + extra).forEach { candidate ->
            when (candidate.proposalType) {
                ScanProposal.TYPE_LONG -> {
                    val existingIndex = long.indexOfFirst { sameTypedLongProposal(it, candidate) }
                    if (existingIndex >= 0) long[existingIndex] = mergeMetadata(long[existingIndex], candidate)
                    else long += candidate
                }
                ScanProposal.TYPE_RESCUE -> Unit
                else -> {
                    val existingIndex = normal.indexOfFirst {
                        samePhysicalProposal(it.normalizedBounds, candidate.normalizedBounds)
                    }
                    if (existingIndex >= 0) normal[existingIndex] = mergeMetadata(normal[existingIndex], candidate)
                    else normal += candidate
                }
            }
        }

        // If an ML Kit proposal is itself elongated and tightly aligned with a
        // long band, keep one LONG proposal with a shared lineage.
        val promoted = ArrayList<ScanProposal>()
        val remainingNormal = normal.toMutableList()
        long.forEach { lp ->
            val idx = remainingNormal.indexOfFirst { np ->
                isLongRect(np.normalizedBounds) &&
                    sameOrientation(np.normalizedBounds, lp.normalizedBounds) &&
                    longCrossSourceAligned(np.normalizedBounds, lp.normalizedBounds)
            }
            if (idx >= 0) {
                val np = remainingNormal.removeAt(idx)
                promoted += mergeMetadata(lp, np).copy(
                    proposalType = ScanProposal.TYPE_LONG,
                    source = ScanProposal.SOURCE_MERGED,
                    lineageId = lp.lineageId.ifBlank { np.lineageId }
                )
            } else {
                promoted += lp
            }
        }

        // Keep both lanes represented. Normal products should not disappear
        // because the scene contains several strong tile/rod bands.
        val longSelected = promoted
            .sortedByDescending { it.strength }
            .groupBy { orientationFamily(it.orientation) }
            .values
            .flatMap { group -> group.take(2) }
            .sortedByDescending { it.strength }
            .take(4)

        val normalSelected = remainingNormal
            .sortedByDescending { area(it.normalizedBounds) }
            .take(4)

        val combined = ArrayList<ScanProposal>()
        // Reserve at least two slots for normal proposals when they exist.
        combined += normalSelected.take(min(2, normalSelected.size))
        combined += longSelected
        normalSelected.drop(min(2, normalSelected.size)).forEach { combined += it }

        return combined
            .distinctBy { it.proposalId + ":" + it.lineageId + ":" + rectKey(it.normalizedBounds) }
            .take(maxObjects.coerceIn(1, MAX_OBJECTS))
    }

    /** Legacy V8.4.5 API retained for compatibility. */
    fun mergeProposals(base: List<Rect>, extra: List<Rect>, maxObjects: Int = MAX_OBJECTS): List<Rect> {
        val selected = ArrayList<Rect>()
        (base + extra)
            .sortedByDescending { it.width().toLong() * it.height().toLong() }
            .forEach { candidate ->
                if (selected.none { samePhysicalProposal(it, candidate) }) selected += candidate
            }
        return selected.take(maxObjects.coerceIn(1, MAX_OBJECTS))
    }

    fun crop(bitmap: Bitmap, bounds: Rect): Bitmap? {
        val safe = expandAndClamp(bounds, bitmap.width, bitmap.height)
        if (safe.width() < 24 || safe.height() < 24) return null
        return runCatching {
            Bitmap.createBitmap(bitmap, safe.left, safe.top, safe.width(), safe.height())
        }.getOrNull()
    }

    fun acceptBest(candidates: List<VisualProductMatch>): VisualProductMatch? {
        if (candidates.isEmpty()) return null
        val ranked = candidates.sortedByDescending { it.score }
        val best = ranked.first()
        val second = ranked.getOrNull(1)
        if (best.score < 82) return null
        if (second != null && best.score - second.score < 8) return null
        return best
    }

    private fun mergeMetadata(a: ScanProposal, b: ScanProposal): ScanProposal {
        val preferred = if (a.strength >= b.strength) a else b
        val union = union(a.normalizedBounds, b.normalizedBounds)
        return preferred.copy(
            proposalId = "${preferred.proposalId}+${if (preferred === a) b.proposalId else a.proposalId}",
            source = if (a.source == b.source) a.source else ScanProposal.SOURCE_MERGED,
            proposalType = if (a.proposalType == ScanProposal.TYPE_LONG || b.proposalType == ScanProposal.TYPE_LONG) ScanProposal.TYPE_LONG else preferred.proposalType,
            originalBounds = union(a.originalBounds, b.originalBounds),
            normalizedBounds = union,
            lineageId = if (a.lineageId == b.lineageId) a.lineageId else preferred.lineageId,
            orientation = if (preferred.orientation != "UNKNOWN") preferred.orientation else orientationOf(union),
            strength = max(a.strength, b.strength)
        )
    }

    private fun sameTypedLongProposal(a: ScanProposal, b: ScanProposal): Boolean {
        if (orientationFamily(a.orientation) != orientationFamily(b.orientation)) return false
        if (a.lineageId.isNotBlank() && a.lineageId == b.lineageId) return true
        return longCrossSourceAligned(a.normalizedBounds, b.normalizedBounds)
    }

    private fun longCrossSourceAligned(a: Rect, b: Rect): Boolean {
        if (!sameOrientation(a, b)) return false
        val vertical = isVertical(a) && isVertical(b)
        return if (vertical) {
            val centerDx = kotlin.math.abs(centerX(a) - centerX(b))
            val widthScale = max(a.width(), b.width()).coerceAtLeast(1)
            val overlap = axisOverlap(a.top, a.bottom, b.top, b.bottom)
            val minLength = min(a.height(), b.height()).coerceAtLeast(1)
            centerDx <= widthScale * 0.9f && overlap.toFloat() / minLength >= 0.35f
        } else {
            val centerDy = kotlin.math.abs(centerY(a) - centerY(b))
            val heightScale = max(a.height(), b.height()).coerceAtLeast(1)
            val overlap = axisOverlap(a.left, a.right, b.left, b.right)
            val minLength = min(a.width(), b.width()).coerceAtLeast(1)
            centerDy <= heightScale * 0.9f && overlap.toFloat() / minLength >= 0.35f
        }
    }

    private fun longLineage(rect: Rect, width: Int, height: Int): String {
        val vertical = isVertical(rect)
        val axisSize = if (vertical) width else height
        val center = if (vertical) centerX(rect) else centerY(rect)
        val bucketSize = (axisSize * 0.18f).coerceAtLeast(24f)
        val bucket = (center / bucketSize).toInt()
        return "LONG-${if (vertical) "V" else "H"}-$bucket"
    }

    private fun tile(w: Int, h: Int, col: Int, row: Int): Rect {
        val tw = (w * 0.62f).toInt().coerceAtLeast(64).coerceAtMost(w)
        val th = (h * 0.62f).toInt().coerceAtLeast(64).coerceAtMost(h)
        val left = if (col == 0) 0 else w - tw
        val top = if (row == 0) 0 else h - th
        return Rect(left, top, min(w, left + tw), min(h, top + th))
    }

    private fun samePhysicalProposal(a: Rect, b: Rect): Boolean {
        val overlap = iou(a, b)
        if (overlap >= MAX_BOX_IOU) return true

        val intersection = intersectionArea(a, b)
        val minArea = minOf(area(a), area(b)).coerceAtLeast(1L)
        if (intersection.toFloat() / minArea.toFloat() >= 0.62f) return true

        val distance = hypot(centerX(a) - centerX(b), centerY(a) - centerY(b))
        val scale = minOf(
            hypot(a.width().toFloat(), a.height().toFloat()),
            hypot(b.width().toFloat(), b.height().toFloat())
        ).coerceAtLeast(1f)
        val areaA = area(a).coerceAtLeast(1L)
        val areaB = area(b).coerceAtLeast(1L)
        val areaRatio = maxOf(areaA, areaB).toFloat() / minOf(areaA, areaB).toFloat()
        return distance <= scale * 0.16f && areaRatio <= 1.85f
    }

    private fun fullFramePenalty(rect: Rect, w: Int, h: Int): Int {
        if (w <= 0 || h <= 0) return 0
        val ratio = area(rect).toFloat() / (w.toLong() * h.toLong()).coerceAtLeast(1L).toFloat()
        return if (ratio > 0.82f) 1 else 0
    }

    private fun iou(a: Rect, b: Rect): Float {
        val intersection = intersectionArea(a, b)
        val union = area(a) + area(b) - intersection
        return if (union <= 0L) 0f else intersection.toFloat() / union.toFloat()
    }

    private fun intersectionArea(a: Rect, b: Rect): Long {
        val left = maxOf(a.left, b.left)
        val top = maxOf(a.top, b.top)
        val right = minOf(a.right, b.right)
        val bottom = minOf(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0L
        return (right - left).toLong() * (bottom - top).toLong()
    }

    private fun expandAndClamp(rect: Rect, width: Int, height: Int): Rect {
        val padX = max(8, (rect.width() * 0.08f).toInt())
        val padY = max(8, (rect.height() * 0.08f).toInt())
        return Rect(
            max(0, rect.left - padX),
            max(0, rect.top - padY),
            min(width, rect.right + padX),
            min(height, rect.bottom + padY)
        )
    }

    private fun union(a: Rect, b: Rect): Rect = Rect(
        min(a.left, b.left),
        min(a.top, b.top),
        max(a.right, b.right),
        max(a.bottom, b.bottom)
    )

    private fun rectKey(r: Rect): String = "${r.left}:${r.top}:${r.right}:${r.bottom}"
    private fun area(r: Rect): Long = r.width().coerceAtLeast(0).toLong() * r.height().coerceAtLeast(0).toLong()
    private fun centerX(r: Rect): Float = (r.left + r.right) / 2f
    private fun centerY(r: Rect): Float = (r.top + r.bottom) / 2f
    private fun isVertical(r: Rect): Boolean = r.height() >= r.width() * 1.45f
    private fun isHorizontal(r: Rect): Boolean = r.width() >= r.height() * 1.45f
    private fun isLongRect(r: Rect): Boolean {
        val short = min(r.width(), r.height()).coerceAtLeast(1)
        val long = max(r.width(), r.height())
        return long.toFloat() / short.toFloat() >= LONG_ASPECT
    }
    private fun sameOrientation(a: Rect, b: Rect): Boolean =
        (isVertical(a) && isVertical(b)) || (isHorizontal(a) && isHorizontal(b))
    private fun orientationOf(r: Rect): String = when {
        isVertical(r) -> "VERTICAL"
        isHorizontal(r) -> "HORIZONTAL"
        else -> "COMPACT"
    }
    private fun orientationFamily(value: String): String = when {
        value.startsWith("VERTICAL") -> "VERTICAL"
        value.startsWith("HORIZONTAL") -> "HORIZONTAL"
        else -> value
    }
    private fun axisOverlap(a0: Int, a1: Int, b0: Int, b1: Int): Int =
        (min(a1, b1) - max(a0, b0)).coerceAtLeast(0)

    private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T =
        suspendCancellableCoroutine { continuation ->
            addOnSuccessListener { value -> if (continuation.isActive) continuation.resume(value) }
            addOnFailureListener { error -> if (continuation.isActive) continuation.resumeWithException(error) }
            addOnCanceledListener { continuation.cancel() }
        }
}
