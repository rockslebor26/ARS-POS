package com.arspos.anglerriausyndicate

import android.graphics.Rect

/**
 * Phase 4.3.2.27 V8.4.7 — canonical scanner proposal metadata.
 *
 * All scanner sources are normalized into the same original-image coordinate
 * system before scoring and aggregation. proposalType controls which identity
 * lane is allowed to run; lineageId is used for quantity safety.
 */
data class ScanProposal(
    val proposalId: String,
    val source: String,
    val proposalType: String,
    val originalBounds: Rect,
    val normalizedBounds: Rect,
    val rotationDegrees: Int = 0,
    val lineageId: String,
    val quantityEligible: Boolean = true,
    val orientation: String = "UNKNOWN",
    val strength: Int = 0
) {
    companion object {
        const val TYPE_NORMAL = "NORMAL_OBJECT"
        const val TYPE_LONG = "LONG_OBJECT"
        const val TYPE_RESCUE = "FULL_FRAME_RESCUE"

        const val SOURCE_MLKIT = "MLKIT"
        const val SOURCE_LONG = "LONG_ANALYZER"
        const val SOURCE_MERGED = "MERGED"
        const val SOURCE_RESCUE = "FULL_FRAME_RESCUE"
        const val SOURCE_SCENE_BARCODE = "SCENE_BARCODE"
    }
}
