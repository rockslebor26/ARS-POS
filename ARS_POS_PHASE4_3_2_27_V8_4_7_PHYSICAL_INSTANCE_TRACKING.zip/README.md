# ARS POS — ANGLER RIAU SYNDICATE

Current official baseline:
- Phase **4.3.2.27**
- Engine **V8.4.7**
- Version **1.4.2 (142)**
- Package `com.arspos.anglerriausyndicate`
- Signing channel: **ARS POS OFFICIAL RELEASE**

## V8.4.7 focus
Physical Instance Tracking + Long Object Coordinate Normalization.

The scanner now keeps proposal source/type/lineage metadata, routes NORMAL and LONG products into separate recognition lanes, prevents full-frame rescue from creating cashier quantity, and applies conservative long-SKU quantity safety so one physical rod is not counted multiple times simply because several proposal bands match it.

## Update rule
Install V8.4.7 directly over V8.4.6 Official. Do **not** uninstall the official app. The report should show an `IN_PLACE_UPDATE` transition from 1.4.1 (141) to 1.4.2 (142), with the same package and signer SHA-256.

See:
- `PHASE4_3_2_27_V8_4_7_PHYSICAL_INSTANCE_TRACKING.md`
- `PROJECT_CONTINUITY.md`
- `ARS_OFFICIAL_RELEASE_SETUP.md`
