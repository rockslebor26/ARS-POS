package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.min

/**
 * ARS Product Identity Engine V8.2 object frontend.
 *
 * The normal ML Kit detector can return at most five objects per image. V8
 * supplements the full-frame pass with four overlapping tiles, then merges
 * duplicate boxes. This helps small fishing accessories and products that sit
 * beside larger products in the same customer photo. It remains conservative:
 * object detection only proposes regions; identity is decided later by the
 * hybrid identity engine.
 */
object SmartVisualScanner {
    private const val MAX_OBJECTS = 8
    private const val MIN_OBJECT_AREA_RATIO = 0.012f
    private const val MAX_BOX_IOU = 0.32f

    private val options = ObjectDetectorOptions.Builder()
        .setDetectorMode(ObjectDetectorOptions.SINGLE_IMAGE_MODE)
        .enableMultipleObjects()
        .build()

    private val detector by lazy { ObjectDetection.getClient(options) }

    suspend fun detectObjects(bitmap: Bitmap): List<Rect> {
        val imageW = bitmap.width
        val imageH = bitmap.height
        val imageArea = imageW.toLong() * imageH.toLong()
        val regions = listOf(
            Rect(0, 0, imageW, imageH),
            tile(imageW, imageH, 0, 0),
            tile(imageW, imageH, 1, 0),
            tile(imageW, imageH, 0, 1),
            tile(imageW, imageH, 1, 1)
        )

        val all = ArrayList<Rect>()
        for (region in regions.distinctBy { "${it.left}:${it.top}:${it.right}:${it.bottom}" }) {
            val crop = runCatching { Bitmap.createBitmap(bitmap, region.left, region.top, region.width(), region.height()) }.getOrNull() ?: continue
            val detected = runCatching {
                detector.process(InputImage.fromBitmap(crop, 0)).await()
            }.getOrElse { emptyList() }
            detected.forEach { obj ->
                val b = obj.boundingBox
                val mapped = Rect(
                    region.left + b.left,
                    region.top + b.top,
                    region.left + b.right,
                    region.top + b.bottom
                )
                val safe = expandAndClamp(mapped, imageW, imageH)
                val area = safe.width().toLong() * safe.height().toLong()
                if (safe.width() >= 24 && safe.height() >= 24 && area.toDouble() / imageArea.toDouble() >= MIN_OBJECT_AREA_RATIO) {
                    all += safe
                }
            }
            if (crop !== bitmap) crop.recycle()
        }

        val selected = ArrayList<Rect>()
        all.sortedByDescending { it.width().toLong() * it.height().toLong() }.forEach { candidate ->
            if (selected.none { samePhysicalProposal(it, candidate) }) {
                selected += candidate
            }
        }

        // Prefer compact regions before an oversized full-frame box when there
        // are several real products. The identity engine still rejects weak
        // regions, so this is only a proposal ordering decision.
        return selected.sortedWith(
            compareBy<Rect> { fullFramePenalty(it, imageW, imageH) }
                .thenByDescending { it.width().toLong() * it.height().toLong() }
        ).take(MAX_OBJECTS)
    }

    fun crop(bitmap: Bitmap, bounds: Rect): Bitmap? {
        val safe = expandAndClamp(bounds, bitmap.width, bitmap.height)
        if (safe.width() < 24 || safe.height() < 24) return null
        return runCatching {
            Bitmap.createBitmap(bitmap, safe.left, safe.top, safe.width(), safe.height())
        }.getOrNull()
    }

    fun acceptBest(candidates: List<VisualProductMatch>): VisualProductMatch? {
        if (candidates.isEmpty()) return null
        val ranked = candidates.sortedByDescending { it.score }
        val best = ranked.first()
        val second = ranked.getOrNull(1)
        if (best.score < 82) return null
        if (second != null && best.score - second.score < 8) return null
        return best
    }

    private fun tile(w: Int, h: Int, col: Int, row: Int): Rect {
        // 62% tile size gives overlap between neighboring passes.
        val tw = (w * 0.62f).toInt().coerceAtLeast(64).coerceAtMost(w)
        val th = (h * 0.62f).toInt().coerceAtLeast(64).coerceAtMost(h)
        val left = if (col == 0) 0 else w - tw
        val top = if (row == 0) 0 else h - th
        return Rect(left, top, min(w, left + tw), min(h, top + th))
    }


    /**
     * V8.4.2 proposal de-duplication. Overlapping tile passes often return several
     * slightly shifted boxes for the same physical product. IoU alone is not enough
     * for thin products such as rods, so we also use intersection-over-smaller-area
     * and a conservative center/size test.
     */
    private fun samePhysicalProposal(a: Rect, b: Rect): Boolean {
        val overlap = iou(a, b)
        if (overlap >= MAX_BOX_IOU) return true

        val intersection = intersectionArea(a, b)
        val minArea = minOf(
            a.width().toLong() * a.height().toLong(),
            b.width().toLong() * b.height().toLong()
        ).coerceAtLeast(1L)
        if (intersection.toFloat() / minArea.toFloat() >= 0.62f) return true

        val ax = (a.left + a.right) / 2f
        val ay = (a.top + a.bottom) / 2f
        val bx = (b.left + b.right) / 2f
        val by = (b.top + b.bottom) / 2f
        val distance = kotlin.math.hypot(ax - bx, ay - by)
        val scale = minOf(
            kotlin.math.hypot(a.width().toFloat(), a.height().toFloat()),
            kotlin.math.hypot(b.width().toFloat(), b.height().toFloat())
        ).coerceAtLeast(1f)
        val areaA = (a.width().toLong() * a.height().toLong()).coerceAtLeast(1L)
        val areaB = (b.width().toLong() * b.height().toLong()).coerceAtLeast(1L)
        val areaRatio = maxOf(areaA, areaB).toFloat() / minOf(areaA, areaB).toFloat()
        return distance <= scale * 0.16f && areaRatio <= 1.85f
    }

    private fun intersectionArea(a: Rect, b: Rect): Long {
        val left = maxOf(a.left, b.left)
        val top = maxOf(a.top, b.top)
        val right = minOf(a.right, b.right)
        val bottom = minOf(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0L
        return (right - left).toLong() * (bottom - top).toLong()
    }

    private fun overlapSimilarity(a: Rect, b: Rect): Float {
        val iou = iou(a, b)
        if (iou > 0f) return iou
        val ax = (a.left + a.right) / 2f
        val ay = (a.top + a.bottom) / 2f
        val bx = (b.left + b.right) / 2f
        val by = (b.top + b.bottom) / 2f
        val distance = kotlin.math.hypot(ax - bx, ay - by)
        val scale = max(a.width(), a.height()).coerceAtLeast(1)
        return if (distance < scale * 0.18f) 0.55f else 0f
    }

    private fun fullFramePenalty(rect: Rect, w: Int, h: Int): Int {
        val ratio = rect.width().toFloat() * rect.height() / (w.toFloat() * h.toFloat()).coerceAtLeast(1f)
        return if (ratio > 0.82f) 1 else 0
    }

    private fun iou(a: Rect, b: Rect): Float {
        val left = maxOf(a.left, b.left)
        val top = maxOf(a.top, b.top)
        val right = minOf(a.right, b.right)
        val bottom = minOf(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val intersection = (right - left).toLong() * (bottom - top).toLong()
        val union = a.width().toLong() * a.height().toLong() +
            b.width().toLong() * b.height().toLong() - intersection
        return if (union <= 0L) 0f else intersection.toFloat() / union.toFloat()
    }

    private fun expandAndClamp(rect: Rect, width: Int, height: Int): Rect {
        val padX = max(8, (rect.width() * 0.08f).toInt())
        val padY = max(8, (rect.height() * 0.08f).toInt())
        return Rect(
            max(0, rect.left - padX),
            max(0, rect.top - padY),
            min(width, rect.right + padX),
            min(height, rect.bottom + padY)
        )
    }

    private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T =
        suspendCancellableCoroutine { continuation ->
            addOnSuccessListener { value -> if (continuation.isActive) continuation.resume(value) }
            addOnFailureListener { error -> if (continuation.isActive) continuation.resumeWithException(error) }
            addOnCanceledListener { continuation.cancel() }
        }
}
