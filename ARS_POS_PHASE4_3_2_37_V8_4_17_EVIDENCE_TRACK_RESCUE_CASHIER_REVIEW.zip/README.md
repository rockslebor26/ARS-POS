# ARS POS 1.5.2 (152) / Phase 4.3.2.37 / V8.4.17

**Evidence Integrity + Physical Track Truth + Rescue Gate V2 + Cashier Scan Review**

This package is the direct successor to ARS POS 1.5.1 / V8.4.16. It keeps the official application ID, Room database v5, recognition thresholds, update channel and release-signing requirements unchanged.

Key additions: mutable diagnostic overlays, unique physical-track evidence IDs, crossing-aware rod continuity, authenticity-qualified Rescue Gate V2, interactive object boxes, quantity confirmation with one-commit-per-scan-session protection, focused visual scan report export, and a simplified cashier screen with technical data behind **DETAIL DIAGNOSTIK**.

See `PHASE4_3_2_37_V8_4_17_EVIDENCE_TRACK_RESCUE_CASHIER_REVIEW.md` for engineering details.
