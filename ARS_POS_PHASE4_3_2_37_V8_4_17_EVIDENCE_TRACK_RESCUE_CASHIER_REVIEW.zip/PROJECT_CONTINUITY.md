# ARS POS Project Continuity

Current engineering baseline: **1.5.2 (152) / Phase 4.3.2.37 / V8.4.17**.

V8.4.17 continues directly from V8.4.16 Visual Evidence Recorder. It repairs immutable-bitmap overlay evidence, hardens physical track identity, adds intersection-aware rod continuity and Rescue Gate V2, then adds cashier-facing interactive object review, quantity confirmation with duplicate-session commit prevention, and focused visual scan reporting.

Recognition thresholds are not lowered. Package remains `com.arspos.anglerriausyndicate`, Room database remains v5, and official signer continuity is mandatory for in-place update from 1.5.1 (151).
