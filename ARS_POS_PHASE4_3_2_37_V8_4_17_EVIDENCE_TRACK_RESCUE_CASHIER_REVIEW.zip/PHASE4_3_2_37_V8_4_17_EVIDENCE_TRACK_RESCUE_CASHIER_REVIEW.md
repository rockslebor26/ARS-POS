# Phase 4.3.2.37 / Engine V8.4.17

## Evidence Integrity + Physical Track Truth + Rescue Gate V2 + Cashier Scan Review

Baseline release: **ARS POS 1.5.2 (152)**.
Package: `com.arspos.anglerriausyndicate`.
Database: v5 (unchanged).
Official signer continuity is mandatory.

## Objectives

V8.4.17 combines scanner-engine correctness work with three cashier-facing features:

1. Interactive object boxes bound to the exact `VisualScanObject` produced by the scanner.
2. Quantity review before cart mutation, with a one-commit-per-`sessionId` guard against double-tap/repeated add.
3. Focused visual scan reporting that exports the report, flight recorder and evidence folder for the selected scan session.

Long technical fields are hidden behind **DETAIL DIAGNOSTIK** so the normal cashier surface remains concise.

## Engine changes

### Evidence Integrity
- Track/final-proposal overlays are rendered on a mutable ARGB_8888 copy, never directly on an immutable scanner bitmap.
- Evidence render failures include `session` and `artifactType` in telemetry.
- Focused visual report ZIP is bound to one scan session.
- Diagnostic report exposes evidence-recorder error counts.

### Physical Track Truth
- Rejected pre-pruning tracks use a separate `REJECTED-*` namespace before retained tracks are reindexed.
- `physicalObjectId` must not identify two different physical regions inside one session.
- Intersection-aware continuity distinguishes a shaft that continues through a crossing from a true persistent branch.
- Recognition thresholds are unchanged.

### Rescue Gate V2
- Presence of a geometric/resolved axis alone no longer suppresses rescue.
- Rescue is blocked only when a TRUSTED rod track is already present, an accepted LONG exists, or no verified LONG master exists. ROD_UNCERTAIN remains diagnostic and may still trigger the evidence-only rescue pass.
- Full-frame rescue remains `quantityEligible=false`; it cannot create a cashier quantity.

## Cashier interaction

### Interactive object box
Green = recognized; red = unresolved; selected = highlighted. Tapping the box selects the exact scanner object; it does not change identity scores or decision rules.

### Quantity confirmation
Recognized physical results are grouped per product, then the cashier confirms the intended quantity before cart mutation. A `sessionId` may commit to the cart only once in the running process. Stock limits remain enforced.

### Visual reporting
**LAPORKAN HASIL SCAN BERGAMBAR** creates a focused ZIP containing the selected session's telemetry and evidence. It is intended for engine debugging and does not affect recognition.

## Recognition safety invariant

V8.4.17 does **not** lower recognition thresholds. Existing identity, visual-margin, text, barcode, rod-anchor and cross-category safety rules remain in force. The next identity-optimization phase starts only after evidence integrity, physical-track truth and rescue behavior are verified in real scans.

## Release gates

- `applicationId` remains `com.arspos.anglerriausyndicate`.
- `versionCode` is 152 and must be greater than installed 151.
- official signer SHA-256 must remain `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`.
- Room database stays at v5.
- install as an in-place update; do not uninstall the official app.
