package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale

/**
 * Phase 4.3.2.37 V8.4.17 cashier review surface.
 * Bounding boxes are interaction aids only; they never change engine decisions.
 */
@Composable
fun InteractiveScanPreview(
    bitmap: Bitmap,
    objects: List<VisualScanObject>,
    selectedObjectIndex: Int?,
    onObjectSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val ratio = (bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1).toFloat()).coerceAtLeast(0.1f)
    val frameWidth = objects.firstOrNull()?.frameWidth?.takeIf { it > 0 } ?: bitmap.width
    val frameHeight = objects.firstOrNull()?.frameHeight?.takeIf { it > 0 } ?: bitmap.height

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(ratio)
    ) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Foto barang pelanggan dengan kotak objek",
            modifier = Modifier.fillMaxWidth().aspectRatio(ratio),
            contentScale = ContentScale.Fit
        )

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(ratio)
                .pointerInput(objects, frameWidth, frameHeight) {
                    detectTapGestures { tap ->
                        val fw = frameWidth.coerceAtLeast(1).toFloat()
                        val fh = frameHeight.coerceAtLeast(1).toFloat()
                        val x = tap.x / size.width.coerceAtLeast(1).toFloat() * fw
                        val y = tap.y / size.height.coerceAtLeast(1).toFloat() * fh
                        val hit = objects
                            .filter { it.bounds.contains(x.toInt(), y.toInt()) }
                            .minByOrNull { it.bounds.width().toLong() * it.bounds.height().toLong() }
                        hit?.let { onObjectSelected(it.index) }
                    }
                }
        ) {
            val sx = size.width / frameWidth.coerceAtLeast(1).toFloat()
            val sy = size.height / frameHeight.coerceAtLeast(1).toFloat()
            objects.forEach { item ->
                val selected = item.index == selectedObjectIndex
                val recognized = item.match != null
                val color = when {
                    selected -> Color(0xFFFFD166)
                    recognized -> Color(0xFF4DD599)
                    else -> Color(0xFFE57373)
                }
                val left = item.bounds.left * sx
                val top = item.bounds.top * sy
                val width = item.bounds.width().coerceAtLeast(1) * sx
                val height = item.bounds.height().coerceAtLeast(1) * sy
                drawRect(
                    color = color,
                    topLeft = Offset(left, top),
                    size = Size(width, height),
                    style = Stroke(width = if (selected) 6f else 3.5f)
                )
            }
        }
    }
}
