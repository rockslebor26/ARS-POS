package com.arspos.anglerriausyndicate

/**
 * Persistent development target lock shown in ARS Dev Center.
 * This is documentation/diagnostics only and is never used as recognition logic.
 */
object ArsProjectCharter {
    val ultimateGoal = """
        CAMERA → PHYSICAL OBJECT → STABLE OBJECT LOCK → IDENTITY → PRODUCT → SAFE QUANTITY

        Satu benda fisik harus dipertahankan sebagai satu objek yang sama sampai identitasnya diputuskan atau evidence dinyatakan belum cukup. Smart Scan harus cepat dan konsisten pada single-object maupun multi-object tanpa membuat quantity palsu.
    """.trimIndent()

    val nonNegotiableRules = """
        • Recognition threshold/margin tidak boleh diturunkan agar terlihat berhasil.
        • Identity accepted tidak otomatis berarti quantity accepted.
        • Cloud/AI tidak boleh membuat quantity, mengubah stok/pembayaran, signer, atau memasang APK.
        • Canonical physical truth, Safety Kernel, Decision Ledger, Ground Truth, Replay, Rod Authenticity, Package Edge Firewall, dan update in-place tetap dilindungi.
        • Package resmi tetap com.arspos.anglerriausyndicate; versionCode wajib meningkat; signer resmi wajib sama.
    """.trimIndent()

    val currentMission = """
        V8.8.8 CURRENT MISSION

        Pertahankan evidence identity terbaik milik canonical physical object sampai finalisasi. Final menggunakan best identity frame untuk pengenalan dan fresh physical frame untuk existence/quantity. Dua NORMAL independen tidak boleh digabung hanya karena shared foreground. Candidate swap hanya boleh terjadi jika evidence baru secara material lebih kuat. Threshold recognition tidak berubah.
    """.trimIndent()

    val baseline = """
        BASELINE V8.8.7 — real-device diagnostic 2026-09-28
        • Scan sessions: 12/12 complete; crash/ANR/native crash/evidence error: 0.
        • Average completed scan: 1826 ms; object end-to-end: 1147 ms; crop OCR: 816 ms.
        • Latest first candidate: 4789 ms; another observed first candidate: 8019 ms; live MATCHED: 0.
        • Live/final comparable: 9; consistent: 5; mismatch: 4.
        • Verified failure: 2 NORMAL proposals sharing coarse foreground were merged into 1 canonical MERGED_FRAGMENT.
        • Ground-truth annotations: 0. PSS high-water: 323 MB; native high-water: 179 MB.
    """.trimIndent()

    val regressionGuard = """
        PHASE GATE
        IMPLEMENTED → TESTING → EVIDENCE VERIFIED → TARGET PASSED → CLOSED

        Target engineering V8.8.8: physical lock ≤700 ms, first plausible candidate ≤1.5 s, stable known identity ≤2.5 s bila evidence memadai, final setelah lock ≤1.5 s, stable live→final identity mismatch = 0, false NORMAL merge = 0 pada regression set, false/duplicate automatic quantity = 0, threshold relaxation = 0, crash/ANR/evidence corruption = 0, ground truth wajib terisi pada regression run.
    """.trimIndent()

}
