package com.arspos.anglerriausyndicate

/**
 * Phase 4.3.4.1 / V8.7.0 — Correct-Type Identity Routing + Live Physical Fusion.
 *
 * V8.7.0 fixes the field-proven failure where an ML-detected compact product
 * with a tall aspect ratio entered the LONG lane, was correctly classified
 * NON_ROD, and was then discarded before NORMAL database identity scoring.
 *
 * Physical truth and cashier safety are production-active. Self-learning is
 * operator-confirmed and bounded to visual references; cloud identity remains
 * non-authoritative until field evidence proves it safe.
 */
object ArsV850Config {
    const val PHASE = "4.3.4.1"
    const val ENGINE = "V8.7.0"
    const val VERSION_NAME = "1.9.0"
    const val VERSION_CODE = 190

    const val FEATURE_PERSISTENT_FRAGMENT_FUSION = true
    const val FEATURE_ML_GUIDED_LOCAL_RECOVERY = true
    const val FEATURE_BEST_EVIDENCE_MEMORY = true
    const val FEATURE_DECISION_EVIDENCE_LEDGER = true
    const val FEATURE_GROUND_TRUTH_LEARNING = true
    const val FEATURE_AI_ENGINEER_UI = true
    const val FEATURE_AI_ENGINEER_VISUAL_EVIDENCE = true
    const val FEATURE_AI_GATEWAY_SIGNED_REQUESTS = true
    const val FEATURE_AI_GATEWAY_STRUCTURED_DIAGNOSTICS = true
    const val FEATURE_AI_GATEWAY_HEALTH_CHECK = true
    const val AI_ENGINEER_MAX_IMAGES = 3
    const val AI_ENGINEER_MAX_REPORT_CHARS = 48_000

    // Cloud identity remains non-authoritative. Confirmed local teaching may
    // enrich visual references but cannot manufacture quantity.
    const val CLOUD_IDENTITY_MODE = "SHADOW"
    const val SELF_LEARNING_MODE = "ACTIVE_CONFIRMED_ONLY"
    const val AI_ENGINEER_MODE = "ENGINEERING_PROPOSAL_GATED"

    // Self-learning may add operator-confirmed visual references, but it may not
    // relax recognition thresholds or bypass physical/quantity safety.
    const val FEATURE_CONFIRMED_VISUAL_TEACHING = true
    const val FEATURE_NORMAL_VISUAL_ONLY_MASTER = true
    const val FEATURE_UPDATE_PROPOSAL_GATE = true

    // V8.7.0 routing/latency controls. These do not relax identity thresholds.
    const val FEATURE_NON_ROD_TO_NORMAL_RESCUE = true
    const val FEATURE_LIVE_ML_TALL_NORMAL_FALLBACK = true
    const val FEATURE_CATALOG_SNAPSHOT_EVIDENCE = true
    const val LIVE_LOOP_DELAY_MS = 180L
    const val LIVE_STABLE_REFRESH_MS = 500L
}
