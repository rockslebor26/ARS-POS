# ARS POS 1.10.6 (206) — V8.8.4 Release 206

- Package: `com.arspos.anglerriausyndicate`
- Phase: `4.3.5.4`
- Engine: `V8.8.4`
- Revision: `STICKY_PHYSICAL_LOCK_BEST_EVIDENCE_IDENTITY_CONVERGENCE`
- Previous official version: `1.10.5 (205)`
- Current version: `1.10.6 (206)`
- Database: v5
- Update: in-place only
- Official signer SHA-256: `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`

## Release objective

Correct the V8.8.3 field failure where the lock CTA blinked despite a stable physical track and where final identity did not preserve materially better live evidence.

## Main changes

- Sticky physical lock UI latch independent from analyzer/OCR/HIGH_RES busy state.
- Atomic lock-gate state with explicit reason/epoch/release telemetry.
- Useful high-resolution gain policy replaces the overly strict 1.35x-per-axis gate.
- Bounded static ambiguity retry for stable objects that otherwise remain unscheduled.
- Discriminative micro-OCR for NORMAL objects with empty full-crop identity OCR.
- Geometry-stable best-frame retention across transient LIVE id fragmentation.
- High-resolution finalization reason and resolution-gain telemetry.

## Immutable safety rules

No recognition threshold is lowered. Cloud identity cannot create quantity. AI Engineer stays diagnostic-only. Quantity remains final-scanner + physical-safety owned.

## Validation status before device build

- Static source invariants: PASS (201 checks before release-document/hash finalization).
- Kotlin lexical sanity: PASS.
- Python release tests: PASS.
- Gateway syntax/security tests: PASS.
- Android/Kotlin compilation and signed APK verification: performed by the supplied GitHub Actions workflow.
- Real-device acceptance: required before declaring V8.8.4 finished.

## BUILD FIX2 — local JVM ROI test contract

GitHub Actions run 388 confirmed that Android Debug/Release Kotlin compilation succeeds after BUILD FIX1. The remaining build stop was isolated to `:app:testDebugUnitTest`: three `AdaptiveIdentityRoiTest` cases called `android.graphics.Rect.width()` / `Rect.equals()` from a plain JVM test, where Android framework methods are intentionally not mocked.

BUILD FIX2 keeps production geometry and all recognition thresholds unchanged. `AdaptiveIdentityRoi` now calculates width/height/equality from Rect coordinate fields (`left/top/right/bottom`), and the regression test compares those fields directly. No Robolectric dependency is added and no scanner acceptance threshold is relaxed.
