# Phase 4.3.5.4 — V8.8.4

## Sticky Physical Lock + Best-Evidence Identity Convergence

V8.8.4 is a field-evidence correction release derived from V8.8.3 sessions where the physical object was already stable (`lockedTracks=1`) but the lock CTA still blinked, live identity work was rarely scheduled, and the final scanner rejected a materially larger identity frame because the old gate required at least 1.35x growth on each axis.

The release does **not** reduce recognition thresholds. It changes orchestration and evidence acquisition only.

## Root causes fixed

1. **UI lock coupled to analyzer activity**
   - V8.8.3 enabled `KUNCI & TINJAU HASIL` only when `!analysisBusy`.
   - Every identity/OCR/high-resolution pass could therefore disable the button even though the physical object remained locked.

2. **Transient track handoff could drop the visible lock**
   - A HIGH_RES/identity pass could temporarily fragment or restabilize tracks.
   - V8.8.4 adds a bounded `LivePhysicalLockLatch`; it can only be acquired from an authoritative `LOCKED` state, then survives transient identity work and releases after confirmed scene loss or a bounded non-reacquisition interval.

3. **Useful final high-resolution evidence was rejected**
   - Observed device path: preview/best frame `609x1280`, analysis bitmap `487x1024`.
   - V8.8.3 required >=1.35x per axis, but the observed frame is ~1.25x per axis and ~1.56x by pixel area.
   - V8.8.4 uses `AdaptiveIdentityRoi.hasUsefulResolutionGain`: >=1.10x each axis and >=1.20x total pixel gain. This preserves materially better evidence without treating equal-resolution frames as HIGH_RES.

4. **Static ambiguity could stall in IDENTITY_NOT_SCHEDULED**
   - `VIEW_CHANGE_REQUIRED` previously waited indefinitely when scene change stayed below the configured threshold.
   - V8.8.4 adds a bounded static ambiguity retry after 3.5 s, capped at four identity evaluations. The retry uses HIGH_RES and does not loosen recognition acceptance.

5. **Small discriminative labels were diluted by full-object OCR**
   - Transparent/glossy products can expose background texture across most of the crop while the useful logo/model text occupies a small end region.
   - V8.8.4 adds bounded discriminative NORMAL OCR: full-crop OCR first; if no identity-bearing text/barcode is found, at most three top/bottom/center or left/right/center micro-ROIs are inspected, with bounded upscaling.

6. **Best evidence could be overwritten by a LIVE id split**
   - `LiveBestFrameStore` now uses geometry continuity rather than raw LIVE ids and only replaces immediately for materially better quality. A temporary track id split no longer automatically destroys the stronger frame.

## New telemetry

Live telemetry now records:

- `uiCanLock`
- `uiCanLockReason`
- `physicalLockEpochMs`
- `physicalLockReleaseReason`
- `analysisInFlight`

Lock telemetry records:

- `bestFrameQuality`
- `bestFrameAgeMs`
- `uiCanLock`
- `uiCanLockReason`
- `physicalLockEpochMs`
- `analysisInFlightAtLock`

Final scoring records:

- `highResolutionIdentityUsed`
- `highResolutionSourceReason`
- `identityWidthGain`
- `identityHeightGain`

These fields make a future lock blink or live/final evidence mismatch directly diagnosable from the report.

## Safety invariants retained

- Package remains `com.arspos.anglerriausyndicate`.
- Room database remains v5; no destructive migration.
- Recognition thresholds remain unchanged 14/14.
- Cloud Identity remains `SHADOW`.
- Self Learning remains `ACTIVE_CONFIRMED_ONLY`.
- ARS AI Engineer remains `DEV_CENTER_DIAGNOSTIC_ONLY` and outside the critical scan path.
- Live identity remains advisory and cannot create quantity.
- Final quantity still requires accepted identity plus `ArsSafetyKernel` / physical quantity safety.
- LONG authenticity, package-edge firewall, cross-lane safety, anchor truth, duplicate prevention and cashier review remain active.

## Device acceptance targets

1. Hold one NORMAL object steady for at least 15 s: after first physical lock, the CTA must not blink during analyzer/OCR/HIGH_RES work.
2. Observe `uiCanLock=true` while `analysisInFlight=true`; this is expected and proves decoupling.
3. For the 609x1280 -> 487x1024 path, final telemetry should show `highResolutionIdentityUsed=true` when the bound live track requests high-resolution identity, or an explicit non-ambiguous `highResolutionSourceReason` explaining why not.
4. A static ambiguous object must receive bounded retry; it must not generate unlimited OCR/HIGH_RES work.
5. Small-label products should show improved identity text when the label is readable in the captured pixels.
6. Wrong auto-accept remains zero; threshold values must remain unchanged.
7. Duplicate physical quantity remains zero.
8. Background/line hypotheses must not become quantity.
9. Memory/native pressure must remain bounded and temp crops must be recycled.
10. Update must be in-place from official version 205 to 206 with identical signer.

## Build-contract correction R2

Run 388 proved the source package, signer configuration, Android SDK, Gradle setup, and both Debug/Release Kotlin compilation stages are valid. The later `testDebugUnitTest` failure was not a scanner-algorithm failure: `AdaptiveIdentityRoiTest` executed Android `Rect.width()` and `Rect.equals()` in a host JVM, producing `Method ... in android.graphics.Rect not mocked` exceptions.

R2 removes Android-framework method calls from the locally unit-tested ROI geometry path by using the equivalent public Rect coordinates. The mathematical ROI behavior is unchanged, while the test is now deterministic on both the host JVM and Android runtime.
