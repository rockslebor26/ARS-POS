# ARS POS V8.8.4 / 1.10.6 (206) — BUILD FIX3 / PURE ROI GEOMETRY

GitHub Actions runs 389 and 390 confirmed that source validation, Android SDK setup,
official release signer validation, Debug/Release Kotlin compilation, and the
`:physicaltruth-jvm:test` suite all pass. The remaining build stop was isolated to
three `AdaptiveIdentityRoiTest` assertions in `:app:testDebugUnitTest`.

## Root cause

`android.graphics.Rect` comes from the Android mockable framework JAR during plain
host-JVM unit tests. Its constructor/framework behavior is not a reliable source of
real Android geometry state, so tests that instantiated `Rect` observed zero-valued
coordinates even after BUILD FIX2 stopped calling `Rect.width()`, `Rect.height()`,
and `Rect.equals()`.

## Fix

- Added `AdaptiveIdentityGeometry.kt` with Android-free `RoiBounds` geometry.
- Moved ROI variants, scale, overlap, discriminative-region selection, clamping, and
  high-resolution-gain arithmetic into pure Kotlin.
- Retained `AdaptiveIdentityRoi` as the production Android `Rect` boundary adapter,
  preserving existing camera/bitmap call sites.
- Rewrote `AdaptiveIdentityRoiTest` to execute the exact pure geometry contract and
  removed all host-JVM construction/use of `android.graphics.Rect`.
- Added an invalid-output-frame regression case so zero-sized geometry is explicit
  and deterministic.
- Strengthened `tools/validate_source.py` so future releases reject ROI tests that
  regress back to Android framework geometry on host JVM.

## Safety invariants

- Package remains `com.arspos.anglerriausyndicate`.
- Version remains `1.10.6 (206)` because no official 206 APK has been released yet.
- Phase remains `4.3.5.4`; engine remains `V8.8.4`.
- Room database remains v5.
- Recognition thresholds are unchanged.
- Quantity ownership and Safety Kernel policy are unchanged.
- Cloud Identity remains SHADOW.
- AI Engineer remains outside the critical scan path.
- Official in-place update signer is unchanged.

## Required CI gates

1. Source SHA-256 and static invariants.
2. `:app:compileDebugKotlin` and `:app:compileReleaseKotlin`.
3. `:physicaltruth-jvm:test`.
4. `:app:testDebugUnitTest` — expected 83/83 after the added regression case.
5. `:app:assembleRelease`.
6. Package/version/signer/zipalign verification.
7. Real-device Smart Scan acceptance before V8.8.4 is considered finished.
