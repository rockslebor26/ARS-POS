# ARS POS V8.8.4 / 1.10.6 (206) — BUILD FIX2 / ROI MOCKABLE-ANDROID FIRST RECOVERY

GitHub Actions run 388 confirmed Android Debug/Release Kotlin compilation passed, but
`:app:testDebugUnitTest` stopped on `AdaptiveIdentityRoiTest` because plain host-JVM
unit tests were invoking framework `android.graphics.Rect` methods such as
`width()`, `height()`, or equality behavior from Android's mockable JAR.

BUILD FIX2 removed those method calls and compared Rect coordinate fields directly.
That was a useful first isolation step, but runs 389 and 390 later proved it was not
complete: host-JVM construction/framework behavior for `Rect` itself still produced
zero/default geometry for three ROI tests.

BUILD FIX3 therefore supersedes this workaround by moving all arithmetic into pure
Kotlin `AdaptiveIdentityGeometry`/`RoiBounds` and retaining `AdaptiveIdentityRoi`
only as the Android boundary adapter.

No recognition threshold, package, database, version, signer, or quantity-safety
policy was changed by BUILD FIX2.
