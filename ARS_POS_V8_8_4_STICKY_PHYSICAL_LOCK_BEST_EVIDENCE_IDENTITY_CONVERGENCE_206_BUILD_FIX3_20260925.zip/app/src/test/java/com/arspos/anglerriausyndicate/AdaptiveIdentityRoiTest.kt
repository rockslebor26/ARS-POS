package com.arspos.anglerriausyndicate

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Host-JVM contract: ROI arithmetic must not depend on android.graphics.Rect runtime behavior. */
class AdaptiveIdentityRoiTest {
    @Test
    fun variantsStayInsideFrameAndBecomeMoreSelective() {
        val variants = AdaptiveIdentityGeometry.variants(
            RoiBounds(-5, 10, 205, 190),
            width = 200,
            height = 200
        )

        assertTrue(variants.size >= 2)
        variants.forEach {
            assertTrue(it.left >= 0 && it.top >= 0)
            assertTrue(it.right <= 200 && it.bottom <= 200)
        }
        assertTrue(variants.last().width < variants.first().width)
    }

    @Test
    fun scalingPreservesNormalizedLocation() {
        val scaled = AdaptiveIdentityGeometry.scale(
            RoiBounds(50, 25, 150, 75),
            fromWidth = 200,
            fromHeight = 100,
            toWidth = 1000,
            toHeight = 500
        )

        assertEquals(250, scaled.left)
        assertEquals(125, scaled.top)
        assertEquals(750, scaled.right)
        assertEquals(375, scaled.bottom)
    }

    @Test
    fun usefulResolutionGainAcceptsObservedDeviceRatio() {
        assertTrue(AdaptiveIdentityGeometry.hasUsefulResolutionGain(609, 1280, 487, 1024))
        assertFalse(AdaptiveIdentityGeometry.hasUsefulResolutionGain(520, 1080, 487, 1024))
    }

    @Test
    fun tallObjectGetsEndcapDiscriminativeRegions() {
        val regions = AdaptiveIdentityGeometry.discriminativeRegions(120, 360)

        assertEquals(3, regions.size)
        assertEquals(0, regions.first().top)
        assertEquals(360, regions[1].bottom)
    }

    @Test
    fun invalidOutputFrameReturnsEmptyGeometryInsteadOfAndroidStubDependentValues() {
        val scaled = AdaptiveIdentityGeometry.scale(
            RoiBounds(50, 25, 150, 75),
            fromWidth = 200,
            fromHeight = 100,
            toWidth = 0,
            toHeight = 0
        )

        assertEquals(RoiBounds(0, 0, 0, 0), scaled)
    }
}
