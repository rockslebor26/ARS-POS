package com.arspos.anglerriausyndicate

import android.graphics.Rect

/**
 * Android boundary adapter for V8.8.4 identity ROI geometry.
 *
 * All arithmetic is delegated to [AdaptiveIdentityGeometry], which is pure Kotlin
 * and can be regression-tested on the host JVM without relying on mockable Android
 * framework constructors or methods.
 */
object AdaptiveIdentityRoi {
    fun variants(bounds: Rect, width: Int, height: Int): List<Rect> =
        AdaptiveIdentityGeometry
            .variants(bounds.toRoiBounds(), width, height)
            .map { it.toAndroidRect() }

    fun discriminativeRegions(width: Int, height: Int): List<Rect> =
        AdaptiveIdentityGeometry
            .discriminativeRegions(width, height)
            .map { it.toAndroidRect() }

    fun hasUsefulResolutionGain(
        sourceWidth: Int,
        sourceHeight: Int,
        analysisWidth: Int,
        analysisHeight: Int
    ): Boolean = AdaptiveIdentityGeometry.hasUsefulResolutionGain(
        sourceWidth = sourceWidth,
        sourceHeight = sourceHeight,
        analysisWidth = analysisWidth,
        analysisHeight = analysisHeight
    )

    fun scale(
        rect: Rect,
        fromWidth: Int,
        fromHeight: Int,
        toWidth: Int,
        toHeight: Int
    ): Rect = AdaptiveIdentityGeometry
        .scale(rect.toRoiBounds(), fromWidth, fromHeight, toWidth, toHeight)
        .toAndroidRect()

    fun overlapRatio(a: Rect, b: Rect): Float =
        AdaptiveIdentityGeometry.overlapRatio(a.toRoiBounds(), b.toRoiBounds())

    private fun Rect.toRoiBounds(): RoiBounds =
        RoiBounds(left = left, top = top, right = right, bottom = bottom)

    private fun RoiBounds.toAndroidRect(): Rect =
        Rect(left, top, right, bottom)
}
