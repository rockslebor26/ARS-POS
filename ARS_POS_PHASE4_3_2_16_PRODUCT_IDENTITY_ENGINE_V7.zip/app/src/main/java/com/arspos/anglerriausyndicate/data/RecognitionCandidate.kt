package com.arspos.anglerriausyndicate.data

import com.arspos.anglerriausyndicate.data.db.ProductEntity

/** Candidate diagnostik per produk pada Phase 4.3.2.11. */
data class RecognitionCandidate(
    val product: ProductEntity,
    val visualScore: Int,
    val textScore: Int,
    val profileScore: Int = 0,
    val finalScore: Int,
    val evidence: String,
    val hasMaster: Boolean,
    val masterVerified: Boolean = false
)
