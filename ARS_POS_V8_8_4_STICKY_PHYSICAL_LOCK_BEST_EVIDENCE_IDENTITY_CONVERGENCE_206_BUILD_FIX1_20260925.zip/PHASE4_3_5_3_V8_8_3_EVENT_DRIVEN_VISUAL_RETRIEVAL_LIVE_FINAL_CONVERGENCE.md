# Phase 4.3.5.3 — V8.8.3

## EVENT_DRIVEN_VISUAL_RETRIEVAL + LIVE_FINAL_DECISION_CONVERGENCE

### Purpose

V8.8.2 proved that physical locking and final exact recognition could work while live identity still remained UNKNOWN for too long. The dominant failure mode was not catalog scoring cost; it was repeated evidence acquisition, global identity scheduling, candidate demotion on non-identity frames, and live/final state separation.

V8.8.3 therefore changes *when* identity work runs and *which object* receives it. It does not relax recognition thresholds.

## Pipeline

1. **Fast perception** detects proposals and updates physical tracks without forcing exact identity.
2. **Physical lock** stabilizes `persistentPhysicalId` before expensive identity work.
3. **Object-scoped scheduling** grants one locked object the identity budget per pass. Manual selection has priority, otherwise unresolved locked objects are round-robined.
4. **Bounded Top-K recall** narrows the catalog. Visual similarity is recall evidence only.
5. **Exact local decision** applies existing OCR/visual/barcode/anchor rules and unchanged thresholds.
6. **Evidence escalation** changes modality after ambiguity rather than repeating the same failed operation:
   - `VISUAL_RETRIEVAL`
   - `OCR`
   - `HIGH_RES_REQUIRED`
   - `VIEW_CHANGE_REQUIRED`
   - `CONFIRMED / IDENTITY_FROZEN`
7. **High-resolution ambiguity recovery** uses adaptive NORMAL ROI crops only when bounded low-resolution evidence cannot separate candidates.
8. **View-change gate** prevents repeated identity work after high-resolution ambiguity until the camera/object view changes materially.
9. **Live/final convergence** carries bound live advisory evidence into final recall/audit. Final exact decision remains authoritative.
10. **Physical Quantity Safety** remains the last transaction gate. Live scan cannot create transaction quantity.

## Key implementation units

### `LiveIdentityScheduler`

- exactly one locked object receives heavy identity per pass;
- matched identity is revalidated only after a bounded interval;
- high-resolution retry has its own cooldown;
- `VIEW_CHANGE_REQUIRED` is blocked until scene change reaches the configured evidence threshold;
- operator-selected object is prioritized without changing acceptance thresholds.

### `PhysicalObjectStateMachine`

Detector-only frames are identity-neutral. A candidate is not demoted merely because identity was not evaluated on that frame. Candidate and matched holds are bounded, and actual contradictory evaluated evidence can still replace stale identity.

### `LiveOcrReusePolicy`

- positive OCR cache: bounded;
- negative/empty OCR cache: bounded;
- visual improvement can invalidate stale negative evidence;
- repository uses a single-flight OCR guard so duplicate OCR work for the same evidence key is suppressed.

### `AdaptiveIdentityRoi`

NORMAL identity can evaluate bounded crop variants (full ROI, inset ROI, tighter detail ROI) at high resolution. This is recovery evidence only and does not bypass `SmartRecognitionEngine`.

### `LiveBestFrameStore`

Stores a bounded scene frame selected from exposure/contrast and identity quality. The final lock prefers this evidence frame instead of blindly taking the newest preview bitmap.

### `PersistentDecisionState`

Captures live advisory product/evidence state by physical identity for final recall seed and convergence telemetry. A live candidate cannot directly authorize final recognition or quantity.

### Multi-object target strip

Each stable physical track is represented independently and can be selected. This follows the principle `detect many, identify selectively`, reducing redundant OCR/scoring in multi-object scenes.

## Diagnostic requirements

V8.8.3 diagnostics record:

- identity target per live pass;
- evidence stage per track;
- whether identity was actually evaluated;
- negative OCR cache reuse;
- high-resolution target/use;
- candidate demotions caused by evaluated evidence;
- live/final comparable decisions and consistency;
- dynamic engine/version metadata in evidence/replay packages.

Replay metadata is sourced from `ArsV850Config` and uses Replay V4 terminology. Stale V8.8.1/V8.8.2 runtime labels must not be used by V8.8.3 events.

## Safety boundaries

- No recognition threshold is lowered.
- Cloud Identity remains `SHADOW`.
- Self Learning remains `ACTIVE_CONFIRMED_ONLY`.
- AI Engineer remains `DEV_CENTER_DIAGNOSTIC_ONLY` and outside the critical scan path.
- High-resolution recovery cannot create quantity by itself.
- Live candidate state is advisory only.
- Package/signing/database invariants remain unchanged.

## Field acceptance targets

Initial targets for the RMX3563 class device:

- visible object indication: < 300 ms where device/frame cadence allows;
- physical lock: ~500–800 ms under stable framing;
- first Top-K/candidate: < 1.5 s for a stable known NORMAL product;
- exact identity with strong evidence: target < 2 s;
- one active OCR request per object/evidence key;
- no candidate demotion on detector-only frames;
- no identical-view OCR loop after negative evidence;
- no live-confirmed → final-different product without explicit convergence telemetry;
- duplicate quantity: zero.

These are validation targets, not threshold changes or guaranteed timings.
