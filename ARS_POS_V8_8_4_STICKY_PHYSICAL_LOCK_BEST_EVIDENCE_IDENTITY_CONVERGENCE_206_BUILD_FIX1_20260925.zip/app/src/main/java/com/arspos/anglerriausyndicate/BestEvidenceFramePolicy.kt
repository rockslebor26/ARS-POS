package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import kotlin.math.abs

/**
 * Bounded best-frame selection for final scene lock. This does not perform SKU
 * recognition; it only prefers a stable, sharp, well-exposed frame already
 * associated with locked physical tracks.
 */
object BestEvidenceFramePolicy {
    fun qualityScore(bitmap: Bitmap, tracks: List<LiveSceneTrack>, sceneChange: Float): Int {
        if (bitmap.width <= 0 || bitmap.height <= 0) return 0
        val locked = tracks.filter {
            it.missingFrames == 0 && it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED
        }
        if (locked.isEmpty()) return 0

        val sharpness = sampledEdgeEnergy(bitmap)
        val exposure = sampledExposure(bitmap)
        val largestArea = locked.maxOfOrNull {
            it.bounds.width().coerceAtLeast(0).toLong() * it.bounds.height().coerceAtLeast(0).toLong()
        } ?: 0L
        val frameArea = bitmap.width.toLong() * bitmap.height.toLong()
        val areaScore = if (frameArea > 0L) ((largestArea.toDouble() / frameArea.toDouble()) * 420.0).toInt().coerceIn(0, 120) else 0
        val stability = ((1f - (sceneChange / 0.10f).coerceIn(0f, 1f)) * 120f).toInt()
        return (sharpness + exposure + areaScore + stability).coerceIn(0, 500)
    }

    private fun sampledEdgeEnergy(bitmap: Bitmap): Int {
        val gridX = 18
        val gridY = 24
        var total = 0L
        var count = 0
        var previousRow = IntArray(gridX)
        for (gy in 0 until gridY) {
            val row = IntArray(gridX)
            val y = ((gy + 0.5f) * bitmap.height / gridY).toInt().coerceIn(0, bitmap.height - 1)
            for (gx in 0 until gridX) {
                val x = ((gx + 0.5f) * bitmap.width / gridX).toInt().coerceIn(0, bitmap.width - 1)
                val l = luma(bitmap.getPixel(x, y))
                row[gx] = l
                if (gx > 0) { total += abs(l - row[gx - 1]); count++ }
                if (gy > 0) { total += abs(l - previousRow[gx]); count++ }
            }
            previousRow = row
        }
        if (count == 0) return 0
        return ((total / count).toInt() * 2).coerceIn(0, 180)
    }

    private fun sampledExposure(bitmap: Bitmap): Int {
        val grid = 16
        var sum = 0L
        var count = 0
        for (gy in 0 until grid) {
            val y = ((gy + 0.5f) * bitmap.height / grid).toInt().coerceIn(0, bitmap.height - 1)
            for (gx in 0 until grid) {
                val x = ((gx + 0.5f) * bitmap.width / grid).toInt().coerceIn(0, bitmap.width - 1)
                sum += luma(bitmap.getPixel(x, y))
                count++
            }
        }
        if (count == 0) return 0
        val mean = (sum / count).toInt()
        val distance = abs(mean - 132)
        return (100 - distance).coerceIn(0, 100)
    }

    private fun luma(pixel: Int): Int {
        val r = (pixel shr 16) and 0xff
        val g = (pixel shr 8) and 0xff
        val b = pixel and 0xff
        return (r * 30 + g * 59 + b * 11) / 100
    }
}
