package com.arspos.anglerriausyndicate

import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min

/** V8.8.4 bounded identity ROI pyramid; detection geometry is never changed. */
object AdaptiveIdentityRoi {
    fun variants(bounds: Rect, width: Int, height: Int): List<Rect> {
        val base = clamp(bounds, width, height)
        if (base.width() < 16 || base.height() < 16) return listOf(base)
        val insetX = max(1, (base.width() * 0.06f).toInt())
        val insetY = max(1, (base.height() * 0.06f).toInt())
        val inset = clamp(Rect(base.left + insetX, base.top + insetY, base.right - insetX, base.bottom - insetY), width, height)
        val centerX = max(1, (base.width() * 0.14f).toInt())
        val centerY = max(1, (base.height() * 0.14f).toInt())
        val detail = clamp(Rect(base.left + centerX, base.top + centerY, base.right - centerX, base.bottom - centerY), width, height)
        return listOf(base, inset, detail).distinctBy { "${it.left}:${it.top}:${it.right}:${it.bottom}" }
    }

    /**
     * Bounded sub-ROIs for tiny logos/model text on transparent or glossy items.
     * Tall objects prioritize top/bottom endcaps; wide objects prioritize left/right
     * endcaps. Square-ish objects use upper/lower and center bands. This only gathers
     * evidence and never relaxes recognition thresholds.
     */
    fun discriminativeRegions(width: Int, height: Int): List<Rect> {
        if (width < 24 || height < 24) return emptyList()
        val full = Rect(0, 0, width, height)
        val regions = ArrayList<Rect>()
        when {
            height >= width * 1.35f -> {
                val end = max(16, (height * 0.38f).toInt())
                val centerInset = max(1, (height * 0.22f).toInt())
                regions += Rect(0, 0, width, end.coerceAtMost(height))
                regions += Rect(0, (height - end).coerceAtLeast(0), width, height)
                regions += Rect(0, centerInset, width, (height - centerInset).coerceAtLeast(centerInset + 1))
            }
            width >= height * 1.35f -> {
                val end = max(16, (width * 0.38f).toInt())
                val centerInset = max(1, (width * 0.22f).toInt())
                regions += Rect(0, 0, end.coerceAtMost(width), height)
                regions += Rect((width - end).coerceAtLeast(0), 0, width, height)
                regions += Rect(centerInset, 0, (width - centerInset).coerceAtLeast(centerInset + 1), height)
            }
            else -> {
                val band = max(16, (height * 0.45f).toInt())
                regions += Rect(0, 0, width, band.coerceAtMost(height))
                regions += Rect(0, (height - band).coerceAtLeast(0), width, height)
                val insetX = max(1, (width * 0.18f).toInt())
                val insetY = max(1, (height * 0.18f).toInt())
                regions += Rect(insetX, insetY, (width - insetX).coerceAtLeast(insetX + 1), (height - insetY).coerceAtLeast(insetY + 1))
            }
        }
        return regions
            .map { clamp(it, width, height) }
            .filter { it.width() >= 16 && it.height() >= 16 && it != full }
            .distinctBy { "${it.left}:${it.top}:${it.right}:${it.bottom}" }
            .take(3)
    }

    /**
     * A frame is useful identity evidence when both axes are materially larger and
     * total pixels are meaningfully higher. V8.8.3 required 1.35x on each axis,
     * incorrectly rejecting 609x1280 over 487x1024 (~1.25x each axis, 1.56x pixels).
     */
    fun hasUsefulResolutionGain(
        sourceWidth: Int,
        sourceHeight: Int,
        analysisWidth: Int,
        analysisHeight: Int
    ): Boolean {
        if (sourceWidth <= 0 || sourceHeight <= 0 || analysisWidth <= 0 || analysisHeight <= 0) return false
        val widthGain = sourceWidth.toFloat() / analysisWidth.toFloat()
        val heightGain = sourceHeight.toFloat() / analysisHeight.toFloat()
        val pixelGain = sourceWidth.toLong() * sourceHeight.toLong() /
            (analysisWidth.toDouble() * analysisHeight.toDouble())
        return widthGain >= 1.10f && heightGain >= 1.10f && pixelGain >= 1.20
    }

    fun scale(rect: Rect, fromWidth: Int, fromHeight: Int, toWidth: Int, toHeight: Int): Rect {
        val sx = toWidth.toFloat() / fromWidth.coerceAtLeast(1)
        val sy = toHeight.toFloat() / fromHeight.coerceAtLeast(1)
        return clamp(Rect(
            (rect.left * sx).toInt(), (rect.top * sy).toInt(),
            (rect.right * sx).toInt(), (rect.bottom * sy).toInt()
        ), toWidth, toHeight)
    }

    fun overlapRatio(a: Rect, b: Rect): Float {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val inter = (right - left).toLong() * (bottom - top).toLong()
        val small = min(a.width().toLong() * a.height().toLong(), b.width().toLong() * b.height().toLong()).coerceAtLeast(1L)
        return inter.toFloat() / small.toFloat()
    }

    private fun clamp(rect: Rect, width: Int, height: Int): Rect {
        val left = rect.left.coerceIn(0, max(0, width - 1))
        val top = rect.top.coerceIn(0, max(0, height - 1))
        val right = rect.right.coerceIn(left + 1, max(left + 1, width))
        val bottom = rect.bottom.coerceIn(top + 1, max(top + 1, height))
        return Rect(left, top, right, bottom)
    }
}
