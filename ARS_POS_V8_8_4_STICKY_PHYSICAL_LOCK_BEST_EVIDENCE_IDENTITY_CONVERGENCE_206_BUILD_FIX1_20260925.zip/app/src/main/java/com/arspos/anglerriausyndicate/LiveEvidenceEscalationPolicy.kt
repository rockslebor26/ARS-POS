package com.arspos.anglerriausyndicate

/**
 * V8.8.4 evidence state machine. This decides what evidence to acquire next;
 * it never changes SmartRecognitionEngine acceptance thresholds.
 */
object LiveEvidenceEscalationPolicy {
    const val TRACK_ONLY = "TRACK_ONLY"
    const val VISUAL_RETRIEVAL = "VISUAL_RETRIEVAL"
    const val OCR = "OCR"
    const val HIGH_RES_REQUIRED = "HIGH_RES_REQUIRED"
    const val VIEW_CHANGE_REQUIRED = "VIEW_CHANGE_REQUIRED"
    const val CONFIRMED = "CONFIRMED"
    const val IDENTITY_FROZEN = "IDENTITY_FROZEN"

    fun stage(
        identityEvaluated: Boolean,
        accepted: Boolean,
        visualScore: Int,
        margin: Int,
        hasIdentityText: Boolean,
        negativeOcrReusable: Boolean,
        highResolutionUsed: Boolean
    ): String = when {
        accepted -> CONFIRMED
        !identityEvaluated -> TRACK_ONLY
        highResolutionUsed && visualScore >= LiveIdentityPolicy.MIN_VISUAL_FOR_NORMAL_IDENTITY &&
            margin < LiveIdentityPolicy.AMBIGUOUS_VISUAL_MARGIN -> VIEW_CHANGE_REQUIRED
        visualScore >= LiveIdentityPolicy.MIN_VISUAL_FOR_NORMAL_IDENTITY &&
            margin < LiveIdentityPolicy.AMBIGUOUS_VISUAL_MARGIN && negativeOcrReusable -> HIGH_RES_REQUIRED
        visualScore >= LiveIdentityPolicy.MIN_VISUAL_FOR_NORMAL_IDENTITY &&
            margin < LiveIdentityPolicy.AMBIGUOUS_VISUAL_MARGIN && !hasIdentityText -> OCR
        else -> VISUAL_RETRIEVAL
    }
}
