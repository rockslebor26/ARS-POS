package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import kotlin.math.max

/** Metadata for the bounded best-evidence scene copy used by finalization. */
data class LiveBestFrameInfo(
    val quality: Int = Int.MIN_VALUE,
    val continuityKey: String = "",
    val storedAtMs: Long = 0L
) {
    fun ageMs(nowMs: Long = System.currentTimeMillis()): Long =
        if (storedAtMs <= 0L) 0L else (nowMs - storedAtMs).coerceAtLeast(0L)
}

/**
 * V8.8.4 bounded best-evidence scene store.
 *
 * A temporary LIVE id split must not overwrite a stronger frame. The continuity
 * key is therefore geometry-based rather than track-id-based, and a continuity
 * change only replaces the stored frame after a bounded delay and with comparable
 * quality. A materially better frame replaces immediately.
 */
class LiveBestFrameStore {
    private var frame: Bitmap? = null
    private var quality: Int = Int.MIN_VALUE
    private var continuityKey: String = ""
    private var storedAtMs: Long = 0L

    fun consider(raw: Bitmap, analysis: Bitmap, tracks: List<LiveSceneTrack>, nowMs: Long) {
        if (tracks.none { it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED && it.missingFrames == 0 }) return
        val key = geometryContinuityKey(analysis, tracks)
        val q = qualityScore(analysis, tracks)
        val continuityChanged = continuityKey.isNotBlank() && key != continuityKey
        val changedLongEnough = continuityChanged && nowMs - storedAtMs >= 1_500L
        val replace = frame == null ||
            q > quality + 4 ||
            (changedLongEnough && q >= quality - 2)
        if (replace) {
            val replacement = boundedCopy(raw, 1280) ?: return
            frame?.takeIf { !it.isRecycled }?.recycle()
            frame = replacement
            quality = q
            continuityKey = key
            storedAtMs = nowMs
        }
    }

    fun snapshot(expectedKey: String? = null): Bitmap? {
        val source = frame ?: return null
        if (source.isRecycled) return null
        if (expectedKey != null && expectedKey.isNotBlank() && expectedKey != continuityKey) return null
        return runCatching { source.copy(Bitmap.Config.ARGB_8888, false) }.getOrNull()
    }

    fun info(): LiveBestFrameInfo = LiveBestFrameInfo(quality, continuityKey, storedAtMs)

    fun clear() {
        frame?.takeIf { !it.isRecycled }?.recycle()
        frame = null
        quality = Int.MIN_VALUE
        continuityKey = ""
        storedAtMs = 0L
    }

    private fun geometryContinuityKey(bitmap: Bitmap, tracks: List<LiveSceneTrack>): String {
        val visible = tracks.filter { it.missingFrames == 0 }
            .sortedWith(compareBy<LiveSceneTrack> { it.bounds.top }.thenBy { it.bounds.left })
        val bucketX = max(1, bitmap.width / 8)
        val bucketY = max(1, bitmap.height / 12)
        return visible.joinToString("|") { track ->
            val cx = (track.bounds.left + track.bounds.right) / 2
            val cy = (track.bounds.top + track.bounds.bottom) / 2
            val w = track.bounds.width().coerceAtLeast(1)
            val h = track.bounds.height().coerceAtLeast(1)
            "${track.proposalType}:${cx / bucketX}:${cy / bucketY}:${w / bucketX}:${h / bucketY}"
        }
    }

    private fun qualityScore(bitmap: Bitmap, tracks: List<LiveSceneTrack>): Int {
        var exposure = 0L
        var contrast = 0L
        var count = 0
        val stepX = max(1, bitmap.width / 16)
        val stepY = max(1, bitmap.height / 16)
        var y = 0
        while (y < bitmap.height) {
            var x = 0
            var previous = -1
            while (x < bitmap.width) {
                val p = bitmap.getPixel(x, y)
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                val lum = (r * 30 + g * 59 + b * 11) / 100
                exposure += 255 - kotlin.math.abs(lum - 128)
                if (previous >= 0) contrast += kotlin.math.abs(lum - previous)
                previous = lum
                count++
                x += stepX
            }
            y += stepY
        }
        val imageScore = if (count == 0) 0 else ((exposure / count) / 4 + (contrast / count)).toInt()
        val identityScore = tracks.maxOfOrNull { it.bestVisualScore + it.bestMargin.coerceAtLeast(0) } ?: 0
        return imageScore + identityScore
    }

    private fun boundedCopy(source: Bitmap, maxSide: Int): Bitmap? = runCatching {
        val largest = max(source.width, source.height)
        if (largest <= maxSide) source.copy(Bitmap.Config.ARGB_8888, false) else {
            val scale = maxSide.toFloat() / largest.toFloat()
            val w = (source.width * scale).toInt().coerceAtLeast(1)
            val h = (source.height * scale).toInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(source, w, h, true)
        }
    }.getOrNull()
}
