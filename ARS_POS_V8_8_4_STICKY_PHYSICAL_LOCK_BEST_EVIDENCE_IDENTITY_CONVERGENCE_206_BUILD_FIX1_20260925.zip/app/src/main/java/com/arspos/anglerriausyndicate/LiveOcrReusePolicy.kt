package com.arspos.anglerriausyndicate

/** V8.8.4 bounded positive/negative OCR cache for one stable live object hypothesis. */
object LiveOcrReusePolicy {
    const val IDENTITY_TTL_MS = 8_000L
    const val EMPTY_TTL_MS = 5_000L
    const val VISUAL_IMPROVEMENT_RESCAN = 5

    fun mayReuse(
        ageMs: Long,
        hasIdentityText: Boolean,
        cachedVisualScore: Int,
        currentVisualScore: Int
    ): Boolean {
        val ttl = if (hasIdentityText) IDENTITY_TTL_MS else EMPTY_TTL_MS
        if (ageMs !in 0..ttl) return false
        return currentVisualScore <= cachedVisualScore + VISUAL_IMPROVEMENT_RESCAN
    }

    fun negativeEvidenceReusable(ageMs: Long, cachedVisualScore: Int, currentVisualScore: Int): Boolean =
        mayReuse(ageMs, false, cachedVisualScore, currentVisualScore)
}
