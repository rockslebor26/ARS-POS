package com.arspos.anglerriausyndicate

/**
 * Phase 4.3.5.4 / V8.8.4 — one authoritative physical-object lifecycle.
 *
 * Detection/tracking/lock are deliberately separated from SKU identity. The
 * live camera may start identity work only after at least one visible physical
 * track is stable enough to lock. This class owns preview hysteresis as well,
 * replacing several overlapping temporal decisions with one bounded policy.
 */
object PhysicalObjectStateMachine {
    const val STATE_NEW = "NEW"
    const val STATE_DETECTED = "DETECTED"
    const val STATE_TRACKING = "TRACKING"
    const val STATE_STABILIZING = "STABILIZING"
    const val STATE_LOCKED = "LOCKED"
    const val STATE_LOST_GRACE = "LOST_GRACE"
    const val STATE_EXITED = "EXITED"

    const val LOCK_HITS = 3
    const val STABILIZING_HITS = 2
    const val MAX_IDENTITY_HOLD_WEAK_FRAMES = 6
    const val MAX_CANDIDATE_HOLD_WEAK_FRAMES = 4
    const val MATCHED_SWITCH_AGREEMENT = 3
    const val UNMATCHED_SWITCH_AGREEMENT = 2
    const val STRONG_SWITCH_ADVANTAGE = 8

    fun state(hitStreak: Int, missingFrames: Int, observationCount: Int): String = when {
        missingFrames > 3 -> STATE_EXITED
        missingFrames > 0 -> STATE_LOST_GRACE
        observationCount <= 0 -> STATE_NEW
        hitStreak >= LOCK_HITS -> STATE_LOCKED
        hitStreak >= STABILIZING_HITS -> STATE_STABILIZING
        hitStreak == 1 -> STATE_DETECTED
        else -> STATE_TRACKING
    }

    fun shouldRunIdentity(hitStreaks: List<Int>, missingFrames: List<Int>): Boolean {
        val count = minOf(hitStreaks.size, missingFrames.size)
        for (index in 0 until count) {
            if (missingFrames[index] == 0 && hitStreaks[index] >= LOCK_HITS) return true
        }
        return false
    }

    fun canLockScene(states: List<String>): Boolean = states.any { it == STATE_LOCKED }

    fun shouldHoldIdentity(
        hadMatched: Boolean,
        productStillOwned: Boolean,
        weakEvidenceFrames: Int,
        missingFrames: Int
    ): Boolean = hadMatched &&
        productStillOwned &&
        missingFrames == 0 &&
        weakEvidenceFrames in 1..MAX_IDENTITY_HOLD_WEAK_FRAMES

    /**
     * Identity may not jump from a proven SKU to a challenger because of one
     * noisy frame. Accepted strong challengers can switch sooner only when they
     * have a material visual advantage; otherwise three agreeing observations
     * are required after a previously matched identity.
     */
    fun shouldSwitchIdentity(
        hadMatched: Boolean,
        currentVisualScore: Int,
        challengerVisualScore: Int,
        challengerAccepted: Boolean,
        pendingAgreement: Int
    ): Boolean {
        if (!hadMatched) return challengerAccepted || pendingAgreement >= UNMATCHED_SWITCH_AGREEMENT
        val strongAcceptedSwitch = challengerAccepted &&
            challengerVisualScore >= currentVisualScore + STRONG_SWITCH_ADVANTAGE &&
            pendingAgreement >= UNMATCHED_SWITCH_AGREEMENT
        return strongAcceptedSwitch || pendingAgreement >= MATCHED_SWITCH_AGREEMENT
    }
}
