package com.arspos.anglerriausyndicate

import android.graphics.Bitmap
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Phase 4.3.2.18 V8.1: offline OCR + optional barcode helper for product intake.
 * This is an assistant only: the operator still reviews the generated fields
 * before saving a product.
 */
object SmartProductInput {
    data class Draft(
        val rawText: String = "",
        val identityText: String = "",
        val brand: String = "",
        val name: String = "",
        val variant: String = "",
        val barcode: String = "",
        val modelCode: String = "",
        val suggestedSku: String = ""
    )

    private val textRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val barcodeScanner by lazy {
        BarcodeScanning.getClient()
    }

    suspend fun analyze(bitmap: Bitmap): Draft {
        val image = InputImage.fromBitmap(bitmap, 0)
        val text = textRecognizer.process(image).await()
        val barcode = barcodeScanner.process(image).await().firstOrNull()?.rawValue.orEmpty()
        return buildDraft(text.text, barcode)
    }


    /** Phase 4.3.2.7.1: OCR + barcode across four orientations.
     * The scanner still captures one photo; the image is rotated in memory only
     * so labels photographed sideways/upside-down can still be read.
     */
    suspend fun analyzeMultiOrientation(bitmap: Bitmap): Draft =
        analyzeOrientations(bitmap, intArrayOf(0, 90, 180, 270))

    /**
     * V8.8.1 fast path for an already oriented elongated identity ROI.
     * Final recognition thresholds are unchanged; this only avoids redundant
     * 90/270 OCR passes on a LONG crop that the scanner has already oriented.
     */
    suspend fun analyzeLongIdentity(bitmap: Bitmap): Draft =
        analyzeOrientations(bitmap, intArrayOf(0, 180))

    /** Lightweight live-preview OCR. Preview is advisory and cannot mutate cart. */
    suspend fun analyzeLiveFast(bitmap: Bitmap): Draft =
        analyzeOrientations(bitmap, intArrayOf(0))

    /**
     * V8.8.4 NORMAL-object identity OCR. Start with the complete crop; when it
     * contains no identity-bearing evidence, inspect at most three bounded
     * discriminative sub-regions (for example a lighter metal head/logo).
     * The result only feeds the existing recognition rules; no threshold changes.
     */
    suspend fun analyzeDiscriminativeNormalIdentity(bitmap: Bitmap): Draft {
        val full = analyzeMultiOrientation(bitmap)
        if (full.identityText.isNotBlank() || full.barcode.isNotBlank()) return full

        var best = full
        var bestQuality = draftIdentityQuality(full)
        for (rect in AdaptiveIdentityRoi.discriminativeRegions(bitmap.width, bitmap.height)) {
            val region = runCatching {
                Bitmap.createBitmap(bitmap, rect.left, rect.top, rect.width(), rect.height())
            }.getOrNull() ?: continue
            val zoomed = upscaleIdentityRegion(region)
            try {
                val draft = analyzeMultiOrientation(zoomed)
                val quality = draftIdentityQuality(draft)
                if (quality > bestQuality) {
                    best = draft
                    bestQuality = quality
                }
                if (draft.barcode.isNotBlank() || (draft.identityText.length >= 3 && quality >= 10)) break
            } finally {
                if (zoomed !== region && !zoomed.isRecycled) zoomed.recycle()
                if (!region.isRecycled) region.recycle()
            }
        }
        return best
    }

    private fun draftIdentityQuality(draft: Draft): Int {
        val identity = draft.identityText.ifBlank { draft.rawText }.trim()
        val tokens = identity.uppercase().split(Regex("[^A-Z0-9]+"))
            .filter { it.length >= 2 }
        return (if (draft.barcode.isNotBlank()) 100 else 0) + tokens.size * 6 + identity.length.coerceAtMost(80)
    }

    private fun upscaleIdentityRegion(source: Bitmap): Bitmap {
        val shortSide = minOf(source.width, source.height).coerceAtLeast(1)
        if (shortSide >= 240) return source
        val scale = (240f / shortSide.toFloat()).coerceAtMost(3.0f)
        val targetW = (source.width * scale).toInt().coerceIn(1, 960)
        val targetH = (source.height * scale).toInt().coerceIn(1, 960)
        if (targetW == source.width && targetH == source.height) return source
        return Bitmap.createScaledBitmap(source, targetW, targetH, true)
    }

    private suspend fun analyzeOrientations(bitmap: Bitmap, rotations: IntArray): Draft {
        val drafts = ArrayList<Draft>()

        for (angle in rotations) {
            val rotated = if (angle == 0) bitmap else rotate(bitmap, angle)
            val draft = try {
                runCatching { analyze(rotated) }.getOrNull()
            } finally {
                if (rotated !== bitmap && !rotated.isRecycled) rotated.recycle()
            }
            if (draft != null) drafts += draft
        }

        if (drafts.isEmpty()) return Draft()

        var barcode = ""
        for (draft in drafts) {
            val value = draft.barcode.trim()
            if (value.isNotBlank()) {
                barcode = value
                break
            }
        }

        var bestText = drafts[0]
        var bestMeaningful = -1

        for (draft in drafts) {
            val identity = draft.identityText.ifBlank { draft.rawText }
            val meaningful = identity
                .uppercase()
                .split(Regex("[^A-Z0-9]+"))
                .count { token -> token.length >= 3 }

            val quality = meaningful * 4 + identity.length.coerceAtMost(160)
            if (quality > bestMeaningful) {
                bestMeaningful = quality
                bestText = draft
            }
        }

        val mergedLines = ArrayList<String>()
        for (draft in drafts) {
            for (line in draft.rawText.lines()) {
                val clean = line.trim()
                if (clean.length >= 2 && !mergedLines.contains(clean)) mergedLines += clean
            }
        }

        var modelCode = ""
        for (draft in drafts) {
            val value = draft.modelCode.trim()
            if (value.isNotBlank()) {
                modelCode = value
                break
            }
        }

        if (barcode.isBlank()) barcode = bestText.barcode

        val mergedRawText = if (mergedLines.isNotEmpty()) mergedLines.joinToString("\n") else bestText.rawText
        return Draft(
            rawText = mergedRawText,
            identityText = IdentityTextPolicy.identityBearingText(mergedRawText),
            brand = bestText.brand,
            name = bestText.name,
            variant = bestText.variant,
            barcode = barcode,
            modelCode = modelCode,
            suggestedSku = bestText.suggestedSku
        )
    }

    private fun rotate(source: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return source
        val matrix = android.graphics.Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    fun buildDraft(raw: String, detectedBarcode: String = ""): Draft {
        val lines = raw.lines()
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.length >= 2 }
            .distinct()
        val identityLines = IdentityTextPolicy.identityLines(lines.joinToString("\n"))
        val identityText = identityLines.joinToString("\n")

        val barcode = detectedBarcode.ifBlank {
            lines.firstOrNull { it.matches(Regex("\\d{8,14}")) }.orEmpty()
        }

        val size = Regex("(?i)\\b(?:SIZE|SZ|UKURAN)\\s*[:.-]?\\s*([A-Z0-9]+)")
            .find(identityLines.joinToString(" "))?.groupValues?.getOrNull(1).orEmpty()

        val joinedForModel = identityLines.joinToString(" ")
        val modelCode = Regex("(?i)\\b[A-Z]{1,4}[- ]?[0-9]{1,5}[A-Z0-9-]*\\b|\\b[0-9]{4,8}\\b")
            .findAll(joinedForModel)
            .map { it.value.trim() }
            .firstOrNull { normalizeCode(it) != normalizeCode(barcode) }
            .orEmpty()

        val brand = identityLines.firstOrNull { line ->
            line.any(Char::isLetter) &&
                !line.contains("SILICONE", ignoreCase = true) &&
                !line.contains("SIZE", ignoreCase = true) &&
                !line.contains("KOREA", ignoreCase = true) &&
                !line.contains("TECHNOLOGY", ignoreCase = true) &&
                !line.contains("QUALITY", ignoreCase = true)
        }.orEmpty()

        val ignored = setOf(
            brand.uppercase(),
            "KOREA", "KOREAN", "TECHNOLOGY", "SILICONE", "SKIRT",
            "QUALITY", "PREMIUM", "BEST", "GO", "SIZE", barcode.uppercase(), modelCode.uppercase()
        )

        val nameParts = identityLines.filter { line ->
            val upper = line.uppercase()
            line.any(Char::isLetter) &&
                upper != brand.uppercase() &&
                !upper.contains("SIZE") &&
                !upper.matches(Regex(".*\\d{2,}.*")) &&
                !upper.split(" ").all { it in ignored }
        }.take(2)

        val name = when {
            nameParts.isNotEmpty() -> listOf(brand, *nameParts.toTypedArray())
                .filter { it.isNotBlank() }
                .distinct()
                .joinToString(" ")
            brand.isNotBlank() -> brand
            else -> identityLines.firstOrNull().orEmpty()
        }

        val consumedIdentity = (listOf(brand) + nameParts).map { it.uppercase() }.toSet()
        val variantParts = buildList {
            if (size.isNotBlank()) add(size)
            val colorLine = identityLines.firstOrNull { line ->
                val u = line.uppercase()
                u.contains("GREEN") || u.contains("ORANGE") || u.contains("RED") ||
                    u.contains("BLUE") || u.contains("BLACK") || u.contains("WHITE") ||
                    u.contains("YELLOW") || u.contains("PINK")
            }
            if (!colorLine.isNullOrBlank()) add(colorLine)
            identityLines.filter { line ->
                line.any(Char::isLetter) &&
                    line.uppercase() !in consumedIdentity &&
                    !line.equals(modelCode, ignoreCase = true) &&
                    !line.equals(colorLine, ignoreCase = true)
            }.take(2).forEach(::add)
            if (modelCode.isNotBlank()) add(modelCode)
        }
        val variant = variantParts.distinct().joinToString(" ")

        val suggestedSku = generateSku(brand, name, variant, modelCode)

        return Draft(
            rawText = lines.joinToString("\n"),
            identityText = identityText,
            brand = brand,
            name = name,
            variant = variant,
            barcode = barcode,
            modelCode = modelCode,
            suggestedSku = suggestedSku
        )
    }

    fun generateSku(brand: String, name: String, variant: String, modelCode: String = ""): String {
        val source = listOf(brand, name, variant, modelCode)
            .filter { it.isNotBlank() }
            .joinToString(" ")
            .uppercase()
            .replace(Regex("[^A-Z0-9]+"), " ")
            .trim()
        val tokens = source.split(" ").filter { it.isNotBlank() }
        val initials = tokens.take(3).joinToString("") { it.take(3) }
        val code = modelCode.filter(Char::isDigit).take(8)
        val suffix = (System.currentTimeMillis() % 10000).toString().padStart(4, '0')
        return listOf(initials.take(9), code, suffix)
            .filter { it.isNotBlank() }
            .joinToString("-")
            .ifBlank { "PRD-$suffix" }
    }

    private fun normalizeCode(value: String): String = value
        .uppercase()
        .replace(Regex("[^A-Z0-9]+"), "")

    private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T =
        suspendCancellableCoroutine { continuation ->
            addOnSuccessListener { value ->
                if (continuation.isActive) continuation.resume(value)
            }
            addOnFailureListener { error ->
                if (continuation.isActive) continuation.resumeWithException(error)
            }
            addOnCanceledListener { continuation.cancel() }
        }
}
