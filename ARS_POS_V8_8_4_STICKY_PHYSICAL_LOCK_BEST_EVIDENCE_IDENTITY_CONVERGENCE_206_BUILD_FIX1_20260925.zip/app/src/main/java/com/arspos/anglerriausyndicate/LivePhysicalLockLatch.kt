package com.arspos.anglerriausyndicate

/**
 * V8.8.4 UI lock latch.
 *
 * Physical scene eligibility is intentionally independent from OCR/high-resolution
 * identity work. A scene becomes lockable only after the authoritative physical
 * state machine reaches LOCKED. Once acquired, a short detector/identity handoff
 * cannot make the operator button flicker. Release remains bounded: two confirmed
 * empty ledger updates or a prolonged period with no reacquired physical lock.
 */
data class LiveLockUiState(
    val canLock: Boolean = false,
    val reason: String = "NO_TRACKS",
    val physicalLockEpochMs: Long = 0L,
    val lastLockedAtMs: Long = 0L,
    val releaseReason: String = ""
)

class LivePhysicalLockLatch(
    private val maxTransientNoLockMs: Long = 5_000L,
    private val emptyUpdatesToRelease: Int = 2
) {
    private var latched = false
    private var physicalLockEpochMs = 0L
    private var lastLockedAtMs = 0L
    private var noLockSinceMs = 0L
    private var consecutiveEmptyUpdates = 0
    private var releaseReason = ""

    fun update(tracks: List<LiveSceneTrack>, nowMs: Long = System.currentTimeMillis()): LiveLockUiState {
        val lockedNow = tracks.any {
            it.missingFrames == 0 && it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED
        }

        if (lockedNow) {
            if (!latched) physicalLockEpochMs = nowMs
            latched = true
            lastLockedAtMs = nowMs
            noLockSinceMs = 0L
            consecutiveEmptyUpdates = 0
            releaseReason = ""
            return snapshot("PHYSICAL_LOCKED")
        }

        if (!latched) {
            return snapshot(if (tracks.isEmpty()) "NO_TRACKS" else "WAITING_PHYSICAL_LOCK")
        }

        if (tracks.isEmpty()) {
            consecutiveEmptyUpdates += 1
            if (consecutiveEmptyUpdates >= emptyUpdatesToRelease) {
                release("SCENE_EMPTY_CONFIRMED")
                return snapshot("NO_TRACKS")
            }
            return snapshot("LOCK_GRACE_EMPTY_FRAME")
        }

        consecutiveEmptyUpdates = 0
        if (noLockSinceMs == 0L) noLockSinceMs = nowMs
        if (nowMs - noLockSinceMs >= maxTransientNoLockMs) {
            release("PHYSICAL_LOCK_NOT_REACQUIRED")
            return snapshot("WAITING_PHYSICAL_LOCK")
        }

        return snapshot("LOCK_HELD_DURING_TRANSIENT_IDENTITY_WORK")
    }

    fun clear() {
        latched = false
        physicalLockEpochMs = 0L
        lastLockedAtMs = 0L
        noLockSinceMs = 0L
        consecutiveEmptyUpdates = 0
        releaseReason = ""
    }

    private fun release(reason: String) {
        latched = false
        physicalLockEpochMs = 0L
        lastLockedAtMs = 0L
        noLockSinceMs = 0L
        consecutiveEmptyUpdates = 0
        releaseReason = reason
    }

    private fun snapshot(reason: String) = LiveLockUiState(
        canLock = latched,
        reason = reason,
        physicalLockEpochMs = physicalLockEpochMs,
        lastLockedAtMs = lastLockedAtMs,
        releaseReason = releaseReason
    )
}
