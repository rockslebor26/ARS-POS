package com.arspos.anglerriausyndicate

/**
 * V8.8.4 detect-many / identify-selectively scheduler.
 * Exactly one locked physical object receives expensive identity work per pass.
 * Ambiguous static objects get a bounded retry even when scene-change is small,
 * preventing a stable object from remaining forever in IDENTITY_NOT_SCHEDULED.
 */
object LiveIdentityScheduler {
    const val IDENTITY_COOLDOWN_MS = 750L
    const val AMBIGUOUS_COOLDOWN_MS = 1_000L
    const val HIGH_RES_COOLDOWN_MS = 2_000L
    const val MATCHED_REVERIFY_MS = 8_000L
    const val REQUIRED_VIEW_CHANGE = 0.055f
    const val STATIC_AMBIGUITY_RETRY_MS = 3_500L
    const val MAX_AMBIGUOUS_IDENTITY_EVALUATIONS = 4

    data class Selection(val trackId: String, val highResolution: Boolean)

    fun choose(
        tracks: List<LiveSceneTrack>,
        lastIdentityAt: Map<String, Long>,
        lastHighResAt: Map<String, Long>,
        nowMs: Long,
        preferredTrackId: String?,
        cursor: Int,
        sceneChange: Float = 1f
    ): Pair<Selection?, Int> {
        val visibleLocked = tracks.filter {
            it.missingFrames == 0 && it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED
        }
        if (visibleLocked.isEmpty()) return null to cursor

        fun eligible(track: LiveSceneTrack): Boolean {
            val age = nowMs - (lastIdentityAt[track.trackId] ?: 0L)
            if (track.state == LiveSceneTrack.STATE_MATCHED) return age >= MATCHED_REVERIFY_MS

            if (track.evidenceStage == LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED &&
                sceneChange < REQUIRED_VIEW_CHANGE
            ) {
                val boundedStaticRetry = track.identityEvaluationCount < MAX_AMBIGUOUS_IDENTITY_EVALUATIONS &&
                    age >= STATIC_AMBIGUITY_RETRY_MS
                if (!boundedStaticRetry) return false
            }

            if (track.evidenceStage == LiveEvidenceEscalationPolicy.HIGH_RES_REQUIRED ||
                track.evidenceStage == LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED
            ) {
                val highResAge = nowMs - (lastHighResAt[track.trackId] ?: 0L)
                if (highResAge < HIGH_RES_COOLDOWN_MS) return false
            }

            val minimum = when (track.evidenceStage) {
                LiveEvidenceEscalationPolicy.HIGH_RES_REQUIRED,
                LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED -> AMBIGUOUS_COOLDOWN_MS
                else -> IDENTITY_COOLDOWN_MS
            }
            return age >= minimum
        }

        val preferred = preferredTrackId?.let { id -> visibleLocked.firstOrNull { it.trackId == id && eligible(it) } }
        val unresolved = visibleLocked.filter { it.state != LiveSceneTrack.STATE_MATCHED && eligible(it) }
        val reverify = visibleLocked.filter { it.state == LiveSceneTrack.STATE_MATCHED && eligible(it) }
        val pool = when {
            preferred != null -> listOf(preferred)
            unresolved.isNotEmpty() -> unresolved
            else -> reverify
        }
        if (pool.isEmpty()) return null to cursor

        val index = Math.floorMod(cursor, pool.size)
        val selected = pool[index]
        val wantsHighRes = selected.evidenceStage == LiveEvidenceEscalationPolicy.HIGH_RES_REQUIRED ||
            selected.evidenceStage == LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED
        return Selection(selected.trackId, wantsHighRes) to (cursor + 1)
    }
}
