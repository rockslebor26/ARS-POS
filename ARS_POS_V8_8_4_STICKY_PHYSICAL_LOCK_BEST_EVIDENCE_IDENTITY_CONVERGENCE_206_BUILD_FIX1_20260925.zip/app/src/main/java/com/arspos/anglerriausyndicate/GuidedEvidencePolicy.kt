package com.arspos.anglerriausyndicate

/** Operator guidance follows the evidence stage; repeated identical OCR is not guidance. */
object GuidedEvidencePolicy {
    const val NONE = ""

    fun message(
        physicalState: String,
        identityState: String,
        proposalType: String,
        visualScore: Int,
        margin: Int,
        missingFrames: Int,
        evidenceStage: String = LiveEvidenceEscalationPolicy.TRACK_ONLY
    ): String = when {
        missingFrames > 0 -> "Tampilkan kembali objek ke kamera"
        physicalState != PhysicalObjectStateMachine.STATE_LOCKED -> "Tahan objek stabil sampai kotak terkunci"
        identityState == "CONFIRMED_PREVIEW" -> NONE
        evidenceStage == LiveEvidenceEscalationPolicy.HIGH_RES_REQUIRED ->
            "Tahan stabil • ARS mengambil detail resolusi tinggi"
        evidenceStage == LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED && proposalType == ScanProposal.TYPE_LONG ->
            "Arahkan ke HANDLE / logo / kode model joran"
        evidenceStage == LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED ->
            "Putar sedikit produk untuk menampilkan sisi atau ciri pembeda baru"
        evidenceStage == LiveEvidenceEscalationPolicy.OCR ->
            "Tahan label tetap tajam agar teks identitas terbaca"
        identityState == "AMBIGUOUS" && margin < LiveIdentityPolicy.AMBIGUOUS_VISUAL_MARGIN ->
            "Kandidat mirip • ARS mencari bukti pembeda"
        visualScore < LiveIdentityPolicy.MIN_VISUAL_FOR_NORMAL_IDENTITY ->
            "Dekatkan kamera dan pastikan produk tajam serta tidak silau"
        else -> "Tahan objek stabil"
    }
}
