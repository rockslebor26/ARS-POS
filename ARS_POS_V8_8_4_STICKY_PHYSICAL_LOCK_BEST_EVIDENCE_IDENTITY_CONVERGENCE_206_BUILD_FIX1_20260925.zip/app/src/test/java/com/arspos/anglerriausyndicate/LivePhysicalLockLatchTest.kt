package com.arspos.anglerriausyndicate

import android.graphics.Rect
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LivePhysicalLockLatchTest {
    private fun track(state: String, missing: Int = 0) = LiveSceneTrack(
        trackId = "LIVE-1",
        bounds = Rect(0, 0, 100, 100),
        proposalType = ScanProposal.TYPE_NORMAL,
        product = null,
        visualScore = 0,
        margin = 0,
        hitStreak = if (state == PhysicalObjectStateMachine.STATE_LOCKED) 3 else 1,
        missingFrames = missing,
        state = LiveSceneTrack.STATE_UNKNOWN,
        quantityPreviewEligible = false,
        reason = "TEST",
        physicalState = state
    )

    @Test fun analyzerOrIdentityHandoffCannotBlinkLockButton() {
        val latch = LivePhysicalLockLatch(maxTransientNoLockMs = 5_000L, emptyUpdatesToRelease = 2)
        assertTrue(latch.update(listOf(track(PhysicalObjectStateMachine.STATE_LOCKED)), 1_000L).canLock)
        assertTrue(latch.update(listOf(track(PhysicalObjectStateMachine.STATE_STABILIZING)), 2_000L).canLock)
        assertTrue(latch.update(listOf(track(PhysicalObjectStateMachine.STATE_STABILIZING)), 4_500L).canLock)
    }

    @Test fun confirmedEmptySceneReleasesLatch() {
        val latch = LivePhysicalLockLatch(maxTransientNoLockMs = 5_000L, emptyUpdatesToRelease = 2)
        assertTrue(latch.update(listOf(track(PhysicalObjectStateMachine.STATE_LOCKED)), 1_000L).canLock)
        assertTrue(latch.update(emptyList(), 1_500L).canLock)
        assertFalse(latch.update(emptyList(), 2_000L).canLock)
    }
}
