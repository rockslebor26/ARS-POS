package com.arspos.anglerriausyndicate

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhysicalObjectStateMachineTest {
    @Test fun objectMustStabilizeBeforeLock() {
        assertEquals(PhysicalObjectStateMachine.STATE_DETECTED, PhysicalObjectStateMachine.state(1, 0, 1))
        assertEquals(PhysicalObjectStateMachine.STATE_STABILIZING, PhysicalObjectStateMachine.state(2, 0, 2))
        assertEquals(PhysicalObjectStateMachine.STATE_LOCKED, PhysicalObjectStateMachine.state(3, 0, 3))
        assertFalse(PhysicalObjectStateMachine.shouldRunIdentity(listOf(2), listOf(0)))
        assertTrue(PhysicalObjectStateMachine.shouldRunIdentity(listOf(3), listOf(0)))
    }

    @Test fun missingObjectUsesGraceInsteadOfNewIdentity() {
        assertEquals(PhysicalObjectStateMachine.STATE_LOST_GRACE, PhysicalObjectStateMachine.state(2, 1, 4))
        assertTrue(PhysicalObjectStateMachine.shouldHoldIdentity(true, true, 6, 0))
        assertFalse(PhysicalObjectStateMachine.shouldHoldIdentity(true, true, 7, 0))
    }

    @Test fun acceptedUnmatchedCandidateCanSurfaceImmediatelyWithoutChangingThresholds() {
        assertTrue(PhysicalObjectStateMachine.shouldSwitchIdentity(false, 0, 82, true, 1))
        assertFalse(PhysicalObjectStateMachine.shouldSwitchIdentity(false, 0, 70, false, 1))
        assertTrue(PhysicalObjectStateMachine.shouldSwitchIdentity(false, 0, 70, false, 2))
    }

    @Test fun matchedIdentityNeedsMoreEvidenceToSwitch() {
        assertFalse(PhysicalObjectStateMachine.shouldSwitchIdentity(true, 88, 90, false, 2))
        assertTrue(PhysicalObjectStateMachine.shouldSwitchIdentity(true, 88, 90, false, 3))
        assertTrue(PhysicalObjectStateMachine.shouldSwitchIdentity(true, 80, 90, true, 2))
    }
}
