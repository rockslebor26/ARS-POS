package com.arspos.anglerriausyndicate

import org.junit.Assert.*
import org.junit.Test

class LiveOcrReusePolicyTest {
    @Test fun identityOcrMayBeReusedInsideBoundedTtl() {
        assertTrue(LiveOcrReusePolicy.mayReuse(5_000, true, 78, 79))
        assertFalse(LiveOcrReusePolicy.mayReuse(8_100, true, 78, 79))
    }

    @Test fun negativeOcrIsCachedButMeaningfullyBetterFrameForcesRefresh() {
        assertTrue(LiveOcrReusePolicy.mayReuse(4_000, false, 75, 75))
        assertFalse(LiveOcrReusePolicy.mayReuse(5_100, false, 75, 75))
        assertFalse(LiveOcrReusePolicy.mayReuse(300, true, 75, 81))
        assertTrue(LiveOcrReusePolicy.negativeEvidenceReusable(4_500, 75, 77))
    }
}
