package com.arspos.anglerriausyndicate

import android.graphics.Rect
import org.junit.Assert.*
import org.junit.Test

class AdaptiveIdentityRoiTest {
    @Test fun variantsStayInsideFrameAndBecomeMoreSelective() {
        val variants = AdaptiveIdentityRoi.variants(Rect(-5, 10, 205, 190), 200, 200)
        assertTrue(variants.size >= 2)
        variants.forEach {
            assertTrue(it.left >= 0 && it.top >= 0)
            assertTrue(it.right <= 200 && it.bottom <= 200)
        }
        assertTrue(variants.last().width() < variants.first().width())
    }

    @Test fun scalingPreservesNormalizedLocation() {
        val scaled = AdaptiveIdentityRoi.scale(Rect(50, 25, 150, 75), 200, 100, 1000, 500)
        assertEquals(Rect(250, 125, 750, 375), scaled)
    }
    @Test fun usefulResolutionGainAcceptsObservedDeviceRatio() {
        assertTrue(AdaptiveIdentityRoi.hasUsefulResolutionGain(609, 1280, 487, 1024))
        assertFalse(AdaptiveIdentityRoi.hasUsefulResolutionGain(520, 1080, 487, 1024))
    }

    @Test fun tallObjectGetsEndcapDiscriminativeRegions() {
        val regions = AdaptiveIdentityRoi.discriminativeRegions(120, 360)
        assertEquals(3, regions.size)
        assertEquals(0, regions.first().top)
        assertEquals(360, regions[1].bottom)
    }

}
