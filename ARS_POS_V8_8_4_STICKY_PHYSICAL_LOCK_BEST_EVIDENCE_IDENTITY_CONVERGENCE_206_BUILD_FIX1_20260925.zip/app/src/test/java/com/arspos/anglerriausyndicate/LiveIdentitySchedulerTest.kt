package com.arspos.anglerriausyndicate

import android.graphics.Rect
import org.junit.Assert.*
import org.junit.Test

class LiveIdentitySchedulerTest {
    private fun track(id: String, stage: String, state: String = LiveSceneTrack.STATE_UNKNOWN) = LiveSceneTrack(
        trackId = id,
        bounds = Rect(0, 0, 100, 100),
        proposalType = ScanProposal.TYPE_NORMAL,
        product = null,
        visualScore = 80,
        margin = 2,
        hitStreak = 3,
        missingFrames = 0,
        state = state,
        quantityPreviewEligible = false,
        reason = "TEST",
        physicalState = PhysicalObjectStateMachine.STATE_LOCKED,
        evidenceStage = stage
    )

    @Test fun onlyOneLockedObjectGetsIdentityBudgetPerPass() {
        val tracks = listOf(track("LIVE-1", LiveEvidenceEscalationPolicy.VISUAL_RETRIEVAL), track("LIVE-2", LiveEvidenceEscalationPolicy.OCR))
        val (selection, _) = LiveIdentityScheduler.choose(tracks, emptyMap(), emptyMap(), 10_000, null, 0)
        assertNotNull(selection)
        assertEquals("LIVE-1", selection!!.trackId)
    }

    @Test fun operatorSelectedObjectGetsPriority() {
        val tracks = listOf(track("LIVE-1", LiveEvidenceEscalationPolicy.VISUAL_RETRIEVAL), track("LIVE-2", LiveEvidenceEscalationPolicy.OCR))
        val (selection, _) = LiveIdentityScheduler.choose(tracks, emptyMap(), emptyMap(), 10_000, "LIVE-2", 0)
        assertEquals("LIVE-2", selection?.trackId)
    }

    @Test fun highResolutionStageUsesBoundedCooldown() {
        val tracks = listOf(track("LIVE-1", LiveEvidenceEscalationPolicy.HIGH_RES_REQUIRED))
        val (blocked, _) = LiveIdentityScheduler.choose(tracks, emptyMap(), mapOf("LIVE-1" to 9_000), 10_000, null, 0)
        assertNull(blocked)
        val (ready, _) = LiveIdentityScheduler.choose(tracks, emptyMap(), mapOf("LIVE-1" to 7_000), 10_000, null, 0)
        assertTrue(ready?.highResolution == true)
    }
    @Test fun viewChangeStageWaitsForMeaningfulNewView() {
        val tracks = listOf(track("LIVE-1", LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED))
        val (blocked, _) = LiveIdentityScheduler.choose(
            tracks, mapOf("LIVE-1" to 9_000L), emptyMap(), 10_000, null, 0, sceneChange = 0.02f
        )
        assertNull(blocked)
        val (ready, _) = LiveIdentityScheduler.choose(
            tracks, emptyMap(), emptyMap(), 10_000, null, 0, sceneChange = 0.08f
        )
        assertEquals("LIVE-1", ready?.trackId)
    }

    @Test fun staticAmbiguityGetsBoundedHighResolutionRetry() {
        val track = track("LIVE-1", LiveEvidenceEscalationPolicy.VIEW_CHANGE_REQUIRED).copy(identityEvaluationCount = 2)
        val (ready, _) = LiveIdentityScheduler.choose(
            listOf(track), mapOf("LIVE-1" to 5_000L), mapOf("LIVE-1" to 5_000L),
            10_000L, null, 0, sceneChange = 0.01f
        )
        assertEquals("LIVE-1", ready?.trackId)
        assertTrue(ready?.highResolution == true)

        val exhausted = track.copy(identityEvaluationCount = LiveIdentityScheduler.MAX_AMBIGUOUS_IDENTITY_EVALUATIONS)
        val (blocked, _) = LiveIdentityScheduler.choose(
            listOf(exhausted), mapOf("LIVE-1" to 5_000L), mapOf("LIVE-1" to 5_000L),
            10_000L, null, 0, sceneChange = 0.01f
        )
        assertNull(blocked)
    }

}
