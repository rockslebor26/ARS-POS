# Current Release Candidate

ARS POS **1.10.6 (206)** — Phase **4.3.5.4** / **V8.8.4 Sticky Physical Lock + Best-Evidence Identity Convergence**.

Primary acceptance focus: lock CTA remains stable after physical lock, best high-resolution evidence reaches final scoring, static ambiguity receives only bounded retries, small discriminative labels can be recovered without threshold changes, and quantity remains final-scan + physical-safety owned.

Recognition thresholds, package, Room v5 and official signer are unchanged. Cloud Identity remains `SHADOW`; Self Learning remains `ACTIVE_CONFIRMED_ONLY`; ARS AI Engineer is `DEV_CENTER_DIAGNOSTIC_ONLY` and outside the automatic cashier scan path.

Install only as an in-place update from official 1.10.5 (205). The release is not device-finished until the supplied GitHub Actions build passes and real-device regression evidence is reviewed.
