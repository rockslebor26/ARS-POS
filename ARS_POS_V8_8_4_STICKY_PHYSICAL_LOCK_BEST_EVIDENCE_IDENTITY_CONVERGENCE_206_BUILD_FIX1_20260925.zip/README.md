# ARS POS 1.10.6 (206) — Phase 4.3.5.4 / V8.8.4

**Sticky Physical Lock + Best-Evidence Identity Convergence**

V8.8.4 is the field-correction release after V8.8.3. It preserves physical lock independently from analyzer/OCR/HIGH_RES work, carries materially better live evidence into the final scanner, gives static ambiguous objects a bounded retry, and adds bounded micro-OCR for small discriminative labels.

Production pipeline:

`detect many → persistent physical track → sticky lock → best evidence → Top-K recall → exact/discriminative identity → bounded evidence escalation → final convergence → physical quantity safety → cashier review`.

## Release invariants

- Package: `com.arspos.anglerriausyndicate`
- versionName/versionCode: `1.10.6 / 206`
- Phase/engine: `4.3.5.4 / V8.8.4`
- Room database: `v5`, no destructive migration
- Cloud Identity: `SHADOW`
- Self Learning: `ACTIVE_CONFIRMED_ONLY`
- ARS AI Engineer: `DEV_CENTER_DIAGNOSTIC_ONLY`
- AI in critical Smart Scan path: disabled
- Recognition thresholds: unchanged (14/14)
- Official signer SHA-256: `AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`
- Update method: in-place only; do not uninstall production data.

See `PHASE4_3_5_4_V8_8_4_STICKY_PHYSICAL_LOCK_BEST_EVIDENCE_IDENTITY_CONVERGENCE.md` and `RELEASE_206.md`.
