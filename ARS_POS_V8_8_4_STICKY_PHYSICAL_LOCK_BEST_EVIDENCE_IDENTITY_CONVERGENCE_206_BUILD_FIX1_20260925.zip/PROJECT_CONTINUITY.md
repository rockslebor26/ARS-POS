# ARS POS Project Continuity

Current source candidate: **1.10.6 (206) / Phase 4.3.5.4 / V8.8.4 — Sticky Physical Lock + Best-Evidence Identity Convergence**.

Direct source predecessor: **1.10.5 (205) / Phase 4.3.5.3 / V8.8.3 Event-Driven Visual Retrieval + Live/Final Decision Convergence**. Package, Room v5, official signer and all 14 recognition thresholds remain unchanged.

## Current architecture direction

Smart Scan must preserve one physical-object truth independently from asynchronous SKU identity. The production order is: physical localization → persistent state/lock → sticky operator lock eligibility → best evidence → bounded Top-K catalog recall → exact/discriminative identity evidence → bounded ambiguity escalation → live/final convergence → physical quantity safety → cashier review.

V8.8.4 specifically removes analyzer activity from CTA eligibility, holds an already-proven physical lock across transient identity/track handoffs, preserves materially better scene evidence into finalization, accepts useful high-resolution gain rather than requiring 1.35x on each axis, and adds bounded discriminative micro-OCR/static ambiguity retry. These changes gather better evidence; they do not lower acceptance thresholds.

ARS AI Engineer remains `DEV_CENTER_DIAGNOSTIC_ONLY`. It can inspect evidence and support engineering diagnosis but does not run automatically inside the cashier scan critical path and cannot create quantity, modify stock/payment, relax recognition thresholds, change signer, or authorize an update.

Cloud Identity remains `SHADOW`; Self Learning remains `ACTIVE_CONFIRMED_ONLY`.

## Finish criteria

The project is not finished until signed-build and real-device evidence demonstrate: non-blinking physical lock after acquisition, correct exact-SKU identity, live/final evidence continuity, no false NORMAL acceptance, no duplicate physical quantity, safe LONG/rod authenticity and anchor ownership, bounded memory/native pressure, acceptable latency, and safe in-place upgrade behavior.
