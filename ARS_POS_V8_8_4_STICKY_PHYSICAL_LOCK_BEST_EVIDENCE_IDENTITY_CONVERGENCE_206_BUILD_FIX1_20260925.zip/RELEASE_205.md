# ARS POS 1.10.5 (205) — V8.8.3 Release 205

## Release identity

- Phase: `4.3.5.3`
- Engine: `V8.8.3`
- Revision: `EVENT_DRIVEN_VISUAL_RETRIEVAL_LIVE_FINAL_CONVERGENCE`
- Previous official version: `1.10.4 (204)`
- Current version: `1.10.5 (205)`
- Package: `com.arspos.anglerriausyndicate`
- Database: `v5`

## What changed

This release replaces the V8.8.2 global/repeated live identity behavior with event-driven, object-scoped identity scheduling. Multiple objects can remain physically tracked, but expensive retrieval/OCR/exact identity is budgeted to one locked object at a time. Candidate evidence persists across detector-only frames, OCR has positive/negative bounded reuse plus single-flight protection, ambiguity escalates to adaptive high-resolution evidence, and an unresolved high-resolution case waits for a meaningful new viewpoint instead of repeating identical work.

The final Smart Scan remains authoritative. Bound live identity may seed final Top-K recall and is compared against the final decision for diagnostics, but cannot bypass exact recognition or Physical Quantity Safety.

## Distribution invariants

The release must be installed **in place** over versionCode 204. Do not uninstall the production application before updating. The official signer must match:

`AA:2A:8C:6C:88:5B:A8:87:57:7A:2C:28:13:AE:A2:F7:2E:5F:B5:18:92:FC:48:61:08:B5:7F:83:89:D5:6A:EB`

The workflow rejects a package mismatch, non-incremented versionCode, wrong versionName, signer mismatch, source hash mismatch, or failed source/test validation.

## Validation status in source package

Static source validation, lexical Kotlin sanity, policy-level Kotlin compilation and gateway security tests are captured under `validation/`. A complete Android release compilation/signing step requires the supplied GitHub Actions workflow and official signing secrets; a local signed APK is not asserted by this source package.
