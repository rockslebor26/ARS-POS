#!/usr/bin/env python3
"""Static release invariants only. This is not Kotlin compilation/device QA."""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from kotlin_sanity import check_tree

EXPECTED_THRESHOLDS = {
    "ACCEPT_EXACT_BARCODE": 90, "ACCEPT_STRONG_IDENTITY": 82,
    "ACCEPT_IDENTITY_WITH_VISUAL": 68, "ACCEPT_CANONICAL_TEXT": 78,
    "ACCEPT_PROFILE_IDENTITY": 78, "ACCEPT_VISUAL_ONLY": 80,
    "ACCEPT_LONG_VISUAL_ONLY": 72, "MIN_VISUAL_SUPPORT": 34,
    "MIN_MARGIN": 10, "MIN_VISUAL_MARGIN": 15, "MIN_LONG_VISUAL_MARGIN": 14,
    "MIN_TEXT_GATE": 58, "MIN_LONG_ANCHOR_SCORE": 55, "MIN_LONG_ANCHOR_MARGIN": 8,
}

def validate(root):
    root = Path(root)
    pkg = root / "app/src/main/java/com/arspos/anglerriausyndicate"
    checks = []
    def check(ok, label):
        if not ok:
            raise ValueError(label)
        checks.append(label)
    gradle = (root / "app/build.gradle.kts").read_text()
    check('applicationId = "com.arspos.anglerriausyndicate"' in gradle, "package unchanged")
    check('versionCode = 202' in gradle and 'versionName = "1.10.2"' in gradle, "release 1.10.2/202")
    check('signingConfig = signingConfigs.getByName("arsOfficialRelease")' in gradle, "official signer configuration")
    check('getByName("debug")' not in gradle, "no debug release signer")
    database = (pkg / "data/db/ArsDatabase.kt").read_text()
    check(bool(re.search(r"version\s*=\s*5\b", database)), "Room DB remains v5")
    check("fallbackToDestructiveMigration" not in database, "no destructive migration")
    engine = (pkg / "data/SmartRecognitionEngine.kt").read_text()
    thresholds = {k:int(v) for k,v in re.findall(r"private const val (\w+) = (\d+)", engine)}
    check(thresholds == EXPECTED_THRESHOLDS, "all 14 recognition thresholds unchanged")
    for rule in ["REJECT_NORMAL_REQUIRES_IDENTITY", "REJECT_IDENTITY_MARGIN", "REJECT_ROD_ANCHOR_MARGIN",
                 "REJECT_BARCODE_MISMATCH", "REJECT_BARCODE_AMBIGUOUS"]:
        check(rule in engine, rule)
    check('NORMAL_VISUAL_MASTER_VERIFIED' in engine and 'visualOnlyEligible' in engine, "verified NORMAL visual-only identity path present")
    check('NORMAL_VISUAL_MASTER_VERIFIED_WEAK_OCR' in engine and 'weakIdentityOcr' in engine, "weak generic OCR may fall through to unchanged verified visual gate")
    check('IdentityTextPolicy.distinctiveTokens(profile?.rawText.orEmpty())' in engine, "historical master OCR can be cleaned into identity-bearing evidence")
    recorder = (pkg / "ArsVisualEvidenceRecorder.kt").read_text()
    for literal in ['snapshotBitmap(scene, mutable = true)', 'PRE_IDENTITY_ANCHORS',
                    'GEOMETRIC_HYPOTHESIS_NOT_IDENTITY', 'evidenceFailures', 'check(flushPending(4_000L))']:
        check(literal in recorder, literal)
    scanner = (pkg / "SmartVisualScanner.kt").read_text()
    check('if (created === bitmap) bitmap.copy(Bitmap.Config.ARGB_8888, false)' in scanner, "owned full-frame crop")
    check('NON_ROD_TO_NORMAL_RESCUE' in scanner and 'CorrectTypeRoutingPolicy.shouldRescueNonRodToNormal' in scanner, "ML-owned NON_ROD safely reroutes to NORMAL")
    check('normal + nonRodNormalRescueRaw' in scanner and 'NormalPhysicalResolver.resolve' in scanner, "rescued NORMAL passes unchanged purity gate")
    firewall = (pkg / "CrossCategorySceneFirewall.kt").read_text()
    check('it.rodAuthenticityState == ScanProposal.AUTH_TRUSTED' in firewall, "trusted-only ownership")
    resolver = (pkg / "RodPhysicalTrackResolver.kt").read_text()
    check('ANALYZER_TRACK_WITHOUT_ML_SUPPORT' not in resolver, "ML absence does not prune pixel evaluation")
    check('if (score <= 0) return 0' in resolver, "complete-link merge guard")
    vm = (pkg / "PosViewModel.kt").read_text()
    for literal in ['ScanCommitPolicy.rejection', 'reviewProducts.getValue', 'committedScanSessions.contains(session)']:
        check(literal in vm, literal)
    ui = (pkg / "MainActivity.kt").read_text()
    for literal in ['InteractiveScanPreview', 'TINJAU JUMLAH & TAMBAH', 'DETAIL DIAGNOSTIK', 'LAPORKAN HASIL SCAN BERGAMBAR', 'quantityCommitInProgress', 'SCAN_REVIEW_OPEN', 'SCAN_CART_COMMIT_OK']:
        check(literal in ui, literal)
    check('AJARKAN KE ARS' in ui and 'MODE BELAJAR ARS AKTIF' in ui, "cashier exposes operator-confirmed visual teaching")
    check('AJARKAN OBJEK ${firstUnrecognized.index} KE ARS' in ui and 'Tidak perlu membuka Detail Diagnostik' in ui, "unknown object exposes direct teaching CTA without diagnostics scroll")
    check('OCR IDENTITAS:' in ui and 'identityOcrText' in ui, "cashier diagnostics distinguish raw OCR from identity OCR")
    check('reservedPersistentIds' in vm and 'filterNot { it.trackId in reservedPersistentIds }' in vm, "final persistent binding excludes pre-gate-owned LIVE IDs")
    learning = (pkg / "ArsAdaptiveLearning.kt").read_text()
    check('saveConfirmedObjectCrop' in learning and 'product_photos/learned' in learning, "bounded adaptive visual crop persistence present")
    repository = (pkg / "data/ProductionRepository.kt").read_text()
    check('shouldRunNormalIdentity(laneLong, liveVisualScore)' in repository and 'visualMargin >= 6' not in repository, "live identity no longer suppresses OCR on low visual margin")
    check('identityOcr' in repository and 'ignoredOcrLines' in repository, "final scan telemetry records raw versus identity-bearing OCR")
    check('enableConfirmedHybridVisual' in repository and 'recognitionMode = "HYBRID_VISUAL"' in repository, "operator-confirmed learning activates conservative HYBRID_VISUAL for verified NORMAL masters")
    rescue = repository[repository.index('proposalId = "RESCUE-'):]
    check('quantityEligible = false' in rescue[:1600], "rescue cannot create quantity")
    for path in [root / "app/src/test/java/com/arspos/anglerriausyndicate/WorkSyncSafetyTest.kt",
                 root / "app/src/test/java/com/arspos/anglerriausyndicate/data/RecognitionSafetyTest.kt"]:
        check(path.is_file(), path.name)

    # ImageIO is a Java SE java.desktop API. Keep JPEG evidence replay out of the
    # Android app test source set and isolate it in the dedicated JVM module.
    settings = (root / "settings.gradle.kts").read_text()
    root_gradle = (root / "build.gradle.kts").read_text()
    jvm_gradle_path = root / "physicaltruth-jvm/build.gradle.kts"
    jvm_evidence_path = root / "physicaltruth-jvm/src/test/kotlin/com/arspos/anglerriausyndicate/RodMaterialEvidenceTest.kt"
    jvm_image_path = root / "physicaltruth-jvm/src/test/kotlin/com/arspos/anglerriausyndicate/PhysicalImageEvidenceTest.kt"
    android_tests = "\n".join(p.read_text() for p in (root / "app/src/test").rglob("*.kt"))
    check('include(":physicaltruth-jvm")' in settings, "physical truth JPEG replay isolated in JVM module")
    check('id("org.jetbrains.kotlin.jvm") version "2.0.21" apply false' in root_gradle, "JVM evidence plugin pinned to Kotlin 2.0.21")
    check(jvm_gradle_path.is_file() and jvm_evidence_path.is_file() and jvm_image_path.is_file(), "JVM evidence module files present")
    check("javax.imageio" not in android_tests and "ImageIO" not in android_tests, "no java.desktop ImageIO in Android test source set")
    jvm_evidence = jvm_evidence_path.read_text() + "\n" + jvm_image_path.read_text()
    check("javax.imageio.ImageIO" in jvm_evidence and "ImageIO.read" in jvm_evidence, "bound JPEG replay retains Java SE ImageIO")
    jvm_gradle = jvm_gradle_path.read_text()
    check("../app/src/main/java" in jvm_gradle and "RodMaterialProfile.kt" in jvm_gradle and "NormalPixelOwnership.kt" in jvm_gradle and "NormalProposalPurityPolicy.kt" in jvm_gradle and "CorrectTypeRoutingPolicy.kt" in jvm_gradle and "PackageEdgePolicy.kt" in jvm_gradle and "RodEndpointRolePolicy.kt" in jvm_gradle and "RodEndpointProfile.kt" in jvm_gradle, "JVM replay compiles exact production physical-truth/routing policies")
    check('ArsV850Config.ENGINE' in recorder and 'ArsV850Config.PHASE' in recorder, "evidence phase/engine sourced from V8.8.1 config")
    check('ARS_DIAGNOSTIC_V8_8_1_' in recorder and 'ARS_SCAN_REPORT_V8_8_1_' in recorder, "export filenames match engine")
    check('ArsV850Config.VERSION_CODE' in recorder and 'ArsV850Config.VERSION_NAME' in recorder, "export application version matches APK config")
    check('tipVisible = proposal.rodTipVisible' in repository and 'proposal.anchorHandleOnLeft' in recorder, "anchor role availability bound to evidence")
    check('results.filter { it.canCommitQuantity }' in vm and '.distinctBy { it.physicalObjectId }' in ui, "physical quantity guard used by UI and backend")
    check('material.supported' in (pkg / "RodAuthenticityEvaluator.kt").read_text(), "pixel body required for trusted rod")
    check("it.segmentSupport && it.foregroundSupported && !it.bridgeSuppressed" in repository, "rescue needs independent pixel body evidence")
    package_edge = (pkg / "PackageEdgePolicy.kt").read_text()
    endpoint_role = (pkg / "RodEndpointRolePolicy.kt").read_text()
    endpoint_profile = (pkg / "RodEndpointProfile.kt").read_text()
    check("NORMAL_BOUNDARY_EDGE" in package_edge and "rejectedAsPackageEdge" in package_edge, "package edge ownership firewall present")
    check("ANCHOR_ROLE_PHYSICAL_CONFIDENT" in endpoint_role and "handleOnLeft" in endpoint_role, "bidirectional anchor role policy present")
    check("persistentCoverage" in endpoint_profile and "persistentWidth" in endpoint_profile, "persistent endpoint body profile present")
    check("applyPackageEdgeFirewall" in scanner and "SOURCE_NORMAL_EDGE" in scanner, "package edge firewall wired before cross-category scoring")
    check("endpointLeftScore" in repository and "anchorRoleState" in repository, "anchor-role truth recorded in scoring telemetry")
    live_preview = (pkg / "LiveScenePreview.kt").read_text()
    live_camera = (pkg / "LiveSmartScanCamera.kt").read_text()
    check("LiveSceneLedger" in live_preview and "quantityPreviewEligible" in live_preview, "temporal scene ledger present")
    check("typed-lane invariant" in live_preview and "pendingAgreement >= 2" in live_preview, "temporal live-ID lane safety + candidate hysteresis")
    check("LiveFrameDifference" in live_preview and "OBJECT_DETECTED" in live_preview, "foreground scene-change trigger present")
    check("KUNCI & TINJAU HASIL" in live_camera and "vm.liveScenePreview" in live_camera, "live database preview wired to final scene lock")
    check("CancellationException" in live_camera and "throw cancelled" in live_camera, "Compose cancellation is not recorded as LIVE_SCENE_ERROR")
    check("LIVE_LOOP_DELAY_MS" in live_camera and "LIVE_STABLE_REFRESH_MS" in live_camera and "frameAcquireMs" in live_camera and "analysisGapMs" in live_camera, "V8.8.1 measured live cadence + identity latency telemetry")
    check("ambiguousOcrTriggered" in live_camera and "ocrGateReasons" in live_camera and "identityOcrPresent" in live_camera, "live report explains whether OCR ran and why")
    check("axisAngleDeg" in live_preview and "axisAngleSimilarity" in live_preview, "LONG temporal continuity uses axis angle")
    binder = (pkg / "PersistentPhysicalIdBinder.kt").read_text()
    check("normalizedAspectSimilarity" in binder and "axisAngleSimilarity" in binder, "type-aware persistent LONG binding present")
    smart_input = (pkg / "SmartProductInput.kt").read_text()
    check("analyzeLongIdentity" in smart_input and "analyzeLiveFast" in smart_input, "adaptive OCR fast paths present")
    identity_policy = (pkg / "IdentityTextPolicy.kt").read_text()
    live_identity_policy = (pkg / "LiveIdentityPolicy.kt").read_text()
    check("identityText" in smart_input and "IdentityTextPolicy.identityLines" in smart_input, "OCR preserves raw text while extracting identity-bearing text")
    check("PERINGATAN" in identity_policy and "MEROKOK" in identity_policy and "MANGO" not in identity_policy, "regulatory text filter is deterministic and product-agnostic")
    check("AMBIGUOUS_VISUAL_REQUIRES_OCR" in live_identity_policy and "MIN_VISUAL_FOR_NORMAL_IDENTITY = 72" in live_identity_policy, "ambiguous NORMAL visual evidence triggers OCR without lowering recognition thresholds")
    check("SmartProductInput.analyzeLiveFast(crop)" in repository and "SmartProductInput.analyzeLongIdentity(crop)" in repository, "fast live OCR + LONG final OCR wired")
    check("Live LONG uses the cheap coarse fingerprint pass" in repository and "ProductVisualMatcher.scoreBatchCoarse(" in repository, "live LONG coarse visual fast path wired")
    check("SOURCE_ML_NORMAL_PREVIEW" in repository and "CorrectTypeRoutingPolicy.shouldPreviewMlTallAsNormal" in repository, "ML tall preview cannot be trapped in LONG lane by aspect ratio alone")
    check("recordCatalogSnapshot" in repository and 'File(dir, "catalog_snapshot.json")' in recorder, "catalog snapshot bound to scan evidence")
    check('File(dir, "ground_truth.jsonl")' in recorder, "ground-truth file is always materialized")
    temporal = (pkg / "TemporalPhysicalConsensus.kt").read_text()
    check("TEMPORAL_ML_SEED" in temporal and scanner.index("seedMissingLongGeometry") < scanner.index("RodAuthenticityEvaluator.apply"), "temporal ML seed runs before mandatory pixel authenticity")
    check("trustedPhysicalHits" in live_preview and "TEMPORAL_TRUSTED_ROD" in live_preview, "temporal physical evidence memory present")
    check("liveScenePreview" in repository and "final cashier quantity" in repository, "live repository path remains non-transactional")
    check("LiveSmartScanCamera" in ui and "startFinalSmartScan" in ui, "cashier uses live scene then production final scan")
    purity = (pkg / "NormalProposalPurityPolicy.kt").read_text()
    normal_resolver = (pkg / "NormalPhysicalResolver.kt").read_text()
    binder = (pkg / "PersistentPhysicalIdBinder.kt").read_text()
    check("NORMAL_NO_FOREGROUND_OWNER_LARGE_REGION" in purity and "NORMAL_PURITY_VERIFIED" in purity, "NORMAL proposal purity gate present")
    check("normalPurityScore" in normal_resolver and "finalQuantityEligible" in normal_resolver, "NORMAL purity gate wired to quantity")
    check("SCAN_LIVE_FINAL_BIND" in vm and "persistentPhysicalId" in binder, "persistent live-to-final physical ID binding present")
    check("bindProposals" in binder and "SCAN_PRE_GATE_BIND" in repository, "persistent ID is bound before identity scoring")
    check("highResolutionIdentityUsed" in repository and "identityBitmap" in repository, "high-resolution LONG identity ROI path present")
    check("cross-lane bind forbidden" in binder and "normalizedCentreSimilarity" in binder, "live-to-final binding uses strict lane + motion geometry")
    check("recordGroundTruth" in recorder and "ground_truth.jsonl" in recorder and "SCAN_GROUND_TRUTH" in recorder, "human ground-truth feedback recorded")
    check("analysis_replay.png" in recorder and "replay_manifest.json" in recorder, "lossless replay-ready evidence present")
    check("identityThresholdsRelaxed" in recorder and "false" in recorder, "replay manifest records unchanged recognition thresholds")
    check("inputSha256" in recorder and "persistentBindingStage" in recorder, "replay manifest V2 binds input hash and pre-gate stage")
    check("finalSessionMeta" in recorder and "evidenceStatus" in recorder, "session metadata finalized atomically with evidence status")

    # Phase 4.3.5.1 / V8.8.1 deterministic object intelligence + gated AI engineering invariants.
    phase_cfg = (pkg / "ArsV850Config.kt").read_text()
    fusion = (pkg / "PersistentPhysicalFragmentFusion.kt").read_text()
    local_recovery = (pkg / "MlGuidedLocalRodRecovery.kt").read_text()
    safety = (pkg / "ArsSafetyKernel.kt").read_text()
    ledger = (pkg / "ArsDecisionEvidenceLedger.kt").read_text()
    check('const val PHASE = "4.3.5.1"' in phase_cfg and 'const val ENGINE = "V8.8.1"' in phase_cfg, "V8.8.1 phase config present")
    check('const val RELEASE_REVISION = "R1_BUILD_INTEGRITY_RECOVERY"' in phase_cfg, "V8.8.1 R1 build-integrity revision present")
    check('CLOUD_IDENTITY_MODE = "SHADOW"' in phase_cfg and 'SELF_LEARNING_MODE = "ACTIVE_CONFIRMED_ONLY"' in phase_cfg, "cloud identity remains shadow and self-learning is operator-confirmed")
    check('AI_ENGINEER_MODE = "ENGINEERING_PROPOSAL_GATED"' in phase_cfg and 'FEATURE_AI_ENGINEER_UI = true' in phase_cfg, "AI Engineer proposal gate is visible")
    check('PERSISTENT_FRAGMENT_FUSION' in fusion and 'AUTH_NON_ROD' in fusion and 'TEMPORAL_TRUSTED_ROD' in fusion, "persistent physical fragment fusion safety present")
    check('ML_GUIDED_LOCAL_RECOVERY' in local_recovery and 'quantityEligible = proposal.quantityEligible' in local_recovery and 'RodAuthenticityEvaluator.apply' in scanner, "ML-guided local recovery preserves eligibility but authenticity remains mandatory")
    check('cloudMayCreateQuantity(): Boolean = false' in safety and 'runtimeMayRelaxRecognitionThresholds(): Boolean = false' in safety, "immutable ARS safety kernel")
    check('DECISION_EVIDENCE_LEDGER' in ledger and 'cloudCreatedQuantity' in ledger and 'thresholdsRelaxed' in ledger, "decision evidence ledger present")
    check('PersistentPhysicalFragmentFusion.fuse' in scanner and 'MlGuidedLocalRodRecovery.recover' in scanner, "V8.5 recovery + fusion wired before identity")
    check('ArsSafetyKernel.quantityDecision' in repository and 'ArsDecisionEvidenceLedger.record' in repository, "safety kernel + evidence ledger wired to final decision")
    check('bestVisualScore' in live_preview and 'bestEvidenceProductId' in live_preview, "persistent LIVE best-evidence metadata present")
    temporal_hold = (pkg / "TemporalIdentityHoldPolicy.kt").read_text()
    ocr_reuse = (pkg / "LiveOcrReusePolicy.kt").read_text()
    long_analyzer = (pkg / "LongObjectAnalyzer.kt").read_text()
    check('FEATURE_FINAL_SCAN_VIEWMODEL_SCOPE = true' in phase_cfg and 'viewModelScope.launch' in vm and 'ownedPreview' in vm, "final scan owned by ViewModel with locked-frame copy")
    check('catch (cancelled: CancellationException)' in vm and 'VIEWMODEL_CANCELLED' in vm and 'NonCancellable' in vm, "final scan cancellation is typed and evidence-finalized")
    check('TemporalIdentityHoldPolicy.shouldHold' in live_preview and 'MAX_WEAK_FRAMES = 2' in temporal_hold, "matched identity has bounded two-frame hold")
    check('LiveOcrReusePolicy.mayReuse' in repository and 'OCR_CACHE_HIT' in repository and 'IDENTITY_TTL_MS = 1_500L' in ocr_reuse, "live OCR reuse is bounded and telemetry-visible")
    check('estimateAxisWidthPx' in long_analyzer and '* 0.095f' not in long_analyzer, "LONG axis width is measured instead of fixed 9.5 percent corridor")
    check('AI_FAILURE_HANDOFF' in vm and 'AUTOMATIC_SCAN_FAILURE' in vm, "scanner anomaly automatically hands evidence to gated AI Engineer")
    check((root / "app/src/test/java/com/arspos/anglerriausyndicate/TemporalIdentityHoldPolicyTest.kt").is_file(), "temporal identity hold regression test present")
    check((root / "app/src/test/java/com/arspos/anglerriausyndicate/LiveOcrReusePolicyTest.kt").is_file(), "live OCR reuse regression test present")

    manifest = (root / "app/src/main/AndroidManifest.xml").read_text()
    check('android.permission.INTERNET' in manifest and 'android:usesCleartextTraffic="false"' in manifest, "AI gateway networking is HTTPS-only at app policy level")
    backup_rules = (root / "app/src/main/res/xml/backup_rules.xml").read_text()
    extraction_rules = (root / "app/src/main/res/xml/data_extraction_rules.xml").read_text()
    check('ars_ai_engineer_gateway.xml' in backup_rules and 'ars_ai_engineer_identity.xml' in backup_rules, "AI gateway credentials excluded from legacy Android backups")
    check('ars_ai_engineer_gateway.xml' in extraction_rules and 'ars_ai_engineer_identity.xml' in extraction_rules, "AI gateway credentials excluded from cloud/device-transfer extraction")
    ai_ui = (pkg / "ArsAiEngineer.kt").read_text()
    ai_client = (pkg / "ArsAiEngineerClient.kt").read_text()
    ai_settings = (pkg / "ArsAiGatewaySettings.kt").read_text()
    ai_evidence = (pkg / "ArsAiEvidencePacket.kt").read_text()
    local_advisor = (pkg / "ArsAiLocalAdvisor.kt").read_text()
    for path in [pkg / "ArsAiEngineer.kt", pkg / "ArsAiEngineerClient.kt", pkg / "ArsAiGatewaySettings.kt", pkg / "ArsAiEvidencePacket.kt", pkg / "ArsAiLocalAdvisor.kt"]:
        check(path.is_file(), path.name)
    check('ARS AI ENGINEER • ANALISIS & ROOT CAUSE' in ui and 'ArsAiEngineerDialog' in ui, "AI Engineer visible from Dashboard")
    check('ENGINEERING_PROPOSAL_GATED' in phase_cfg and 'mayChangeQuantity", false' in ai_client and 'mayChangeStock", false' in ai_client and 'mayChangePayment", false' in ai_client, "AI Engineer preserves explicit transaction mutation boundary")
    check('AndroidKeyStore' in ai_settings and 'AES/GCM/NoPadding' in ai_settings, "gateway token protected with Android Keystore AES-GCM")
    check('startsWith("https://"' in ai_settings and '/v1/ars-ai/analyze' in ai_client, "AI Engineer routes through operator HTTPS gateway")
    check('OPENAI_API_KEY' not in ai_client and 'api.openai.com' not in ai_client, "OpenAI secret/API endpoint not embedded in Android client")
    check('ArsAiEvidenceCollector.latest' in ai_client and 'physical_track_overlay.jpg' in ai_evidence and 'ground_truth.jsonl' in ai_evidence, "bound visual evidence packet available to AI Engineer")
    check('LOCAL_FALLBACK' in local_advisor or 'OFFLINE DIAGNOSTIC FALLBACK' in local_advisor, "deterministic local diagnostic fallback present")
    gateway = root / "ars-ai-gateway/server.mjs"
    security_module = root / "ars-ai-gateway/security.mjs"
    deployment = root / "ars-ai-gateway/DEPLOYMENT.md"
    dockerfile = root / "ars-ai-gateway/Dockerfile"
    check(gateway.is_file() and security_module.is_file(), "ARS AI Gateway production server + security module included")
    gateway_text = gateway.read_text()
    security_text = security_module.read_text()
    check('https://api.openai.com/v1/responses' in gateway_text and 'OPENAI_API_KEY' in gateway_text and 'ARS_AI_GATEWAY_TOKENS' in gateway_text, "gateway uses server-side OpenAI Responses API credentials")
    check('store: false' in gateway_text and 'safety_identifier' in gateway_text and 'json_schema' in gateway_text, "gateway uses non-stored structured Responses API diagnostic")
    check('gpt-5.6-sol' in gateway_text and 'gpt-5.6-terra' in gateway_text, "gateway routes deep and routine diagnostics to configured GPT-5.6 models")
    check("'DEVELOPMENT_PROPOSAL', 'REGRESSION_ANALYSIS'" in gateway_text and "effort: isDeep ? 'medium' : 'low'" in gateway_text, "interactive AI modes use latency-bounded reasoning")
    check('OPENAI_TIMEOUT' in gateway_text and "httpStatus: 504" in gateway_text and 'gateway_deadline_ms' in gateway_text, "gateway emits typed OpenAI timeout telemetry")
    check("return 'high'" in gateway_text and "return 'low'" in gateway_text, "visual evidence uses selective image detail")
    check('verifySignedRequest' in gateway_text and 'REPLAY_DETECTED' in gateway_text and 'RATE_LIMITED' in gateway_text, "gateway signed request, replay protection and rate limiting present")
    check('HmacSHA256' in (pkg / "ArsAiRequestSecurity.kt").read_text() and 'X-ARS-Signature' in ai_client, "Android signs gateway requests with HMAC-SHA256")
    check('/v1/ars-ai/status' in ai_client and 'UJI KONEKSI AI' in ai_ui, "authenticated gateway health test is visible in app")
    check('HttpsURLConnection' in ai_client and 'instanceFollowRedirects = false' in ai_client, "Android AI client enforces HTTPS and rejects redirects")
    check('FEATURE_AI_GATEWAY_SIGNED_REQUESTS = true' in phase_cfg and 'FEATURE_AI_GATEWAY_STRUCTURED_DIAGNOSTICS = true' in phase_cfg, "production gateway feature flags remain active")
    check('signaturePayload' in security_text and 'NonceWindow' in security_text and 'SlidingMinuteLimiter' in security_text, "gateway security primitives present")
    check(deployment.is_file() and dockerfile.is_file(), "gateway Docker + deployment runbook included")
    check('may not create quantity' in gateway_text and 'read-only' in gateway_text.lower(), "gateway developer policy is read-only")

    fixtures = root / "app/src/test/resources/physical_truth"
    rows = (fixtures / "tracks.tsv").read_text().splitlines()[1:]
    check(len(rows) == 47, "47 bound material regression cases")
    for row in rows:
        parts = row.split("\t")
        if hashlib.sha256((fixtures / parts[3]).read_bytes()).hexdigest() != parts[4]:
            raise ValueError(f"Fixture SHA mismatch: {parts[0]}/{parts[2]}")
    check(True, "all fixture image hashes match bound telemetry")
    rescue_regression = fixtures / "v860_normal_bottle_misrouted_long.jpg"
    check(rescue_regression.is_file(), "V8.6.0 misrouted NORMAL bottle regression image present")
    check(hashlib.sha256(rescue_regression.read_bytes()).hexdigest() == "1eea8d1af200f415f49d15e19fedfd6e09e87664e5253c3cbd8e1bc85c0fb939", "misrouted NORMAL bottle regression hash bound")
    rescue_test = root / "physicaltruth-jvm/src/test/kotlin/com/arspos/anglerriausyndicate/NormalRescueRegressionTest.kt"
    check(rescue_test.is_file() and "CorrectTypeRoutingPolicy" in rescue_test.read_text() and "NormalProposalPurityPolicy.evaluate" in rescue_test.read_text(), "V8.7.0 correct-type NORMAL rescue regression retained")
    identity_fixture = root / "app/src/test/resources/identity/v870_esse_change_double_unknown.jpg"
    check(identity_fixture.is_file(), "V8.7.0 ESSE UNKNOWN field regression frame present")
    check(hashlib.sha256(identity_fixture.read_bytes()).hexdigest() == "8a9f49121738346d6d2fc73425208517ffa789afbba7758cbb4a5fc64ca2b8a0", "ESSE field regression frame hash bound")
    identity_test = root / "app/src/test/java/com/arspos/anglerriausyndicate/IdentityTextPolicyTest.kt"
    live_identity_test = root / "app/src/test/java/com/arspos/anglerriausyndicate/LiveIdentityPolicyTest.kt"
    check(identity_test.is_file() and "ESSE CHANGE DOUBLE" in identity_test.read_text(), "regulatory OCR identity regression test present")
    check(live_identity_test.is_file() and "AMBIGUOUS_VISUAL_REQUIRES_OCR" in live_identity_test.read_text(), "low-margin live OCR regression test present")

    regression = fixtures / "v8419_false_trusted_package_scene.jpg"
    check(regression.is_file(), "V8.4.19 false trusted package regression image present")
    check(hashlib.sha256(regression.read_bytes()).hexdigest() == "65152d3296f0713e58f068d9925be52d87ddd4aa1f5b814fb29109e00b108c96", "package-edge regression image hash bound")
    endpoint_right = fixtures / "v8419_trusted_rod_handle_right.jpg"
    endpoint_left = fixtures / "v8419_crossing_rod_handle_left.jpg"
    check(hashlib.sha256(endpoint_right.read_bytes()).hexdigest() == "5f025fb2ab5e88a043eb8c74eac9d830052170e5d6df028ccf7eb9181ba79e11", "trusted-rod endpoint regression hash bound")
    check(hashlib.sha256(endpoint_left.read_bytes()).hexdigest() == "e309d8694b7a29cf0e98e379a5e9e348d27b372c20ae64ee091cfd8b7ab2ddae", "crossing-rod endpoint regression hash bound")
    kotlin_files = check_tree(root / "app/src") + check_tree(root / "physicaltruth-jvm/src")
    return {"static_invariants": "PASS", "checks": len(checks), "details": checks,
            "kotlin_files_lexically_checked": kotlin_files,
            "kotlin_compilation": "NOT_RUN_BY_THIS_SCRIPT", "device_tests": "NOT_RUN_BY_THIS_SCRIPT"}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    try:
        print(json.dumps(validate(args.root), indent=2))
    except (ValueError, OSError) as exc:
        sys.exit(f"SOURCE VALIDATION FAILED: {exc}")
