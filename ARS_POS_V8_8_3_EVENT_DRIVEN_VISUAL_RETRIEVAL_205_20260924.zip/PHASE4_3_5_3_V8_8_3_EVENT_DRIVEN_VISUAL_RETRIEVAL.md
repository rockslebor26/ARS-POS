# Phase 4.3.5.3 / V8.8.3

## Event-Driven Visual Retrieval + Live/Final Decision Convergence

V8.8.3 changes when identity intelligence runs. Object perception/tracking remains continuous, while expensive identity work is granted only to locked physical objects through a bounded per-object scheduler. The release is designed from the V8.8.2 field evidence where a product could remain UNKNOWN/CANDIDATE in live preview for tens of seconds even though the final locked scan immediately produced a strong exact OCR identity.

### Production path

`detect many → establish physical track → lock → select one identity target → retrieve Top-K → acquire discriminative evidence only when needed → preserve candidate memory → converge live state into final exact verification → quantity safety → cashier review`

### Added/changed components

- `LiveIdentityScheduler`: one expensive identity target per cycle by default. Locked/matched state, manual target priority and staged evidence escalation determine compute allocation.
- `LiveIdentityRoiPolicy`: detection ROI and identity ROI are separate. RETRIEVE/OCR/HIGH_RES stages receive bounded padding appropriate to the evidence request.
- `LiveBestFrameStore`: final lock may use the best stable scene frame rather than blindly using the most recent frame.
- `LiveSceneLedger`: perception-only frames are neutral identity evidence. They cannot demote a candidate merely because identity was intentionally not scheduled.
- Candidate hysteresis/memory: candidate state survives weak/skipped frames and changes only on actual identity evidence under the existing bounded switch policy.
- OCR single-flight: duplicate OCR work for the same physical hypothesis/resolution class is suppressed.
- Positive and negative OCR cache: identity-bearing OCR is reusable for 4 s; empty OCR is reusable for 3 s unless a materially better frame appears.
- Discriminative evidence escalation: `RETRIEVE → OCR → HIGH_RES → GUIDANCE`. Repeating the same failed evidence operation indefinitely is prohibited by the scheduler state.
- High-resolution NORMAL ambiguity recovery: strong-but-close NORMAL candidates may earn a high-resolution identity crop without lowering recognition thresholds.
- Object-scoped target selection: multi-object scenes expose independently selectable physical targets; manual selection gets scheduler priority.
- Live/final convergence: the locked scene carries advisory persistent identity state into final candidate recall. Final recognition still reruns the exact scorer and existing Safety Kernel before quantity.
- Convergence telemetry: `SCAN_LIVE_FINAL_CONVERGENCE` records live candidate, final candidate, consistency, live stage and final decision rule.
- Replay metadata is V4 and `sourceVersion` comes from `ArsV850Config`, eliminating stale hard-coded release identity.

### Safety invariants retained

Package remains `com.arspos.anglerriausyndicate`. Room remains v5 with no destructive migration. The official signing configuration remains unchanged. Cloud Identity remains SHADOW. Self Learning remains ACTIVE_CONFIRMED_ONLY. ARS AI Engineer remains DEV_CENTER_DIAGNOSTIC_ONLY and is not in the critical cashier scan path. Cloud/AI cannot create quantity or mutate stock/payment. All 14 `SmartRecognitionEngine` thresholds are byte-for-value unchanged from V8.8.2.

### Device acceptance targets

The intended device QA targets are: visible physical object under 300 ms when camera acquisition permits; physical lock around 500–800 ms; first useful Top-K around 0.8–1.2 s after lock; candidate under 1.5 s; exact match under 2 s when strong evidence is already visible; zero candidate demotion caused only by an unscheduled identity pass; zero duplicate OCR requests for one physical hypothesis; zero duplicate physical quantity; and confirmed LIVE candidate consistent with FINAL exact recognition whenever the locked evidence remains the same.

These are acceptance targets, not claims of achieved device performance until a signed 205 APK is installed and measured on the target device.
