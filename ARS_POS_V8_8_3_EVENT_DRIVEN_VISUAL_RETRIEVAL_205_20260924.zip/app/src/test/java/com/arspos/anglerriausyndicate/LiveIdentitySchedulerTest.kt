package com.arspos.anglerriausyndicate

import android.graphics.Rect
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LiveIdentitySchedulerTest {
    private fun track(
        id: String,
        physical: String = PhysicalObjectStateMachine.STATE_LOCKED,
        state: String = LiveSceneTrack.STATE_UNKNOWN,
        product: com.arspos.anglerriausyndicate.data.db.ProductEntity? = null,
        attempts: Int = 0,
        lastStage: String = LiveIdentityStage.NONE,
        score: Int = 0
    ) = LiveSceneTrack(
        trackId = id,
        bounds = Rect(10, 10, 110, 160),
        proposalType = ScanProposal.TYPE_NORMAL,
        product = product,
        visualScore = score,
        margin = 0,
        hitStreak = if (physical == PhysicalObjectStateMachine.STATE_LOCKED) 3 else 1,
        missingFrames = 0,
        state = state,
        quantityPreviewEligible = false,
        reason = "TEST",
        physicalState = physical,
        identityAttemptCount = attempts,
        lastIdentityStage = lastStage
    )

    @Test fun identityWaitsForPhysicalLockAndBudgetsOneObject() {
        val scheduler = LiveIdentityScheduler(maxTargetsPerCycle = 1)
        assertTrue(scheduler.selectTargets(listOf(track("A", PhysicalObjectStateMachine.STATE_DETECTED)), 0f, 1_000L).isEmpty())
        val targets = scheduler.selectTargets(listOf(track("A"), track("B")), 0f, 1_000L)
        assertEquals(1, targets.size)
        assertEquals(LiveIdentityStage.RETRIEVE, targets.single().stage)
    }

    @Test fun candidateEscalatesFromRetrieveToOcrThenHighRes() {
        val scheduler = LiveIdentityScheduler(maxTargetsPerCycle = 1, retrieveCooldownMs = 0L, ocrCooldownMs = 0L, highResCooldownMs = 0L)
        scheduler.selectTargets(listOf(track("A")), 0f, 1_000L)
        val candidate = track("A", state = LiveSceneTrack.STATE_CANDIDATE, attempts = 1, lastStage = LiveIdentityStage.RETRIEVE, score = 82)
        assertEquals(LiveIdentityStage.OCR, scheduler.selectTargets(listOf(candidate), 0f, 1_001L).single().stage)
        val afterOcr = candidate.copy(identityAttemptCount = 2, lastIdentityStage = LiveIdentityStage.OCR)
        assertEquals(LiveIdentityStage.HIGH_RES, scheduler.selectTargets(listOf(afterOcr), 0f, 1_002L).single().stage)
    }

    @Test fun matchedIdentityIsFrozenAndManualTargetWins() {
        val scheduler = LiveIdentityScheduler(maxTargetsPerCycle = 1)
        val matched = track("A", state = LiveSceneTrack.STATE_MATCHED)
        val other = track("B")
        val targets = scheduler.selectTargets(listOf(matched, other), 0f, 1_000L, selectedTrackId = "B")
        assertEquals("B", targets.single().trackId)
        assertTrue(scheduler.selectTargets(listOf(matched), 0f, 2_000L).isEmpty())
    }
}
