package com.arspos.anglerriausyndicate

import android.graphics.Rect

/** Event-driven per-object evidence scheduling for V8.8.3. */
object LiveIdentityStage {
    const val NONE = "NONE"
    const val RETRIEVE = "RETRIEVE"
    const val OCR = "OCR"
    const val HIGH_RES = "HIGH_RES"
    const val GUIDANCE = "GUIDANCE"
}

data class LiveIdentityTarget(
    val trackId: String,
    val bounds: Rect,
    val proposalType: String,
    val stage: String,
    val productIdHint: Long = 0L,
    val force: Boolean = false
)

/**
 * Detection may run for every object. Expensive identity is granted to at most
 * [maxTargetsPerCycle] locked physical objects, so multi-object scenes cannot
 * multiply OCR cost. A skipped pass is not negative identity evidence.
 */
class LiveIdentityScheduler(
    private val maxTargetsPerCycle: Int = 1,
    private val retrieveCooldownMs: Long = 450L,
    private val ocrCooldownMs: Long = 900L,
    private val highResCooldownMs: Long = 1_250L,
    private val guidanceCooldownMs: Long = 2_500L
) {
    private data class State(
        var stage: String = LiveIdentityStage.RETRIEVE,
        var lastAttemptAtMs: Long = 0L,
        var observedAttemptCount: Int = 0
    )

    private val states = LinkedHashMap<String, State>()

    fun clear() = states.clear()

    fun selectTargets(
        tracks: List<LiveSceneTrack>,
        sceneChange: Float,
        nowMs: Long,
        selectedTrackId: String? = null
    ): List<LiveIdentityTarget> {
        val visibleIds = tracks.filter { it.missingFrames == 0 }.map { it.trackId }.toSet()
        states.keys.retainAll(visibleIds)

        val eligible = tracks.filter {
            it.missingFrames == 0 &&
                it.physicalState == PhysicalObjectStateMachine.STATE_LOCKED &&
                it.state != LiveSceneTrack.STATE_MATCHED
        }
        if (eligible.isEmpty()) return emptyList()

        val ordered = eligible.sortedWith(
            compareByDescending<LiveSceneTrack> { it.trackId == selectedTrackId }
                .thenByDescending { it.state == LiveSceneTrack.STATE_CANDIDATE }
                .thenByDescending { it.visualScore }
                .thenBy { it.firstSeenAtMs }
        )
        val result = ArrayList<LiveIdentityTarget>(maxTargetsPerCycle)
        for (track in ordered) {
            if (result.size >= maxTargetsPerCycle) break
            val state = states.getOrPut(track.trackId) { State() }
            if (track.identityAttemptCount > state.observedAttemptCount) {
                state.observedAttemptCount = track.identityAttemptCount
                state.stage = nextStage(track)
            }
            if (state.stage == LiveIdentityStage.GUIDANCE && sceneChange >= 0.055f) {
                state.stage = LiveIdentityStage.RETRIEVE
            }
            val forced = track.trackId == selectedTrackId
            val cooldown = when (state.stage) {
                LiveIdentityStage.RETRIEVE -> retrieveCooldownMs
                LiveIdentityStage.OCR -> ocrCooldownMs
                LiveIdentityStage.HIGH_RES -> highResCooldownMs
                else -> guidanceCooldownMs
            }
            val due = forced || state.lastAttemptAtMs == 0L || nowMs - state.lastAttemptAtMs >= cooldown
            if (!due || state.stage == LiveIdentityStage.GUIDANCE || state.stage == LiveIdentityStage.NONE) continue
            state.lastAttemptAtMs = nowMs
            result += LiveIdentityTarget(
                trackId = track.trackId,
                bounds = Rect(track.bounds),
                proposalType = track.proposalType,
                stage = state.stage,
                productIdHint = track.product?.id ?: track.bestEvidenceProductId,
                force = forced
            )
        }
        return result
    }

    private fun nextStage(track: LiveSceneTrack): String = when {
        track.state == LiveSceneTrack.STATE_MATCHED -> LiveIdentityStage.NONE
        track.lastIdentityStage == LiveIdentityStage.RETRIEVE && track.product != null -> LiveIdentityStage.OCR
        track.lastIdentityStage == LiveIdentityStage.RETRIEVE -> LiveIdentityStage.HIGH_RES
        track.lastIdentityStage == LiveIdentityStage.OCR -> LiveIdentityStage.HIGH_RES
        track.lastIdentityStage == LiveIdentityStage.HIGH_RES -> LiveIdentityStage.GUIDANCE
        track.identityAttemptCount <= 0 -> LiveIdentityStage.RETRIEVE
        else -> LiveIdentityStage.GUIDANCE
    }
}
