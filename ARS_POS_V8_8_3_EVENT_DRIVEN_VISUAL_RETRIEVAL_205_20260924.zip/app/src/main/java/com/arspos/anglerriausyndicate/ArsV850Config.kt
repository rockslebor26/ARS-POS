package com.arspos.anglerriausyndicate

/**
 * Phase 4.3.5.3 / V8.8.3 — Event-Driven Visual Retrieval + Live/Final Decision Convergence.
 *
 * Physical perception stays cheap and continuous while identity work is scheduled
 * per locked object. Evidence escalates from retrieval to OCR to high-resolution
 * only when needed; recognition thresholds and quantity safety remain unchanged.
 *
 * Physical truth and cashier safety are production-active. Self-learning is
 * operator-confirmed and bounded to visual references; cloud identity remains
 * non-authoritative until field evidence proves it safe.
 */
object ArsV850Config {
    const val PHASE = "4.3.5.3"
    const val ENGINE = "V8.8.3"
    const val RELEASE_REVISION = "EVENT_DRIVEN_VISUAL_RETRIEVAL_LIVE_FINAL_CONVERGENCE"
    const val VERSION_NAME = "1.10.5"
    const val VERSION_CODE = 205

    const val FEATURE_PERSISTENT_FRAGMENT_FUSION = true
    const val FEATURE_ML_GUIDED_LOCAL_RECOVERY = true
    const val FEATURE_BEST_EVIDENCE_MEMORY = true
    const val FEATURE_DECISION_EVIDENCE_LEDGER = true
    const val FEATURE_GROUND_TRUTH_LEARNING = true
    const val FEATURE_AI_ENGINEER_UI = true
    const val FEATURE_AI_ENGINEER_VISUAL_EVIDENCE = true
    const val FEATURE_AI_GATEWAY_SIGNED_REQUESTS = true
    const val FEATURE_AI_GATEWAY_STRUCTURED_DIAGNOSTICS = true
    const val FEATURE_AI_GATEWAY_HEALTH_CHECK = true
    const val AI_ENGINEER_MAX_IMAGES = 3
    const val AI_ENGINEER_MAX_REPORT_CHARS = 48_000

    // Cloud identity remains non-authoritative. Confirmed local teaching may
    // enrich visual references but cannot manufacture quantity.
    const val CLOUD_IDENTITY_MODE = "SHADOW"
    const val SELF_LEARNING_MODE = "ACTIVE_CONFIRMED_ONLY"
    const val AI_ENGINEER_MODE = "DEV_CENTER_DIAGNOSTIC_ONLY"

    // Self-learning may add operator-confirmed visual references, but it may not
    // relax recognition thresholds or bypass physical/quantity safety.
    const val FEATURE_CONFIRMED_VISUAL_TEACHING = true
    const val FEATURE_NORMAL_VISUAL_ONLY_MASTER = true
    const val FEATURE_UPDATE_PROPOSAL_GATE = true

    // V8.8.1+ evidence-routing controls. These do not relax identity thresholds.
    const val FEATURE_NON_ROD_TO_NORMAL_RESCUE = true
    const val FEATURE_LIVE_ML_TALL_NORMAL_FALLBACK = true
    const val FEATURE_CATALOG_SNAPSHOT_EVIDENCE = true
    const val FEATURE_AMBIGUOUS_VISUAL_OCR = true
    const val FEATURE_REGULATORY_TEXT_FILTER = true
    const val FEATURE_WEAK_OCR_VISUAL_FALLBACK = true
    const val FEATURE_DIRECT_TEACH_CTA = true
    const val FEATURE_CONFIRMED_HYBRID_VISUAL = true

    // V8.8.2 safety foundations retained; thresholds remain unchanged.
    const val FEATURE_FINAL_SCAN_VIEWMODEL_SCOPE = true
    const val FEATURE_LOCKED_SCENE_CONTINUITY = true
    const val FEATURE_LIVE_OCR_CACHE = true
    const val FEATURE_ADAPTIVE_ROD_AXIS_WIDTH = true
    const val FEATURE_PHYSICAL_OBJECT_STATE_MACHINE = true
    const val FEATURE_TWO_STAGE_CANDIDATE_RETRIEVAL = true
    const val FEATURE_UNIFIED_RECOVERY_COORDINATOR = true
    const val FEATURE_GUIDED_EVIDENCE_ACQUISITION = true
    const val FEATURE_AI_IN_CRITICAL_SCAN_PATH = false

    // V8.8.3 scheduling and convergence features.
    const val FEATURE_EVENT_DRIVEN_IDENTITY = true
    const val FEATURE_OBJECT_SCOPED_RETRIEVAL = true
    const val FEATURE_CANDIDATE_MEMORY = true
    const val FEATURE_CANDIDATE_HYSTERESIS = true
    const val FEATURE_SINGLE_FLIGHT_OCR = true
    const val FEATURE_NEGATIVE_OCR_CACHE = true
    const val FEATURE_DISCRIMINATIVE_EVIDENCE = true
    const val FEATURE_HIGH_RES_NORMAL_AMBIGUITY = true
    const val FEATURE_ADAPTIVE_IDENTITY_ROI = true
    const val FEATURE_BEST_FRAME_SELECTION = true
    const val FEATURE_MULTI_OBJECT_TARGET_SELECTION = true
    const val FEATURE_IDENTITY_FREEZE_AFTER_CONFIRMATION = true
    const val FEATURE_LIVE_FINAL_DECISION_CONVERGENCE = true
    const val FEATURE_LIVE_CANDIDATE_FINAL_RECALL_SEED = true
    const val LIVE_LOOP_DELAY_MS = 180L
    const val LIVE_STABLE_REFRESH_MS = 500L
}
