package com.arspos.anglerriausyndicate

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Phase 4.3.2.30 V8.4.10 — persistent official update-channel identity.
 *
 * The package id and signing certificate are the identity of an Android update.
 * This helper records version transitions in app-private storage so every
 * diagnostic report can say whether the current APK is a fresh install,
 * in-place update, same-version relaunch, or rollback.
 */
object ArsUpdateChannel {
    private const val PREFS = "ars_official_update_channel"
    private const val KEY_LAST_CODE = "last_version_code"
    private const val KEY_LAST_NAME = "last_version_name"
    private const val KEY_PREV_CODE = "previous_version_code"
    private const val KEY_PREV_NAME = "previous_version_name"
    private const val KEY_LAST_TRANSITION = "last_install_transition"
    private const val KEY_LAST_TRANSITION_AT = "last_install_transition_at"

    data class Snapshot(
        val packageName: String,
        val versionName: String,
        val versionCode: Long,
        val previousVersionName: String?,
        val previousVersionCode: Long?,
        val lastTransition: String,
        val lastTransitionAt: Long,
        val firstInstallTime: Long,
        val lastUpdateTime: Long,
        val signerSha256: String,
        val signingChannel: String
    )

    fun observeLaunch(context: Context): Snapshot {
        val current = packageSnapshot(context)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val storedCode = if (prefs.contains(KEY_LAST_CODE)) prefs.getLong(KEY_LAST_CODE, -1L) else null
        val storedName = prefs.getString(KEY_LAST_NAME, null)

        if (storedCode == null) {
            val now = System.currentTimeMillis()
            prefs.edit()
                .putLong(KEY_LAST_CODE, current.versionCode)
                .putString(KEY_LAST_NAME, current.versionName)
                .putString(KEY_LAST_TRANSITION, "FRESH_INSTALL")
                .putLong(KEY_LAST_TRANSITION_AT, now)
                .apply()

            ArsFlightRecorder.event(
                type = "APP_INSTALL",
                message = "ARS POS official channel first launch",
                fields = mapOf(
                    "currentVersion" to current.versionName,
                    "currentVersionCode" to current.versionCode,
                    "package" to current.packageName,
                    "signingChannel" to current.signingChannel,
                    "signerSha256" to current.signerSha256,
                    "firstInstallTime" to current.firstInstallTime,
                    "lastUpdateTime" to current.lastUpdateTime
                )
            )
        } else if (storedCode != current.versionCode || storedName != current.versionName) {
            val transition = when {
                current.versionCode > storedCode -> "IN_PLACE_UPDATE"
                current.versionCode < storedCode -> "VERSION_ROLLBACK"
                else -> "VERSION_NAME_CHANGE"
            }
            val now = System.currentTimeMillis()

            prefs.edit()
                .putLong(KEY_PREV_CODE, storedCode)
                .putString(KEY_PREV_NAME, storedName)
                .putLong(KEY_LAST_CODE, current.versionCode)
                .putString(KEY_LAST_NAME, current.versionName)
                .putString(KEY_LAST_TRANSITION, transition)
                .putLong(KEY_LAST_TRANSITION_AT, now)
                .apply()

            ArsFlightRecorder.event(
                type = if (transition == "IN_PLACE_UPDATE") "APP_UPDATE" else "APP_VERSION_TRANSITION",
                message = transition,
                fields = mapOf(
                    "fromVersion" to (storedName ?: "unknown"),
                    "fromVersionCode" to storedCode,
                    "toVersion" to current.versionName,
                    "toVersionCode" to current.versionCode,
                    "databasePreserved" to (transition == "IN_PLACE_UPDATE"),
                    "package" to current.packageName,
                    "signingChannel" to current.signingChannel,
                    "signerSha256" to current.signerSha256,
                    "firstInstallTime" to current.firstInstallTime,
                    "lastUpdateTime" to current.lastUpdateTime
                )
            )
        }

        return snapshot(context)
    }

    fun snapshot(context: Context): Snapshot {
        val current = packageSnapshot(context)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        val previousCode = if (prefs.contains(KEY_PREV_CODE)) prefs.getLong(KEY_PREV_CODE, -1L) else null
        val previousName = prefs.getString(KEY_PREV_NAME, null)
        val transition = prefs.getString(KEY_LAST_TRANSITION, "CURRENT") ?: "CURRENT"
        val transitionAt = prefs.getLong(KEY_LAST_TRANSITION_AT, 0L)

        return current.copy(
            previousVersionName = previousName,
            previousVersionCode = previousCode,
            lastTransition = transition,
            lastTransitionAt = transitionAt
        )
    }

    fun formatTime(epochMs: Long): String {
        if (epochMs <= 0L) return "-"
        return SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US).format(Date(epochMs))
    }

    @Suppress("DEPRECATION")
    private fun packageSnapshot(context: Context): Snapshot {
        val pm = context.packageManager
        val flags = if (Build.VERSION.SDK_INT >= 28) {
            PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            PackageManager.GET_SIGNATURES
        }
        val info: PackageInfo = pm.getPackageInfo(context.packageName, flags)
        val code = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
        val version = info.versionName ?: "unknown"
        val debuggable = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0

        return Snapshot(
            packageName = context.packageName,
            versionName = version,
            versionCode = code,
            previousVersionName = null,
            previousVersionCode = null,
            lastTransition = "CURRENT",
            lastTransitionAt = 0L,
            firstInstallTime = info.firstInstallTime,
            lastUpdateTime = info.lastUpdateTime,
            signerSha256 = signingSha256(info),
            signingChannel = if (debuggable) "DEVELOPMENT/DEBUG" else "ARS POS OFFICIAL RELEASE"
        )
    }

    @Suppress("DEPRECATION")
    private fun signingSha256(info: PackageInfo): String {
        val certBytes = if (Build.VERSION.SDK_INT >= 28) {
            val signingInfo = info.signingInfo ?: return "UNAVAILABLE"
            val signatures = if (signingInfo.hasMultipleSigners()) {
                signingInfo.apkContentsSigners
            } else {
                signingInfo.signingCertificateHistory
            }
            signatures.firstOrNull()?.toByteArray()
        } else {
            info.signatures?.firstOrNull()?.toByteArray()
        } ?: return "UNAVAILABLE"

        val digest = MessageDigest.getInstance("SHA-256").digest(certBytes)
        return digest.joinToString(":") { byte -> "%02X".format(byte) }
    }
}
