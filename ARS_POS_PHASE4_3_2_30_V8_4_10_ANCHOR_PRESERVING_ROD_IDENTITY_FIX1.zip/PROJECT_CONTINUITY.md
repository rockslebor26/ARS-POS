# ARS POS PROJECT CONTINUITY

Baseline resmi saat ini: **Phase 4.3.2.30 / V8.4.10 / 1.4.5 (145)**.

Update chain resmi:
- V8.4.6 Official: 1.4.1 (141)
- V8.4.7: 1.4.2 (142) — IN_PLACE_UPDATE terbukti berhasil
- V8.4.8: 1.4.3 (143) — multi-object physical-instance separation + scanner hardening
- V8.4.9: 1.4.4 (144) — rod anchor identity + cross-lane scene gate + cached long matcher
- V8.4.10: 1.4.5 (145) — anchor-preserving rod shortlist + deterministic identity evidence

Aturan permanen:
- applicationId tetap `com.arspos.anglerriausyndicate`
- ARS POS OFFICIAL RELEASE signer harus tetap identik
- versionCode selalu meningkat
- jangan uninstall official app ketika menguji update berikutnya
- UNKNOWN lebih aman daripada salah SKU
- jangan menurunkan recognition threshold hanya agar produk terlihat dikenali
- AMBIGUOUS_CONTAINER/bridge dan FULL_FRAME_RESCUE tidak boleh membuat quantity baru
- same SKU + physical instance berbeda boleh menjadi quantity > 1

Fokus validasi V8.4.10:
1. 2 LIGHTS tetap dua NORMAL instances tanpa phantom LONG quantity
2. NORMAL-owned region tidak boleh direbut LONG analyzer tanpa bukti struktur joran yang cukup
3. background linear ditolak sebagai candidate joran
4. 1 rod -> Qty 1
5. 2 rod sama -> Qty 2 bila physical hints benar-benar berbeda
6. 2 rod SKU berbeda -> identity memakai rod anchor + visual safety; ambiguous tetap UNKNOWN
7. rod + LIGHTS -> typed lanes tidak saling merge/claim
8. full-frame rescue quantityEligible=false
9. decision rule, margin, rod anchor score/margin tercatat
10. native heap delta/PSS/temp crop telemetry tercatat
11. scanner latency membaik melalui cached long matcher tanpa threshold relaxation
12. update 1.4.4 (144) -> 1.4.5 (145) harus IN_PLACE_UPDATE dengan package/signer sama
