# ARS POS — ANGLER RIAU SYNDICATE

Current official development baseline:

- Phase **4.3.2.30**
- Engine **V8.4.10**
- Version **1.4.5**
- versionCode **145**
- Package **com.arspos.anglerriausyndicate**
- Signing channel **ARS POS OFFICIAL RELEASE**

## V8.4.10 focus
Rod Anchor Identity + Cross-Lane Scene Gate + Cached Long Matcher.

Main protections/improvements:
- NORMAL-owned region cross-lane arbitration;
- rod-structure background rejection before LONG recognition/quantity;
- rod anchor identity using existing long-master capture angles;
- deterministic decision rule + margin/anchor telemetry;
- physical-instance/anti-bridge/quantity safety retained from V8.4.8;
- full-frame rescue remains evidence-only;
- cached/batched long matcher and per-product shortlist for lower latency;
- Java/native/PSS/crop telemetry;
- persisted official update transition remains reportable after diagnostic-log clear.

Install V8.4.10 directly over V8.4.9 Official. Do **not** uninstall the official app.

See `PHASE4_3_2_30_V8_4_10_ANCHOR_PRESERVING_ROD_IDENTITY.md`.
