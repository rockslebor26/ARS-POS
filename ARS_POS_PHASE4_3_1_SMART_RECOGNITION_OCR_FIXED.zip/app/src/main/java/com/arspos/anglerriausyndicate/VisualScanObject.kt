package com.arspos.anglerriausyndicate

import android.graphics.Rect

/** Hasil deteksi satu objek dalam satu foto scan. */
data class VisualScanObject(
    val index: Int,
    val bounds: Rect,
    val match: VisualProductMatch?,
    val bestScore: Int = match?.score ?: 0
)
