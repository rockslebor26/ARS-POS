# ARS POS — Phase 4.3.2.5 Full: ARS Product Master Studio

Version: 1.1.1 / versionCode 111

## Tujuan
Membuat master visual produk menggunakan video saat input/master barang. Video bersifat sementara; sistem memilih frame terbaik dan menyimpannya sebagai banyak referensi foto offline.

## Alur
1. Buka PRODUK → MASTER.
2. Ikuti enam sudut: Depan, Kanan, Belakang, Kiri, Atas, Bawah.
3. Rekam sekitar 2–4 detik pada setiap sudut.
4. Sistem otomatis mengambil beberapa frame terbaik berdasarkan kualitas/ketajaman dan perbedaan visual.
5. Frame disimpan ke `product_photos` dengan `captureAngle`.
6. OCR dan barcode dicoba dari frame terbaik.
7. Kelengkapan master dihitung sebagai kesiapan enrollment, bukan confidence AI.

## Kelengkapan
- 6 sudut: 60%
- frame master berkualitas: sampai 10%
- OCR/data identitas tersedia: 15%
- barcode tersedia: 15%

## Database
Room dinaikkan dari version 4 ke 5. `ProductPhotoEntity` sekarang memiliki `captureAngle`.

## Scan Belanja
Phase ini tidak mengubah prinsip Smart Shopping Scan: kamera pelanggan/kasir mengambil FOTO tunggal yang dapat berisi banyak objek. Master Studio menyiapkan referensi visual yang akan dipakai oleh fase multi-object shopping scan berikutnya.

## Catatan teknis
Video tidak disimpan sebagai dataset permanen. File video sementara berada di cache dan dihapus setelah frame terbaik diekstrak. Referensi visual disimpan offline di `filesDir/product_photos/master/<productId>/<angle>`.
