package com.arspos.anglerriausyndicate.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities=[
        ProductEntity::class, SaleEntity::class, SaleItemEntity::class,
        StockMovementEntity::class, UserEntity::class, CustomerEntity::class,
        CashTransactionEntity::class, ReturnEntity::class, ReturnItemEntity::class,
        AuditLogEntity::class, StockReceiptEntity::class, StockReceiptItemEntity::class,
        SettingEntity::class, ProductPhotoEntity::class
    ],
    version=5, exportSchema=false
)
abstract class ArsDatabase:RoomDatabase(){
    abstract fun dao():ArsDao
    companion object{
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS product_photos (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, productId INTEGER NOT NULL, localPath TEXT NOT NULL, isPrimary INTEGER NOT NULL DEFAULT 0, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_product_photos_productId ON product_photos(productId)")
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE product_photos ADD COLUMN captureAngle TEXT NOT NULL DEFAULT 'UNKNOWN'")
            }
        }
        @Volatile private var instance:ArsDatabase?=null
        fun get(context:Context):ArsDatabase =
            instance ?: synchronized(this){
                instance ?: Room.databaseBuilder(
                    context.applicationContext,ArsDatabase::class.java,"ars_pos.db"
                ).addMigrations(MIGRATION_3_4, MIGRATION_4_5).build().also{instance=it}
            }
    }
}
