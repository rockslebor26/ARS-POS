package com.arspos.anglerriausyndicate

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arspos.anglerriausyndicate.data.*
import com.arspos.anglerriausyndicate.data.db.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

class PosViewModel(app:Application):AndroidViewModel(app){
    private val repo=ProductionRepository(ArsDatabase.get(app))
    val query=MutableStateFlow("")
    val products=query.flatMapLatest(repo::search).stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    private val _cart=MutableStateFlow<List<CartLine>>(emptyList())
    val cart=_cart.asStateFlow()
    val subtotal=_cart.map{it.sumOf(CartLine::subtotal)}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0L)
    private val start=Calendar.getInstance().apply{
        set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)
    }.timeInMillis
    val revenue=repo.revenue(start).stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0L)
    val transactions=repo.transactionCount(start).stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0)
    val cashBalance=repo.cashBalance().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0L)
    val sales=repo.sales().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val customers=repo.customers().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    init{viewModelScope.launch{repo.seed()}}
    fun search(s:String){query.value=s}
    fun add(p:ProductEntity){
        if(p.stock<=0) return
        val x=_cart.value.find{it.product.id==p.id}
        if(x==null){
            _cart.value=_cart.value+CartLine(p,1)
        }else if(x.quantity < p.stock){
            _cart.value=_cart.value.map{if(it.product.id==p.id)it.copy(quantity=it.quantity+1)else it}
        }
    }
    fun qty(id:Long,d:Int){
        _cart.value=_cart.value.mapNotNull{line ->
            if(line.product.id!=id) line
            else {
                val next=(line.quantity+d).coerceIn(0,line.product.stock)
                line.copy(quantity=next).takeIf{it.quantity>0}
            }
        }
    }
    fun remove(id:Long){
        _cart.value=_cart.value.filterNot{it.product.id==id}
    }
    fun clear(){_cart.value=emptyList()}
    suspend fun login(u:String,p:String)=repo.login(u,p)
    suspend fun checkout(paid:Long,method:String)=runCatching{repo.checkout(_cart.value,paid,method).also{clear()}}
    suspend fun addProduct(n:String,s:String,b:String?,c:String,cost:Long,price:Long,stock:Int,brand:String?=null,variant:String?=null)=runCatching{repo.addProduct(n,s,b,c,cost,price,stock,brand,variant)}
    fun productPhotos(productId:Long)=repo.productPhotos(productId)
    suspend fun findVisualMatches(bitmap:android.graphics.Bitmap)=repo.visualProductMatches(bitmap)
    suspend fun smartVisualScan(bitmap:android.graphics.Bitmap)=repo.smartVisualScan(bitmap)
    suspend fun addProductPhoto(productId:Long,path:String,primary:Boolean=false,captureAngle:String="UNKNOWN")=runCatching{repo.addProductPhoto(productId,path,primary,captureAngle)}
    suspend fun clearProductPhotoAngle(productId:Long,angle:String)=runCatching{repo.clearProductPhotoAngle(productId,angle)}
    suspend fun setPrimaryProductPhoto(productId:Long,photoId:Long)=runCatching{repo.setPrimaryProductPhoto(productId,photoId)}
    suspend fun deleteProductPhoto(photo:ProductPhotoEntity)=runCatching{repo.deleteProductPhoto(photo)}
    suspend fun stockIn(id:Long,qty:Int,cost:Long,supplier:String?,invoice:String?)=runCatching{repo.stockIn(id,qty,cost,supplier,invoice)}
    suspend fun cashOut(amount:Long,cat:String,desc:String?)=runCatching{repo.cashOut(amount,cat,desc)}
    suspend fun saleItems(id:Long)=repo.saleItems(id)
    suspend fun processReturn(id:Long,reason:String)=runCatching{repo.processReturn(id,reason)}
    suspend fun profitSummary():ProfitSummary{
        val start=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis
        return repo.profitSummary(start)
    }
}
