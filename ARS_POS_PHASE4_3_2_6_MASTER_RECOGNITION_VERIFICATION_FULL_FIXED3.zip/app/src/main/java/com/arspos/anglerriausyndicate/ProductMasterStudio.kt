package com.arspos.anglerriausyndicate

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import com.arspos.anglerriausyndicate.data.MasterVerificationResult
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executor
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val StudioGold = Color(0xFFE1BC68)
private val StudioPanel = Color(0xFF151515)
private val StudioBlack = Color(0xFF080808)
private val StudioMuted = Color(0xFF9A9A9A)

private data class MasterAngle(val key: String, val label: String)

private val MASTER_ANGLES = listOf(
    MasterAngle("FRONT", "Depan"),
    MasterAngle("RIGHT", "Kanan"),
    MasterAngle("BACK", "Belakang"),
    MasterAngle("LEFT", "Kiri"),
    MasterAngle("TOP", "Atas"),
    MasterAngle("BOTTOM", "Bawah")
)

private class MasterCameraController(private val context: Context) {
    var videoCapture: VideoCapture<Recorder>? = null
        private set
    private var recording: Recording? = null
    private var cameraProvider: ProcessCameraProvider? = null

    fun bind(previewView: PreviewView, owner: LifecycleOwner) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            runCatching {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(
                            Quality.HD,
                            FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
                        )
                    )
                    .build()
                val capture = VideoCapture.withOutput(recorder)
                videoCapture = capture
                provider.unbindAll()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun start(file: File, executor: Executor, onEvent: (VideoRecordEvent) -> Unit): Boolean {
        val capture = videoCapture ?: return false
        if (recording != null) return false
        val output = FileOutputOptions.Builder(file).build()
        return runCatching {
            recording = capture.output.prepareRecording(context, output)
                .start(executor) { event -> onEvent(event) }
            true
        }.getOrDefault(false)
    }

    fun stop() {
        recording?.stop()
        recording = null
    }

    fun release() {
        recording?.stop()
        recording = null
        cameraProvider?.unbindAll()
        videoCapture = null
    }
}

private data class FrameCandidate(val bitmap: Bitmap, val score: Double, val timeUs: Long)

private fun frameQuality(source: Bitmap): Double {
    val w = min(160, source.width)
    val h = max(1, (source.height.toFloat() * w / source.width).toInt())
    val small = Bitmap.createScaledBitmap(source, w, h, true)
    var sum = 0.0
    var sumSq = 0.0
    var count = 0
    var prev = 0
    for (y in 1 until h step 2) {
        for (x in 1 until w step 2) {
            val c = small.getPixel(x, y)
            val gray = (0.299 * android.graphics.Color.red(c) + 0.587 * android.graphics.Color.green(c) + 0.114 * android.graphics.Color.blue(c)).toInt()
            val left = small.getPixel(x - 1, y)
            val up = small.getPixel(x, y - 1)
            val gx = abs(gray - ((0.299 * android.graphics.Color.red(left) + 0.587 * android.graphics.Color.green(left) + 0.114 * android.graphics.Color.blue(left)).toInt()))
            val gy = abs(gray - ((0.299 * android.graphics.Color.red(up) + 0.587 * android.graphics.Color.green(up) + 0.114 * android.graphics.Color.blue(up)).toInt()))
            val edge = gx + gy
            sum += edge
            sumSq += edge * edge
            count++
            prev = gray
        }
    }
    val mean = if (count == 0) 0.0 else sum / count
    val variance = if (count == 0) 0.0 else max(0.0, sumSq / count - mean * mean)
    if (small !== source) small.recycle()
    return variance + mean * 0.4 + prev * 0.0
}

private fun extractBestFrames(video: File, maxFrames: Int = 3): List<Bitmap> {
    val retriever = MediaMetadataRetriever()
    val candidates = mutableListOf<FrameCandidate>()
    return try {
        retriever.setDataSource(video.absolutePath)
        val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        if (durationMs <= 0L) return emptyList()
        val samples = 7
        for (i in 0 until samples) {
            val timeUs = ((durationMs * 1000L) * (i + 1) / (samples + 1)).coerceAtLeast(0L)
            val bitmap = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST) ?: continue
            candidates += FrameCandidate(bitmap, frameQuality(bitmap), timeUs)
        }
        val selected = mutableListOf<Bitmap>()
        candidates.sortedByDescending { it.score }.forEach { candidate ->
            if (selected.size >= maxFrames) return@forEach
            val distinct = selected.none { other ->
                val w = min(24, min(candidate.bitmap.width, other.width))
                val h = min(24, min(candidate.bitmap.height, other.height))
                if (w <= 0 || h <= 0) false else {
                    val a = Bitmap.createScaledBitmap(candidate.bitmap, w, h, true)
                    val b = Bitmap.createScaledBitmap(other, w, h, true)
                    var diff = 0.0
                    for (y in 0 until h step 3) for (x in 0 until w step 3) {
                        val ca = a.getPixel(x, y)
                        val cb = b.getPixel(x, y)
                        diff += abs(android.graphics.Color.red(ca) - android.graphics.Color.red(cb)) +
                                abs(android.graphics.Color.green(ca) - android.graphics.Color.green(cb)) +
                                abs(android.graphics.Color.blue(ca) - android.graphics.Color.blue(cb))
                    }
                    a.recycle(); b.recycle()
                    diff / ((w * h + 1) * 3) < 0.035
                }
            }
            if (distinct) selected += candidate.bitmap
        }
        candidates.map { it.bitmap }.filter { it !in selected }.forEach { it.recycle() }
        selected
    } finally {
        retriever.release()
    }
}

private fun saveMasterFrame(context: Context, productId: Long, angle: String, bitmap: Bitmap, index: Int): String {
    val dir = File(context.filesDir, "product_photos/master/$productId/$angle").apply { mkdirs() }
    val file = File(dir, "${angle}_${System.currentTimeMillis()}_$index.jpg")
    FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    return file.absolutePath
}


private fun decodeStudioCameraBitmap(file: File, maxDimension: Int = 1600): Bitmap? {
    if (!file.exists() || file.length() <= 0L) return null
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) sample *= 2
    return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.ARGB_8888
    })
}

@Composable
fun ProductMasterStudio(
    vm: PosViewModel,
    product: com.arspos.anglerriausyndicate.data.db.ProductEntity,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val photos by vm.productPhotos(product.id).collectAsState(initial = emptyList())
    var angleIndex by remember { mutableIntStateOf(0) }
    var recording by remember { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Arahkan produk sesuai panduan lalu rekam 2–4 detik.") }
    var detectedText by remember { mutableStateOf("") }
    var detectedBarcode by remember { mutableStateOf("") }
    var seconds by remember { mutableIntStateOf(0) }
    val controller = remember { MasterCameraController(context) }
    var videoFile by remember { mutableStateOf<File?>(null) }
    var tickJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    var verification by remember { mutableStateOf<MasterVerificationResult?>(null) }
    var verifiedPreviously by remember { mutableStateOf(false) }
    LaunchedEffect(product.id) {
        verifiedPreviously = runCatching { vm.isMasterVerified(product.id) }.getOrDefault(false)
    }
    var verifying by remember { mutableStateOf(false) }
    var pendingVerificationFile by remember { mutableStateOf<File?>(null) }
    val verifyLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.TakePicture()
    ) { success ->
        val file = pendingVerificationFile
        pendingVerificationFile = null
        if (success && file != null) {
            val bitmap = runCatching { decodeStudioCameraBitmap(file) }.getOrNull()
            file.delete()
            if (bitmap != null) {
                verifying = true
                verification = null
                scope.launch {
                    verification = runCatching {
                        withContext(Dispatchers.Default) { vm.verifyProductMaster(product.id, bitmap) }
                    }.getOrElse {
                        MasterVerificationResult(
                            productId = product.id, productName = product.name, sku = product.sku,
                            barcode = product.barcode.orEmpty(), referenceCount = photos.size,
                            visualScore = 0, textScore = 0, finalScore = 0, ocrText = "",
                            detectedBarcode = "", accepted = false,
                            reason = "Uji master gagal: ${it.message ?: "kesalahan tidak diketahui"}"
                        )
                    }
                    if (verification?.accepted == true) verifiedPreviously = true
                    bitmap.recycle()
                    verifying = false
                }
            } else {
                message = "Foto uji tidak dapat dibaca. Silakan coba lagi."
            }
        } else {
            file?.delete()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            tickJob?.cancel()
            controller.release()
        }
    }

    val currentAngle = MASTER_ANGLES[angleIndex]
    val completedAngles = MASTER_ANGLES.count { a -> photos.any { it.captureAngle == a.key } }
    val sharpFrames = photos.count { it.captureAngle in MASTER_ANGLES.map(MasterAngle::key) }
    val ocrReady = detectedText.isNotBlank()
    val barcodeReady = detectedBarcode.isNotBlank() || !product.barcode.isNullOrBlank()
    val completeness = (
        completedAngles * 10 +
        min(10, (sharpFrames * 10) / 6) +
        (if (ocrReady) 15 else 0) +
        (if (barcodeReady) 15 else 0)
    ).coerceIn(0, 100)

    AlertDialog(
        onDismissRequest = { if (!recording && !processing) onClose() },
        title = {
            Column {
                Text("ARS PRODUCT MASTER STUDIO", fontWeight = FontWeight.Bold)
                Text(product.name, color = StudioGold, fontSize = 12.sp)
            }
        },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 650.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(colors = CardDefaults.cardColors(StudioBlack), modifier = Modifier.fillMaxWidth()) {
                    AndroidView(
                        factory = { ctx ->
                            PreviewView(ctx).apply {
                                scaleType = PreviewView.ScaleType.FILL_CENTER
                                controller.bind(this, owner)
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(230.dp)
                    )
                }

                Text("KELENGKAPAN MASTER  $completeness%", color = StudioGold, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { completeness / 100f }, modifier = Modifier.fillMaxWidth())
                Text("100% = master visual lengkap, bukan tingkat kepastian AI.", color = StudioMuted, fontSize = 10.sp)

                if (verifiedPreviously) {
                    Text("✓ MASTER SUDAH TERVERIFIKASI", color = StudioGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }

                if (photos.size >= 3) {
                    OutlinedButton(
                        enabled = !recording && !processing && !verifying,
                        onClick = {
                            runCatching {
                                val dir = File(context.cacheDir, "camera_capture").apply { mkdirs() }
                                val file = File.createTempFile("master_verify_", ".jpg", dir)
                                pendingVerificationFile = file
                                val uri = androidx.core.content.FileProvider.getUriForFile(
                                    context, "${context.packageName}.fileprovider", file
                                )
                                verifyLauncher.launch(uri)
                            }.onFailure {
                                pendingVerificationFile?.delete()
                                pendingVerificationFile = null
                                message = "Kamera uji tidak dapat dibuka: ${it.message ?: "perangkat tidak mendukung"}"
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (verifying) "MEMVERIFIKASI MASTER..." else "🔎 UJI PENGENALAN MASTER")
                    }
                }

                verification?.let { result ->
                    Card(
                        colors = CardDefaults.cardColors(if (result.accepted) StudioPanel else Color(0xFF241818)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                if (result.accepted) "✓ MASTER TERVERIFIKASI" else "✕ MASTER BELUM TERVERIFIKASI",
                                color = if (result.accepted) StudioGold else Color(0xFFE57373),
                                fontWeight = FontWeight.Bold
                            )
                            Text("Referensi: ${result.referenceCount} frame", color = Color.White, fontSize = 11.sp)
                            Text("Visual ${result.visualScore}% • OCR ${result.textScore}% • Final ${result.finalScore}%", color = StudioGold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            if (result.barcode.isNotBlank()) Text("Barcode master: ${result.barcode}", color = Color.White, fontSize = 10.sp)
                            if (result.detectedBarcode.isNotBlank()) Text("Barcode foto uji: ${result.detectedBarcode}", color = Color.White, fontSize = 10.sp)
                            if (result.ocrText.isNotBlank()) Text("OCR: ${result.ocrText.replace("\n", " • ").take(160)}", color = StudioMuted, fontSize = 9.sp)
                            Text(result.reason, color = if (result.accepted) StudioMuted else Color.White.copy(alpha = 0.78f), fontSize = 10.sp)
                            if (result.accepted) {
                                Text("✓ Produk ini siap menjadi referensi untuk Smart Shopping Scan.", color = StudioGold, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                        }
                    }
                }

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(MASTER_ANGLES) { a ->
                        val done = photos.any { it.captureAngle == a.key }
                        AssistChip(
                            onClick = { angleIndex = MASTER_ANGLES.indexOf(a) },
                            label = { Text(if (done) "✓ ${a.label}" else "○ ${a.label}") },
                            colors = AssistChipDefaults.assistChipColors(
                                labelColor = if (done) StudioGold else Color.White
                            )
                        )
                    }
                }

                Card(colors = CardDefaults.cardColors(StudioPanel), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("SEKARANG: ${currentAngle.label.uppercase()}", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(
                            when (currentAngle.key) {
                                "FRONT" -> "Tampilkan bagian depan produk."
                                "RIGHT" -> "Putar ke sisi kanan."
                                "BACK" -> "Putar ke bagian belakang."
                                "LEFT" -> "Putar ke sisi kiri."
                                "TOP" -> "Arahkan kamera ke bagian atas."
                                else -> "Arahkan kamera ke bagian bawah dengan aman."
                            },
                            color = StudioMuted,
                            fontSize = 12.sp
                        )
                        Text("Putar produk perlahan • jangan terlalu dekat • pastikan tulisan terlihat jelas.", color = StudioMuted, fontSize = 11.sp)
                    }
                }

                if (recording) {
                    Text("● MEREKAM ${seconds} detik", color = Color.White, fontWeight = FontWeight.Bold)
                }
                if (processing) {
                    Text("MEMPROSES VIDEO → MEMILIH FRAME TERBAIK...", color = StudioGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                if (message.isNotBlank()) Text(message, color = StudioMuted, fontSize = 11.sp)
                if (detectedText.isNotBlank()) Text("OCR: $detectedText", color = Color.White, fontSize = 11.sp)
                if (detectedBarcode.isNotBlank()) Text("Barcode: $detectedBarcode", color = StudioGold, fontSize = 11.sp)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        enabled = !recording && !processing,
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                message = "Izin kamera diperlukan. Izinkan kamera lalu buka Master Studio lagi."
                                return@Button
                            }
                            verifiedPreviously = false
                            verification = null
                            scope.launch { vm.invalidateMasterVerification(product.id) }
                            val file = File(context.cacheDir, "master_video_${product.id}_${currentAngle.key}_${System.currentTimeMillis()}.mp4")
                            videoFile = file
                            seconds = 0
                            val started = controller.start(file, ContextCompat.getMainExecutor(context)) { event ->
                                if (event is VideoRecordEvent.Finalize) {
                                    scope.launch {
                                        processing = true
                                        recording = false
                                        tickJob?.cancel()
                                        if (event.hasError()) {
                                            message = "Rekaman gagal: ${event.error}"
                                            file.delete()
                                            processing = false
                                            return@launch
                                        }
                                        val angle = currentAngle
                                        val frames = withContext(Dispatchers.Default) { extractBestFrames(file, 3) }
                                        if (frames.isEmpty()) {
                                            message = "Frame tidak berhasil diambil. Ulangi rekaman dengan cahaya lebih baik."
                                            file.delete()
                                            processing = false
                                            return@launch
                                        }
                                        photos.filter { it.captureAngle == angle.key }.forEach { old ->
                                            runCatching { File(old.localPath).delete() }
                                        }
                                        vm.clearProductPhotoAngle(product.id, angle.key)
                                        var saved = 0
                                        for ((i, frame) in frames.withIndex()) {
                                            val path = saveMasterFrame(context, product.id, angle.key, frame, i + 1)
                                            vm.addProductPhoto(product.id, path, photos.isEmpty() && saved == 0, angle.key)
                                            runCatching {
                                                val draft = withContext(Dispatchers.Default) { SmartProductInput.analyze(frame) }
                                                if (draft.rawText.isNotBlank()) detectedText = draft.rawText.take(220)
                                                if (draft.barcode.isNotBlank()) detectedBarcode = draft.barcode
                                            }
                                            frame.recycle()
                                            saved++
                                        }
                                        file.delete()
                                        message = "$saved frame terbaik disimpan untuk ${angle.label}."
                                        processing = false
                                        if (angleIndex < MASTER_ANGLES.lastIndex) angleIndex++
                                    }
                                }
                            }
                            if (started) {
                                recording = true
                                tickJob = scope.launch {
                                    while (recording) {
                                        kotlinx.coroutines.delay(1000)
                                        seconds++
                                        if (seconds >= 4) controller.stop()
                                    }
                                }
                            } else message = "Kamera belum siap. Tunggu preview muncul lalu coba lagi."
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = StudioGold)
                    ) { Text(if (recording) "MEREKAM..." else "REKAM ${currentAngle.label.uppercase()}", color = Color.Black) }
                    OutlinedButton(
                        enabled = recording,
                        onClick = { controller.stop() },
                        modifier = Modifier.weight(0.55f)
                    ) { Text("STOP") }
                }

                if (photos.isNotEmpty()) {
                    Text("REFERENSI MASTER TERSIMPAN: ${photos.size} FRAME", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    if (completedAngles == MASTER_ANGLES.size) {
                        Text("✓ MASTER 6 SISI LENGKAP", color = StudioGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Master siap menjadi referensi visual offline untuk Smart Shopping Scan.", color = StudioMuted, fontSize = 11.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !recording && !processing, onClick = onClose) { Text("SELESAI") }
        },
        dismissButton = {
            TextButton(enabled = !recording && !processing, onClick = {
                angleIndex = 0
                message = "Mulai lagi dari sisi depan."
            }) { Text("ULANG DARI DEPAN") }
        }
    )
}
